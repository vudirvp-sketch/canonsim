# WORLD TRACK NEXT v4.5 — SOURCE CROSSWALK / NO-LOSS AUDIT

This file is an external audit artifact for the derived navigation bundle. It is **not** a repository owner document.

## 1. Original operating thesis

**Retained:** causal state first, narrative/read-side second; “prove one living region before scaling”; quality = diversity of honest human histories, not map size.

**Product-model clarification:** the simulator is the world/history generator; the LLM is a language interface and interpreter. World Track may strengthen the causal substrate but must not become an LLM plot authority or narrative-causality repair layer.
**Location:** `WORLD_TRACK_NEXT.md` §§1, 23; owner sources remain `WORLD_WORKPLAN.md`, `WORLD_AUTHORING.md`.

## 2. Governance / owner boundaries

**Retained:** runtime truth vs authored-setting truth vs verification/research routing; pack-data preference; no second source of truth; explicit proof-status separation.
**Correction:** the v4.1 bundle itself is explicitly derived and non-authoritative. This fixes the only structural wording problem in v4.

## 3. Foundation state

**Retained:** post-collapse connected civilization → divergence; CONNECTIVITY↔RESILIENCE; CONTINUITY↔IDENTITY; negative space; Resonance/life/personhood/peoples/culture ownership.
**Owner:** `WORLD_KERNEL.md`, `RESONANCE.md`, `LIFE_PERSONHOOD.md`, `PEOPLES.md`, `CULTURES_CIVILIZATION.md`.

## 4. Sarrow anchor / W3 / W4 / W5

**Retained:** Sarrow as strongest witness; eight-loop causal mesh; four W4 meso units; W5 biography/humor/heartbreak status and open discovery/arc questions.
**Location:** `01_CURRENT_EVIDENCE.md` + `WORLD_TRACK_NEXT.md` §3A.

## 5. P1 composition / carrier-surface / market legs

**Retained:** D-237, D-238, D-239, D-240 measured evidence and limits.
**Correction:** D-238 J-3 is described as a **structurally dead proposed path / rejected embodiment target**, not as a “real gap”.

## 6. WTN GAP-01..13

**Retained:** expressive range, agency, social practice, narrativity, arc assembly, discovery-path residues, economy breadth, historical residue, epistemic interpretation, second-region proof, Ancient Network gate, Resonance demand-gate, long-horizon design memory.
**Compression:** these are expressed as current priority gates rather than a duplicated 13-row gap catalogue; owner documents remain the detailed owners.

## 7. Architectural additions

**Retained:** agency reconstruction, social practice, narrativity read model, story opportunity, arc assembly, attractor cards, cross-regime transfer, multi-cycle institutions, narrative polysemy.
**New v4 proposals:** liveness, admissibility/contact, causal passport, institutional reproduction, stateful cadence, heterogeneous institutional agency.

## 7A. Frontier mechanisms added in v4.3

These are **synthesis proposals**, not owner decisions:

1. **Moving-meso / world ignition:** a recurring caravan/crew/convoy assembly
   transfers people, material stock, knowledge, and claims/obligations with
   partially decoupled timing; perturb one route edge and inspect downstream
   divergence.
2. **Capacity/fracture:** route existence is insufficient; realized delay should
   produce an identifiable downstream fracture (queue, spillover, abandonment,
   scarcity, price/obligation change).
3. **Pool provenance:** authored pools need a source/admission path not only for
   rare presence but also for meaningful absence.
4. **Expectation feedback:** mismatch can drive evidence acquisition and update
   future behaviour; this is not a generic belief graph.
5. **Maintenance ecology:** recurring infrastructure can expose wear → repair
   decision → labour/resource cost → service restoration → next-cycle change.
   First consumer should be one existing route/market/water leg; never open a
   global maintenance subsystem by analogy.

All five must pass the existing material-verdict and runtime-promotion gates.

### 7B. Caravan v3 selective absorption

The full source is preserved in `07_CARAVAN_MOBILITY_DOSSIER.md`. Only discriminating additions are promoted into the navigation bundle:

| Residue | Bundle owner | Use | Runtime status |
|---|---|---|---|
| functional corridor / dependency cut | `06` §2A + `03` §11 | separate topology from functional viability | diagnostic proposal |
| route-memory ablation | `03` §10 | distinguish causal residue from chronology | test procedure |
| carrier vs institution continuity | `03` §6 | distinguish person-dependence from institutional survival | test procedure |
| synchronization latency | `06` §2B + `03` §9/17 | test stale reports and delayed transfer | diagnostic proposal |
| channel asymmetry | `03` §17 | observe BODY/CARGO/WITNESS/CLAIM independently | test vocabulary |
| return asymmetry | `03` §11 | do not infer symmetric continuity | test case |
| travel price vs institutional cost | `03` §11 | prevent universal mobility-cost scalar | anti-pattern |
| negative-result interpretation | `03` §17 | classify non-effects without forcing a mechanism | test interpretation |

### 7C. Claim/disposition status axes

Caravan v3 uses a more granular claim-type vocabulary than the bundle's repository disposition vocabulary. They are orthogonal, not synonyms. Preserve only when a source record requires it; do not invent a one-to-one mapping.

### 7D. Not promoted from caravan v3

No dedicated `Caravan`, `RouteInstitution`, `RouteHistory`, `MobilityTier`, global isolation/compatibility/provenance graph, route-reputation scalar, or caravan civilizational regime is promoted by this intake. Their promotion remains subject to the existing runtime/material-verdict gates.

## 8. Dormant regimes

**Retained:** riverine/central, mountain/industrial, maritime/pirate, deepwater, necropolis, sky, closed-tech, refuge, ruin, cosmic frontier.
**Correction:** v4.1 adds source-owner / contradiction routing discipline and explicitly separates regime, lineage, institution, and place archetype.

## 9. Research-method memory

**Retained:** cross-domain transplantation, falsification, experiment contracts, realized-intervention gate, minimal pairs, held-out transfer, synthesis-over-selection, narrative/emergent-agent/social-practice/storylet concepts.
**Routing:** these remain research/authoring methods; they do not become runtime primitives or a second architecture.

## 10. Intake routing

`caravan-mobility-consolidated.v3` → **ABSORBED + PRESERVED SOURCE**; no silent loss. Full text is retained in `07_CARAVAN_MOBILITY_DOSSIER.md`; only the discriminating residues listed in §7B are inserted into active probes/frontier navigation.


The previous v4.1 routing list was **not fully lossless as a navigation map**:
it skipped intakes 32–35 even though their residues were absorbed elsewhere.
v4.3 restores the provenance without reopening rejected forms.

| Intake / D | Disposition | Retained residue / routing | First owner / gate |
|---|---|---|---|
| 31 / D-189 | ACTIVE MEMORY | function-loss, heterogeneous meso assembly, residue lifecycle, natural-pattern transfer | `WORLD_AUTHORING` §§6–8; `WORLD_WORKPLAN` §6 |
| 32 / D-190 | ABSORBED + DEFERRED | re-expansion law; ripple-audit procedure; generic knowledge graph unresolved | agent/tooling procedure only; no world runtime row |
| 33 / D-191 | ABSORBED | anti-arbitrage spread; turnover question; outcome-perception laws | `WORLD_AUTHORING` turnover / economy gates |
| 34 / D-194 | ABSORBED / METHODOLOGY | capability/resolution/progression separation; NPC agency; carrier taxonomy; anti-grind/LOD | research/test discipline; named consumer gate |
| 35 / D-195 | ABSORBED / DEFERRED | second-instance control requirement; capability claims need consumer/held-out test | `WORLD_TESTS` / cross-domain evidence gate |
| 36 / D-196 | ACTIVE WORLD-TEST MEMORY | relation formation; road capacity/fracture; denominator integrity | W5 heartbreak station; road-traffic rider; future lint |
| 37 / D-197 | ABSORBED / METHODOLOGY | mutation visibility; path-bound evidence | verification owner, not world runtime |
| 38 / D-199 | STANDING DOCTRINE | Cross-Domain transplant + promotion gate | external instruction / governance |
| 39 / D-231/D-232 | ABSORBED | agent-instruction re-edit; synthesis-over-selection | research method |
| 40 / D-233 | ABSORBED / PARKED | test corpus form rejected as second TEST_PLAN; residue enters D-237–D-240 | `WORLD_TESTS` / owner-gated first consumer |
| D-236 | ENGINE CONTRACT BOUNDARY | `A2 + B2/B3`; `B1 deferred` | engine owner; world track must not reopen silently |
| Caravan v3 | ABSORBED + PRESERVED SOURCE | full source retained in `07_CARAVAN_MOBILITY_DOSSIER.md`; selective bundle residues: functional cut, route-memory ablation, carrier-vs-institution continuity, synchronization latency, channel asymmetry, return asymmetry, travel-price vs institutional-cost distinction, negative-result interpretation | mobility/corridor + knowledge/institutional probes; no runtime promotion |

**No-loss rule:** skipped/no-row intake material must be explicitly classified as
`ABSORBED | DEFERRED | REJECTED | SUPERSEDED`, never silently omitted.

## 11. Original WTN sections 8–13

**Retained:** economy expansion gate, relationship/kinship gate, historical residue policy, knowledge/belief policy, Resonance policy, peoples/cultures policy.
**Location:** `WORLD_TRACK_NEXT.md` §§8–16 and `03_PROBES_AND_GATES.md` §§9–16, plus owner files for exact doctrine.

## 12. Anti-patterns / non-goals

**Retained:** no atlas-for-coverage, no encyclopedic species/religion/language expansion, no generic relationship meters, no plot generator, no LLM causal invention, no second region for map completion, no Ancient Network work without contradiction, no gratuitous Resonance.

## 13. Evaluation and evidence formats

**Retained:** W6 package schema, agency probe schema, social-practice schema, session completion contract, mechanism “future-state / coupling / removal / carrier / knowledge / beneficiary / payer / residue” questions.
**Location:** `03_PROBES_AND_GATES.md`.

## 14. Legacy design-memory terms preserved

The original memo's labels are intentionally retained in routing language even where the detailed schema lives elsewhere: `semantic forgetting`, `Story Arc Assembly`, `Story Opportunity`, `Carrier-ablation`, `40-80 asymmetry`, and `Relationship / Kinship`.

## 14A. Source-backed vs synthesis boundary

The three D-196 residues are **source-routed research memory**, not newly invented
mechanisms in this pack. Moving-Meso / World Ignition, pool/role provenance +
meaningful absence, expectation feedback, and maintenance ecology are synthesis
candidates and must remain `PROPOSAL` until measured.

## 15. Explicitly NOT promoted

No v4–v4.5 proposal is runtime-approved merely because it is written here. Runtime promotion still requires the existing admission gate: real consumer, real failure, material quality gap, native limit, repeated shape, falsifier, owner, phase/gate.
