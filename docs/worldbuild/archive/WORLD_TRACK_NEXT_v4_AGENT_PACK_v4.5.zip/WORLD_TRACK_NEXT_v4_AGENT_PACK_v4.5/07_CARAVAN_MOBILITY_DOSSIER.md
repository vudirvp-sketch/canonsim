# CARAVAN MOBILITY — PRESERVED SOURCE DOSSIER v3

This file preserves `caravan-mobility-consolidated.v3.md` as a full research/source artifact. The source body is retained verbatim after this header; integration into the v4.5 navigation bundle is selective and does not promote new runtime architecture.

## Integration contract

- **Role:** specialized mobility research/source dossier.
- **Authority:** derived bundle only; owner documents remain authoritative.
- **Primary consumers:** `WORLD_TRACK_NEXT.md` §10/§20, `03_PROBES_AND_GATES.md` §§6–12/17, `06_FRONTIER_MECHANISMS.md`, `05_SOURCE_CROSSWALK.md`.
- **Promoted into bundle navigation:** functional corridor/cut, causal route-memory test, carrier-vs-institution continuity, synchronization latency, channel asymmetry, return asymmetry, travel-price vs institutional-cost distinction, negative-result interpretation.
- **Not promoted:** dedicated Caravan runtime type, RouteHistory store, global mobility/isolation scalar, global compatibility matrix, global provenance graph, route-reputation scalar, caravan civilizational regime.
- **Status model:** claim type and repository disposition/test result are orthogonal; do not collapse them into a one-to-one status mapping.
- **Load policy:** load this file only when a task crosses mobility/caravan/corridor design or its specialized probes. Do not use it as a replacement for `WORLD_TRACK_NEXT.md`.

---

# Караван и межрегиональная связность в Canonsim — ультимативная консолидация v3

> Рабочий документ. Это не добавление нового runtime-примитива и не утверждение нового цивилизационного режима. Караван здесь — causal witness / recurring contact mechanism, а не самостоятельная продуктовая цель и не narrative engine. Документ сводит существующие механизмы worldbuilder с исследовательской гипотезой о караване как повторяющемся институте контакта.
>
> Основные опоры: `AGENTS.md`, `AGENT_NAVIGATION.md`, `WORLD_KERNEL.md`, `RESONANCE.md`, `LIFE_PERSONHOOD.md`, `PEOPLES.md`, `CULTURES_CIVILIZATION.md`, `WORLD_AUTHORING.md`, `WORLD_TESTS.md`, `ANCHOR_REGION.md`, `WORLD_WORKPLAN.md`, `WORLD_TRACK_NEXT(1).md`, `Cross-Domain Mechanism Transplantation — Agent Instruction(5).md`, а также существующие runtime-примитивы `travel`, `groups`, `roads`, `macro`, `LOD`, `knowledge`, `relations`, `accounts` и carried state.
>
> Статусы используются строго: `FACT | INFERENCE | HYPOTHESIS | PROPOSAL | UNKNOWN`; результаты: `CONFIRMED | PARTIALLY CONFIRMED | REJECTED | UNRESOLVED | DEFERRED`.

---

## 0. Опорная картина v3: что доказано, что предлагается, что ещё не существует

### 0.1 Что реально есть в substrate

На момент v3 текущий repository уже предоставляет значительную часть механического основания:

- event-sourced canonical state: изменение мира должно проходить через события;
- deterministic replay и единый RNG-contract;
- location graph / roads;
- `travel` как отдельное edge-priced действие;
- carried state, следующий вместе с носителем;
- groups и materialization/condensation;
- macro cadence и road-traffic aggregation;
- scene LOD с `ACTIVE / WARM / COLD` зонами;
- knowledge stack и observer/read-side separation;
- relationships, factions, accounts/economy surfaces;
- calendar / weather / seasonality;
- pack-first authoring и owner/gate discipline.

**FACT / CONFIRMED:** этих механизмов достаточно, чтобы поставить первый caravan experiment без отдельной транспортной подсистемы.

Это не утверждает, что они уже образуют караванный институт.

### 0.2 Что v3 считает рабочей гипотезой

Основная гипотеза:

> **Караван становится значимым не в момент, когда он существует как движущаяся группа, а в момент, когда повторные проходы начинают менять условия следующего прохода.**

Отсюда v3 исследует не «объект караван», а lifecycle:

```text
ROUTE
→ VIABILITY
→ CARRIER
→ PASSAGE
→ HANDOVER / SETTLEMENT
→ RESIDUE
→ ADAPTATION
→ NEXT-CYCLE CONDITIONS
→ NEXT PASSAGE
```

**HYPOTHESIS:** если такая петля устойчиво работает на существующем substrate, то отдельный caravan runtime object не нужен.

### 0.3 Что v3 не утверждает

Пока не доказано:

1. что караван — отдельный civilizational regime;
2. что все caravan traditions имеют единый lineage;
3. что ancient network является их обязательным происхождением;
4. что нужен global mobility/isolation score;
5. что нужен global membrane/gate system;
6. что нужен generic route-history/provenance graph;
7. что route reputation должно быть отдельным runtime state;
8. что stale knowledge требует отдельного production primitive.

Все эти пункты остаются `HYPOTHESIS / PROPOSAL / DEFERRED` до вертикального доказательства.

### 0.4 Главная дисциплина v3: passage сам по себе недостаточен

Для обычного traffic достаточно:

```text
MOVE
→ ARRIVE
```

Для caravan institution требуется более сильный признак:

```text
PASSAGE #1
→ MATERIAL / EPISTEMIC / SOCIAL CONSEQUENCE
→ RESIDUE
→ CHANGED CONDITIONS
→ PASSAGE #2 DIFFERENT FROM #1
```

А для устойчивого института — ещё и:

```text
CARRIER TURNOVER
+ FUNCTIONAL SURVIVAL
+ SUCCESSION / HANDOVER
```

Именно эти тесты отделяют recurring traffic от recurring institution.

### 0.5 Substrate preference и runtime-promotion discipline

v3 следует агентской инструкции:

```text
source heuristic ≠ transferred mechanism ≠ target principle ≠ implementation requirement
```

и правилу:

```text
existing primitive
→ minimal extension
→ only then new primitive
```

В частности, `Caravan`, `RouteInstitution`, `RouteHistory`, `MobilityTier`, `GlobalIsolation` и `ProvenanceGraph` не являются частью current runtime contract только потому, что они удобны как названия.

## 1. Центральная идея

### 1.1 Определение

**Караван — это повторяющийся meso-институт контакта, который использует существующие маршруты и периодически перемещает носителей между местами, связанными обязательствами, знаниями и материальными потоками.**

Караван не обязан быть отдельным runtime-типом и не обязан физически «владеть» дорогой.

Его минимальная причинная форма:

```text
ROUTE
  → WINDOW
  → CARRIER
  → PASSAGE
  → ARRIVAL
  → LOCAL RESPONSE
  → RESIDUE
```

Где:

- **ROUTE** — существующий физический/графовый путь;
- **WINDOW** — временная/сезонная возможность прохода;
- **CARRIER** — человек, группа или другой существующий носитель;
- **PASSAGE** — реально реализованный `move/travel`;
- **ARRIVAL** — каноническое появление в новом месте;
- **LOCAL RESPONSE** — реакция уже существующих институтов и акторов;
- **RESIDUE** — состояние, которое меняет будущее: объект, знание, долг, отношение, репутацию, обязательство, локальную практику и т.п.

Это важнее, чем ярлык «караван»: если ту же цепочку может выполнить существующий субстрат, новый primitive не оправдан.

### 1.2 Что делает караван уникальным

Его основная функция — не «двигать NPC», а **периодически снижать стоимость причинного контакта между местами, которые иначе слабо связаны**, не устраняя при этом цену, время, риск и локальные ограничения.

Караван поэтому является не «мобильным объектом», а **повторяющимся каналом связности**.

### 1.3 Контакт не равен смешению

Регион может быть связан с другим по одному носителю связи и почти не связан по другим.

Контакт следует мыслить через реализованные проходы, а не через единственный `connected = true`:

```text
BODY    — человек физически прибыл;
CARGO   — материальный объект прибыл;
WITNESS — кто-то привёз/получил знание, свидетельство или наблюдение;
CLAIM   — право, долг, обещание, признание или другое обязательство теперь существует у другого носителя.
```

Это не четыре новые подсистемы. Это четыре аналитических класса для наблюдения за уже существующими state changes.

**PROPOSAL:** различие `BODY / CARGO / WITNESS / CLAIM` должно использоваться прежде всего на уровне authoring и тестов, а не как обязательные runtime-структуры.

---

## 2. Главный механизм: распределённый институт

### 2.1 Караван не обязан владеть всей своей инфраструктурой

Сильнейшая версия концепции требует отказаться от образа «движущейся точки на карте».

Караван может быть распределён между множеством стационарных зависимостей:

- место ночлега;
- источник воды;
- ремонтная мастерская;
- склад;
- держатель права прохода;
- кредитор;
- местный переводчик запретов;
- свидетель прошлых сделок;
- адресат писем;
- человек, который принимает часть груза;
- место, где должны встретиться следующие участники маршрута.

Тогда физически движется только часть института.

> **Караван — это институт, чья функция распределена по маршруту, а люди периодически перемещают между его узлами носителей этой функции.**

Это позволяет получить глубокий социальный эффект без нового глобального объекта.

### 2.2 Route institution, а не route ownership

Не нужно предполагать, что караван владеет дорогой.

Гораздо интереснее:

```text
ROUTE EXISTS
+ SOMEONE KNOWS HOW TO USE IT
+ SOMEONE AGREES TO HOST THE PASSAGE
+ SOMEONE EXPECTS A RECIPROCAL RESPONSE
```

Отсюда появляется институт маршрута даже там, где нет формального территориального суверенитета.

### 2.3 Исторический остаток маршрута

Повторяющиеся проходы создают **route residue**.

Один и тот же физический edge может становиться причинно разным, потому что на нём накопились:

- прошлые встречи;
- долги;
- обещания;
- известные имена;
- плохая или хорошая репутация;
- местные обычаи обслуживания;
- потерянные грузы;
- старые запреты;
- места смерти или спасения;
- знания о том, когда дорога действительно проходима.

Это не означает новый `RouteHistory` primitive. В первом приближении residue должен возникать из существующих events/state/knowledge/relations.

---

### 2.4 Институциональная память маршрута

Самая важная новая конструкция v3:

> **Маршрут помнит только через изменение условий собственного будущего.**

Это означает, что `route memory` не обязана быть отдельным хранилищем.

Она наблюдается, когда:

```text
PASSAGE
→ local residue
→ changed expectation / obligation / service / knowledge
→ altered next passage
```

Примеры:

```text
successful passage
→ host invests in storage
→ later cargo can stay longer
```

```text
lost cargo
→ host requires prepayment
→ next cycle has different settlement conditions
```

```text
repeated trustworthy delivery
→ buyer plans around arrival window
→ delay now has a downstream consumer
```

**Инвариант:** если удаление прошлого passage не способно изменить будущие условия, его «память» может быть лишь хроникой, а не causal residue.

### 2.5 Functional corridor: геометрическая связь не равна рабочей связи

Физическая connectedness недостаточна.

```text
GEOMETRIC ROUTE
A -------- B -------- C
```

может одновременно зависеть от:

```text
WATER      → X
HOST       → Y
REPAIR     → Z
PERMISSION → Q
SETTLEMENT → R
```

Поэтому следует различать:

```text
TOPOLOGY
vs
FUNCTIONAL VIABILITY
```

Очень важный probe:

```text
REMOVE DEPENDENCY X
→ road remains geometrically connected
→ carrier still exists
→ functional passage fails or changes materially
```

Это `FUNCTIONAL CUT`.

**PROPOSAL:** functional cut использовать как read-side/test relation, а не как новый runtime object.

### 2.6 Carrier turnover: институт должен переживать людей

Один и тот же carrier, который приезжает двадцать раз, ещё не доказывает институт. Это может быть просто recurring actor behavior.

Более сильный тест:

```text
CYCLE A
carrier_1 + host_1 + broker_1

CYCLE B
carrier_2 + successor_host + broker_2
```

при этом сохраняется хотя бы часть функции маршрута через:

- obligation;
- local practice;
- knowledge;
- successor;
- stationary service;
- recognized claim.

**Institutional continuity test:** конкретный человек может исчезнуть, а функция контакта — нет.

Если исчезновение одного actor автоматически стирает весь маршрут, это ещё не обязательно институт.

### 2.7 Succession и inheritance

Маршрут может жить через смену держателей функций:

```text
keeper dies / leaves
→ successor inherits role
→ successor has partial knowledge
→ practice changes
→ route survives under altered terms
```

Это особенно ценно, потому что соединяет mobility с уже существующими темами:

```text
CONTINUITY ↔ IDENTITY
```

Смена носителя не обязана сохранять функцию идеально. Более глубокий вариант:

```text
SUCCESSION
→ PARTIAL MEMORY
→ PROTOCOL DRIFT
→ NEW LOCAL PRACTICE
```

Так институт не только сохраняется, но и исторически меняется.

### 2.8 Protocol drift: долгий контакт меняет способ совместимости

Повторные проходы могут создавать не общую культуру и не единый язык, а **локальный протокол взаимодействия**:

- знаки допуска;
- формы расписок;
- меры веса;
- порядок обмена;
- toll etiquette;
- recognition cues;
- сигнализацию дороги;
- порядок ночлега;
- способы передачи писем.

Пока corridor работает:

```text
REPEATED PASSAGE
→ COMPATIBILITY PROTOCOL
```

После длительного разрыва:

```text
ROUTE REMAINS
BUT PROTOCOL DRIFTS
```

При reopening:

```text
PHYSICAL CONNECTIVITY ≠ INSTITUTIONAL COMPATIBILITY
```

**PROPOSAL:** protocol drift должен сначала быть выражен существующими knowledge / practice / relation / item state surfaces. Отдельный `Protocol` runtime object не нужен без повторного consumer/failure evidence.

### 2.9 Синхронизационный пульс

Повторяющийся караван может стать временной опорой для чужих планов:

```text
DEBT SETTLEMENT
LETTER DELIVERY
APPRENTICE ARRIVAL
TOOL DELIVERY
WITNESS APPEARANCE
COUNTER-CARGO
```

Тогда важен не только arrival, но и **ожидаемое arrival window**, принадлежащее конкретному knowledge-holder / claimant.

```text
EXPECTED ARRIVAL
→ LOCAL PLAN
→ DELAY / NON-ARRIVAL
→ PLAN REVISION
```

Ожидание никогда не должно быть скрытой truth-state. Оно должно иметь носителя, основание и, по возможности, стареть вместе с информацией.

### 2.10 Возвратный цикл

Для института принципиален не только outbound passage:

```text
OUTBOUND
→ HANDOVER / SETTLEMENT
→ RETURN LOAD / COUNTER-CLAIM
→ RETURN
→ NEXT OUTBOUND
```

Возврат необязательно физически симметричен.

Возможны:

```text
BODY OUT / CARGO BACK
BODY BACK / CLAIM FORWARD
WITNESS OUT / CARGO RETURN
```

Асимметрия обратного пути — отдельный источник человеческих последствий и resilience failure.

## 3. Караван как механизм синхронизации мира

### 3.1 Самая важная новая глубина: latency

Караван переносит не только людей и товары. Он переносит **ограниченную и устаревающую синхронизацию** между регионами.

Расстояние создаёт временной сдвиг между:

```text
WORLD STATE
    ↓
OBSERVATION
    ↓
CARRIER
    ↓
PASSAGE
    ↓
ARRIVAL
    ↓
LOCAL INTERPRETATION
```

Поэтому письмо, приказ, цена, карта, обещание или свидетельство могут прибыть тогда, когда описываемая ими реальность уже изменилась.

### 3.2 Почему это механически полезно

Это создаёт живость без отдельного narrative engine:

- договор может устареть до прибытия;
- рынок может исчезнуть до прихода груза;
- человек может приехать с устаревшим запретом;
- свидетель может рассказать правдивую информацию, которая уже перестала быть актуальной;
- предмет может приобрести локальную интерпретацию раньше, чем приедет его создатель;
- письмо может физически прибыть, но не породить ожидаемого действия, если адресат уже умер/уехал/изменил обязательство.

Это естественное продолжение цепочки наблюдения:

```text
TRUTH → WITNESS → KNOWLEDGE → BELIEF → INTERPRETATION → NARRATION
```

### 3.3 Расхождение носителей

Один проход не обязан доставить всё вместе:

```text
PERSON arrives
CARGO is lost
WITNESS survives
CLAIM remains
```

или:

```text
CARGO arrives first
LOCAL INTERPRETATION forms
PERSON arrives later
ORIGINAL MEANING is no longer authoritative
```

Такие расхождения способны создавать реальные downstream consequences без сюжетного генератора.

---

## 4. Изоляция и межрегиональная мобильность

### 4.1 Региональная изоляция

Региональная изоляция — не флаг и не физическая стена. Это **отсутствие дешёвого причинного пути** между двумя состояниями мира.

Опора остаётся прежней:

- `RESONANCE.md` R4/R5/R8 ограничивают масштаб, дальнее coupling и устойчивость;
- Negative Space не допускает произвольную массовую телепортацию как универсальное решение;
- `PEOPLES.md` задаёт биологические/инфраструктурные ограничения для миграции;
- Technology Law не превращает наличие древнего механизма в автоматическую доступность;
- существующий travel уже учитывает стоимость edge.

Отсюда следует:

> **Не нужно создавать отдельный закон изоляции, если отсутствие дешёвого причинного пути уже возникает из существующих ограничений.**

### 4.2 Аналитическая декомпозиция контакта

Вместо одной «формулы mobility» v3 использует три стадии:

```text
PRECONDITIONS
  ROUTE
  VIABILITY / WINDOW
  CARRIER
  LOCAL GATE

REALIZATION
  ASSIGNMENT
  REALIZED PASSAGE
  ARRIVAL / NON-ARRIVAL

DOWNSTREAM
  BODY / CARGO / WITNESS / CLAIM
  RESIDUE
  NEXT-CYCLE CHANGE
```

Это **diagnostic decomposition**, а не runtime object.

Ключевое различие:

```text
PRICE
```

— это конкретная существующая цена travel edge,

а:

```text
INSTITUTIONAL COST
```

— совокупность downstream costs, возникающих из obligations, service, knowledge, risk и missed plans.

Не следует смешивать обе категории в одну универсальную scalar metric.

### 4.3 ROUTE

Маршрут должен быть выражен существующим location graph.

Новый route object появляется только при доказанной архитектурной необходимости.

### 4.4 WINDOW

Проход может зависеть от:

- сезона;
- погоды;
- состояния дороги;
- availability локального носителя;
- периодического права прохода;
- институционального расписания.

Никаких глобальных процентов «открытости».

### 4.5 CARRIER

Носителем может быть:

- обычный actor;
- существующая group;
- caravan-like group;
- флот/отряд/иной уже поддерживаемый meso-unit;
- в редких случаях — уникальный actor как carrier of a special crossing.

### 4.6 LOCAL GATE

Ограничение должно быть локальным и объяснимым:

- биологическая пригодность;
- инфраструктурное требование;
- социальный допуск;
- необходимость посредника;
- локальный запрет;
- цена обслуживания.

Gate не должен превращаться в глобальный таблицезаменитель мира.

### 4.7 PRICE

В v3 разделяются:

```text
TRAVEL PRICE
= existing edge-local travel duration
```

и:

```text
DIEGETIC / INSTITUTIONAL COST
= consequences composed from existing state surfaces
```

Текущий travel substrate уже вычисляет edge-local duration из pack override или derived world data; это не следует переизобретать внутри caravan model.

Например:

```text
edge price = 400 ticks
```

не означает автоматически:

```text
high economic cost
high danger
low trust
```

Такие свойства должны быть доказаны отдельными state changes / relations / failures.

### 4.7a Seasonality не превращать в global mobility scalar

Вместо `route_open = 0.73` использовать конкретные основания:

```text
season
+ road condition
+ local availability
+ carrier need
+ service readiness
→ different realized passage
```

Календарь должен создавать различия условий, а не один глобальный «коэффициент открытости».

### 4.8 REALIZED PASSAGE

Назначенный переход не равен реализованному.

Сам факт:

```text
assigned = true
```

не доказывает:

```text
arrived = true
```

Каноническим считается фактически реализованный travel/move/event.

### 4.9 RESIDUE

После прохождения должны сохраняться только те следы, которые меняют будущее:

- человек остался;
- товар сменил владельца;
- появилась новая информация;
- возник долг;
- изменилось отношение;
- возникло право/запрет;
- изменилось локальное понимание мира;
- маршрут получил репутационный след.

Не создавать permanent diagnostics только ради истории симуляции.

---

## 5. Уникальные, процедурные и межрегиональные акторы

### 5.1 Основное правило

Чужеземный актор не должен возникать как необъяснимый статистический шум.

Базовый инвариант:

> **No unexplained material cross-boundary transition.**

Это сильнее и аккуратнее, чем требование полного provenance для каждого случая.

Различать четыре состояния:

```text
CAUSAL BASIS + RECONSTRUCTABLE
CAUSAL BASIS + ORIGIN / MECHANISM UNKNOWN
CAUSAL BASIS + INTENTIONALLY OPAQUE
NO CAUSAL BASIS
```

Нарушением является прежде всего последнее.

Поэтому:

```text
ORIGIN UNKNOWN
```

может быть честной эпистемической ситуацией,

а:

```text
ARRIVAL WITHOUT CAUSAL BASIS
```

— кандидатом на world violation.

Минимальная причинная форма по-прежнему:

```text
ORIGIN → CARRIER / PASSAGE → ARRIVAL
```

но observer может знать только часть этой цепочки.

### 5.2 Категории

| Категория | Функция | Межрегиональность |
|---|---|---|
| **Local procedural resident** | Обычный житель своего региона | По умолчанию локален |
| **Bounded traveler** | Обычный участник реализованного маршрута | Да, через существующий канал |
| **Bridge actor** | Носитель институциональной функции перехода | Да, если существует конкретная цепочка перехода |
| **Rare crossing** | Особый переход через необычный anchor/событие | Только с полным causal basis |

Эти категории — authoring/test vocabulary, а не обязательно новые runtime classes.

### 5.3 Bridge actor

Уникальность должна быть функциональной, а не «силовой».

Bridge actor может быть:

- держателем права прохода;
- посредником между запретами;
- переводчиком локального институционального языка;
- свидетелем долгов;
- резонансным anchor-bearer;
- человеком, который делает возможным конкретный маршрут.

Если функция не влияет на причинную связность, уникальность может быть декоративной.

### 5.4 Не ретроактивное исчезновение

После того как актор реально приехал, закрытие дороги не должно стирать его из мира.

Различать:

```text
COUNTERFACTUAL BEFORE ARRIVAL
```

и:

```text
ACTUAL WORLD AFTER ARRIVAL
```

При ablation первого типа мы меняем достижимость события в будущем.
После реализованного события мы меняем только будущие возможности: человек остаётся, но дальнейший проход может стать невозможным или дорогим.

---

## 6. Караван и цивилизационные режимы

### 6.1 Почему «13-й режим» пока рано фиксировать

Караван имеет сильный кандидат на отдельную цивилизационную логику, но это ещё не доказано.

Пока его правильнее описывать как:

```text
MESO-INSTITUTION
    ↓
recurrent route institution
    ↓
possible later civilizational pattern
```

### 6.2 Что потенциально отличает caravan pattern

Если гипотеза подтвердится, его возможный инвариант будет не «кочевничество», а:

> **сообщество, которое сохраняет связность через контроль над маршрутом, памятью пути и взаимными обязательствами, а не через владение одной территорией.**

Но это остаётся `HYPOTHESIS`.

### 6.3 Что не следует предполагать заранее

Не следует автоматически утверждать:

- отсутствие территории как необходимое происхождение;
- единое происхождение всех caravan traditions;
- прямое наследование Ancient Network;
- отдельный sovereign status;
- единый набор институтов для всех караванов.

Караван может возникать в разных местах по разным причинам, если они приводят к одному механизму:

```text
recurrent contact under constrained connectivity
```

### 6.4 Более интересная возможность: несколько lineage

Возможны независимые происхождения караванных институтов:

- бывшая торговая сеть;
- беженский маршрут;
- экспедиционный путь;
- религиозный pilgrimage corridor;
- маршрут снабжения frontier;
- остаток древней инфраструктуры;
- смешанный институт, возникший после нескольких поколений.

Это оставляет миру историческую неоднозначность и избегает преждевременного единого myth of origin.

---

## 7. История караванов: осторожная версия

### 7.1 Что можно утверждать сейчас

**INFERENCE / PROPOSAL:** после Great Fracture устойчивой могла стать не максимальная связность, а **периодическая низкополосная связность**, которая переносит ограниченное количество людей, материальных объектов и информации через дорогие контактные пути.

Это хорошо согласуется с центральным конфликтом:

```text
CONNECTIVITY ↔ RESILIENCE
```

### 7.2 Что нельзя утверждать без отдельного доказательства

Пока не следует фиксировать как canon:

> «караванная традиция напрямую произошла из древних Resonance-binding protocols».

Возможна и другая история:

```text
Ancient route survives
        ↓
modern users rediscover it
        ↓
recurrent local use
        ↓
institution forms
        ↓
later people assume the institution is ancient
```

Или вообще:

```text
Great Fracture
→ local need
→ route institution
→ coincidence with ancient trace
```

Такая неопределённость потенциально создаёт более глубокую археологию мира, чем единая официальная версия.

### 7.3 Historical residue как принцип

Прошлое не обязано существовать только в records.

Прошлое может оставаться в:

- topology;
- ownership;
- knowledge;
- relationships;
- obligations;
- локальных запретах;
- привычных маршрутах;
- местах, где люди продолжают делать что-то по причине, которую уже никто не помнит.

Это прямой материал для живого мира.

---

## 8. Маршрут как цепочка обязательств

### 8.1 Route contract

Один caravan route становится интересным, когда он зависит от нескольких взаимных обещаний:

```text
A promises water
→ B promises repair
→ C guarantees passage
→ D buys the cargo
→ A expects payment next cycle
```

Это не новый глобальный contract engine. Это композиция существующих obligations/accounts/relations и локальных событий.

### 8.2 Разрыв цепочки

Если караван не приходит:

- B может остаться с непроданным ремонтом;
- C — с неиспользованным правом прохода;
- D — без ожидаемого товара;
- A — с невозвращённым долгом;
- письма могут не дойти;
- будущие участники получают новые решения.

При этом **не следует принудительно объявлять кризис**.

Если downstream consumer нет, отсутствие каравана должно не дать ничего особенного. Это полезный отрицательный результат: маршрут был декоративным.

### 8.3 Repeated route as institution

Повторяемость делает возможным:

```text
passage
→ expectation
→ obligation
→ reputation
→ next passage
```

То есть предыдущий проход меняет условия следующего.

Это важнее, чем просто «караван приезжает раз в год».

---

## 9. Внутренняя неоднородность каравана

Караван не должен моделироваться как одна mind-like сущность.

Минимальная рабочая гетерогенность:

- глава маршрута хочет прибыть вовремя;
- охранник хочет снизить риск;
- держатель учёта хочет закрыть обязательства;
- проводник знает, что участок дороги хуже, чем записано;
- пассажир хочет сойти раньше;
- грузчик знает о повреждённом товаре;
- местный посредник ожидает возврата старого долга.

Эти цели могут конфликтовать, хотя все находятся внутри одной группы.

### 9.1 Почему это полезно

Один и тот же `route` может давать разные результаты без добавления сюжетного генератора:

```text
same route
+ different local knowledge
+ different obligations
+ different incentives
→ different realized passage
```

Это соответствует `Heterogeneous Agency`: aggregate actor нельзя считать единым сознанием без доказательства. 

### 9.2 Минимальный первый шаг

Не нужно создавать внутренний AI-движок каравана.

Достаточно проверить один конфликтующий pair:

```text
TIMELINESS vs SAFETY
```

или:

```text
HONOR OLD OBLIGATION vs SAVE CURRENT CARGO
```

и убедиться, что существующие actions/state/decision surfaces способны выразить последствия.

---

## 10. Механическая форма без нового runtime-примитива

### 10.1 Первая реализация

Первый caravan pilot должен собираться из:

```text
existing group
+ existing position/route
+ existing travel/move
+ carried state
+ existing knowledge/relations/accounts
+ existing macro/LOD
+ a small amount of pack-authored behavior
```

### 10.2 Не нужно вводить сейчас

```text
Caravan runtime type
Membrane runtime type
Global Region object
Global isolation score
Global compatibility matrix
Global crossover budget
Generic provenance graph
Generic route-history store
```

Каждый из этих объектов может оказаться полезным позже, но ни один сейчас не доказан Runtime-Promotion Gate.

### 10.3 Minimal causal representation

Если для первого теста требуется authoring metadata, достаточно локальной записи вида:

```text
route
carrier
window
required local condition
expected residue
```

И даже эта форма предпочтительна как derived/authoring data, пока exact runtime contract не доказан.

---

## 11. Контактные модели: унификация прежних вариантов

Ранее существовали несколько описаний одной идеи:

- membrane с несколькими gate;
- six-boundary law;
- mobility tiers;
- origin tags / canon seams.

Не следует выбирать одну как глобальную систему.

### 11.1 Синтез

Использовать как authoring/checklist одну композицию:

```text
CONTACT
= ROUTE
+ WINDOW
+ CARRIER
+ LOCAL GATE
+ PRICE
+ REALIZED PASSAGE
+ RESIDUE
```

Она сохраняет сильные стороны прежних вариантов:

- membrane даёт внимание к локальным ограничениям;
- boundary-модель напоминает, что каналы связи неодинаковы;
- mobility tiers полезны для классификации редкости;
- origin/canon seam полезны как диагностическая запись события.

Но ни одно из них не превращается в отдельный production subsystem.

### 11.2 Когда допустим Rare crossing

Особый переход требует:

```text
CONCRETE ANCHOR
→ EFFECT
→ PRICE
→ FAILURE MODE
→ SOCIAL CONSEQUENCE
```

Если один из элементов отсутствует, переход остаётся `HYPOTHESIS`, а не процедурной генерацией.

---

## 12. No unexplained cross-boundary arrival

### 12.1 Инвариант

> **Если актор оказался за пределами своего обычного population envelope, должен существовать причинный путь, объясняющий его приход.**

Минимальная форма:

```text
ORIGIN → CARRIER/PASSAGE → ARRIVAL
```

### 12.2 Что не требуется

Не требуется permanent provenance graph.

Не требуется хранить все intermediate diagnostics.

Не требуется превращать каждое пересечение в уникальный schema object.

### 12.3 Что действительно требуется

Канонические события должны делать путь реконструируемым.

Если нельзя восстановить, как foreign actor пришёл, это не должно автоматически считаться нормальным результатом генератора.

### 12.4 Closed-world caution

Отсутствие записи не всегда доказывает отсутствие события. Следует отличать:

```text
NO ARRIVAL OBSERVED
```

от:

```text
ARRIVAL PROVEN IMPOSSIBLE
```

Это сохраняет closure discipline из agent instructions.

---

## 13. Каналы контакта и эпистемическая глубина

Контакт может менять мир по разным цепочкам:

### 13.1 Physical channel

```text
body → new position → local action
```

### 13.2 Material channel

```text
cargo → ownership/resource change → downstream economic effect
```

### 13.3 Witness channel

```text
observation → knowledge → belief/decision → behavior
```

### 13.4 Claim channel

```text
promise/debt/right → recognized obligation → later decision
```

### 13.5 Несовпадение каналов

Особенно ценный класс событий:

```text
BODY without CARGO
CARGO without BODY
WITNESS without CURRENT TRUTH
CLAIM without AVAILABLE ENFORCEMENT
```

Такие случаи являются хорошими candidate mechanisms для глубины мира.

---

### 13.6 Channel matrix как тест, а не runtime schema

Полезно анализировать контакт как матрицу:

| Канал | Реализован? | Что меняется | Что может быть потеряно |
|---|---|---|---|
| `BODY` | physical arrival | position / action opportunity | carrier |
| `CARGO` | transfer | ownership / stock / function | item |
| `WITNESS` | knowledge transfer | belief / decision | truthfulness / freshness |
| `CLAIM` | recognized obligation | future choice / entitlement | enforcement |

Эта таблица не означает четыре runtime-subsystems.

Её задача — выявлять cases, где:

```text
one channel arrives
while another does not
```

Именно такие divergences особенно ценны для narrative polysemy и human-history breadth.


## 14. Караванное знание не обязано быть истинным знанием

Сам факт прибытия носителя информации не делает информацию canonical truth.

Следует сохранять разделение:

```text
WORLD AUTHORITY
vs
LOCAL BELIEF
vs
TRAVELER REPORT
vs
LATER INTERPRETATION
```

Например:

1. караван видел паводок;
2. рассказал о паводке следующему региону;
3. местный интерпретатор решил, что паводок повторится завтра;
4. население изменило поведение;
5. вода отступила раньше;
6. «верное свидетельство» породило неверное решение.

Именно такие эффекты позволяют мобильности менять мир через knowledge, а не только через предметы.

---

## 15. Сезонность, окна и жизнеспособность corridor

Сезонность не должна быть глобальным `mobility score`.

Она должна менять локальные условия:

```text
SEASON
→ ROAD CONDITION
→ SERVICE AVAILABILITY
→ CARRIER NEED
→ LOCAL DEMAND
→ REALIZED PASSAGE
```

Полезно различать:

- **physical window** — когда физически можно пройти;
- **economic window** — когда проход имеет смысл;
- **institutional window** — когда host / permission / service готовы;
- **social window** — когда местные заинтересованы в приёме;
- **return window** — когда обратный путь остаётся жизнеспособным.

Один и тот же маршрут может быть:

```text
PHYSICALLY OPEN
BUT INSTITUTIONALLY CLOSED
```

или:

```text
INBOUND VIABLE
BUT RETURN FRAGILE
```

Это полезнее одного бинарного gate и лучше согласуется с channelized contact model.

## 16. Экономика без торгового мини-движка

Не создавать отдельную caravan economy system.

Первый economic proof:

```text
arrival
→ carried item changes hands
→ existing ownership / account / stock state changes
→ later event differs
```

### 16.1 Более сильная идея: ожидание поставки

Интереснее самого товара может быть **ожидание товара**:

```text
EXPECTED DELIVERY
→ holder forms plan
→ delivery delayed
→ plan expires / changes
→ actor chooses differently
```

Но ожидание обязано иметь:

```text
HOLDER
BASIS
EXPECTED WINDOW
FRESHNESS
```

То есть `expected arrival` — это epistemic/social state, а не скрытая world truth.

### 16.2 Counter-cargo и settlement

Повторный route может перестать быть однонаправленной торговлей:

```text
OUTBOUND CARGO
→ LOCAL SETTLEMENT
→ COUNTER-CARGO / COUNTER-CLAIM
→ RETURN
```

Даже без freight engine это можно сначала проверять через существующие ownership/accounts/relations и carried state.

### 16.3 Экономическая зависимость как emergent effect

Если несколько cycles проходят успешно, локальный actor может начать планировать под route:

```text
repeated delivery
→ specialization / expectation
→ route becomes a planning dependency
```

Это не надо кодировать как `dependency_score`.

Достаточно показать конкретный altered future.

## 17. Репутация маршрута без `route_reputation_score`

Репутация маршрута не должна существовать как отдельное число.

Она может наблюдаться через реальные изменения:

- host перестаёт требовать предоплату;
- buyer соглашается на settlement позже;
- watch принимает привычный документ без повторного посредника;
- местный актор предупреждает другого о состоянии дороги;
- посредник меняет условия обмена на основании прошлого опыта.

Правильная форма:

```text
PAST PASSAGE
→ KNOWN CONSEQUENCE
→ ACTOR UPDATE
→ FUTURE DECISION
```

Неправильная форма:

```text
PASSAGE
→ route_reputation += 0.1
```

Пока `reputation` не имеет конкретного holder и consumer, она остаётся читательской интерпретацией, а не world state.

## 18. Что происходит, когда караван не приходит

Это центральный тест концепции.

### 18.1 Base run

```text
route active
→ carrier departs
→ carrier arrives
→ downstream residue materializes
```

### 18.2 Removal run

```text
same initial state
→ remove the passage before realization
→ no arrival
→ compare future state
```

Ожидается, что:

- future differs там, где существовали реальные downstream consumers;
- уже существующие прошлые residue не стираются;
- связанные знания/отношения не откатываются ретроактивно;
- если downstream effects отсутствуют, отсутствие каравана может оказаться почти безразличным.

### 18.3 Почему это важно

Если удаление каравана ничего не меняет, то либо:

1. маршрут не имеет настоящих consumers;
2. связь выражена только декоративно;
3. downstream механизм не реализован;
4. наблюдение идёт не на том resolution.

Все четыре исхода полезны как диагностический результат.

---

### 18.4 Multi-cycle institutional memory test

Одного ablation между двумя состояниями недостаточно для доказательства institution.

Минимальный stronger test:

```text
CYCLE 1
PASSAGE
→ RESIDUE

CYCLE 2
PASSAGE under changed conditions
→ NEW RESIDUE

CYCLE 3
same route, changed carrier / host
→ continuity OR collapse
```

Смотреть нужно не только на `cycle 2`, но и на divergence после `cycle 3`.

Если удаление passage #1 расходится только до конца ближайшего события, возможно, мы наблюдаем ordinary causal chain.

Если оно меняет условия нескольких последующих cycles, появляется evidence для institutional memory.

### 18.5 Turnover test

Минимальный pair:

```text
A: same carrier repeated
B: carrier replaced, institution-related context held where possible
```

Если функция исчезает полностью, это evidence against institutional independence.

Если часть функции сохраняется через obligations / practices / knowledge / service, это evidence for distributed institution.

### 18.6 Functional-cut test

Выбрать одну stationary dependency:

```text
WATER / HOST / REPAIR / PERMISSION / SETTLEMENT
```

и удалить её до следующего cycle.

Ожидаемые различия:

```text
GEOMETRY UNCHANGED
but
PASSAGE VIABILITY CHANGES
```

Это более сильный тест распределённой институциональности, чем простое наличие нескольких nodes.

### 18.7 Succession test

Удалить одного holder:

```text
holder leaves / dies
→ successor appears or does not
```

Тестирует два разных результата:

```text
FUNCTION SURVIVES WITH DRIFT
FUNCTION COLLAPSES
```

Оба результата полезны, потому что различают institutional resilience и person-dependent coupling.

### 18.8 Protocol-drift test

Сравнить:

```text
repeated route
→ long interruption
→ reopening
```

Держать physical route constant, но позволить knowledge / relations / practices стареть.

Если reopen приводит к friction, renegotiation или new mediation без изменения topology, это candidate evidence для protocol drift.

## 19. Counterfactual ablation

Ключевая проверка:

```text
REMOVE CARAVAN PASSAGE
→ recompute future
→ identify first divergence
→ shrink to sufficient blocker set
```

Измерять не «стало ли в мире больше событий», а:

- какие reachable states исчезли;
- какая причинная цепочка оборвалась;
- какой residual state больше не появился;
- какие последующие решения изменились.

Это прямо соответствует counterfactual-ablation и causal-slice дисциплине.

---

## 20. Негативные и положительные контроли

### Positive control

Известный проход действительно должен менять минимум одно downstream state.

### Negative control

Путь, не имеющий ожидаемого consumer, не должен искусственно порождать caravan-specific consequence.

### Sham control

Workflow запускается, но semantic passage не реализуется.

Ожидание: никакой атрибуции нельзя делать только по assignment.

---

## 21. Первый практический pilot

### 21.1 Почему не континент

Первый pilot должен быть маленьким, но **циклическим**.

Один existing route в existing anchor region, желательно Sarrow Vale, достаточно.

Цель — не показать карту, а показать:

```text
CYCLE 1
→ CYCLE 2
→ CYCLE 3
```

с минимум одной реальной causally persistent difference.

### 21.2 Минимальный состав

Нужны:

1. один существующий group/carrier;
2. один существующий route;
3. одно локальное physical/institutional window;
4. один stationary dependency;
5. один carried material flow;
6. один witness/knowledge flow;
7. одно обязательство, способное пережить конкретного passage;
8. один downstream consumer;
9. один failure mode;
10. один return/settlement step, если substrate позволяет;
11. минимум два cycles, предпочтительно три;
12. carrier-turnover или succession arm.

### 21.3 Минимальные сценарии

**Scenario A — Healthy recurrence**

```text
cycle 1 arrives
→ residue
cycle 2 arrives under changed conditions
→ different outcome
```

**Scenario B — Delayed recurrence**

```text
expected arrival
→ delay
→ local plan changes
```

**Scenario C — Broken recurrence**

```text
cycle 2 does not realize
→ cycle 3 starts from altered state
```

**Scenario D — Turnover**

```text
carrier_1 leaves
→ carrier_2 takes over part of function
```

### 21.4 Что не нужно

Не нужно сразу создавать:

- новый регион;
- отдельную caravan faction;
- глобальный торговый рынок;
- generic route-history store;
- route reputation scalar;
- отдельную mobility tier system;
- narrative quest generator.

## 22. Испытательная таблица

| Проба | Изменение | Что должно наблюдаться |
|---|---|---|
| A — Closed route | future passage blocked | no new realized arrival; past residue unchanged |
| B — Active route | realized carrier passage | downstream effect appears only where a consumer exists |
| C — Residue | one successful cycle | concrete material / witness / claim residue persists |
| D — Next-cycle memory | run second cycle | conditions differ because of cycle 1 |
| E — Removal | remove cycle-1 passage | later reachable future diverges |
| F — Non-realization | assignment without realized passage | no arrival attribution |
| G — Positive control | known consumer | causal delta appears |
| H — Negative control | route with no consumer | no invented caravan-specific crisis |
| I — Sham | workflow runs, semantic passage absent | no effect attributed to passage |
| J — Channel split | separate body/cargo/witness/claim | only realized channels create corresponding effects |
| K — Turnover | replace carrier | institution survives partly or fails in a diagnosable way |
| L — Functional cut | remove one dependency | topology survives while viability changes materially |
| M — Succession | replace holder | continuity vs collapse becomes observable |
| N — Protocol drift | long gap, then reopen | same route may require new mediation / interpretation |
| O — Return asymmetry | alter return path | outbound success does not imply symmetric continuity |

## 23. Что считать успехом

Успехом не считаются:

- красивое появление каравана;
- отдельное имя NPC;
- wagon visual;
- рост числа событий;
- описание «древнего маршрута»;
- отдельная lore-база;
- одна успешная доставка.

Минимальный успех:

```text
existing primitives
→ realized recurring passage
→ persistent residue
→ altered next-cycle condition
```

Сильный успех:

```text
cycle 1
→ residue
→ cycle 2 differs
→ carrier turnover / succession
→ function partly survives
→ later cycle still bears the history
```

Это доказывает не просто traffic, а candidate institution.

### 23.1 Что будет считаться отрицательным результатом

Если:

```text
cycle 1
→ no meaningful residue
→ cycle 2 identical for all material purposes
```

то повторяемость сама по себе ничего не добавляет.

Если:

```text
route disappears
→ nothing downstream changes
```

route может быть decorative or currently unconsumed.

Если:

```text
carrier dies
→ all function disappears
```

это не обязательно ошибка; это evidence, что конкретная система person-dependent.

Отрицательный результат остаётся полезным только при правильной attribution discipline.

## 24. Когда нужен новый runtime primitive

Новый `Caravan` / `RouteInstitution` / `RouteHistory` primitive допускается только после repeated evidence.

Минимальный gate:

```text
REAL CONSUMER
+ REAL FAILURE
+ MATERIAL QUALITY GAP
+ EXISTING PRIMITIVES INSUFFICIENT
+ REPEATED SHAPE
+ CHEAPEST FALSIFIER
+ INFORMATION / SEMANTIC OWNER
+ PHASE / GATE
```

Для caravan-specific primitive v3 добавляет два обязательных вопроса:

```text
CAN THE FUNCTION SURVIVE CARRIER TURNOVER?
CAN THE MEMORY BE EXPRESSED THROUGH EXISTING RESIDUE SURFACES?
```

Если ответ на второе — да, отдельная route-history store не нужна.

Если ответ на первое — нет, это может быть именно actor-specific coupling, а не institutional need.

Пока gate не закрыт, caravan remains:

- authoring pattern;
- meso composition;
- research vocabulary;
- test relation.

## 25. Возможная promotion path

### Stage 0 — Traffic

Существующий road traffic / travel.

### Stage 1 — Recurring passage

Group + route + repeated passage + one downstream consumer.

### Stage 2 — Route institution

Passage #1 изменяет условия passage #2.

### Stage 3 — Distributed institution

Несколько stationary dependencies образуют функциональный corridor.

### Stage 4 — Institutional continuity

Carrier turnover / succession допускает частичное сохранение функции.

### Stage 5 — Historical memory

Повторные cycles создают long-lived residue, который меняет дальнейшие решения.

### Stage 6 — Protocol drift / reactivation

Долгий разрыв меняет совместимость; reopening требует adaptation.

### Stage 7 — Cross-domain mechanism

Один corridor регулярно изменяет states нескольких цивилизационных доменов.

### Stage 8 — Possible civilizational pattern

Только если возникает воспроизводимая логика власти, наследования, культуры, памяти и адаптации, не сводимая к одному route.

Только здесь имеет смысл снова обсуждать отдельный civilizational regime.

## 26. Спорные вопросы, которые остаются открытыми

| № | Вопрос | Статус | Дискриминирующий тест |
|---|---|---|---|
| 1 | Караван — отдельный civilizational regime? | `UNRESOLVED` | самостоятельная воспроизводимая логика за пределами конкретного route |
| 2 | Должен ли институт переживать carrier turnover? | `HYPOTHESIS` | turnover + succession test |
| 3 | Должен ли route memory переживать один passage на несколько cycles? | `HYPOTHESIS` | 3-cycle ablation |
| 4 | Нужен ли отдельный route-history store? | `DEFERRED` | repeated residual consumer, невыразимый state/knowledge/relations |
| 5 | Нужен ли dedicated caravan primitive? | `DEFERRED` | repeated native-limit failure |
| 6 | Может ли functional corridor быть выражен без new graph object? | `PROPOSAL` | functional-cut test |
| 7 | Может ли protocol drift быть выражен существующим knowledge/practice state? | `PROPOSAL` | reopen-after-gap test |
| 8 | Все караванные lineage имеют общий источник? | `UNKNOWN` | independent lineage cases |
| 9 | Ancient Network обязателен для caravan origin? | `UNKNOWN / DEFERRED` | concrete contradiction in anchor |
| 10 | Нужен ли mobility tier в runtime? | `DEFERRED` | repeated operational consumer |
| 11 | Может ли stale knowledge быть reusable read-side mechanism? | `PROPOSAL` | current truth vs delayed report minimal pair |
| 12 | Может ли inbound/outbound asymmetry стать отдельной закономерностью? | `RESEARCH` | return asymmetry probe |

## 27. Что было исправлено относительно v1/v2

### Убрано или понижено по статусу

- утверждение о готовом «13-м режиме»;
- единая происхождительная история караванов;
- глобальная mobility/isolation scalar model;
- dedicated provenance graph;
- generic route-history store;
- route reputation as universal numeric state;
- retroactive disappearance of already-arrived actors;
- обязательная полная реконструкция provenance для любого observer;
- смешение travel price с generic diegetic cost.

### Сохранено и усилено

- караван как recurring meso-institution;
- no unexplained material cross-boundary transition;
- distributed route institution;
- no ownership requirement for route;
- BODY / CARGO / WITNESS / CLAIM;
- stale knowledge / synchronization latency;
- obligation chains;
- heterogeneous agency;
- counterfactual passage ablation;
- pack-first / substrate-first implementation;
- explicit proof states.

### Новое в v3

- institutional route memory;
- next-cycle condition change as the primary institutional criterion;
- functional corridor vs geometric route;
- functional cut test;
- carrier turnover test;
- succession / inheritance test;
- protocol drift;
- synchronization pulse;
- return-cycle asymmetry;
- multi-cycle ablation;
- explicit distinction between travel price and institutional cost;
- causal opacity as legitimate epistemic state;
- stronger promotion ladder from traffic to possible civilization.

### Точечная коррекция терминов

Исправлена опечатка: `каравайная традиция` → `караванная традиция`.

`CONTACT = ...` теперь рассматривается как analytic decomposition, а не как hidden runtime schema.

## 28. Material Verdict Test

### PRINCIPLE

Повторяющийся ограниченный контакт способен создавать институт, который связывает территории не постоянной высокой связностью, а регулярными дорогими проходами и накопленным историческим остатком.

### FORM

Большая часть формы уже выражается существующим substrate: groups, travel, position, carried state, knowledge, relations, macro/LOD.

### QUALITY

Ключевой quality gain — не «караван на карте», а способность существующих механизмов выразить:

- delayed knowledge;
- distributed obligations;
- route absence;
- persistent residue;
- cross-domain downstream consequences.

### TRANSFER

Механизм может быть применён к:

- pilgrimage routes;
- refugee corridors;
- military supply lines;
- maritime convoys;
- bridge actors;
- knowledge chains;
- frontier expeditions.

### COMBINED DESIGN

Лучшее сочетание прежних идей:

```text
existing travel/group substrate
+ recurring institution
+ local gates
+ delayed knowledge
+ obligation residue
+ counterfactual route ablation
```

Такой дизайн получает преимущества mobility/corridor/obligation моделей без введения глобальных score systems.

---

## 29. Архитектурный инвариант

Наиболее устойчивая формулировка v3:

> **Региональная изоляция в Canonsim — это не запрет на смешение, а отсутствие дешёвого причинного пути между различающимися условиями жизни. Караван — повторяющийся meso-институт, который периодически делает такой путь реализуемым, не отменяя его цену, задержку, локальные ограничения, channel asymmetry и исторические последствия.**

И ещё сильнее:

> **Караван не столько перемещает мир, сколько несовершенно синхронизирует его несинхронные части — тела, вещи, знания и обязательства. Его основная память существует не как архив, а как изменившиеся условия следующего прохода.**

Это даёт причинную петлю:

```text
PASSAGE
→ MEMORY
→ DEPENDENCY
→ ADAPTATION
→ SUCCESSION
→ PROTOCOL
→ NEXT PASSAGE
```

### 29.1 Главный emergent trade-off

Повторяющаяся связность сама может снижать resilience:

```text
CONNECTIVITY ↑
→ EXPECTATION ↑
→ SPECIALIZATION / DEPENDENCY ↑
→ ROUTE CENTRALITY ↑
→ FAILURE IMPACT ↑
```

При этом не нужен global `dependency_score`.

Достаточно доказать конкретными reachable-state changes, что успешная серия проходов породила новые зависимости, а отмена маршрута после их возникновения наносит больший downstream effect, чем отмена первого passage.

Это один из наиболее сильных кандидатов на прямое механическое воплощение мировой оси:

```text
CONNECTIVITY ↔ RESILIENCE
```

### 29.2 Что делает караван уникальным относительно обычной дороги

Дорога:

```text
enables movement
```

Караван:

```text
enables recurrent coordination under latency and constraint
```

То есть difference не геометрическая, а институционально-временная.

## 30. Итоговый практический план

### N0 — Snapshot substrate

Зафиксировать существующие world/engine surfaces, которые pilot использует:

```text
roads / travel / group / carried state / knowledge / relations / accounts / macro / LOD
```

Не создавать новый owner.

### N1 — One corridor

Выбрать один существующий route и один functional dependency.

### N2 — Cycle 1

Провести реальный passage с одним material flow, одним witness flow и одним claim/obligation, где substrate это поддерживает.

### N3 — Cycle 2

Дать residue возможность изменить условия следующего passage.

### N4 — Failure

Запустить delay / non-arrival / dependency loss.

### N5 — Cycle 3

Проверить, переживает ли downstream divergence несколько циклов.

### N6 — Turnover

Заменить carrier или functional holder.

### N7 — Succession

Попробовать сохранить функцию через successor с неполной памятью.

### N8 — Long-gap / reopening

Разорвать corridor на достаточно долгий интервал и проверить protocol drift.

### N9 — Ablation / controls

Провести positive / negative / sham controls и shrink к first divergence.

### N10 — Material verdict

Согласно §28 проверить:

```text
PRINCIPLE
FORM
QUALITY
TRANSFER
COMBINED DESIGN
```

### N11 — Promotion decision

Только после N10 выбирать:

```text
KEEP AS AUTHORING PATTERN
KEEP AS MESO PATTERN
PROMOTE NARROW READ/TEST SUPPORT
REQUEST NEW RUNTIME PRIMITIVE
DEFER
REJECT
```

### N12 — World-growth decision

Если anchor pilot действительно показывает institutional continuity, только тогда проверять transfer на втором civilizational coupling.

Не строить второй регион раньше этой точки только ради breadth.

## 31. Session completion contract

### Question

Как превратить существующий дорожный трафик и travel substrate в причинно значимый механизм межрегиональной связности без искусственного global mobility system?

### Verdict

`PARTIALLY CONFIRMED / PROPOSAL`

Субстрат уже способен выразить большую часть базового механизма. Самая перспективная новая конструкция — recurring distributed route institution с persistent residue и ограниченной синхронизацией знания.

### Established evidence

- travel и groups уже существуют как механические primitives;
- carried state может сопровождать перемещение;
- macro/LOD уже позволяют не материализовать всех участников сразу;
- worldbuild law требует опираться на существующие primitives до добавления новых;
- mobility уже constrained на уровне мира, но agent-level cross-boundary causality требует явной authoring/test discipline.

### Key reasoning / alternatives

Отвергнуты как преждевременные:

- глобальные isolation scores;
- fixed exotic caps;
- automatic 13th civilization regime;
- dedicated provenance infrastructure;
- retroactive deletion of arrived actors;
- отдельная транспортная subsystem.

Принят синтез:

```text
ROUTE + WINDOW + CARRIER + LOCAL GATE + PRICE + REALIZED PASSAGE + RESIDUE
```

### Remaining uncertainty

- достаточно ли existing state surfaces для route residue;
- может ли stale knowledge быть выражено без новой representation;
- требуется ли отдельный recurring-institution primitive после pilot;
- образуется ли действительно самостоятельная civilizational logic.

### Practical consequence

Следующий шаг — не расширять карту, а доказать один вертикальный route на существующем регионе и показать, что его наличие/отсутствие меняет достижимое будущее мира.

### Next verification step

`BASE RUN` vs `ROUTE ABLATION` vs `NON-REALIZED ASSIGNMENT` на одном конкретном recurring route.

---

## 32. Final status table

| Компонент | Статус v3 |
|---|---|
| Caravan-like group на existing substrate | `SUPPORTED` |
| Recurring passage | `SUPPORTED AS IMPLEMENTABLE HYPOTHESIS` |
| Caravan as recurring meso-institution | `PROPOSAL / HIGH-VALUE` |
| Route as distributed institution | `PROPOSAL` |
| Institutional route memory | `PROPOSAL / PRIMARY NEW MECHANISM` |
| Next-cycle condition change | `PROPOSED INVARIANT` |
| Functional corridor | `PROPOSAL / TEST RELATION` |
| Functional cut | `TEST METHOD` |
| Carrier turnover | `TEST METHOD` |
| Succession / inheritance | `TEST METHOD` |
| Protocol drift | `PROPOSAL / RESEARCH` |
| Synchronization pulse | `PROPOSAL` |
| Return asymmetry | `RESEARCH` |
| Stale knowledge | `PROPOSAL / READ-SIDE MECHANISM` |
| BODY / CARGO / WITNESS / CLAIM | `AUTHORING / ANALYSIS MODEL` |
| No unexplained material cross-boundary transition | `PROPOSED INVARIANT` |
| Route reputation numeric score | `REJECTED FOR NOW` |
| Global mobility score | `REJECTED FOR NOW` |
| Global compatibility matrix | `REJECTED FOR NOW` |
| Generic provenance graph | `REJECTED FOR NOW` |
| Generic route-history store | `DEFERRED` |
| Dedicated Caravan runtime primitive | `DEFERRED` |
| Separate civilizational regime | `DEFERRED / UNRESOLVED` |
| Ancient Network as mandatory origin | `UNKNOWN / DEFERRED` |

### Final disposition

`PARTIALLY CONFIRMED / HIGH-VALUE PROPOSAL`

Сильнейшее текущее утверждение — не «Canonsim нуждается в караванах».

Это:

> **A recurring, constrained, imperfectly synchronizing corridor may be able to become a self-modifying institution using the existing world substrate, with historical memory expressed as altered future conditions rather than a dedicated history object.**

Решающее доказательство должно прийти из многоциклового vertical pilot, особенно:

```text
cycle 1
→ residue
→ cycle 2 change
→ failure / ablation
→ cycle 3 divergence
→ carrier turnover / succession
```

Пока такого witness нет, механизм остаётся в research/authoring space; новый runtime primitive не продвигается.

