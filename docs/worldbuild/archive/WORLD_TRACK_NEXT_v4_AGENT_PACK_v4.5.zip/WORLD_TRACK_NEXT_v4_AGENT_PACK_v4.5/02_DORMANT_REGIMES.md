# DORMANT CIVILIZATIONAL DESIGN MEMORY v4

These are preserved design hypotheses, not a build order. A dormant regime must
remain compact, source-backed, and mechanically distinct.

## 1. Regime card schema

```text
REGIME
CORE PROBLEM
ADVANTAGE
DEPENDENCY
INSTITUTIONAL RESPONSE
SOCIAL NORMALIZATION
CHARACTERISTIC FAILURE
HISTORICAL RESIDUE
DISTINCTIVE HUMAN-HISTORY SHAPE
UNRESOLVED CONTRADICTION
TRANSFER / COUPLING TEST
WHY NOT NOW
REACTIVATION TRIGGER
STATUS
```

## 2. Riverine / Central — ACTIVE witness

Source owner(s): `docs/worldbuild/ANCHOR_REGION.md`; `docs/worldbuild/CULTURES_CIVILIZATION.md` §6.

Core problem: scarcity + politics.

Dependency: water, food, trade, transport, fertile land.

Failure: control of flow, scarcity, political concentration.

Current use: Sarrow Vale anchor and strongest integration witness.

Distinctive coupling already demonstrated:

`season / water → institutions → debt / practice → household choices → residue`.

Status: `ACTIVE`.

## 3. Mountain / Industrial — next-region candidate

Source owner(s): `docs/worldbuild/CULTURES_CIVILIZATION.md` §9 + §12.

Core problem: infrastructure + scale.

Dependency: minerals, engineering, maintenance, supply chains, capital.

Institutional response: standards, contracts, specialist work, maintenance
networks, worker organizations.

Failure: maintenance backlog, concentrated production, supply dependency,
specialist succession.

Distinctive test:

`infrastructure → skilled labour → maintenance → contract/capital pressure
→ household/faction divergence`.

Human-history shape: stories where continuity depends on invisible work and
succession rather than only immediate scarcity.

Trigger: anchor exposes infrastructure/maintenance/succession as a missing
coupling that Sarrow cannot discriminate.

Status: `NEXT-REGION CANDIDATE`.

## 4. Maritime / Pirate

Source owner: `docs/worldbuild/CULTURES_CIVILIZATION.md` §13.

Core problem: mobility under weak territorial enforcement.

Dependency: ports, routes, cargo, information, legitimacy.

Failure: route closure, port denial, information asymmetry, legitimacy loss.

Distinctive test:

`mobility → corridor dependency → port/contact institution → reputation /
knowledge → altered route choice`.

Trigger: land-based mobility cannot expose a required territorial-decoupling or
port-legitimacy mechanism.

Status: `DORMANT / HIGH-VALUE`.

## 5. Deepwater / Underwater

Source owners: `docs/worldbuild/CULTURES_CIVILIZATION.md` §10; `docs/worldbuild/PEOPLES.md` §3.

Core problem: habitat integrity.

Dependency: controlled environment, pressure, light, food, energy, temperature,
transport, specialist maintenance.

Failure: containment or maintenance failure becomes habitat-scale risk.

Distinctive test:

`ordinary mistake → infrastructure/habitat consequence → specialist scarcity
→ collective vulnerability`.

Trigger: current substrate cannot express environment-scale coupled failure.

Status: `DORMANT / HIGH-VALUE`.

## 6. Necropolis / Continuity

Source owner: `docs/worldbuild/CULTURES_CIVILIZATION.md` §11.

Core problem: memory ownership and continuity.

Dependency: genealogy, testimony, records, preserved remains, validation.

Failure: disputed identity, corrupted memory, inheritance conflict, loss of
preservation/trust.

Distinctive test:

`memory carrier → validation → legitimacy / inheritance → identity conflict
→ changed social future`.

No metaphysical answer about souls is required to make the regime causal.

Trigger: W5/W6 demonstrates persistent memory/identity as a substrate limit.

Status: `DORMANT / HIGH-VALUE`.

## 7. Sky Enclave

Source owner: `docs/worldbuild/CULTURES_CIVILIZATION.md` §14.

Core problem: stability under extreme infrastructure dependence.

Dependency: water, food, materials, energy, transport, repair, legacy systems.

Failure: cascading maintenance, supply dependency, legacy lock-in.

Distinctive test:

`concentrated infrastructure → maintenance institution → repair/supply failure
→ cross-scale cascade → migration / legitimacy / succession`.

Design law: a sky city is an infrastructure machine, not a floating castle.

Trigger: integration tests need a concentrated infrastructure stress case that
cannot be discriminated elsewhere.

Status: `DORMANT / HIGH-VALUE`.

## 8. Closed-Technology City

Source owner: `docs/worldbuild/CULTURES_CIVILIZATION.md` §15.

Core problem: knowledge monopoly.

Dependency: specialist knowledge, rare components, external inputs.

Failure: knowledge bottleneck, component dependency, succession failure.

Distinctive test:

`knowledge concentration → specialist succession → component dependence
→ institutional legitimacy / exclusion`.

Trigger: agency/knowledge tests expose specialist concentration as a missing
coupling.

Status: `DORMANT`.

## 9. Refuge City

Source owner: `docs/worldbuild/CULTURES_CIVILIZATION.md` §16.

Core problem: social exclusion and negotiated inclusion.

Dependency: mixed skills, information, water, political tolerance.

Failure: exclusion pressure, factional legitimacy, resource squeeze.

Distinctive test:

`population mixing → boundary practice → resource allocation → legitimacy
→ migration / solidarity / conflict`.

Trigger: social-practice tests need a stronger population-mixing/boundary case.

Status: `DORMANT`.

## 10. Ruin Frontier

Source owner: `docs/worldbuild/CULTURES_CIVILIZATION.md` §17.

Core problem: uncertainty under incomplete access.

Dependency: relics, site knowledge, hazardous access.

Failure: unreliable interpretation, irrecoverable loss, competing preservation /
use claims.

Distinctive test:

`uncertain access → partial evidence → divergent interpretations → action
→ historical residue / contested ownership`.

Trigger: residue/knowledge tests need uncertainty created by incomplete access,
not simply hidden information.

Status: `DORMANT`.

## 11. Cosmic Frontier

Core problem: extreme distance and infrastructure scale.

Dependency: energy, logistics, research, maintenance.

Failure: isolation, scale, extreme maintenance.

Trigger: only after lower-scale regimes fail to express the required coupling.

Status: `LATE / ONLY IF EARNED`.
Unresolved contradiction: lower-scale regimes should be exhausted before any cosmic extrapolation; no activation evidence exists.

## 12. Type separation

Do not flatten these regimes into a single taxonomy with peoples or places.

A later region may be:

```text
REGIME + LINEAGE MIX + INSTITUTIONAL ECOLOGY + PLACE ARCHETYPES
```

The same lineage can exist in multiple regimes; one regime can contain multiple
cultures; a place archetype can recur across regimes.

## 13. Cross-regime transfer card

When reusing a mechanism:

```text
SOURCE REGIME
MECHANISM
INVARIANT
REMOVED DOMAIN CARGO
TARGET REGIME
HIDDEN ASSUMPTIONS
INCOMPATIBILITIES
CHEAPEST FALSIFIER
OBSERVABLE CONSEQUENCE
RESIDUE
DISPOSITION
```

Analogy without changed capability or a revealed limit is not a successful
transfer.

## 14. Activation rule

Activate a dormant regime only when it answers:

```text
What anchor limitation does this expose?
What new material pressure does it introduce?
What new institutional coupling does it require?
What new failure mode appears?
What new human-history shape becomes possible?
What is the cheapest falsifier?
```

No map-completion trigger is valid.

## 15. Preservation rule

Every dormant regime must have:

- source owner(s);
- why it matters;
- why not now;
- reactivation trigger;
- unresolved contradiction(s);
- status/disposition.

Use `PRESERVE | TRIGGERED | REJECTED | SUPERSEDED` for disposition; `DEFERRED` is not semantic forgetting.

A regime may be rejected or superseded. It must not disappear silently.
