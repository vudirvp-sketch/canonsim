# WORLD TRACK — FRONTIER MECHANISMS v4.5

This file is **proposal-only**. It is not canon, not runtime architecture, not
a second workplan, and not an owner document. Its job is to hold high-value
synthesis candidates that can be tested with existing primitives.

Every candidate must strengthen the **world generator**, not compensate for a
missing narrator. The simulator remains causal authority; LLM output remains
read-side/interface unless the repository explicitly defines a non-causal
presentation capability.

## 0. Frontier card contract

Every candidate must be carried through:

`SOURCE → MECHANISM → INVARIANT → TARGET PROBLEM → EXISTING PRIMITIVES →
HIDDEN ASSUMPTIONS → OBSERVABLE CONSEQUENCE → CHEAPEST TEST → FALSIFIER →
OWNER / CONSUMER → DISPOSITION`.

A candidate with no named owner/consumer remains research vocabulary.

## 0A. Product-model admission rule

Reject a candidate when its primary effect is only “better story”. Require a
concrete downstream state/decision/knowledge/resource/relation/permission/future-option
difference. A narrative gain can be a secondary validation signal, never the
causal justification.

## 1. Moving-Meso / World Ignition

### Source / status

Synthesis over D-189 meso assembly, D-196 road-capacity coupling, W4 crew/caravan
space, and existing mobility primitives. **PROPOSAL.**

### Mechanism

Treat a caravan/crew/convoy as a transient heterogeneous meso assembly carrying
partially independent flows:

```text
PEOPLE / ROLES
MATERIAL STOCK
KNOWLEDGE
CLAIMS / OBLIGATIONS
ROUTE / CAPACITY
MAINTENANCE DEPENDENCIES
```

The assembly is not a proposed runtime class. First compose it from existing
actors, carried items, positions, knowledge, relations, travel, market and event
primitives.

### Why it is unusually valuable

One ordinary recurring movement can connect systems that otherwise remain
locally correct but weakly coupled:

```text
ROUTE
→ DELAY / RISK
→ STOCK DIVERGENCE
→ PRICE / OBLIGATION PRESSURE
→ INSTITUTIONAL RESPONSE
→ KNOWLEDGE DISTRIBUTION
→ ACTOR CHOICES
→ RESIDUE
→ NEXT CYCLE
```

The important property is **partial decoupling**. Goods, people, knowledge and
claims do not have to arrive together. That creates lag, misunderstanding,
substitution, inheritance, disputes and reconciliation without adding arbitrary
plot events.

### Cheapest witness

Three locations, three cycles, one route-edge perturbation. Require one downstream
fracture and one persistent residue.

### Falsifiers

- no downstream state/decision changes;
- only travel time changes, with no consumer;
- all flows are forcibly synchronized;
- the witness requires a new global mobility subsystem before a causal effect can be shown.

## 2. Capacity / Fracture Law

`ROUTE EXISTS` does not imply `ROUTE CAN CARRY THE REQUIRED FLOW`.

Perturb one edge:

```text
EDGE CAPACITY Δ
→ REALIZED DELAY
→ STOCK / KNOWLEDGE / OBLIGATION DIVERGENCE
→ QUEUE / SPILLOVER / ABANDONMENT / SCARCITY
→ RESPONSE
→ RESIDUE
```

Never use average utilization alone as the fracture oracle.

## 2A. Functional Corridor / Dependency Cut

### Source / status

Specialized expansion of caravan v3 §2.5/§18.6. **PROPOSAL / diagnostic relation.**

### Mechanism

Geometric route existence does not imply functional viability. A corridor may depend on stationary services, hosts, repair, permission, settlement, or other local conditions.

```text
ROUTE GEOMETRY HELD CONSTANT
→ REMOVE ONE STATIONARY DEPENDENCY
→ REALIZED PASSAGE VIABILITY CHANGES
```

### Invariant

`FUNCTIONAL CONNECTIVITY ≠ GEOMETRIC CONNECTIVITY`.

### Target problem

Routes that look connected in topology but cannot realize the claimed world history.

### Existing primitives

Use existing route/travel, local actors, services, relations, obligations, carried state, and pack-authored gates first. No global corridor object.

### Cheapest test

Choose one dependency (`WATER | HOST | REPAIR | PERMISSION | SETTLEMENT`), remove it before the next cycle, hold topology constant, compare realized passage and downstream state.

### Falsifier

Removing the dependency does not change any reachable future relevant to the corridor consumer.

### Owner / consumer / disposition

Owner: mobility/corridor probe + relevant local domain owner. Consumer: a realized route-dependent downstream effect. Disposition: remain diagnostic until repeated native insufficiency is demonstrated.

## 2B. Mobility Synchronization Latency / Channel Asymmetry

### Source / status

Specialized expansion of caravan v3 §§3, 13–15, 18.9, 22/J. **PROPOSAL / diagnostic relation.**

### Mechanism

Mobility carries partially decoupled channels across time and space. At minimum observe: `BODY | CARGO | WITNESS | CLAIM`. The channel results may diverge.

```text
OBSERVATION
→ CARRIER / DELAY
→ ARRIVAL
→ LOCAL INTERPRETATION
→ ACTION
```

The report may be stale when it arrives; a physical object may arrive without its carrier; a claim may persist after cargo loss.

### Invariant

`ARRIVAL OF ONE CHANNEL DOES NOT PROVE ARRIVAL / FRESHNESS OF ANOTHER`.

### Target problem

False synchronization assumptions that erase latency, stale knowledge, partial delivery, or obligation persistence.

### Existing primitives

Use existing travel, carried state, knowledge, relations, accounts/claims, event log, and observer/read-side separation. Do not create a generic stale-knowledge subsystem.

### Cheapest test

Hold canonical world state fixed until after departure, change the underlying state before arrival, then compare the receiver's authorized knowledge and action. In the same witness, force one channel to fail while another succeeds.

### Falsifier

No legal downstream decision distinguishes fresh state from delayed report, or all channels are intrinsically and necessarily synchronized by the existing substrate.

### Owner / consumer / disposition

Owner: knowledge/mobility probe. Consumers: actual receiver decision, claim, stock, relation, or institutional response. Disposition: diagnostic/test vocabulary only.

## 3. Pool Provenance / Absence Grammar

For any content family whose members can materialize, preserve:

```text
SOURCE POOL
→ LOCAL POOL FILTERS
→ CONTACT / ADMISSION
→ MATERIALIZATION
→ LOCAL CONSEQUENCE
```

A meaningful absence can be authored as an actual consequence of the same grammar.
This is the main guard against arbitrary Atlantis-in-the-sky-city style mixing
without requiring a universal taxonomy.

## 4. Expectation Feedback

```text
EXPECTATION
→ MISMATCH
→ EVIDENCE ACQUISITION
→ INTERPRETATION
→ ACTION
→ UPDATED EXPECTATION
→ RESIDUE
```

Use only where the update changes future options or decisions. Do not create a
generic graph of all beliefs.

## 5. Relationship as Topology

Source-backed D-196/W5 design residue, not a new world primitive. First owner/gate:
heartbreak/W5 relation-formation witness.

Keep the already-routed relation mechanism explicit:

```text
REPEATED CONSEQUENTIAL CO-PRESENCE
× RECIPROCITY
× SELECTIVE DISCLOSURE
→ RELATION
→ ADD / REMOVE / MERGE / SPLIT / SEMANTIC-CHANGE IN OPTIONS
```

The useful output is not a relationship score; it is a change in what actors can
legitimately do next.

## 6. Maintenance Ecology

Existing authored support: maintenance is already a named civilizational pressure
in `CULTURES_CIVILIZATION.md` and a dependency/cost chain in `RESONANCE.md`.
The synthesis below remains **PROPOSAL** and is intentionally narrow.

A narrow recurring physical service can provide a powerful world-pulse witness:

```text
CAPACITY
→ WEAR / FAILURE
→ REPAIR DECISION
→ LABOUR / RESOURCE COST
→ SERVICE RESTORATION
→ KNOWLEDGE / REPUTATION RESIDUE
→ NEXT CYCLE
```

Start from one existing infrastructure leg (road, water, market, ferry, archive)
and only retain the mechanism if it changes future decisions.

## 7. Cross-Domain discipline

For every frontier candidate:

```text
SOURCE
→ MECHANISM
→ INVARIANT
→ REMOVE CARGO
→ TARGET PROBLEM
→ HIDDEN ASSUMPTIONS
→ ADAPTATION
→ OBSERVABLE CONSEQUENCE
→ CHEAPEST DISCRIMINATING TEST
→ EVIDENCE
→ SCOPE / TRANSFER
→ DURABLE RESIDUE
```

See the standing Cross-Domain Agent Instruction. The repository's existing
promotion gate remains binding.

## 8. Promotion checklist

Before any candidate leaves this file, require:

- real current failure or explicit unresolved capability;
- existing primitive / pack-data expression attempted first;
- named consumer and owner;
- realized intervention and observable consequence;
- counterexample or ablation path;
- held-out transfer where the claim is general;
- no duplicated canonical store / universal graph / generic scheduler;
- durable residue only if it changes a future decision.
