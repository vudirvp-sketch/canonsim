# WORLD TRACK — PROBES, GATES, AND AGENT PROCEDURES v4.5

## 0A. Owner-surface rule

A probe is a measurement contract, not a feature request. Each run must name the
owner surface it consumes (`WORLD_WORKPLAN`, `WORLD_TESTS`, `WORLD_AUTHORING`,
`ANCHOR_REGION`, or the relevant domain owner) and route any substrate finding
back to that owner.

## 1. World liveness probe

### Question

Is an authored causal family actually alive, or only present as event/render
surface?

### Procedure

```text
REALIZED RUN
→ IDENTIFY CLAIMED CAUSAL LEG
→ READER / CONSUMER AUDIT
→ ABLATION
→ RE-FOLD / RE-RUN
→ INJECTION (where safe)
→ COMPARE REACHABLE FUTURE
```

### Record

```text
PRESSURE
REALIZED RESPONSE
CONSUMER
DOWNSTREAM STATE
RESIDUE
NEXT-CYCLE EFFECT
ABLATION DELTA
INJECTION DELTA
FIRST DIVERGENCE
DISPOSITION
```

### Pass

Removal changes a meaningful reachable future and the claimed consumer path is
real.

### Fail classes

`SURFACE_ONLY | MISSING_CONSUMER | LOD_BOUNDARY | GATE_BOUNDARY |
CONTENT_BOUNDARY | SUBSTRATE_LIMIT | TEST_DEFECT`

## 2. Admissibility / contact probe

### Question

Why is this entity/practice/knowledge/technology allowed to appear in this
region or interact with this institution?

### Matrix

| Test | Expected status |
|---|---|
| normal local case | REQUIRED/COMPATIBLE |
| compatible outsider | COMPATIBLE |
| rare outsider | CONDITIONAL/RARE + contact path |
| unsupported outsider | INACCESSIBLE/FORBIDDEN |

### Record

```text
SOURCE
TARGET
CONTACT PATH
ENTRY CONDITIONS
COMPATIBILITY
EXCEPTION CLASS
RESIDUE
REPEATABILITY
```

### Pass

Every non-local placement has a causal provenance or is explicitly rejected.

## 3. Causal Passport

Use for unusual contacts, not routine local entities.

```text
SOURCE DOMAIN
SOURCE HOLDER
CONTACT EVENT / PATH
TRANSPORT / HANDOVER
LOCAL ADMISSION CONDITIONS
KNOWLEDGE DISTRIBUTION
RESOURCE / HABITAT COMPATIBILITY
EXCEPTION CLASS
RESIDUE
NEXT-CYCLE CONSEQUENCE
```

Do not turn this into runtime state unless a repeated consumer proves it is needed.

## 4. Agency probe

Use only after liveness is established.

```text
PROBE
CANONICAL EVENT
ACTOR
GOAL
KNOWLEDGE
BELIEF (if represented)
CONSTRAINTS
AVAILABLE OPTIONS
OBSERVED CHOICE
EXPECTED OUTCOME
ACTUAL OUTCOME
FUTURE-STATE CHANGE
LATER UPDATE
READER TEST
VERDICT
```

### Pass

The choice is actor-specific, alternatives are plausible, the action changes
future state, and the explanation does not require hidden author knowledge.

## 5. Social practice probe

```text
PRACTICE
PRECONDITIONS
ROLES
AFFORDANCES
NORMS
TABOOS
DEVIATIONS
MATERIAL CARRIERS
KNOWLEDGE CARRIERS
CONSEQUENCES
RESIDUES
INTERLOCKS
FUNCTION-LOSS TEST
VERDICT
```

A practice is worth retaining only if removal changes a real function or future.

## 6. Institutional reproduction probe

### Minimum run

```text
CYCLE 1
→ RESIDUE
→ CYCLE 2 UNDER ALTERED CONDITIONS
→ TURNOVER / SUCCESSION
→ CYCLE 3
```

### Required observations

- at least one changed condition from prior residue;
- at least one lawful deviation;
- one turnover/succession event or carrier substitution;
- one failure or repair branch where applicable;
- an ablation that changes a meaningful later outcome.

### Failure

Repeated identical surface events with no history-sensitive condition are not
proof of institutional life.

### Continuity discriminator

After turnover/carrier replacement, classify the result as: 

```text
FUNCTION COLLAPSES
→ PERSON-DEPENDENT

FUNCTION SURVIVES WITH DRIFT
→ CANDIDATE INSTITUTIONAL CONTINUITY
```

Do not treat carrier turnover itself as proof of an institution; the surviving function must have a real consumer.

## 7. Stateful cadence probe

Use for market days, fairs, maintenance rounds, water allocation, caravans,
convoys, archive transfer, seasonal labour, or similar cycles.

```text
CYCLE N
→ WHAT WAS CONSUMED?
→ WHAT WAS CHANGED?
→ WHAT REMAINS?
→ CYCLE N+1
→ WHAT IS DIFFERENT BECAUSE OF N?
```

Law:

> Cadence consumes history.

For durable functions, also record `CURRENT CARRIER → SUCCESSOR / REPLACEMENT →
CONTINUITY OR BREAK`. This is a turnover test, not a generic lifecycle engine.

## 8. Heterogeneous institutional agency probe

```text
AGGREGATE
→ SUBGROUPS
→ KNOWLEDGE DIFFERENCES
→ INCENTIVE DIFFERENCES
→ COORDINATION
→ INTERNAL CONFLICT
→ OBSERVED AGGREGATE EFFECT
```

Use only where the aggregate abstraction hides materially different options or
responses.

## 9. Knowledge-circulation probe

```text
TRUTH
→ WITNESS
→ KNOWLEDGE RECORD
→ TRANSFER
→ INTERPRETATION
→ ACTION
→ RESIDUE
```

### Pass

Different epistemic positions lead to different lawful decisions or institutional
responses.

### Reject

“Mystery” exists only because the reader was denied the answer, with no decision
or causal consequence.

## 10. Historical residue probe

```text
EVENT
→ RESIDUE
→ CARRIER
→ HOLDER
→ TRANSFORMATION
→ TRANSFER
→ INHERITANCE / CLEARANCE
→ NEW OPTION
→ NEXT PRESSURE
```

Delete one meaningful transition and verify future divergence.

### Route-memory discriminator

For a recurring corridor, test whether prior passage changes later conditions rather than merely leaving a historical record:

```text
PASSAGE #1
→ RESIDUE
→ CHANGED CONDITION
→ PASSAGE #2 / #3 DIFFERS

ABLATE PASSAGE #1
→ LATER FUTURE DIVERGES
```

If ablation removes no later causal difference, classify the residue as non-causal history/observation rather than route memory.

## 11. Mobility / corridor probe

```text
RECURRENT CONSTRAINED PASSAGE
→ HANDOVER
→ RESIDUE
→ ALTERED NEXT CYCLE
```

Test it first on one ordinary route/caravan-like mechanism. Then use held-out
contexts to determine whether the invariant transfers to another domain.

Potential targets:

`road corridor | maritime convoy | specialist rotation | archive transfer |
sky supply | refugee corridor | maintenance chain`

Do not create a generic “mobility subsystem” from analogy alone.

### Specialized discriminators

**Functional cut**

```text
HOLD ROUTE TOPOLOGY CONSTANT
→ REMOVE WATER / HOST / REPAIR / PERMISSION / SETTLEMENT
→ COMPARE REALIZED PASSAGE
```

Pass only if the removed dependency changes a real reachable future. This is a read-side/test relation, not a runtime corridor object.

**Return asymmetry**

```text
OUTBOUND SUCCESS
≠
RETURN SUCCESS
```

Test cases such as `BODY OUT / CARGO BACK`, `BODY BACK / CLAIM FORWARD`, or `WITNESS OUT / CARGO RETURN`. Do not infer symmetric continuity from outbound realization.

**Travel price vs institutional cost**

Keep separate:

```text
TRAVEL PRICE = existing edge-local travel duration / traversal cost
INSTITUTIONAL COST = evidenced obligations + service + knowledge + risk + missed-plan consequences
```

Do not create or infer a universal mobility-cost scalar.

## 12. Mobility capacity / fracture probe

### Question

Does a route actually function as a capacity-bearing flow, or is the mobility
claim only route existence?

### Procedure

```text
BASELINE ROUTE
→ PERTURB ONE EDGE / ADMISSION CONDITION
→ MEASURE REALIZED DELAY / LOSS
→ TRACE STOCK + KNOWLEDGE + OBLIGATION DIVERGENCE
→ OBSERVE INSTITUTIONAL / ACTOR RESPONSE
→ NEXT-CYCLE EFFECT
```

### Accepted fracture oracles

`QUEUE | SPILLOVER | ABANDONMENT | LOCAL SCARCITY | PRICE/OBLIGATION CHANGE`.

Average utilization alone is not sufficient.

### Record

`CAPACITY | REALIZED DELTA | AFFECTED FLOWS | FIRST DIVERGENCE | RESPONSE | RESIDUE |
NEXT-CYCLE CHANGE | HELD-OUT CONTEXT`.

## 12A. Anti-arbitrage / stock-exchange probe

Use only when an economy witness claims that one stock can be converted into
another. Test whether the transformation preserves a real loss/constraint rather
than creating arbitrary abundance.

```text
INPUT STOCK
→ EXCHANGE / TRANSFORMATION
→ LOSS / FRICTION / CONSTRAINT
→ OUTPUT STOCK
→ DOWNSTREAM PRICE / LABOUR / OBLIGATION CHANGE
```

Pass only if the loss/constraint has a named owner and downstream consumer. Do
not introduce a global market-balance primitive merely to enforce this.

## 13. Pool / role provenance probe

For a materialized pool, record:

```text
SOURCE POOL
→ LOCAL POOL CONDITIONS
→ CONTACT / ENTRY PATH
→ ADMISSION CONDITIONS
→ MATERIALIZATION
→ LOCAL CONSEQUENCE
→ RESIDUE
```

Also record the intentional absence of important incompatible alternatives **only
when that absence is a causal/authored claim**. The absence must follow from the
same local admission constraints, not from a global ban invented for convenience.
A rare outsider without a provenance path fails the probe even if the generated
content would be interesting.

## 14. Influence-boundary probe

### Question

Can an actor react to another entity's hidden internal state without observing a
legal marker?

### Procedure

```text
FIX PUBLICLY OBSERVABLE SURFACE
→ SWAP HIDDEN OTHER-STATE
→ RE-RUN AUTHORIZED DECISION
→ COMPARE
```

### Pass

No authorized actor-specific result changes until the changed fact becomes
observable and enters knowledge. Use the repository's existing perception/knowledge
surfaces; do not add an omniscient world graph.

## 15. Expectation / mismatch probe

```text
EXPECTATION
→ MISMATCH
→ EVIDENCE ACQUISITION
→ INTERPRETATION
→ ACTION
→ UPDATED EXPECTATION
→ RESIDUE
```

Pass only if the mismatch changes a future option, decision, relation, institution,
resource, or investigation path.

## 16. Relation-formation / option-topology probe

Use the existing winter-kin mechanism as the first witness:

```text
REPEATED CONSEQUENTIAL CO-PRESENCE
× RECIPROCITY
× SELECTIVE DISCLOSURE
→ RELATION
→ OPTION TOPOLOGY CHANGE
```

Measure an `ADD / REMOVE / MERGE / SPLIT / SEMANTIC-CHANGE` in future legal/social
options. Reject generic relationship meters unless a separate failure demands one.

## 16A. Maintenance / service-ecology probe

Proposal-only. Begin from an existing service-bearing leg (road, water, ferry,
market, archive, habitat).

```text
SERVICE CAPACITY
→ WEAR / FAILURE
→ REPAIR / SUBSTITUTION DECISION
→ LABOUR / MATERIAL COST
→ RESTORATION OR DEGRADATION
→ KNOWLEDGE / REPUTATION RESIDUE
→ NEXT-CYCLE CHANGE
```

Pass only when an existing reader/decision changes. Do not create a global
maintenance subsystem because a dormant regime mentions maintenance.

## 17. Moving-meso / world-ignition witness

Run the smallest caravan/crew/convoy-like assembly expressible with existing
primitives for at least three cycles. Track independently:

`PEOPLE/ROLES | MATERIAL STOCK | KNOWLEDGE | CLAIMS/OBLIGATIONS`.

At least one perturbation must alter route delay or admission. Require a downstream
divergence, a response, residue, and a changed next cycle. Record whether people,
material stock, knowledge, and claims/obligations remain partially decoupled in
time; forced synchronization is a failure of the witness.

The assembly is a probe composition, not a proposed runtime type.

### Channel record

Record independently:

```text
BODY: arrived / delayed / lost
CARGO: arrived / delayed / lost
WITNESS: current / stale / lost
CLAIM: transferred / unresolved / lost
```

A partial result is expected; forced synchronization is a witness failure.

### Negative-result interpretation

```text
NO RESIDUE / NO FUTURE DELTA
→ recurrence may be decorative or currently unconsumed

CARRIER REMOVAL → TOTAL FUNCTION LOSS
→ person-dependent coupling is evidenced

ROUTE REMOVAL → NO DOWNSTREAM CHANGE
→ no demonstrated consumer at the tested resolution
```

Do not convert any of these results into a failure of the test merely because the intended mechanism did not appear.

## 18. Third-order synthesis probe

For mechanisms A and B, record:

```text
A IMPROVES B?
A CONSTRAINS B?
A EXPOSES B'S HIDDEN ASSUMPTION?
B REVEALS NEW USE OF A?
A+B COLLAPSE INTO EXISTING PRIMITIVE?
A+B CREATE NEW CAPABILITY?
```

Then falsify the composite. Prefer a synthesized construction only when it
matches or exceeds the material advantages of parents while removing at least
one material disadvantage.

## 19. W6 genre evidence

For each genre package:

```text
GENRE
CANONICAL PACKAGE
ENTRY CONDITIONS
ACTORS
KNOWLEDGE DISTRIBUTION
PRESSURE
CHOICES
CONSEQUENCES
RESIDUES
NARRATIVE CORE
READER RESULT
FAILURE CLASS
MISSING CAPABILITY
OWNER DECISION
```

Allowed failure classes:

`CANONICAL_GAP | DISCOVERY_PATH_GAP | RENDERING_GAP | CONTENT_GAP |
SUBSTRATE_GAP | TEST_GAP | LIVENESS_GAP | ADMISSIBILITY_GAP`

Never patch the intended plot to rescue a failed substrate test.

## 20. Narrative polysemy probe

Hold one canonical event sequence fixed and test multiple readings:
`mystery | politics | relationship | tragedy | comedy | biography | adventure`.

Pass only when the variation comes from bounded knowledge, values, position, or stakes rather than changed facts.

## 21. W7 negative/compression gate

For every newly justified mechanism:

```text
WHY POSSIBLE?
WHY NOT UNIVERSAL?
WHAT DID IT REPLACE?
WHAT DID IT MAKE HARDER?
WHO PROFITS?
WHO RESISTS?
WHO REMEMBERS THE TRANSITION?
WHAT IF IT DISAPPEARS?
```

Then remove decorative structure and merge duplicate functions.

## 22. W8 integration gate

Require:

1. authored causal substrate;
2. one or more demonstrated meso units;
3. pack expression or a named justified substrate gap;
4. ordinary event → persistent human consequence;
5. explicit knowledge asymmetry where relevant;
6. world-specific material outside core ontology;
7. proof state separated from hypothesis;
8. liveness evidence strong enough to trust the next experiment;
9. dormant regime memory intact;
10. enough genre/agency evidence to justify generalization.

## 23. Second-region gate

Do not start a second region until the selected candidate has:

- a demonstrated anchor limitation;
- a new material pressure;
- a new institutional coupling;
- a distinct failure mode;
- a distinct human-history shape;
- a transferred-mechanism hypothesis;
- an incompatibility list;
- a cheapest falsifier.

## 24. Runtime-promotion gate

A new runtime primitive requires:

`REAL CONSUMER + REAL FAILURE + MATERIAL QUALITY GAP + NATIVE LIMIT +
REPEATED SHAPE + FALSIFIER + OWNER + PHASE/GATE`

Otherwise keep the result as pack data, test logic, authoring vocabulary, or
research.

## 25. Agent completion contract

Every finished world-track research session ends with:

1. Question.
2. Current verdict.
3. Evidence.
4. Competing explanation(s).
5. Cheapest discriminating test.
6. First divergence / material delta.
7. Remaining uncertainty.
8. Routing consequence.
9. Next verification step.

## 26. Compact decision vocabulary

```text
KEEP
PROBE
EMBODY
DEFER
REJECT
SUPERSEDE
ROUTE TO ENGINEERING
ROUTE TO AUTHORING
ROUTE TO TESTING
```

Use the smallest disposition justified by evidence.

### 26A. Caravan status handling

Caravan v3 claim type, repository disposition, and test result are orthogonal. Do not one-to-one map them; see `05_SOURCE_CROSSWALK.md` §7C.

## 27. Final agent rule

When a proposed world feature looks exciting, do not ask first:

> “How do we build it?”

Ask:

> “What world failure or missing coupling would this feature discriminate,
> what existing mechanism already covers it, and what is the cheapest test that
> would prove whether the feature changes reachable futures?”
