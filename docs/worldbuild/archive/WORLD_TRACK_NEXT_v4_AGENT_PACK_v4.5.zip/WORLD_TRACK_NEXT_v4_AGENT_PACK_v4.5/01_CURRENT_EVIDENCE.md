# CURRENT WORLD-TRACK EVIDENCE

This file is intentionally evidence-heavy and compact. It prevents the master
strategy from becoming a substitute for the actual measured state.

## Audit snapshot

The uploaded repository snapshot is `iter-272`, commit
`8ec6442d8406d901a0605175474bbd61dd3954da`. This bundle's detailed causal
evidence below remains intentionally bounded to D-236–D-240 plus the named W4/W5
evidence; it is not a substitute for the current repository owner documents.
Do not infer that an older measurement table is the latest implementation state.


## Evidence boundary for v4.5

**Source-backed current evidence:** D-236 through D-240, W4/W5 records, and the
owner documents named in this bundle.

**Synthesis proposals introduced by this bundle:** Moving-Meso / World Ignition,
pool/role provenance + meaningful absence, expectation-feedback expansion, and
maintenance ecology. These are not claimed as already-proven mechanisms.

Maintenance is nevertheless an existing authored pressure in the dormant design
space (`CULTURES_CIVILIZATION.md` mountain/industrial and deepwater/sky material;
`RESONANCE.md` maintenance/dependency chains). The proposal is to test one narrow
consumer-bearing instance rather than introduce a generic maintenance engine.

### Current owner-state pointer

The uploaded repository has advanced beyond D-240: W5 owner work has landed
additional pack-only embodiment surfaces through iter-272. Treat
`docs/worldbuild/WORLD_WORKPLAN.md`, `WORLD_TESTS.md`, and `ANCHOR_REGION.md` as
the current state owners. This bundle preserves D-237–D-240 because those
measurements are useful diagnostic evidence for the liveness boundary.

## D-236 — temp-1 owner contract state that still matters to world-track interpretation

The owner decision was `A2 + B2/B3`, with `B1` deferred. The crossing-family equivalence arm is contract-tested; B2/B3 keep existing temporal/provenance semantics through the current primitive; B1 `generate-at-T` remains a deferred proposal. World-track work must not silently reopen this engine contract.


## W4/W5 evidence retained from the prior world-track memo

W4 is not merely “meso units exist”. The current working set is four specific units:

- crossing household;
- step bench / water-governance practitioner;
- winter kin / constructed kinship edge;
- camp / charcoal debt.

These units are important because they demonstrated new causal couplings from existing primitives, function-loss/ablation discipline, carrier availability/verb-gate boundaries, residue lifecycle, and turnover/succession effects.

W5 status remains asymmetric:

- biography: clean probe passed;
- humor: mechanism-grounded and human-band reading received, station still not globally closed;
- heartbreak: mandatory pair met after rendering/re-subjectivation fixes, station remains partially confirmed with discovery-path residues still open.

Open W5 owner questions remain explicit: fail-then-pass / 40-80 discovery-path asymmetry, runner/grudge residue, and shave temporal placement / arc assembly. These are not canon facts merely because they recur in probes.

## D-237 — integrated composition witness

Source: `docs/blueprint/phases.md` §6, iter-261.

Observed:

- province composition used existing verbs and no new content;
- one deterministic run produced 2371 events;
- 16 relational oracles covered the integrated witness;
- six interacting causal families crossed end-to-end;
- a year-scale calendar/seasonal witness and macro-economic flows were present;
- 383 autonomous resolutions carried the origin field;
- one measured OCC miss existed on the timing arm;
- the A–H census over the composition run was `A1 · B3 · C5 · D1 · E2 · F0 · G0 · H10`;
- losses concentrated in assignment/consequence/content boundaries, not scheduler
  failure;
- the H1/H2 sliced pair showed material trajectories invariant at the measured
  substrate while door-level checks changed with deferral span.

Interpretation:

- the substrate can compose multiple families without a plot subsystem;
- timing semantics are real but not yet a general production consumer;
- the main world-track risk is causal density/consumer closure, not “more events”.

## D-238 — composition diagnosis

Observed:

- D-237 observations reproduced;
- removing all 52 calendar turns and all five institutional events from the
  realized log left the final projection byte-identical;
- those events were therefore causally inert on the measured projection even
  though they participated in chronological cause chains;
- `wait` dropped authored knowledge blocks even though the pack admitted them;
- the `wait` knowledge mint was fixed and regression-pinned;
- the proposed calendar gating of market/fair openings was rejected as cosmetic;
- `J-3` road-fear was **closed as a non-gap / rejected embodiment target**: the
  relevant LOD/decay behavior prevents the intended downstream threshold from
  being reached. It remains a substrate-density/LOD observation, not a missing
  urgency mechanic.

Interpretation:

- static/event existence is not causal relevance;
- a world component needs a consumer, not merely a producer or story line;
- liveness diagnosis must distinguish content, consumer, LOD, gate, and scheduler
  failure modes.

## J-1/J-2/J-3 diagnosis retained from D-238

The diagnosis is important because it defines the current liveness boundary:

- after Malby burned, `market_opens` remained `36/36` and `fair_opens` `12/12` on the ash; neither had runtime consumers beyond tale/read surfaces; the economic calendar path was not actually gated by market state;
- the institutional `guild_councils` / `wergeld_vigil` events were realized but had empty canonical `state_changes` / `knowledge` / `hooks` in this witness; their material value was intentionally on a read-side surface unless a real carrier leg was later embodied;
- the proposed road-fear urgency was **REJECTED as a material gap**: the measured road actors are ambient/off-stage, max fear remained 10, and decay-before-rolls plus LOD made the proposed threshold structurally unreachable. It remains a density/LOD observation, not a missing urgency mechanic.

The correct response to J-1/J-2 was not separate cosmetic fixes. The evidence exposed a single carrier problem later resolved per-leg in D-239/D-240.

## D-239 — carrier vs surface

Observed:

- the three-move discriminator was adopted: reader audit → ablation → injection;
- the verdict is per-leg, not per-institution;
- some market legs are live carriers;
- some economic/reader legs are state/read carriers;
- the calendar line is surface-only by construction because no consumer path
  exists;
- knowledge legs around council/vigil and briefing were measurable carriers;
- no new runtime primitive was required by the tested market question.

Interpretation:

> Representation does not make an entity causal. Causal status is earned by
> changed reachable futures.

This is the direct empirical basis for the v4 liveness law.

## D-240 — market-leg embodiment

Observed:

- market mourning hook landed as pack data;
- trigger-only behavior was enforced so triggered weight-0 ambient hooks did not
  leak into the quiet path;
- a market trade verb was expressed through existing gates;
- council/vigil knowledge blocks became live authored residues;
- composition deltas matched prior D-239 predictions;
- the market remains an authored meso/carrier unit;
- one render-side conditional remains owner-gated;
- no core change was required.

Interpretation:

- the market example validates the pattern “carrier leg + explicit consumer +
  pack-only embodiment”;
- render contradiction is not a reason to mutate calendar canon.


## Sarrow causal mesh — retained exact family memory

The anchor mesh remains eight named families:

`fire → institutional response`; `feud residue → present politics`; `season → weather → social signal`; `route → condensation → culture`; `credit/debt`; `step/water-governance`; `winter kinship`; `camp/charcoal debt`.

The disable test and shared-stage anti-double-count rule remain governing authoring/test laws.

## What this evidence does NOT prove

It does not yet prove:

- a universal world-liveness architecture;
- universal institutional reproduction;
- general cross-regime admissibility;
- full agency reconstruction;
- multi-region generalization;
- a production need for B1 `generate-at-T`;
- that every existing world institution is causally live.

## Required next measurements

1. One recurring institution with a real consumer and at least three cycles.
2. One controlled contact/admissibility matrix.
3. One fully realized actor choice with alternatives.
4. One held-out W6 genre package after the above gates.

## Evidence rule

A measured failure should be classified before repair:

`CANONICAL_GAP | DISCOVERY_PATH_GAP | RENDERING_GAP | CONTENT_GAP |
SUBSTRATE_GAP | TEST_GAP | LIVENESS_GAP | ADMISSIBILITY_GAP`

The last two labels are v4 routing labels, not a replacement for existing test
vocabulary; they identify the world-track question before owner routing.
