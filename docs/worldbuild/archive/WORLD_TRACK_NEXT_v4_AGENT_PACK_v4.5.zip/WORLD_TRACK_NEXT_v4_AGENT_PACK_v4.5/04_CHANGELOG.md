## v4.5

1. Added `00_PROJECT_CONSTITUTION.md`: compact product-model alignment for agents.
2. Reframed World Track explicitly as causal-substrate / authored-setting work, not LLM plot generation.
3. Made the simulator-vs-LLM authority boundary explicit: simulator = canon/causality; LLM = interface/interpretation.
4. Added the embodied-player rule and the autonomous-world requirement to the agent navigation surface.
5. Added a narrative/read-side admission rule: prose quality cannot substitute for a causal consumer or persistent world consequence.
6. Updated snapshot pointer to uploaded `iter-272` while preserving D-237–D-240 as historical measurement evidence.

# WORLD TRACK NEXT v4.5 — CHANGELOG / AUDIT CORRECTIONS

## Compared with v4

1. **Authority correction:** the pack is now explicitly a derived external navigation bundle, not a second project-memory / source-of-truth document.
2. **D-238 wording correction:** the J-3 road-fear proposal is recorded as a structurally dead proposed path / rejected embodiment target, not as a confirmed “real gap”.
3. **D-236 restored:** temp-1 owner contract state `A2 + B2/B3`, `B1 deferred` is preserved so world-track agents do not silently reopen temporal semantics.
4. **W4 restored explicitly:** crossing household, step bench, winter kin, camp/charcoal debt.
5. **W5 residual state restored:** biography clean; humor/heartbreak partially confirmed; discovery-path and shave/arc questions preserved.
6. **Eight-loop mesh names restored** as exact design memory.
7. **Narrative polysemy restored** as a distinct read-side probe.
8. **Research-method memory restored:** emergent narrative, intentional agents, social practices/affordances, storylets, cautious drama management, plus the cross-domain method.
9. **Evaluation axes restored:** artifact class + failure class + mechanism questions.
10. **Dormant status discipline strengthened:** source owners, why-not-now, triggers, contradictions, and explicit disposition vocabulary.
11. **Intake routing corrected and made precise:** intake-36=D-196, intake-37=D-197, intake-38=D-199, intake-39=D-231/D-232, intake-40=D-233, with D-236 separately preserved.
12. **Source crosswalk added:** `05_SOURCE_CROSSWALK.md` provides the no-loss audit trail.

## What remains intentionally compressed

The pack does not duplicate owner documents such as `WORLD_WORKPLAN.md`, `WORLD_TESTS.md`, `WORLD_AUTHORING.md`, `CULTURES_CIVILIZATION.md`, or `PEOPLES.md`. Their detailed mechanics stay at their owner surfaces; the pack preserves navigation, evidence status, routing, and probe shapes only.

## v4.3 audit-driven additions

13. **Snapshot pin added:** the bundle names the exact repository commit used for the audit.
14. **Agent-surface map added:** current snapshot has `docs/worldbuild/`, not a literal `worldbuilder/` directory; the practical owner/agent chain is recorded.
15. **Intake 32–35 restored to the navigation crosswalk:** no-loss means explicit `ABSORBED/DEFERRED/REJECTED/SUPERSEDED`, not silent omission.
16. **D-196 world residues surfaced:** relation formation, road-traffic capacity/fracture, denominator integrity.
17. **Mobility strengthened:** route existence is separated from capacity; queue/spillover/abandonment and downstream response become the fracture oracle.
18. **Moving-meso/world-ignition witness added:** one recurring caravan/crew/convoy-like witness can exercise mobility, cadence, admissibility, knowledge, agency, institutions and residue before opening new subsystems.
19. **Pool provenance and meaningful absence added:** protects against arbitrary cross-regime/content-pool mixing.
20. **Expectation-mismatch feedback added:** expectation → mismatch → evidence → interpretation → action → update.
21. **Influence-boundary rule explicitly referenced:** use the repository's existing perception/knowledge boundary rather than introducing omniscient state access.
22. **Stateful-cadence admission law strengthened:** a recurring event must consume history and name a real downstream reader/decision.
23. **Status wording normalized:** `PARTIALLY CONFIRMED` is used consistently with repository vocabulary.
24. **`06_FRONTIER_MECHANISMS.md` added:** proposal-only synthesis candidates; never an authoritative owner surface.


## v4.3 correction pass

25. **Owner-anchor map added:** active proposals now point back to `WORLD_AUTHORING`,
`WORLD_WORKPLAN`, `WORLD_TESTS`, `ANCHOR_REGION`, domain owners, and `phases.md` §6.
26. **Source/synthesis boundary made explicit:** D-196 residues are restored source
memory; Moving-Meso, provenance/absence, expectation feedback, and maintenance
ecology remain synthesis proposals.
27. **Stateful cadence strengthened with turnover:** recurring functions must name
carrier replacement/succession where the function is durable.
28. **Anti-arbitrage made operational:** the D-191 residue is now an explicit
economy probe, not merely a crosswalk note.
29. **Maintenance provenance corrected:** maintenance ecology is anchored in existing
`CULTURES_CIVILIZATION.md` / `RESONANCE.md` material but remains proposal-only.
30. **Probe contracts tightened:** every new frontier probe now names owner surface,
consumer, and falsifier requirements.
31. **Frontier card contract added:** no synthesis candidate can silently become an
implementation requirement.
32. **No-loss routing strengthened:** intake rows now carry an explicit first-owner /
gate destination instead of only a disposition label.
33. **Version/snapshot consistency rechecked:** v4.3 is pinned to `iter-264` /
`980c3f5e03672a485f812ee9b3bc9e4e12fae3cb` because that is the HEAD contained in
`15151canonsim.zip`.


## v4.4 — Caravan mobility integration

34. **Full-source preservation:** added `07_CARAVAN_MOBILITY_DOSSIER.md` containing the complete caravan v3 source body after a compact integration header.
35. **Selective absorption:** only non-duplicative discriminators were integrated into active navigation: functional corridor/dependency cut, route-memory ablation, carrier-vs-institution continuity, synchronization latency, channel asymmetry, return asymmetry, travel-price vs institutional-cost separation, and negative-result interpretation.
36. **Frontier additions:** `06_FRONTIER_MECHANISMS.md` adds two specialized proposal cards: `Functional Corridor / Dependency Cut` and `Mobility Synchronization Latency / Channel Asymmetry`.
37. **Probe strengthening:** `03_PROBES_AND_GATES.md` extends institutional reproduction, historical residue, mobility, and moving-meso probes without introducing a new mobility runtime layer.
38. **Status discipline:** claim type, repository disposition, and test result are explicitly treated as separate axes; caravan labels are not mechanically mapped to repository status.
39. **No-loss routing:** `05_SOURCE_CROSSWALK.md` records the full source preservation and the exact retained/deferred residues.
40. **No runtime promotion:** no caravan-specific runtime primitive, global mobility score, route-history store, route reputation scalar, or civilizational regime was promoted.

41. **Master strategy updated:** `WORLD_TRACK_NEXT.md` now carries only the compact mobility discriminators and source routing; full caravan detail remains externalized to `07_CARAVAN_MOBILITY_DOSSIER.md`.
