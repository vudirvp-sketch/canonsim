# CanonSim Core / World Agent Suite v1.0

This archive is the synchronized, non-duplicating agent handoff surface built
from:

- `CANONSIM_CORE_WORLD_AGENT_PACK_v1.3`
- `WORLD_TRACK_NEXT_v4_AGENT_PACK_v4.6`

It is a **portable derivative**, not a new repository source of truth.

## Ownership split

```text
CORE_WORLD
  → cross-cutting semantic authority
  → execution / scale POCs
  → LLM / observation boundary
  → generic agent/research routing
  → shared history/replay/equivalence questions

WORLD_TRACK
  → W-stage status and sequence
  → current world evidence
  → world-specific probes and gates
  → frontier mechanisms
  → caravan mobility dossier
  → dormant civilizational memory
  → intake/D provenance
```

## Deliberately not duplicated

The suite does not create parallel:

- world workplans;
- engine task queues;
- canonical stores;
- generic knowledge/causal graphs;
- relationship engines;
- LLM plot authority;
- second TEST_PLAN;
- generic liveness/story/confidence systems.

Where a concept crosses both layers, the narrower owner remains authoritative and
the other layer references it.

## Read order

1. `SYNC_MATRIX.md`
2. `CORE_WORLD/00_README.md`
3. `WORLD_TRACK/00_README.md`
4. Relevant owner document in the repository.
5. Only then load detailed frontier/probe/dossier material.

## Authority

Repository owner documents, runtime code, tests, event history and decisions
remain authoritative. This suite is an agent navigation and research handoff.
