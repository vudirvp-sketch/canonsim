# CANONSIM — PROJECT MODEL / CONSTITUTION

This is a compact **product-model alignment layer** for agents using this
World Track bundle. It does not override `AGENTS.md`, runtime code, tests,
`docs/worldbuild/`, or their owner documents.

## 1. Product identity

Canonsim is a **deterministic living-world simulation core**.

Its primary job is to generate an autonomous world and its history through
rules, actors, constraints, resources, institutions, knowledge, events and
persistent consequences.

The simulation must be capable of being interesting **without a player and
without an LLM**.

```text
SIMULATOR → WORLD CAUSALITY / CANON
LLM       → HUMAN INTERFACE / INTERPRETATION
```

## Cross-pack scope

The detailed cross-cutting LLM/observation and semantic execution contracts live in `CANONSIM_CORE_WORLD_AGENT_PACK_v1.3`. This constitution keeps only the product-model boundary needed to interpret World Track work; it does not create a second core architecture.

## 2. Causality boundary

The simulator determines what actually happens:

- state changes;
- events and outcomes;
- relationships and permissions;
- resource / ownership changes;
- knowledge and institutional consequences;
- persistent residue;
- changed future conditions.

The LLM does not author canonical causality.

## 3. LLM role

The LLM is a language interface and narrative interpreter. It may:

- parse player language into structured intent;
- render canonical state/events into prose;
- provide dialogue and voice;
- provide viewpoint, perception and sensory texture;
- enrich non-causal descriptive detail.

It must not:

- decide simulation outcomes;
- invent canonical events or hidden state;
- override constraints;
- force NPC behaviour;
- retroactively alter history;
- invent unsupported causal motives as fact.

**Presentation may be richer than stored simulation detail; causality may not.**

## 4. Player model

The player is an **embodied canonical actor**, not an external author or god.

Natural language expresses intent; the simulation resolves the consequential
result under the same world rules and constraints that govern other actors.

```text
PLAYER LANGUAGE
→ LLM / INTENT INTERPRETATION
→ STRUCTURED INTENT
→ SIMULATOR
→ OUTCOME
→ CANON
```

Entering, leaving and later re-entering the world must expose genuine accumulated
change rather than a paused or plot-staged world.

## 5. Story principle

Canonsim is a **story generator, not a storyteller**.

No hidden runtime plot is required to produce narrative. History emerges from
interaction among systems and actors. Narrative is a read-side interpretation
of that history.

Avoid runtime systems whose actual authority is:

- plot generation;
- scripted story arcs;
- drama forcing;
- LLM game-master decisions;
- prose-based causal repair.

## 6. Worldbuilding boundary

Worldbuilding defines causal possibility and constraint:

```text
WORLDBUILDING
→ WHAT CAN EXIST / HAPPEN / MATTER
→ SIMULATION
→ WHAT ACTUALLY HAPPENS
→ LLM PRESENTATION
```

Worldbuilding must not become a disguised quest, scene, plot, or character-arc
script.

## 7. World Track responsibility

World Track exists to strengthen the **causal substrate and authored setting**
that allow many different human histories to emerge.

Its default direction is:

```text
PRESSURE
→ ACCESS / CONTACT / MOBILITY
→ PRACTICE / INSTITUTION
→ AGENCY
→ EVENT
→ KNOWLEDGE
→ RESIDUE
→ NEXT-CYCLE CHANGE
```

A stronger narrative surface is not a World Track success if the underlying
world cannot produce a new causal consequence.

## 8. Feature admission test

Prefer a real causal capability over a new presentation layer.

For every candidate ask:

```text
WHAT FUTURE STATE CAN CHANGE?
WHAT EXISTING SYSTEM CONSUMES IT?
WHAT HAPPENS IF IT IS REMOVED?
WHO / WHAT CARRIES THE STATE?
WHO KNOWS IT?
WHAT RESIDUE PERSISTS?
```

If the answer is only "the prose becomes better", the item belongs on the
read/render side rather than the causal World Track.

## 9. Final invariant

> **The simulation is the generator of the world and its history. The LLM is the
> prism through which a human perceives and interacts with that generated world.**
