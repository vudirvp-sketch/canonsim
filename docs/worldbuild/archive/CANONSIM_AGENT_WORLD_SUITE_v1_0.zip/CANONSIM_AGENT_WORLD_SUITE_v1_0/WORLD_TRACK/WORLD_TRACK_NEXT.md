# CANONSIM — WORLD TRACK NEXT v4.6

## 0. Purpose

This is the compact execution surface for world-track work after the Sarrow
composition, diagnosis, carrier/surface, and market-leg iterations.

It is **not** a second engine architecture, second source of truth, or plot
manager. Dense evidence and reusable probe forms live in the companion files.

Read first:

1. `00_PROJECT_CONSTITUTION.md` for the project-model boundary;
2. this file;
3. `01_CURRENT_EVIDENCE.md` for measured state;
4. `02_DORMANT_REGIMES.md` when choosing/retaining civilizational experiments;
5. `03_PROBES_AND_GATES.md` when executing a test.

## 0A. Product-model boundary

Canonsim is a **deterministic living-world simulation core**. World Track work
strengthens the causal substrate and authored setting that can autonomously
generate events, consequences, relationships and history. It is not a plot
manager and not an LLM story-writing track.

```text
SIMULATOR → CANON / CAUSALITY
LLM       → LANGUAGE INTERFACE / INTERPRETATION
```

The LLM may render canonical state into prose, dialogue, perception and
non-causal texture, and may translate player language into structured intent.
It must not become the source of canonical events, outcomes, hidden state, or
unsupported causal motives.

The player is an embodied canonical actor: language expresses intent; the
simulator resolves the consequential result under world constraints. The world
must remain capable of evolving without the player or the LLM.

For World Track admission, prefer a mechanism that increases the world’s ability
to produce persistent causal differences. Presentation-only improvement belongs
to the read/render side unless it exposes a real underlying capability gap.

## 0B. Owner-anchor map

| World-track question | Read first |
|---|---|
| causal authoring, meso, residue, knowledge asymmetry | `WORLD_AUTHORING.md` §§6–10, §18–19 |
| current active plan / W4 / W5 / expansion | `WORLD_WORKPLAN.md` §§6–12 |
| test contract and evidence | `WORLD_TESTS.md` |
| anchor content | `ANCHOR_REGION.md` |
| regime/culture mechanisms | `CULTURES_CIVILIZATION.md`, then `02_DORMANT_REGIMES.md` |
| intake history / D decisions | `docs/blueprint/phases.md` §6 |

The compact pack may propose a synthesis, but it must name which owner surface
would consume it before any promotion.


## 0C. Cross-pack boundary

`CANONSIM_CORE_WORLD_AGENT_PACK_v1.3` owns cross-cutting execution, scale,
semantic-equivalence, history/replay, and LLM-boundary questions. This file
owns the current world-track sequence, world-specific gaps, probes, frontier
mechanisms, evidence, intake routing, and dormant design memory.

Do not reopen a world-specific gap here by creating a duplicate core subsystem;
route a demonstrated engine-native limit to `docs/TASKS.md`.

## 1. Operating thesis

The target loop is:

```text
WORLD STATE
→ PRESSURE
→ ACCESS / CONTACT
→ INSTITUTION / PRACTICE
→ AGENCY / CHOICE
→ EVENT
→ KNOWLEDGE
→ RESIDUE
→ CONSUMER
→ NEXT-CYCLE CHANGE
→ NEW PRESSURE
→ NARRATIVE OPPORTUNITY
```

Only the canonical world/event/state side is simulation truth. Narrative, genre,
arc, and reader interpretation remain read-side unless an owner explicitly
promotes a capability.

Primary question:

> Can one deterministic substrate generate many materially different human
> histories because pressure, contact, knowledge, agency, institutions, and
> residues interact differently?

Long-horizon question:

> Does the same world law survive transfer into a materially different
> civilizational regime without hidden substrate changes?

## 2. Governance

1. Runtime implementation truth remains the repository runtime and event log.
2. Authored-setting truth remains `docs/worldbuild/`.
3. World Track owns setting models, experiments, routing, and proof status.
4. Engine changes require demonstrated substrate limitation + owner routing.
5. Prefer existing primitives and pack data.
6. One fact has one owner; link instead of duplicating.
7. Separate `CONFIRMED / PARTIALLY CONFIRMED / PROPOSAL / DEFERRED / REJECTED / SUPERSEDED`.
8. Research intake is evidence/routing memory, not a second architecture.

## 3. Current state

### Foundation

Stable enough to stop reopening for detail:

- post-collapse connected civilization → divergence/path dependence;
- `CONNECTIVITY ↔ RESILIENCE`;
- `CONTINUITY ↔ IDENTITY`;
- hard world laws and negative-space constraints;
- Resonance, life/personhood, peoples/cultures ownership;
- authoring/test doctrine.

### Sarrow Vale

Strongest witness. Existing substrate covers geography, roads/travel, calendar,
weather, factions, economic slices, knowledge asymmetry, causal mesh, meso units,
human probes, composition, and carrier-vs-surface discrimination.

### Current evidence frontier

D-237 → D-240 established:

- integrated multi-family composition with relational oracles;
- timing/assignment observability;
- causal-inertness diagnosis;
- `wait` knowledge materialization fix;
- per-leg carrier/surface law;
- market carrier embodiment as pack data;
- no demonstrated need for a new core primitive from these J-questions.

See `01_CURRENT_EVIDENCE.md` for exact measurements and limits.

## 3A. Retained anchor proof memory

### W4 meso working set

The current tested meso set is:

1. crossing household;
2. step bench / water-governance practitioner;
3. winter kin / constructed kinship edge;
4. camp / charcoal debt.

Keep these as evidence-bearing units, not as a requirement to add more meso entities. Each exists because it changed causal composition.

### W5 human-test state

Biography is clean; humor and heartbreak have passed important bands but remain partially confirmed. Open owner-controlled discovery/assembly questions are: fail-then-pass / 40-80 asymmetry, runner/grudge residue, and shave temporal placement / arc assembly. Keep canonical facts, discovery-path failures, and rendering failures separated.

### Anchor causal mesh

The eight named families are:
`fire → institutional response`; `feud residue → present politics`; `season → weather → social signal`; `route → condensation → culture`; `credit/debt`; `step/water-governance`; `winter kinship`; `camp/charcoal debt`.

Disable one unique driver and the other families must survive; shared driver + mediator is one mechanism family, not duplicated loops.

## 4. New priority: World Liveness

### 4.1 Definition

A world component is **causally live** when a realized change reaches a real
consumer that changes later state, decisions, knowledge, resources, relations,
permissions, or future options.

Event existence is not proof of causality. A chronology or render line may be
intentionally surface-only.

### 4.2 Liveness loop

```text
PRESSURE
→ REALIZATION
→ CONSUMER
→ DOWNSTREAM CHANGE
→ RESIDUE / NEXT-CYCLE EFFECT
```

Use the existing A–H runtime loss vocabulary to locate where a path dies:

```text
A no pressure
B pressure without urgency
C urgency without intent
D intent without realization
E realization without consequence
F consequence without residue
G residue without consumer
H complete path
```

### 4.3 Liveness gate

Before adding a mechanism, identify:

- trigger/pressure;
- realization path;
- consumer;
- downstream effect;
- persistence or next-cycle effect;
- ablation delta.

If no consumer exists, treat it as surface/read-side until a real consumer is
proven. Do not repair it by prose or by inventing a scheduler.

## 5. New priority: World Admissibility / Contact Routing

The world must constrain not only what exists but **why it may appear here**.

### 5.1 Admissibility chain

```text
REGION / REGIME
→ HABITAT / RESOURCE / INFRASTRUCTURE
→ LINEAGE / CULTURE / INSTITUTION
→ KNOWLEDGE / TECHNOLOGY
→ MOBILITY / CONTACT PATH
→ ENTITY / EVENT / ROLE POOL
```

Use:

`REQUIRED | COMPATIBLE | CONDITIONAL | RARE | INACCESSIBLE | FORBIDDEN`

### 5.2 Boundary law

> No unexplained provenance teleportation.

This does **not** forbid unusual stories. A rare character, technology, or
practice can cross a boundary if a contact path explains it:

`migration | caravan | convoy | war | refuge flow | pilgrimage | specialist
transfer | archive transfer | unique encounter | trade corridor`.

When materially relevant, the contact leaves residue.

### 5.3 Causal Passport

For unusual cross-boundary content, preserve compact authoring/test metadata:

```text
SOURCE
CONTACT PATH
ADMISSION CONDITIONS
LOCAL COMPATIBILITY
EXCEPTION CLASS
RESIDUE
REPEATABILITY
```

This is not runtime state by default.

## 6. Keep abstraction layers distinct

| Layer | Example | Question |
|---|---|---|
| Civilizational regime | riverine, industrial, maritime, deepwater, necropolis, sky | What survival problem dominates organized reproduction? |
| Lineage / survival strategy | human, sylvan, mountain, deepwater, construct | What biology/continuity constraint changes causality? |
| Institution / practice | guild, market, water bench, archive, council | How is a recurring dependency managed? |
| Place / frontier | refuge city, ruin frontier, enclave, port | What spatial/social condition concentrates pressure? |

A region is a composition of these layers, not one row in a flat taxonomy.

## 7. Agency comes after liveness

Only probe agency on an already realized consequential action.

```text
ACTOR
→ GOAL
→ KNOWLEDGE / BELIEF
→ CONSTRAINTS
→ AVAILABLE OPTIONS
→ CHOICE
→ ACTUAL OUTCOME
→ LATER UPDATE
```

Pass requires actor-specific explanation, plausible alternatives, changed future
state, and no hidden author facts.

Do not use an agency probe to diagnose a path that already dies on LOD, gating,
content, or consumer absence.

## 8. Institutional reproduction

A repeated event is not yet an institution. Test:

```text
BIRTH
→ OPERATION
→ RECOGNITION
→ TURNOVER
→ FAILURE / REPAIR
→ SUCCESSION
→ PROTOCOL DRIFT
→ NEXT CYCLE
```

The important question is whether history changes the next iteration.

### Heterogeneous institutional agency

Where the aggregate abstraction may hide real alternatives:

```text
AGGREGATE
→ SUBGROUPS / ROLES
→ KNOWLEDGE DIFFERENCES
→ INCENTIVES
→ PARTIAL COORDINATION
→ INTERNAL CONFLICT
→ AGGREGATE ACTION
```

Use only when a material distinction is demonstrated.

## 9. World Pulse / Stateful Cadence

Recurring systems should consume history, not merely repeat by calendar:

```text
CYCLE N
→ INPUT FROM HISTORY
→ OUTPUT / RESIDUE
→ ALTERED CONDITIONS
→ CYCLE N+1
→ TURNOVER / FAILURE / ADAPTATION
```

**Stateful-cadence admission law:** a recurring cycle is causally meaningful
only when it names (a) what from earlier cycles it consumes, (b) a real
reader/decision that can differ because of that history, and, for durable
functions, (c) what survives when the current carrier leaves, fails, or is
replaced. `time passed` is never sufficient causal attribution.

Candidate domains: market days, water allocation, maintenance, caravans,
convoys, archive transfer, seasonal labour, recurring councils.

Do not make a global scheduler. Prove the shape on one existing cycle first.

## 10. Mobility / Corridor — strengthened invariant

The v4 corridor shape is too weak if it only proves that something can travel.
For flow-bearing mobility, preserve the stronger hypothesis:

```text
RECURRENT CONSTRAINED PASSAGE
→ CAPACITY / DELAY
→ HANDOVER / PARTIAL DELIVERY
→ STOCK / KNOWLEDGE / OBLIGATION DIVERGENCE
→ INSTITUTIONAL RESPONSE
→ RESIDUE
→ CHANGED NEXT-CYCLE CONDITIONS
```

**Critical distinction:** route existence ≠ route capacity.
A mobility probe should perturb one edge, measure realized delay, then look for a
material downstream divergence such as `QUEUE | SPILLOVER | ABANDONMENT | LOCAL
SCARCITY | PRICE/OBLIGATION CHANGE`. Average utilization alone is not a fracture
oracle.

### Mobility bundle

A caravan/convoy/crew should be treated first as a **moving meso assembly**, not
as a new engine noun. The reusable bundle is:

```text
ROLES / PEOPLE
+ MATERIAL STOCK
+ KNOWLEDGE
+ CLAIMS / OBLIGATIONS
+ ROUTE / CAPACITY STATE
+ MAINTENANCE DEPENDENCIES
```

The four flows need not move together. Cargo can arrive while knowledge lags;
people can separate while claims persist; an obligation can be handed over even
when a physical object is lost. These differences are a source of depth.
Use existing actors, carried items, positions, knowledge, relations, travel,
market and event primitives first.

Potential target domains:

- road/caravan corridor;
- maritime convoy;
- deepwater specialist rotation;
- archive transfer;
- sky supply/repair;
- refugee corridor;
- maintenance network.

Transfer only if the invariant survives domain removal and produces a new
observable consequence or a real incompatibility.

### Mobility-specific discriminators

These are test relations, not runtime objects:

- **Functional corridor:** hold route topology constant and remove one stationary dependency; functional viability must change or the relation is unproven.
- **Route memory:** prior passage must alter later conditions; ablate passage #1 and require a later reachable-state divergence to call the residue causal memory.
- **Channel asymmetry:** `BODY | CARGO | WITNESS | CLAIM` may diverge; never infer synchronization from one successful channel.
- **Synchronization latency:** carried knowledge can be stale at arrival; test receiver decisions against authorized knowledge, not hidden truth.
- **Return asymmetry:** outbound realization does not imply return continuity.
- **Travel price ≠ institutional cost:** traversal price is edge-local; institutional cost must be evidenced by downstream obligations, service, knowledge, risk, or missed-plan consequences.

The full source dossier and specialized procedures are in
`07_CARAVAN_MOBILITY_DOSSIER.md`; do not duplicate it here.

## 11. Historical residue and knowledge

### Residue

```text
EVENT
→ RESIDUE
→ CARRIER
→ HOLDER
→ TRANSFORMATION
→ TRANSFER
→ INHERITANCE / CLEARANCE
→ SUCCESSION / REPLACEMENT (where the function is durable)
→ NEW OPTION
→ NEXT PRESSURE
```

Delete a meaningful transition and verify future divergence. A durable authored
force without a successor/carrier path is a frozen force; it should remain a
named uncertainty rather than an immortal assumption.

### Knowledge circulation

```text
TRUTH
→ WITNESS
→ KNOWLEDGE
→ TRANSFER
→ INTERPRETATION
→ ACTION
→ RESIDUE
```

Epistemic difference matters only when it changes lawful decisions, institutions,
resources, relations, memory, or future options.

### 11A. Influence boundary

Actors may react to their own canonical state and their own knowledge. Another
entity's hidden internal state may enter only through an observable marker that
can be perceived and become knowledge. This is an explicit **observation-boundary
check**, not permission for omniscient authoring.

Test:

```text
FIX PUBLIC SURFACE
→ SWAP HIDDEN OTHER-STATE
→ SAME AUTHORIZED RESULT?
```

If the result changes without a new observation, attribution is invalid. The
repository already contains this rule in its agent/perception material; the world
track should reference it rather than invent a second epistemic subsystem.

### 11B. Expectation-mismatch loop

Knowledge should be able to change through failed expectation, not only through
explicit lore transfer:

```text
EXPECTATION
→ MISMATCH / SURPRISE
→ EVIDENCE ACQUISITION
→ INTERPRETATION
→ ACTION
→ UPDATED EXPECTATION
→ RESIDUE
```

Use only when the mismatch changes a later option, relationship, institution,
resource allocation, or investigation path. Do not create a generic belief graph.

### 11C. Relation formation as option-topology change

Retain the already-routed D-196 mechanism explicitly because it is unusually
useful for human depth:

```text
REPEATED CONSEQUENTIAL CO-PRESENCE
× RECIPROCITY
× SELECTIVE DISCLOSURE
→ ENDOGENOUS RELATION
→ FUTURE-OPTION CHANGE
```

Measure relations by changed legal/social options (ADD / REMOVE / MERGE / SPLIT /
SEMANTIC-CHANGE), not by a universal relationship score. This is an authored/test
mechanism already demonstrated in the winter-kin work, not a new runtime primitive.

## 12. Narrativity remains read-side

The narrative layer is a consumer of simulation history, not a hidden causal
engine. A strong story opportunity is evidence that the substrate exposes useful
causal material; it is not evidence that a plot subsystem is required.

Do not make a global plot score.

Useful salience dimensions:

`AGENCY | CHANGE | STAKE | IRREVERSIBILITY | KNOWLEDGE ASYMMETRY |
SOCIAL CONSEQUENCE | PERSISTENCE | CROSS-SCALE COUPLING |
UNEXPECTEDNESS_WITHIN_LAWS | FUTURE_OPTION_CHANGE`

Story opportunity describes what the current world permits, not what must happen.

```text
OPPORTUNITY
→ ACTORS
→ KNOWN / UNKNOWN FACTS
→ ACTIONS
→ CONSTRAINTS / COSTS
→ POSSIBLE CONSEQUENCES
```

Build arcs from existing causes/residues, not invented causes:

`BASELINE → PRESSURE → CHOICE → CONSEQUENCE → RESIDUE → NEW OPTION`.

## 13. Narrative polysemy / multi-reading test

Use the same canonical sequence to test multiple valid readings:
`mystery | politics | relationship | tragedy | comedy | biography | adventure`.

Success means the facts stay fixed while different knowledge, values, positions, or stakes expose genuinely different readings. This is a read-side test, not a genre-specific canon.

## 13A. Proposal classification

The following are **bundle-level synthesis candidates**, not source-backed current
capabilities: Moving-Meso / World Ignition; pool/role provenance + meaningful
absence; expectation-feedback expansion; and narrow maintenance ecology. Keep them
as probes until a named owner/consumer and falsifier accept them.

D-196 relation formation, capacity/fracture, and denominator integrity are restored
intake residues, not new inventions in this bundle.

## 14. Third-order synthesis

When mechanisms A and B are both candidates, test whether:

`A improves B | A constrains B | A exposes B's assumption | B reveals a new
use of A | A+B collapse into an existing primitive | A+B create a new capability`.

Do not automatically implement both. The best result may be a simpler mechanism
or a demonstrated incompatibility.

Use the repository's synthesis-over-selection doctrine before selecting among
real trade-offs.

## 15. Preserved research-method inputs

These remain conceptual donor/method material, not runtime architecture:

- emergent narrative: discover narrative material from simulation rather than fabricate causality after the fact;
- intentional-agent planning: goals, beliefs, knowledge, constraints, choices, consequences;
- bounded social practices / agent affordances;
- storylet-like conditional opportunities as read-side projections;
- story-arc assembly from existing causes/residues: baseline → pressure → choice → consequence → residue → new option;
- carrier-ablation and cross-regime continuity as reusable test patterns;
- drama management only as a later presentation/interaction layer, never as a causal plot-forcing engine.

The current Cross-Domain Mechanism Transplantation instruction remains the main research discipline: source → mechanism → invariant → remove cargo → target adaptation → discriminating test → evidence → scope/transfer check.

## 16. Priority gaps

Cross-cutting execution/scale/LLM gaps are owned by `CANONSIM_CORE_WORLD_AGENT_PACK_v1.3`; this list contains only world-specific frontiers.

These are substrate/frontier gaps, not a request to make the LLM invent missing
causality. Any apparent narrative weakness must first be classified as
`CANONICAL_GAP | DISCOVERY_PATH_GAP | RENDERING_GAP | CONTENT_GAP | SUBSTRATE_GAP | TEST_GAP | LIVENESS_GAP | ADMISSIBILITY_GAP`.


1. **Liveness / causal circulation** — the central near-term proof gap.
2. **Admissibility / contact routing** — why content can occur where it occurs.
3. **Pool / role provenance** — why an actor, role, technology, or practice is present **or absent** in a local pool.
4. **Mobility capacity / flow fracture** — route existence, capacity, delay, spillover and downstream regime change.
5. **Agency / influence boundary / intent** — choice reconstruction without hidden-state leakage.
6. **Institutional reproduction** — turnover, succession, drift, history-fed cycles.
7. **Social practices + relation formation** — bounded practices whose interactions alter future options.
8. **Knowledge feedback** — circulation plus expectation mismatch and evidence acquisition.
9. **Stateful cadence / maintenance ecology** — repeated cycles whose outputs alter the next cycle.
10. **Economy breadth** — only if repeated human-history tests demand it; preserve the anti-arbitrage spread.
11. **W6 expressive range** — multiple readings after earlier gates are clean.
12. **Historical residue depth** — more carrier classes and multi-cycle transfer.
13. **Second-region generalization** — only after anchor proof.
14. **Ancient Network / broader Resonance** — contradiction-gated.

## 17. Evaluation / classification discipline

Every proposal should carry two axes:

**artifact class:** `CANONICAL | AUTHORED | READ-SIDE | RENDERING | RESEARCH | DEFERRED | REJECTED`

**failure class:** `CANONICAL_GAP | DISCOVERY_PATH_GAP | RENDERING_GAP | CONTENT_GAP | SUBSTRATE_GAP | TEST_GAP | LIVENESS_GAP | ADMISSIBILITY_GAP`

Every mechanism must answer:

```text
WHAT FUTURE STATE DOES THIS MAKE POSSIBLE OR IMPOSSIBLE?
WHAT EXISTING SYSTEM DOES IT COUPLE TO?
WHAT HAPPENS IF IT IS REMOVED?
WHO/WHAT CARRIES THE STATE?
WHO KNOWS IT?
WHO BENEFITS?
WHO PAYS?
WHAT RESIDUE REMAINS?
WHAT DESIGN MEMORY DOES THIS PRESERVE / REPLACE / RETIRE?
```

Do not promote a hypothesis because its label sounds useful.

## 18. Dormant civilizational memory

Disposition is separate from evidence status: `PRESERVE | TRIGGERED | REJECTED | SUPERSEDED`. Every dormant card must retain source owner(s), why-not-now, reactivation trigger, and unresolved contradictions. `DEFERRED` never means forgotten: this is the explicit semantic-forgetting guard.

Dormant regimes are design memory, not queue order.

Activation rule:

```text
SAME WORLD LAWS
+ NEW MATERIAL PRESSURE
+ NEW INSTITUTIONAL COUPLING
+ NEW FAILURE MODE
+ NEW HUMAN-HISTORY SHAPE
```

Cards and triggers live in `02_DORMANT_REGIMES.md`.

Do not flatten regimes with lineages or places. Do not activate for map completion.

## 19. Intake / D routing

`intake-31 / D-189` → W4 meso operators: function-loss, heterogeneous meso assembly, residue lifecycle, natural-pattern transfer. **ACTIVE MEMORY.**

`intake-32 / D-190` → mostly substrate/presentation separation. Retain two items as navigation memory: **re-expansion law** for disposable model-facing bundles, and the **worldbuild ripple-audit** as a tooling/procedure proposal only. The generic knowledge-propagation graph remains unresolved and must not become a runtime graph.

`intake-33 / D-191` → **anti-arbitrage spread** (lossy stock exchange rather than a magic multiplier), **turnover question**, and outcome-perception laws. World-facing residues belong to economy/function-loss/legibility gates; presentation material stays presentation-owned.

`intake-34 / D-194` → capability/resolution/progression separation, NPC-agency hypothesis, carrier taxonomy, and anti-grind/LOD cautions. Treat these as agent/world-test methodology. No generic progression or cognition subsystem.

`intake-35 / D-195` → re-confirmation plus two method residues: generalized-controls remains deferred until a second independent instance; procedural-capability claims require a real discriminating consumer/held-out test. No new world primitive.

`intake-36 / D-196` → **three world-track residues must stay visible:** relation formation (`co-presence × reciprocity × selective disclosure → future-option change`), road-traffic capacity/fracture (`capacity ≠ route existence` + queue/spillover/abandonment oracle), and denominator integrity for stock-derived rates. The first two are world-test material; the third remains assurance/lint material.

`intake-37 / D-197` → mutation visibility and path-bound evidence discipline. Retain as verification method, not world primitive.

`intake-38 / D-199` → standing Cross-Domain doctrine and promotion gate. Do not duplicate its architecture.

`intake-39 / D-231/D-232` → agent-instruction re-edit plus the one fresh synthesis-over-selection adoption. Active research method, not second project-memory store.

`intake-40 / D-233` → testing/verification corpus form refused as second TEST_PLAN. World-track residue enters through D-237–D-240; P1-2/P1-3 remain parked behind their named first-consumer gate. `D-236` is the temporal-contract boundary and must not be silently reopened.

`caravan-mobility-consolidated.v3` → ABSORBED + PRESERVED SOURCE; full text lives in `07_CARAVAN_MOBILITY_DOSSIER.md`. Active residues route through §10 and the mobility/institution/knowledge probes; no runtime promotion.

**No-loss rule:** an intake may be marked `ABSORBED`, `DEFERRED`, or `REJECTED`; it must not disappear from the routing map merely because it produced no runtime row.

## 20. Execution sequence

The recommended witnesses are chosen because they can make the world more
causally self-propelling. Do not add narrative machinery merely to make the
witness read better.


### I0 — World Ignition Witness (recommended synthesis probe)

Before opening many independent rows, run one **ordinary recurring moving meso**
(the smallest caravan/crew/convoy-like witness that existing primitives can
express) across three points for at least three cycles. Track four separable flows:

`PEOPLE/ROLES | MATERIAL STOCK | KNOWLEDGE | CLAIMS/OBLIGATIONS`

Perturb one route edge or destination admission condition. Require a realized
delay or exclusion, downstream stock/knowledge/obligation divergence, an
institutional or personal response, persistent residue, and a changed next-cycle
condition. This single witness is intended to exercise mobility, cadence,
admissibility, knowledge feedback, agency, institutional reproduction, and
residue without creating a new subsystem.

Do **not** force all flows to couple. The depth comes from their partial
decoupling and delayed reconciliation. If the existing substrate cannot express
the witness, classify the first missing leg rather than inventing the whole
caravan system.

For the witness record, keep these outcomes separate:

```text
BODY / CARGO / WITNESS / CLAIM
= independent realized results
```

And classify negative outcomes diagnostically: no later delta may mean no
consumer at the tested resolution; total collapse after carrier removal may
indicate person-dependence; a route removal with no downstream change may
indicate an unconsumed/decorative corridor.

### N0 — Design-memory integrity

Keep every major dormant regime card complete with why-not-now, trigger, status,
and unresolved contradictions.

### N1 — W5 residuals

Resolve or explicitly keep open fail-then-pass / 40-80 discovery-path asymmetry, runner/grudge residue, and shave temporal placement / arc assembly questions;
never confuse canonical fact, discovery path, and rendering failure; do not use prose to repair a substrate defect.

### N2 — World Liveness

Pick one existing recurring carrier/institution and prove:

`PRESSURE → REALIZATION → CONSUMER → RESIDUE → NEXT CYCLE`.

Use minimal pair + ablation. No runtime abstraction first.

### N3 — Admissibility / Contact

Use one region boundary and test:

`local | compatible outsider | rare lawful outsider | unsupported outsider`.

Require a contact path for the rare case.

### N3a — Pool / Role Provenance

For any authored pool that can materialize an actor, role, technology, creature,
or practice, record:

`SOURCE POOL → LOCAL POOL CONDITIONS → ENTRY / CONTACT → MATERIALIZATION → RESIDUE`.

Also record why conspicuous alternatives are absent when that absence is a world
claim. This is the main guard against arbitrary cross-regime contamination without
creating a global content taxonomy.

### N4 — Agency

Use one fully realized consequential action from N2/N3-compatible substrate.

### N5 — Institutional reproduction

Run one recurring practice for at least three cycles with changed conditions and
turnover/succession where applicable.

### N6 — Social practice / Knowledge

Formalize one practice and one knowledge-circulation path using existing Sarrow
content. Prefer a case where failed expectation forces evidence acquisition:
`EXPECTATION → MISMATCH → EVIDENCE → INTERPRETATION → ACTION → UPDATE`.

### N7 — W6

Run the genre matrix on the same canonical package. Classify failures; do not
write plot patches.

### N8 — Targeted substrate repair

Only repair repeatedly demonstrated limitations. Prefer the smallest capability
that unlocks multiple histories.

### N9 — W7 / W8

Run negative/compression and integration readiness. Preserve dormant design memory.

### N10 — Held-out regime

Select by missing coupling, not aesthetics. Record:

`ANCHOR LIMIT | NEW PRESSURE | NEW INSTITUTION | NEW FAILURE | NEW HISTORY SHAPE
| TRANSFERRED MECHANISM | INCOMPATIBILITIES | CHEAPEST FALSIFIER`.

Only then build the second region.

## 21. Second-region candidates

Mountain/Industrial remains a strong candidate because it tests infrastructure,
skilled labour, maintenance, standards, contracts, supply chains, capital/debt,
worker households, and concentrated production.

Alternatives remain experiments, not rankings:

`Maritime | Deepwater | Necropolis | Sky | Closed-Technology | Refuge | Ruin`.

The choice must be tied to a specific anchor limitation.

## 22. Expansion gates

### Economy

Only expand when needed for:

`SCARCITY → PRICE/FLOW → SUBSTITUTION → LABOUR/TRANSPORT → HOUSEHOLD PRESSURE
→ OBLIGATION/DEBT → INSTITUTION → MIGRATION / CONFLICT / INHERITANCE
→ FUTURE OPTION`.

Preserve the D-191 **anti-arbitrage spread** for stock exchange/transformation:
conversion must retain a real loss, friction, or constraint rather than create
free abundance through a magic multiplier. Test it against an actual downstream
consumer before adding economy machinery.

### Relationships

Prefer durable structure:

`CLAIM | OBLIGATION | DEPENDENCE | CARE | TRUST/DISTRUST | KINSHIP |
MEMORY | KNOWLEDGE ASYMMETRY | INHERITANCE | FUTURE OPTION`.

### Resonance

New capability requires active-region need, insufficiency of existing primitives,
affordance + constraint, a negative test, and evidence that it is not only an
authoring shortcut.

### Peoples / cultures

New lineage/culture requires a material/biological/ecological/institutional /
epistemic constraint that changes causal outcomes.

## 23. Anti-patterns

Explicit current non-goals include full atlas construction, exhaustive demographics/ecology, complete religion/language catalogues, continent-scale cosmology, and generalized Resonance powers without an active-region need.

Do not:

- build an atlas for coverage;
- create generic relationship meters;
- introduce a drama manager;
- let an LLM invent unsupported canonical facts, outcomes, hidden state, or causal motives;
- use prose quality as evidence that the underlying simulation is causally complete;
- treat the player as an exception to the world rules;
- add runtime primitives without consumer + failure + native limit + falsifier;
- promote calendar decoration to causality without a consumer;
- duplicate institutional functions;
- allow unexplained cross-regime placement;
- patch plot to rescue failed genre tests;
- research the Ancient Network without contradiction;
- build the second region to fill the map;
- delete dormant design memory because it is not active;
- add global liveness/confidence/story scores before evidence requires them.

## 24. Runtime-promotion gate

A new runtime primitive requires:

`REAL CONSUMER + REAL FAILURE + MATERIAL QUALITY GAP + NATIVE LIMIT +
REPEATED SHAPE + FALSIFIER + OWNER + PHASE/GATE`.

Otherwise keep the result as pack data, authoring vocabulary, test logic,
read-side representation, or research.

## 25. W8 success condition

Before second-region construction, require:

- authored causal substrate;
- demonstrated meso units;
- ordinary event → persistent human consequence;
- explicit knowledge asymmetry where relevant;
- world-specific material outside core ontology;
- proof/hypothesis separation;
- liveness evidence;
- agency evidence;
- institutional multi-cycle evidence where relevant;
- sufficient genre evidence for generalization;
- dormant-regime memory intact.

## 26. Final direction

Do not evolve:

`SIMULATOR → PLOT GENERATOR`.

Strengthen the causal middle:

```text
SIMULATOR
→ PRESSURE
→ ACCESS / CONTACT
→ INSTITUTION
→ AGENCY
→ CONSEQUENCE
→ KNOWLEDGE
→ RESIDUE
→ CONSUMER
→ NEXT CYCLE
→ NARRATIVE OPPORTUNITY
```

Long-horizon:

```text
ACTIVE PROOF
→ PRESERVED DESIGN MEMORY
→ HELD-OUT REGIME
→ GENERALIZATION
```

The LLM is a downstream interpreter of this history, not its author. The player
is an embodied actor inside it, not an exception to its rules.

The world should feel alive because accumulated history changes what can happen
next, not because the engine produces more events.
