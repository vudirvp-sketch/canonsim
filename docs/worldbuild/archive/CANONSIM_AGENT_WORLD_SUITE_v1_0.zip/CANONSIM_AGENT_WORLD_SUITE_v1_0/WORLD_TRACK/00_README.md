# CANONSIM WORLD TRACK — AGENT NAVIGATION BUNDLE v4.6

This is an **external, derived navigation bundle** for agents. It is intentionally a compact context surface built from the repository's existing owner documents. It is **not a new repository source of truth, not a second WORLD_WORKPLAN, and not an agent-instruction law file**.

`00_PROJECT_CONSTITUTION.md` is the bundle's compact product-model alignment surface: it prevents World Track work from being mistaken for an LLM plot/narrative engine. Repository owner documents remain authoritative.


## Synchronization with Core World Pack

Peer pack: `CANONSIM_CORE_WORLD_AGENT_PACK_v1.3`.

Responsibility split:

```text
CORE v1.3
→ cross-cutting semantic/execution/scale/LLM/research-routing questions

WORLD_TRACK v4.6
→ world-specific W-stage evidence/probes/frontiers/intake/dormant regimes
```

Do not duplicate Core's execution/scale POC, detailed LLM boundary, or generic
research bridge here. Reference them when a world probe crosses those boundaries.

## Authority

- Repository implementation truth: `AGENTS.md`, runtime code, tests, event log.
- Authored-setting truth: `docs/worldbuild/` and its named owner files.
- Operational world-track owner: `docs/worldbuild/WORLD_WORKPLAN.md`.
- Verification owner: `docs/TEST_PLAN.md` + `docs/worldbuild/WORLD_TESTS.md`.
- Research/intake provenance: `docs/blueprint/phases.md` §6 + named iteration reports.
- This bundle is a **portable derivative**: use it for navigation, not to override owner documents.

## Read order

1. `00_PROJECT_CONSTITUTION.md` — product identity and authority boundaries.
2. `WORLD_TRACK_NEXT.md` — compact strategy and gate order.
3. `01_CURRENT_EVIDENCE.md` — measured current evidence and limits.
4. `02_DORMANT_REGIMES.md` — preserved civilizational design memory.
5. `03_PROBES_AND_GATES.md` — reusable probe contracts.
6. `05_SOURCE_CROSSWALK.md` — intake/D audit trail and retained/absorbed/deferred routing.
7. `06_FRONTIER_MECHANISMS.md` — proposal-only synthesis candidates; never authoritative.
8. `07_CARAVAN_MOBILITY_DOSSIER.md` — full preserved caravan source; load only for mobility/caravan/corridor tasks.

Do not load all files unless the task crosses their boundaries.

## Audited repository / agent surface

The semantic-alignment and cross-pack synchronization update is v4.6. The uploaded repository snapshot is `iter-272` at commit
`8ec6442d8406d901a0605175474bbd61dd3954da`. The detailed evidence tables in this bundle intentionally preserve their earlier D-237–D-240 measurement boundary; for current owner-state, read the repository owner documents named below. It contains `docs/worldbuild/`
plus the main agent/governance surfaces; it does **not** contain a literal
`worldbuilder/` directory at this snapshot. Do not infer a missing subsystem
from that naming difference.

For agent navigation, the practical chain is:

```text
AGENTS.md
→ docs/AGENT_NAVIGATION.md
→ docs/worldbuild/README.md
→ WORLD_KERNEL / RESONANCE / LIFE_PERSONHOOD / PEOPLES / CULTURES
→ WORLD_AUTHORING / ANCHOR_REGION
→ WORLD_TESTS / WORLD_WORKPLAN
→ docs/blueprint/phases.md §6 for intake/D provenance
```

``WORLD_TRACK_NEXT.md` is the compact world-specific execution surface; owner documents remain
authoritative.

## Source anchors for agents

| Concern | Owner surface |
|---|---|
| causal authoring / meso / residue / knowledge asymmetry | `docs/worldbuild/WORLD_AUTHORING.md` §§6–10, §18–19 |
| active W4/W5 plan and expansion gates | `docs/worldbuild/WORLD_WORKPLAN.md` §§6–12 |
| evidence / probes / W5–W8 | `docs/worldbuild/WORLD_TESTS.md` |
| anchor-specific authored facts | `docs/worldbuild/ANCHOR_REGION.md` |
| regime/culture design memory | `docs/worldbuild/CULTURES_CIVILIZATION.md` + `02_DORMANT_REGIMES.md` |
| intake/D provenance | `docs/blueprint/phases.md` §6 + named D-row |
| actor perception/knowledge boundary | `docs/ref/live_char_guide.md` + `docs/DIRECTOR_SPEC.md` |
| caravan/corridor specialized research | `07_CARAVAN_MOBILITY_DOSSIER.md` + `WORLD_TRACK_NEXT.md` §10/§20 + probes/frontier owners |

The label **worldbuilder** in `phases.md` §6 is a phase/surface name here, not
the name of a missing runtime directory.

## Status vocabulary

Use repository status vocabulary strictly:

`CONFIRMED | PARTIALLY CONFIRMED | PROPOSAL | DEFERRED | REJECTED | SUPERSEDED`

`DEFERRED` never means forgotten. Dormant design memory additionally uses:
`PRESERVE | TRIGGERED | REJECTED | SUPERSEDED` as disposition, not as a replacement for repository evidence status.

All v4–v4.6 additions — World Liveness, Admissibility Grammar, Causal Passport,
Institutional Reproduction, World Pulse, provenance/absence, expectation feedback,
and related routing concepts — remain **PROPOSAL / test concepts** unless an owner document or measured evidence explicitly promotes them.

## Core operating loop

```text
PRESSURE
→ ACCESS / MOBILITY / CONTACT
→ INSTITUTION / PRACTICE
→ AGENCY / CHOICE
→ EVENT
→ KNOWLEDGE
→ RESIDUE
→ CONSUMER
→ NEXT-CYCLE CHANGE
→ NEW PRESSURE
```

A noisy world is not necessarily alive. A causal claim requires an identified leg, a real consumer/observable consequence, and an ablation or equivalent discriminating test where applicable.

## Anti-drift rule

Do not:

- turn this bundle into a second canon or project-memory store;
- turn read-side narrative analysis into canonical state;
- treat the LLM as a causal authority, hidden game master, or plot generator;
- treat improved prose as evidence that a world mechanism is causally live;
- turn calendar decoration into causality without a consumer;
- create one giant world simulation layer;
- flatten regime, lineage, institution, and place into one taxonomy;
- broaden the engine when pack data or a test relation already expresses the need;
- add a region because the map feels incomplete;
- delete dormant design memory because it is not on the active queue.

## Cheapest next question

> What smallest deterministic intervention would distinguish a missing world capability from a missing consumer, routing, observation, witness, or test-boundary problem?
