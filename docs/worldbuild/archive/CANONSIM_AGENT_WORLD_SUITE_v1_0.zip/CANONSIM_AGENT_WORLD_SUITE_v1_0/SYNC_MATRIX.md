# Synchronization Matrix

| Concern | Core World Pack | World Track Pack | Final owner |
|---|---|---|---|
| Product identity / causality | compact cross-track alignment | compact world interpretation | repository owners |
| LLM authority / observation | detailed contract | world-specific boundary use | Core shared contract + repository owners |
| W-stage status/order | references current state | full current state/sequence | WORLD_TRACK |
| World evidence | substrate summary only | detailed evidence | WORLD_TRACK |
| World priority gaps | only cross-cutting residuals | world-specific gap list | WORLD_TRACK |
| Capability tests | index/router | concrete world probes | WORLD_TRACK for world cases |
| Execution/index/batch/LOD | POC + shared gaps | references only | CORE |
| Research method | bridge to standing Cross-Domain instruction | uses method, no duplicate manual | standing Cross-Domain instruction |
| Caravan/mobility | routed reference only | full dossier + selected frontier residues | WORLD_TRACK |
| Dormant regimes | not duplicated | preserved design memory | WORLD_TRACK |
| TASKS routing | generic owner-gate | world→TASKS routing | repository TASKS owner |
| Canonical authority | simulator/event history | same | repository runtime |

## Synchronization invariant

```text
same project model
+ no conflicting status
+ no duplicated owner function
+ no second canonical authority
+ explicit cross-reference at every shared boundary
```

## Current synchronized versions

```text
CANONSIM_CORE_WORLD_AGENT_PACK = v1.3
WORLD_TRACK_NEXT               = v4.6
```

The suite version is a packaging version, not a replacement project version.
