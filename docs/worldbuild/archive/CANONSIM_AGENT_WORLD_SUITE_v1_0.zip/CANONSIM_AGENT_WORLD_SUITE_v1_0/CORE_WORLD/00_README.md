# CanonSim Core / World Agent Pack v1.3

## Purpose

This pack is a **handoff and research-control layer**, not a second project constitution.
It aligns the agent with the repository's existing vision, worldbuilding owners, current evidence, open gaps, and promotion gates.

Do not re-author `VISION`, `WORLD_TRACK_AGENT_CONTEXT`, `WORLD_WORKPLAN`, `WORLD_AUTHORING`, `TASKS`, `PACK_SPEC`, or `OBSERVATORY_LAW` here. Read those owner documents and use this pack to route work between them.

## North star already owned by the repository

```text
seed + rules + initial conditions
        -> living world
        -> autonomous canonical change
        -> history / residue / knowledge
        -> altered future possibilities

player / LLM intent
        -> sanctioned boundary
        -> simulator resolution
        -> canonical commit
        -> authorized read surface
        -> LLM narration
```

The repository's frozen `docs/VISION.md` already defines the intended model: deterministic procedural simulation, seed/lazy generation/irreversibility/simulation-not-script, simulator as canon, LLM as parser/renderer, and the world running outside the context window.

## What this pack adds

It does **not** invent a new vision. It does four things:

1. maps the existing owner documents and their authority;
2. separates proven substrate from world-model targets and proposals;
3. isolates the remaining high-value engineering frontiers;
4. gives agents a compact procedure for proving a native gap before promoting runtime machinery.

## Current world-track position

The repository's documented world-track status is:

```text
W1-W4  closed
W5     gate met / evidence retained
W6     complete
W7     complete
W8     current execution stage; readiness audit landed
```

Do not reopen closed W-stages without fresh regression evidence. The world track is separate from `docs/TASKS.md`; an engine capability exposed by world work enters `TASKS.md` only through the owner's routing decision.

## Reading order

1. `01_PROJECT_ALIGNMENT.md`
2. `02_OWNER_MAP_AND_STATUS.md`
3. `03_CURRENT_SUBSTRATE.md`
4. `04_REAL_OPEN_GAPS.md`
5. `05_EXECUTION_AND_SCALE_POC.md`
6. `06_WORLD_CAPABILITY_TESTS.md`
7. `07_LLM_AND_OBSERVATION_BOUNDARY.md`
8. `08_CHANGE_GATE.md`
9. `09_AGENT_WORK_PROTOCOL.md`
10. `10_RESEARCH_METHOD_BRIDGE.md`
11. `INDEX.md`

## Status vocabulary

Use the repository / Cross-Domain vocabulary only:

```text
statement tag: FACT | INFERENCE | HYPOTHESIS | PROPOSAL | UNKNOWN
result: CONFIRMED | PARTIALLY CONFIRMED | REJECTED | UNRESOLVED | DEFERRED
```

Do not create a parallel project-law vocabulary.

## Non-negotiable working boundaries

- the simulator is the only canonical semantic authority;
- event history / canonical commit remain authoritative;
- read-side/indexed representations are derived and rebuildable;
- LLM output is a proposal or rendering, never a canon commit;
- worldbuilding defines causal possibility/constraint, not scripted plot;
- use existing primitives before proposing new runtime machinery;
- a world-authoring need is not automatically an engine task;
- a benchmark or demo is not proof of a causal capability;
- semantic equivalence must be defined before calling an execution change an optimization.

## Synchronization contract

This pack is the **cross-track control surface**. It does not own the World
Track work queue or repeat its world-specific probes/frontiers.

```text
CORE/WORLD PACK
  = cross-cutting semantic + execution + scale + LLM + research routing

WORLD_TRACK v4.6
  = current world evidence + W-stage sequence + world probes +
    world frontier mechanisms + source/intake provenance
```

For world-specific questions, route to `WORLD_TRACK_NEXT_v4_AGENT_PACK_v4.6`.
Do not recreate its priority gaps, probe procedures, caravan dossier, dormant
regimes, or evidence tables here.
