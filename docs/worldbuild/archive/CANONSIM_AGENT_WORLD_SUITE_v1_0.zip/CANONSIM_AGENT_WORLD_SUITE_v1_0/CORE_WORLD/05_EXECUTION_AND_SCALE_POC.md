# Execution / Scale POC Contract

## Status

**RESEARCH / POC ONLY.** Nothing here is approved runtime architecture.

## Goal

Reduce repeated discovery work while preserving the existing canonical semantics.

```text
validated mechanism
 -> compiled immutable plan (optional)
 -> deterministic derived query/index
 -> candidate superset
 -> exact verification
 -> ordinary mechanism execution
 -> existing EventDraft / StateChange
 -> existing canonical commit
```

## Semantic input contract

A POC mechanism descriptor should expose at least:

```text
READS
WRITES
TRIGGERS
SCOPE
CADENCE
PRECONDITIONS
ORDER
RNG
CANDIDATE KEY(S)
```

Missing ownership/inputs are a correctness defect, not just a typing issue.

## Index correctness

For an index-assisted path:

```text
indexed_candidates ⊇ exact_eligible_candidates
```

False positives are allowed because exact verification removes them. False negatives are not allowed.

The comparison oracle should run:

```text
indexed path
vs
brute-force/reference path
```

over the same canonical input and declared scope.

## Semantic equivalence

CanonSim's documented deterministic contract includes byte-identical replay per environment.

Therefore, an execution optimization must not be admitted as semantics-preserving merely because final state "looks the same".

Where an equivalent optimized path is claimed, compare as applicable:

- canonical event log bytes / event identity;
- event ordering;
- RNG draws and derived results;
- state transitions;
- fingerprints/replay;
- knowledge/observation boundaries;
- provenance and future-option effects.

Endpoint-state equality alone is insufficient when intermediate canonical consequences are observable or can affect later execution.

## Batch visibility contract

Before any batch implementation is promoted, state explicitly:

```text
SNAPSHOT BOUNDARY
CAUSAL VISIBILITY
SAME-BEAT PROPAGATION
ORDERING
DUPLICATE SUPPRESSION
CONFLICT HANDLING
RNG ORDER / DRAW OWNERSHIP
```

If these are not explicit, batching is a semantic redesign risk rather than an optimization.

## Representation / LOD POC

Any aggregation must define:

```text
representation boundary
preserved causal obligations
materialization trigger
upward propagation
cross-level knowledge rules
replay behavior
```

Do not claim "equivalent simulation" until the declared relation is demonstrated with a reference witness.

## Optimization admission order

```text
measure workload
 -> identify repeated work
 -> establish native failure/cost
 -> smallest derived representation
 -> reference comparison
 -> material benefit
 -> runtime gate
```

Never start from a target entity count and retrofit a generic scaling engine.
