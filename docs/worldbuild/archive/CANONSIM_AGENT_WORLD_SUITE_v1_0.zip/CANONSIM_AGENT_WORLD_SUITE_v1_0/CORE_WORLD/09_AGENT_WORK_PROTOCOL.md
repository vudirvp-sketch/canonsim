# Agent Work Protocol

## Step 0 — orient to existing owners

For world-specific work, load `WORLD_TRACK_NEXT_v4_AGENT_PACK_v4.6` as the portable navigation surface. It is the active world-track procedure/evidence layer; this pack supplies the cross-cutting core/shared layer.

Read only the relevant owner docs first:

```text
docs/VISION.md
docs/CONTRACTS.md
docs/DECISIONS.md
docs/TASKS.md              # only when engine work is implicated
docs/PACK_SPEC.md          # pack/content question
docs/OBSERVATORY_LAW.md

docs/worldbuild/WORLD_TRACK_AGENT_CONTEXT.md
docs/worldbuild/WORLD_WORKPLAN.md
docs/worldbuild/WORLD_TESTS.md
docs/worldbuild/WORLD_AUTHORING.md
docs/worldbuild/ANCHOR_REGION.md
```

Then inspect implementation/tests for the exact consumer path.

## Step 1 — locate whether the idea already exists

Ask:

```text
Is this already a project law?
Is it already a worldbuilding owner statement?
Is it already implemented by an existing primitive?
Is it already a parked/closed task?
Is it already a measured limitation proposal?
```

Do not reopen a closed decision merely because a new name sounds useful.

## Step 2 — prove the world need

For a worldbuilding request:

```text
CAUSE
-> POSSIBILITY
-> PRESSURE
-> ACTORS
-> INSTITUTION
-> KNOWLEDGE
-> CONSEQUENCE
-> RESIDUE
-> NEW OPTIONS
```

The missing link is a named uncertainty, not automatically a new system.

## Step 3 — try composition first

Ask:

```text
Can existing primitives express it?
Can pack data express it?
Can an existing resolver/fold/read surface express it?
Can a new composition produce the intended consequence?
```

Only then inspect the native limit.

## Step 4 — use an unseen witness

Prefer a novel composition over replaying a known scenario.

Good witnesses include:

```text
new object/practice
new settlement
new route
unusual migration
recovery after destruction
unexpected social relationship
rare but lawful cross-boundary presence
```

## Step 5 — diagnose before redesign

Use:

```text
failure
 -> first divergence
 -> causal slice
 -> competing explanation
 -> cheapest falsifier
 -> minimized witness
```

## Step 6 — route honestly

Possible dispositions:

```text
already supported
pack/content change
read-side representation
test-only relation
worldbuilding hypothesis
world-track deferred item owned by WORLD_TRACK
engine TASKS row (owner-gated)
rejected
unresolved
```

Do not create a new `TASKS.md` queue inside the pack.

## Step 7 — completion record

Every investigation closes with:

```text
QUESTION
VERDICT
ESTABLISHED EVIDENCE
ALTERNATIVES TESTED
REMAINING UNCERTAINTY
PRACTICAL CONSEQUENCE
NEXT VERIFICATION STEP
```

Persist only durable residue that changes future work.
