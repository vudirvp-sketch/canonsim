# Owner Map / Current Status

## Core sources

| Source | Use it for | Do not replace it with |
|---|---|---|
| `docs/VISION.md` | frozen project thesis / architecture intent | this pack |
| `docs/CONTRACTS.md` | engine invariants / external contracts | this pack |
| `docs/DECISIONS.md` | historical owner decisions | this pack |
| `docs/TASKS.md` | live owner-gated engine queue | a world-track list |
| `docs/PACK_SPEC.md` | pack/content/code boundary and affordance grammar | a new DSL by default |
| `docs/OBSERVATORY_LAW.md` | observation, rerun, evidence, steering boundaries | runtime machinery |

## World owners

**Synchronized derivative:** `WORLD_TRACK_NEXT_v4_AGENT_PACK_v4.6` is the portable navigation/agent surface for the current world track. It owns world-specific evidence, probes, frontier mechanisms, intake routing, dormant regimes, and W-stage execution order.

| Source | Use it for |
|---|---|
| `docs/worldbuild/WORLD_TRACK_AGENT_CONTEXT.md` | durable world-track identity, non-negotiables, evidence, open proposals, current stage |
| `docs/worldbuild/WORLD_WORKPLAN.md` | W-stage status, working sequence, exit/expansion/defer rules |
| `docs/worldbuild/WORLD_AUTHORING.md` | causal authoring doctrine, meso, residue, knowledge, composition |
| `docs/worldbuild/ANCHOR_REGION.md` | Sarrow Vale witness / measured world embodiment |
| `docs/worldbuild/WORLD_TESTS.md` | proof contracts and world-track claim packets |
| `docs/worldbuild/PEOPLES.md` | lineage, migration, biology, demography ownership |
| `docs/worldbuild/LIFE_PERSONHOOD.md` | life, death, continuity, personhood, reconstruction |
| `docs/worldbuild/CULTURES_CIVILIZATION.md` | dormant regimes and civilizational authoring |

## Current documented world evidence

The durable world-track context records, among other things:

- eight audited causal families at the anchor;
- five authored meso units;
- account/economy arms expressed over existing primitives;
- a 2371-event composition run with relational oracles;
- I0 world-ignition evidence over a recurring moving meso;
- separate people/material/knowledge/obligation timelines;
- knowledge-asymmetry witnesses;
- genre/human tests already run at the documented bands.

This proves a substantial causal substrate. It does **not** prove universal open-ended ontology, arbitrary-horizon autonomy, complete demography, generic dynamic topology, or exact equivalence under aggregation/batching.

## Current W-stage

`WORLD_WORKPLAN.md` documents:

```text
W1-W4 closed
W5 gate met
W6 complete
W7 complete
W8 current; seven-criteria readiness audit landed at the measured band
```

The W8 readiness audit itself records the honest boundary list: meaning is thinner than the mechanical layer at one region, the long persistence band is thinner, the influence-boundary check is not yet an oracle, and some evidence remains documentary rather than CI-replayable.

## Do not confuse later repository activity with world-stage movement

The repository contains later iterations on other tracks. Unless `WORLD_WORKPLAN.md` / `WORLD_TRACK_AGENT_CONTEXT.md` changes, do not infer that the world track advanced or that a deferred world capability became implemented merely because unrelated iterations landed.
