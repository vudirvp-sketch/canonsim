# Current Substrate — What Is Actually Demonstrated

## Canonical semantic path

The documented shape is:

```text
intent
 -> validation / OCC
 -> resolver
 -> canonical commit
 -> event history
 -> fold / projection
 -> derived/read-side
 -> knowledge / narration
```

The canonical write path and event history remain authoritative.

## Reusable mechanics

The current evidence records registered resolver kinds such as:

```text
observe inspect movement converse wait pickup drop use_item
stealth_take divert ignite flee recuperate coerce account
```

This demonstrates a reusable mechanic + data-driven content pattern. It does not establish a universal open action language.

## Pack boundary

`docs/PACK_SPEC.md` already establishes that setting nouns/data live in packs while mechanics live in the core. Its affordance derivation is intentionally narrow: the `requires` grammar is closed today, with derived affordances such as `has: fire -> ignite` represented through pack data/lint rather than a new universal planner.

Therefore:

```text
new noun / new setting data
        !=
new engine primitive
```

and:

```text
new composition not expressible today
        !=
permission to invent a universal ontology
```

## Current world witness

The anchor / world-track evidence already demonstrates:

- cross-family causal chains;
- meso heterogeneity rather than one homogeneous faction mind;
- carrier/surface discrimination;
- residue affecting later options;
- knowledge asymmetry;
- economic/account consequences using existing machinery;
- moving meso behavior and route-dependent divergence.

## Current documented substrate limitations

The I0 limitation inventory names three candidates:

1. no runtime route writer — an edge closure is not itself a world event;
2. a two-sided band condition — current gates can read floors but not all required ceiling constraints;
3. a response-repertoire floor — attempts exist, but no generic reroute/adaptation door is established.

These are **PROPOSALS / open limitations**, not approved runtime subsystems. They require the repository's promotion gate before becoming engine work.


## World-specific evidence owner

Measured world witnesses, exact W-stage evidence, Sarrow anchor detail, and
world-track historical intake provenance are not duplicated here. Their
portable current surface is `WORLD_TRACK_NEXT_v4_AGENT_PACK_v4.6`; its owner
documents remain in `docs/worldbuild/`.
