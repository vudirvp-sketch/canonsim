# Cross-Cutting Open Gaps — Shared/Core Surface

This file deliberately does **not** duplicate the World Track priority-gap
catalogue. World-specific gaps are owned by
`WORLD_TRACK_NEXT_v4_AGENT_PACK_v4.6` §16 and its probes/frontier files.

## C1 — Semantic representation continuity

Target:

```text
macro / aggregate ↔ meso ↔ individual ↔ detailed interaction
```

Open question: which canonical causal obligations must survive a representation
change, when must materialization occur, and how are changes propagated across
levels without semantic drift?

## C2 — Compiled / indexed execution

Candidate shape:

```text
mechanism
→ explicit semantic reads
→ derived index/query
→ conservative candidate superset
→ exact predicate
→ existing mechanism
→ existing canonical commit
```

Required properties: no false negatives, deterministic behavior, explicit
snapshot/visibility/order semantics, and preserved canonical meaning.

## C3 — History / replay scale

Measure before changing canonical storage:

```text
history length
checkpoint cost
replay cost
index rebuild
knowledge reconstruction
historical query cost
```

Committed history remains authoritative; scaling machinery must remain derived
until a real native limit is demonstrated.

## C4 — LLM boundary under unusual interaction

Test the authority boundary for ambiguous/multi-action intents, novel actions,
hidden information, rejected or partially realized actions, and narrative
requests that conflict with canon.

Resolution remains in the simulator; the LLM may interpret and narrate.

## C5 — Shared semantic equivalence

When execution is optimized, define what must remain invariant. Different
internal traversal, indexing, batching, caching, or representation is allowed
only when the declared canonical relation still holds. A changed event/history
semantics is a redesign, not an optimization.

## Routing

World-specific open problems such as provenance/admissibility, liveness,
institutional reproduction, social practice, mobility fracture, historical
residue depth, and second-region transfer are **not** repeated here. Use the
World Track pack and owner docs.

