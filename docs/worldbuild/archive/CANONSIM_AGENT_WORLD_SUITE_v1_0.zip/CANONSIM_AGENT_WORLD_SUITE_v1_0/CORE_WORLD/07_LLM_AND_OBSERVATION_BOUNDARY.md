# LLM / Observation Boundary

## Canon boundary

The repository already defines:

```text
SIMULATOR -> CANON / CAUSALITY
LLM       -> INTERFACE / INTERPRETATION
PLAYER    -> CANONICAL ACTOR
WORLD     -> AUTONOMOUS
NARRATIVE -> READ-SIDE INTERPRETATION
```

## Interpreter side

Player language may produce:

```text
candidate intent
candidate targets
candidate parameters
ambiguity
```

The simulator then resolves what is actually possible.

Examples such as "forge a coin" or "build a device that does X" are not special LLM powers. They are tests of whether existing world primitives can express the proposed operation.

A failed interpretation must not become a canon event merely because the prose would read better that way.

## Narrator side

Narration consumes authorized canonical/knowledge state. It may add descriptive texture, voice, dialogue framing, or uncertainty appropriate to the observer, but it cannot repair missing facts by inventing them.

## Observation law

Use the `OBSERVATORY_LAW` boundary:

```text
canonical log
 -> replay / fold
 -> derived evidence / diagnostics
 -> interpretation
```

Observatory state is not canon. A visualization, metric, oracle agreement, or LLM statement is not itself a semantic commit.

## Special LLM memory

LLM-only memory/style/context may exist outside canon. It remains outside simulator authority unless a separate explicit contract promotes information into canonical state.

## High-risk cases to test

- ambiguous or multi-intent utterance;
- action that has no dedicated script;
- action forbidden by resources/permissions/capabilities;
- action partially realized by ordinary world constraints;
- request that asks the narrator to contradict current canon;
- hidden information unavailable to the acting observer;
- post-event narration after a world change.
