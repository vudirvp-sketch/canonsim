# Changelog — v1.1 -> v1.2

## Why v1.2 exists

v1.1 treated several ideas from the 2026-10-02 discussion as though they were newly established project laws. The repository already contained most of that vision in `docs/VISION.md`, `docs/worldbuild/*`, `docs/TASKS.md`, `docs/PACK_SPEC.md`, and `docs/OBSERVATORY_LAW.md`.

v1.2 corrects that model.

## Changes

- removed the pack's competing "binding world laws" layer;
- restored owner-document precedence explicitly;
- aligned the north star with the frozen `VISION.md` instead of restating it as new design;
- aligned current world status to `WORLD_WORKPLAN.md` / `WORLD_TRACK_AGENT_CONTEXT.md`;
- separated proven substrate from open proposals and deferred world-track mechanisms;
- preserved the compiled/indexed execution idea as a POC only;
- tightened semantic-equivalence requirements around CanonSim's documented byte-identical replay contract;
- made index false-negative prohibition explicit;
- added batch visibility / ordering / RNG questions as prerequisites, not features;
- reframed open-ended actions/objects as composition witnesses against the current closed pack grammar;
- connected provenance, lifecycle, topology, autonomy, knowledge, representation continuity and scale to existing world-track owners instead of presenting them as a new roadmap;
- retained the separate-track law: world work does not become `TASKS.md` work without owner routing;
- reduced duplicate prose and removed claims not supported by the repository evidence.
