# Project Alignment — Owner Documents and Non-Redundant Reading

This file is a navigation layer. It is **not an authority source**.

## Authority order

Use the repository's own owners:

```text
docs/VISION.md                         frozen project thesis
        ↓
docs/CONTRACTS.md / DECISIONS.md     engine contracts / decisions
        ↓
docs/worldbuild/* owner docs        authored world + world-track evidence
        ↓
docs/TASKS.md                      owner-gated engine backlog
        ↓
docs/PACK_SPEC.md                  pack/module contract
        ↓
docs/OBSERVATORY_LAW.md             observation / experiment boundary
```

`docs/worldbuild/WORLD_TRACK_AGENT_CONTEXT.md` is the durable compact navigation surface for the world track. It explicitly says it navigates and reconciles but does not replace owner documents.

## The project vision already contains the user's clarified target

`docs/VISION.md` already establishes:

- deterministic procedural simulation outside the LLM context;
- seeded deterministic generation;
- lazy generation;
- append-only / irreversible canon;
- simulation instead of script;
- simulator as canon and LLM as interface/interpretation;
- player input as data resolved under world rules;
- core/setting separation;
- a living-world target rather than a static lorebook.

Do **not** restate these as newly discovered requirements.

## Worldbuild already contains the intended world behavior

`docs/worldbuild/WORLD_TRACK_AGENT_CONTEXT.md` and `WORLD_AUTHORING.md` already establish:

```text
world = causal possibility space
world -> runs without player / LLM
history -> residue -> future options
small alphabet -> deep composition
meso units -> bridge macro pressure to human choices
knowledge asymmetry is real state
institutions survive carrier turnover when warranted
provenance must be explainable
multiple genres can emerge from one canonical package
```

`WORLD_AUTHORING.md` explicitly uses the quality bar:

```text
CAUSE -> POSSIBILITY -> PRESSURE -> ACTORS -> INSTITUTION
-> KNOWLEDGE -> CONSEQUENCE -> RESIDUE -> NEW OPTIONS
```

It also states the operational maxim:

> Do not invent more things. Invent more consequences.

## Worldbuilding is not the engine queue

`WORLD_TRACK_AGENT_CONTEXT.md` and `docs/TASKS.md` both establish the separate-track law:

```text
worldbuilding experiment / setting need
        -> prove a real engine limitation
        -> owner routes a standing engine row only when warranted
```

Never create a second backlog inside this pack.

## Implication for agents

When a task sounds new, first locate the existing owner statement. The default assumption is **"already intended; perhaps not yet proven/implemented"**, not **"new feature request"**.
