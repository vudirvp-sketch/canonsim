# Cross-Track Capability Test Index

This file is an index, not a second world-test plan.

## World-specific capability witnesses

| Capability | Procedure owner |
|---|---|
| novel composition / novel object or practice | `WORLD_TRACK .../03_PROBES_AND_GATES.md` + `06_FRONTIER_MECHANISMS.md` |
| causal presence / provenance | World Track §5 / §13 probes |
| destruction → recovery | World Track liveness / historical-residue probes |
| lifecycle / succession | World Track institutional-reproduction probe |
| autonomous horizon | World Track liveness probe |
| knowledge asymmetry | World Track knowledge/influence probes |
| genre / human-scale continuity | World Track W6 / narrative-polysemy material |

Do not copy their detailed procedures into this pack.

## Shared/core witnesses

| Capability | Core surface |
|---|---|
| semantic equivalence under optimization | `05_EXECUTION_AND_SCALE_POC.md` |
| representation continuity | `05_EXECUTION_AND_SCALE_POC.md` |
| LLM authority boundary | `07_LLM_AND_OBSERVATION_BOUNDARY.md` |
| history/replay scale | `04_REAL_OPEN_GAPS.md` + repository runtime/tests |

## Rule

If a world witness fails, first route the failure through the World Track
diagnostic/probe owner. Only a demonstrated native engine limit is routed to
`docs/TASKS.md` through the repository owner process.
