# Research Method Bridge

The supplied `Cross-Domain Mechanism Transplantation — Agent Instruction.md` is the research-method authority. This file only states how it applies to CanonSim; it does not duplicate the source.

## Required loop

```text
foreign mechanism / candidate idea
 -> invariant
 -> remove domain cargo
 -> target problem
 -> hidden assumptions
 -> target adaptation
 -> observable consequence
 -> cheapest discriminating test
 -> evidence
 -> disposition
```

## Always separate

```text
observed behavior
!= intended behavior
!= implementation possibility
!= warranted implementation
```

Use:

```text
FACT | INFERENCE | HYPOTHESIS | PROPOSAL | UNKNOWN
```

and:

```text
CONFIRMED | PARTIALLY CONFIRMED | REJECTED | UNRESOLVED | DEFERRED
```

## Prefer the existing substrate

Before a transfer or new primitive, test:

1. Is the problem real?
2. What does the current substrate already explain?
3. What is the strongest competing explanation?
4. What is the cheapest falsifier?

## Critical controls for CanonSim

For execution/causal claims, use where relevant:

- realized-intervention checks;
- minimal pairs;
- positive/negative/sham controls;
- mutation adequacy;
- deterministic fault curriculum;
- delta debugging / counterexample shrink;
- held-out transfer;
- evidence-independence audit;
- metric anti-Goodhart checks.

## Runtime promotion

The Cross-Domain `Runtime-Promotion Gate` and CanonSim's change gate are complementary:

```text
research method proves the gap
        ↓
CanonSim owner/phase gate decides whether runtime may change
```

A clever mechanism is not enough. It must have a real consumer, a real failure/capability gap, a native limit, a falsifier, and an owner/gate.


## World-track relationship

`Cross-Domain Mechanism Transplantation — Agent Instruction.md` remains the
standing research-method source. WORLD_TRACK reuses its method but does not
replace it; this file only bridges it to CanonSim-wide execution/semantic
questions. Do not duplicate the full research manual in either pack.
