#!/usr/bin/env python3
"""station_m6_setup.py — THE PINNED ENGINE INSTALLER (m5 = the m4
iter-357 tool, renamed for the m5 pack; the pinned b11541 and the
install/swap laws ride verbatim).

What this does (double-click law, one-time step 1):
  1. Downloads the PINNED official llama.cpp build (sha256-verified,
     idempotent — a hash match skips the download; an offline local
     archive beside the script wins over the network):
       Windows: b11541 win-cuda-12.4-x64  (the RTX 3080 Ti band; the
                SAME generation that carries /v1/systemone for the
                decision-model five: laya/julia-1/lev/openjev/kev)
       Linux:   b11541 ubuntu-x64         (the validation band)
  2. Windows + CUDA build: resolves the CUDA runtime DLLs. The b11541
     release now SHIPS the official companion archive
     (cudart-llama-bin-win-cuda-12.4-x64.zip = cudart64_12.dll +
     cublas64_12.dll + cublasLt64_12.dll) — the primary path; the
     resolution ladder stays: already visible to the system > the
     companion archive > a CUDA toolkit on the machine.
  3. Unpacks into THIS pack's llama.cpp/ folder (the repo is never
     touched).
  4. Verifies: llama-server(.exe) present + the build carries
     /v1/systemone (a byte grep of the server binary — the decision
     surface is the battery's core, and a missing surface must be
     LOUD, not a mid-run HTTP 404).
  5. On Windows prints the live --list-devices probe result (the device
     band verdict; a missing CUDA there means driver trouble, not a
     setup failure — the build still runs on CPU).

The swap form (the owner's broken workbench/runtime/llama.cpp folder —
a canonsim repo CLONE, not a llama.cpp build):
  --swap         installs the SAME pinned build INTO
                 <repo>/workbench/runtime/llama.cpp/ — whatever is
                 there moves to a sibling backup llama.cpp.bak-<ts>
                 (whole-folder, .git included, nothing deleted);
                 --restore undoes it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import platform
import shutil
import subprocess
import sys
import tarfile
import time
import urllib.request
import zipfile
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent

#: THE PIN (b11541, the newest nightly of 2026-10-10; carries
#: /v1/systemone since the b11538 window — live-verified in this
#: session on the ubuntu build: 'decision model type: laya' + the
#: systemone route answering the real tavern inventory).
BUILDS = {
    ("win", "cuda"): {
        "url": ("https://github.com/ggml-org/llama.cpp/releases/download/"
                "b11541/llama-b11541-bin-win-cuda-12.4-x64.zip"),
        "bytes": 265_224_711,
        "sha256": ("c5ccdd22e6b11c013efd6a931f93c3707e6fa5ab2f90df5c7"
                   "d1838785540ece3"),
        "kind": "zip",
    },
    ("linux", "cpu"): {
        "url": ("https://github.com/ggml-org/llama.cpp/releases/download/"
                "b11541/llama-b11541-bin-ubuntu-x64.tar.gz"),
        "bytes": 17_809_316,
        "sha256": ("36ca310be4405acb7ba59b32dbdce32bb9cd7b1ef95358997b7"
                   "eaed2c6f0188b"),
        "kind": "tar",
    },
}
#: the official CUDA-runtime companion (b11541; Windows CUDA band):
#: cudart64_12.dll + cublas64_12.dll + cublasLt64_12.dll — exactly the
#: three DLLs ggml-cuda.dll loads dynamically (the iter-355 datum).
CUDART = {
    "url": ("https://github.com/ggml-org/llama.cpp/releases/download/"
            "b11541/cudart-llama-bin-win-cuda-12.4-x64.zip"),
    "bytes": 391_443_627,
    "sha256": ("8c79a9b226de4b3cacfd1f83d24f962d0773be79f1e7b75c6af4d"
               "ed7e32ae1d6"),
}


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def download(url: str, dest: Path, *, expect_bytes: int,
             expect_sha256: str, label: str) -> None:
    """The pinned download: resumeless retry x3, the size checked as it
    streams, the sha256 verified after; a mismatch DELETES the partial
    (never a broken file left behind to poison the idempotent skip)."""
    if dest.is_file():
        got = sha256_file(dest)
        if got == expect_sha256:
            print(f"[setup] {label}: already present, sha256 matches "
                  f"— skip", flush=True)
            return
        print(f"[setup] {label}: present but hash differs — "
              f"re-downloading", flush=True)
        dest.unlink()
    last: Exception | None = None
    for attempt in range(1, 4):
        try:
            print(f"[setup] downloading {label}\n  {url}", flush=True)
            t0 = time.monotonic()
            req = urllib.request.Request(url, headers={"User-Agent":
                                                        "canonsim-m5"})
            with urllib.request.urlopen(req, timeout=60) as r, \
                    open(dest, "wb") as out:
                total = 0
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    total += len(chunk)
                    out.write(chunk)
                    if total % (64 << 20) < (1 << 20):
                        mb = total / 1e6
                        rate = mb / max(time.monotonic() - t0, 0.1)
                        print(f"    {mb:8.0f} MB "
                              f"({rate:5.1f} MB/s)", flush=True)
            if total != expect_bytes:
                raise OSError(f"size {total} != pinned {expect_bytes}")
            got = sha256_file(dest)
            if got != expect_sha256:
                raise OSError(f"sha256 {got} != pinned {expect_sha256}")
            print(f"[setup] {label}: {total / 1e6:.0f} MB, sha256 "
                  f"verified", flush=True)
            return
        except (OSError, urllib.error.URLError) as exc:
            last = exc
            print(f"[setup] attempt {attempt} failed: {exc}", flush=True)
            if dest.is_file():
                dest.unlink()
            time.sleep(3.0 * attempt)
    raise SystemExit(f"the {label} download failed after 3 attempts: "
                     f"{last}\nThe offline path: place the archive "
                     f"beside this script and re-run.")


def local_archive(candidate: Path, expect_sha256: str) -> Path | None:
    """The offline law: an archive already beside the script with the
    RIGHT hash wins (never re-downloads); a wrong-hash file is refused
    loudly (never silently used)."""
    if candidate.is_file():
        got = sha256_file(candidate)
        if got == expect_sha256:
            print(f"[setup] local archive {candidate.name} — hash "
                  f"matches, using it", flush=True)
            return candidate
        raise SystemExit(
            f"{candidate.name} is present but its sha256 does not match "
            f"the pin — delete it or replace it with the official "
            f"archive.\n  expected {expect_sha256}\n  got      {got}")
    return None


def unpack(archive: Path, into: Path, kind: str) -> None:
    into.mkdir(parents=True, exist_ok=True)
    if kind == "zip":
        with zipfile.ZipFile(archive) as zf:
            zf.extractall(into)
    else:
        with tarfile.open(archive) as tf:
            tf.extractall(into)


def server_binary(root: Path) -> Path | None:
    """llama-server at the unpacked root or ONE folder deep (the
    launcher discovery law)."""
    name = "llama-server.exe" if os.name == "nt" else "llama-server"
    for base in (root, *[p for p in root.iterdir() if p.is_dir()]):
        cand = base / name
        if cand.is_file():
            return cand
    return None


def systemone_support(exe: Path) -> bool:
    """The decision-surface check: the binary carries /v1/systemone
    (a byte grep — offline, no spawn needed; the battery's core surface)."""
    try:
        blob = exe.read_bytes()
    except OSError:
        return False
    if b"/v1/systemone" in blob:
        return True
    # the server code lives in a sibling lib on some layouts
    for pattern in ("*.so", "*.dll"):
        for lib in exe.parent.glob(pattern):
            try:
                if b"/v1/systemone" in lib.read_bytes():
                    return True
            except OSError:
                continue
    return False


def find_repo(flagged: str | None) -> Path | None:
    """The pack ladder (the m2 v2 subset: beside/above + the home
    paths); None when not found."""
    here = HERE
    rel = ("canonsim", "../canonsim", "../../canonsim",
           "../../../canonsim")
    home_rel = ("Desktop/repo/canonsim", "OneDrive/Desktop/repo/canonsim",
                "Desktop/canonsim", "OneDrive/Desktop/canonsim",
                "Documents/canonsim", "Documents/repo/canonsim")
    cands = [Path(flagged)] if flagged else []
    cands += [os.environ.get("CANONSIM_REPO") or ""]
    cands += [str((here / r).resolve()) for r in rel]
    cands += [str((Path.cwd() / r).resolve()) for r in rel]
    cands += [str(Path.home() / r) for r in home_rel]
    for c in cands:
        if not c:
            continue
        p = Path(c)
        if (p / "core" / "pack.py").is_file() and \
                (p / "brief" / "gbnf.py").is_file():
            return p
    return None


def cuda_dlls_visible() -> list[str]:
    """The DLLs ggml-cuda.dll needs, if the system already exposes
    them (System32 / PATH dirs)."""
    import ctypes.util

    found = []
    for dll in ("cudart64_12", "cublas64_12", "cublasLt64_12"):
        if ctypes.util.find_library(dll):
            found.append(dll + ".dll")
    return found


def do_setup(args) -> int:
    is_win = platform.system() == "Windows"
    band = ("win", "cuda") if is_win else ("linux", "cpu")
    pin = BUILDS[band]
    dest = HERE / Path(pin["url"]).name
    print(f"[setup] the pinned engine: "
          f"{Path(pin['url']).name}", flush=True)

    archive = local_archive(dest, pin["sha256"])
    if archive is None:
        download(pin["url"], dest, expect_bytes=pin["bytes"],
                 expect_sha256=pin["sha256"], label="the engine")
        archive = dest

    target = HERE / "llama.cpp"
    if target.exists() and server_binary(target) is not None:
        print(f"[setup] llama.cpp/ already carries a server — "
              f"unpacking over it (idempotent)", flush=True)
    unpack(archive, target, pin["kind"])
    exe = server_binary(target)
    if exe is None:
        raise SystemExit("the archive unpacked but no llama-server was "
                         "found at llama.cpp/ root or one folder deep")
    print(f"[setup] llama-server: {exe}", flush=True)

    if not systemone_support(exe):
        raise SystemExit(
            "the unpacked build does NOT carry /v1/systemone — the "
            "decision-model surface the battery needs. Refusing to "
            "continue with a wrong build (the pin is wrong or the "
            "archive was tampered).")

    if is_win and band == ("win", "cuda"):
        visible = cuda_dlls_visible()
        if visible:
            print(f"[setup] CUDA runtime DLLs already visible to the "
                  f"system: {', '.join(visible)} — nothing to do",
                  flush=True)
        else:
            cd = HERE / Path(CUDART["url"]).name
            carch = local_archive(cd, CUDART["sha256"])
            if carch is None:
                download(CUDART["url"], cd, expect_bytes=CUDART["bytes"],
                         expect_sha256=CUDART["sha256"],
                         label="the CUDA runtime companion")
            print("[setup] unpacking the CUDA runtime beside the "
                  "server (cudart64_12 / cublas64_12 / cublasLt64_12)",
                  flush=True)
            with zipfile.ZipFile(cd) as zf:
                zf.extractall(exe.parent)
            after = cuda_dlls_visible() or [
                p.name for p in exe.parent.glob("*64_12.dll")]
            print(f"[setup] CUDA runtime in place: {after}", flush=True)

    # the live device probe (Windows: the driver band verdict)
    verdict: dict[str, object] = {
        "build": Path(pin["url"]).name,
        "exe": str(exe),
        "systemone": True,
        "time": datetime.now(timezone.utc).isoformat(),
    }
    if is_win:
        try:
            r = subprocess.run([str(exe), "--list-devices"], timeout=60,
                               capture_output=True, text=True,
                               errors="replace")
            blob = (r.stdout or "") + (r.stderr or "")
            lines = [ln for ln in blob.splitlines() if ln.strip()]
            verdict["devices_raw"] = lines[:40]
            verdict["cuda_visible"] = "CUDA" in blob and \
                "device" in blob.lower()
            print("[setup] --list-devices says:", flush=True)
            for ln in lines[:10]:
                print("    " + ln, flush=True)
        except (OSError, subprocess.SubprocessError) as exc:
            verdict["list_devices_error"] = str(exc)[:300]
            print(f"[setup] --list-devices did not run: {exc}",
                  flush=True)
    else:
        verdict["cuda_visible"] = None  # the honest non-Windows skip
        print("[setup] non-Windows host — the --list-devices probe "
              "skipped (the validation band)", flush=True)
    (HERE / "setup_gate.json").write_text(
        json.dumps(verdict, indent=2, sort_keys=True), encoding="utf-8")

    if args.swap:
        do_swap(args, exe_parent=exe.parent)
    print("[setup] DONE — next: station_m6_doctor.bat, then "
          "station_m6_probe.bat", flush=True)
    return 0


def do_swap(args, exe_parent: Path | None = None) -> None:
    """The PATH B form (iter-355's swap law, now inside the pack): the
    pinned build INTO <repo>/workbench/runtime/llama.cpp/ — whatever is
    there (a CPU build, stray exes, or the owner's canonsim-clone
    folder) moves to a SIBLING backup llama.cpp.bak-<ts>, whole-folder,
    nothing deleted; --restore reverses."""
    repo = find_repo(args.repo)
    if repo is None:
        raise SystemExit("--swap needs the canonsim repo (not found; "
                         "pass --repo)")
    target = repo / "workbench" / "runtime" / "llama.cpp"
    target.parent.mkdir(parents=True, exist_ok=True)

    if args.restore:
        baks = sorted(target.parent.glob("llama.cpp.bak-*"))
        if not baks:
            raise SystemExit("no backup found — nothing to restore")
        if target.exists():
            ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            keep = target.parent / f"llama.cpp.pre-restore-{ts}"
            target.rename(keep)
            print(f"[swap] the current tree saved as {keep.name}",
                  flush=True)
        baks[-1].rename(target)
        print(f"[swap] restored {baks[-1].name} -> llama.cpp",
              flush=True)
        return

    # the diagnosis of what is being swapped out (the LOUD form)
    if target.exists():
        has_git = (target / ".git").exists()
        has_cmake = (target / "CMakeLists.txt").exists()
        has_canonsim = ((target / "AGENTS.md").is_file()
                        or (target / "pyproject.toml").is_file())
        stray_exes = sorted(p.name for p in target.glob("llama-*.exe"))
        if has_git or has_canonsim:
            print("[swap] DIAGNOSIS: workbench/runtime/llama.cpp is a "
                  "canonsim REPO CLONE, not a llama.cpp build"
                  + (f" (with {len(stray_exes)} stray llama-*.exe at "
                     f"its root)" if stray_exes else "")
                  + ".\n  It backs up whole-folder (.git included) — "
                  "nothing is deleted; --restore reverses.", flush=True)
        elif has_cmake:
            print("[swap] the folder carries a llama.cpp SOURCE "
                  "checkout (CMakeLists.txt) — backing it up "
                  "whole-folder.", flush=True)
        else:
            print("[swap] the folder backs up whole-folder.",
                  flush=True)
        ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
        bak = target.parent / f"llama.cpp.bak-{ts}"
        target.rename(bak)
        print(f"[swap] backup: {bak}", flush=True)
    else:
        print("[swap] no existing folder — fresh install", flush=True)

    # install the pack's build (flat: the exe at the root — the
    # discovery law finds it first)
    src = (exe_parent if exe_parent is not None
           else (HERE / "llama.cpp"))
    if server_binary(src) is None:
        raise SystemExit("the pack's llama.cpp/ has no server — run "
                         "the setup first (no --swap)")
    target.mkdir(parents=True, exist_ok=True)
    for p in sorted(src.iterdir()):
        if p.name.startswith("llama.cpp.bak") or p.name.endswith(".zip"):
            continue
        dst = target / p.name
        if dst.exists():
            if dst.is_dir():
                shutil.rmtree(dst)
            else:
                dst.unlink()
        (shutil.copytree if p.is_dir() else shutil.copy2)(p, dst)
    exe = server_binary(target)
    print(f"[swap] the pinned build installed at {target} "
          f"(server: {exe})", flush=True)
    if exe is not None and not systemone_support(exe):
        print("[swap] WARNING: the installed server lacks "
              "/v1/systemone — this build cannot serve decision "
              "models!", flush=True)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(
        description="the m4 pinned engine installer")
    ap.add_argument("--swap", action="store_true",
                    help="also install the build INTO "
                         "workbench/runtime/llama.cpp (sibling backup)")
    ap.add_argument("--restore", action="store_true",
                    help="undo the swap (the newest backup returns)")
    ap.add_argument("--repo", default=None)
    args = ap.parse_args(argv)
    if args.restore:
        return do_swap(args)
    return do_setup(args)


if __name__ == "__main__":
    raise SystemExit(main())
