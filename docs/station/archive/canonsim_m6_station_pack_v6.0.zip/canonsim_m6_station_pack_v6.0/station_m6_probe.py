#!/usr/bin/env python3
"""station_m6_probe.py — THE M6 PROMOTION PACK (iter-368, v6.0, R AT
THE DOOR). The owner's promotion permission (2026-10-11, «разрешаю
promotion R») executes D-250's recorded M3 decision: THE ROUTER IS
THE VERDICT-PATH OPERATOR — the production form is R at the door +
THE L12 TEMPLATE RUNG as the prose surface (a SEPARATE surface,
PRESENTATION_SPEC §7; the narrator's production form stays the
template rung — the 2026-10-03 call stands). The m5 v5.0 battery
rides verbatim beneath (Rule 9: the pack lives outside the repo;
rebuilding from scratch would re-risk the iter-352/359/360 lessons);
the m5 zip itself is now archived IN the repo at
docs/station/archive/ (the owner's explicit 2026-10-11 instruction —
the station source preserved for every future session):

  R    THE PRODUCTION FORM: the router arm (m4/m5 verbatim) — the
       /v1/systemone decision route -> the deterministic door -> the
       REAL ParserDoor. 0 inventions, output_tokens=0 — the
       construction proofs ride every record. The gate rides the
       PROFILE: --gate 0.5 the default (D-250 M2), --gate 0.4 the
       explicit recall-oriented deployment override (NEVER a more-
       reliable mode — the measured cost verbatim in --gate's help
       and the report; no separating threshold exists).
  G    the control (m4 verbatim): the generative model under the
       GBNF reply grammar, temp 0 — the cross-battery anchor (skip
       with --no-g; R is self-sufficient).
  RU   the RU band at the PROFILE gate — the same-session Russian
       baseline (12 hand-authored rows).
  narrate THE L12 TEMPLATE RUNG (NEW, the production prose surface):
       every R-arm unit's log rendered through the repo's own
       chronicle renderer (render/chronicle.py — the tale as a pure
       function of the log, T1-covered). Each tale rendered TWICE
       with the md5 compared — the L12 rung's determinism proof,
       live; the tales ship as narrate/<unit>.txt for the owner's
       own reading; the reference (gold) units render beside the R
       units — the prose surface's own like-for-like.
  det  the determinism mini: the systemone call twice, the G route
       twice (temp 0) — byte-identical, digests recorded.
  package the m6_*.zip (always ships, even on crash).

  h    OPT-IN ONLY (--stages h): the hybrid single-pass halves (H0
       temp 0 + H8 temp 0.8-seeded, the m5 core verbatim) — H is NOT
       promoted (D-250: the m5 evidence insufficient; the artistic
       quality unmeasured; the aesthetic call open). The stage stays
       in the pack as the instrument for that future call; it is
       NEVER in the default battery.

THE FALSE-ALLOW CENSUS IS NOW THE STANDING WATCH (the m5 instrument
promoted): every gate-passed cycle of R and RU — at ANY profile gate
— is checked against its gold; a wrong-kind or wrong-object pass is
a falsely-allowed action, never a win; a non-intent gold that passes
is the gravest class (the owner's recorded words: the growth of
accepted requests does not by itself prove the system more
reliable). Field-value divergences stay their own census class.

THE BAND INSTRUMENT (the KI#119 tooth, NEW): the m5 station run's
own logs carry ZERO CUDA lines — no ggml_cuda_init, no offload, zero
cuda mentions in either server log — the spawned servers initialized
no CUDA backend; the run was the CPU band while cuda_gate.bands
honestly read {} the whole time. The GPU-band latency readings of
the series (iter-358's ×6.3, iter-361's «FULL offload») rode the
assumption, not the instrument — the same class as KI#118. The m6
gate now DERIVES the band verdict from the server logs and SAYS IT
LOUD at run end: cuda visible + no init in the log = the CUDA DLL
resolution failed (re-run station_m6_setup.bat — the cudart
companion); the band verdict lands in cuda_gate.json and the report
with the evidence. The station's next run settles its own band by
data.

Everything else rides the m4/m5 laws verbatim: the resumable stages,
the crash zip (the server logs INSIDE), the log tail in every
failure, the lazy spawn + recycle + the batch law + the 400
escalation + the planned GPU rung, the TTY prompts, the
premise-drift fingerprints, the always-a-zip finally.

Outside the repo by law (Rule 9 / D-046). The analysis carries no
decision — the owner's call.
"""

from __future__ import annotations

import argparse
import json
import os
import re
import shutil
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from collections.abc import Mapping, Sequence
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

# -- the pack's own identity ----------------------------------------------------

#: v4 (iter-357): THE CLASSIFIER SEMANTICS — the F arm (the generative
#: grammar extractor) REPLACED by the R arm (the /v1/systemone
#: decision route); the engine installer + the model doctor live in
#: the pack; the pinned b11541; the RU band; the device-class gate
#: inside the pack's own spawns.
#: v4.1 (iter-358): THE BATCH LAW + THE PLANNED GPU RUNG — the owner's
#: station run died on the router's first systemone call (741 tokens
#: against the stock n_batch=512 -> HTTP 400 -> three identical
#: restarts -> RouterDown). Fixed: an explicit -b on every spawn
#: (2048 default), the ubatch tied to it on the router (the embeddings
#: law: n_batch = n_ubatch), the 400-class heal escalation, and a
#: deliberate -ngl planned from the LIVE free VRAM per spawn.
#: v4.2 (iter-359): THE FLAG FIX — the iter-358 chat guidance named
#: --g/--ru/--det/--full-corpus; the owner tried them; they did not
#: exist (argparse refused them). Added as no-op aliases for the
#: default (all stages run, full corpus). Plus --stages for the
#: subset selector (the "run only RU+det after R+G" form), and
#: allow_abbrev=False so --ru no longer collides with --run-dir's
#: prefix (the confusing "expected one argument" error). Zero
#: battery behavior change — the four flags are documentation, the
#: real toggles stay --no-g and --stages.
#: iter-360: the Verb attribute fix — the pack's own crash on the
#: first live drop_break route (see README_RU.txt, the v4.3 section).
#: v5.0 (iter-365): THE M5 SAME-CORPUS BATTERY — the H arm (the m3
#: hybrid single-pass form on the m4 corpus at last: the terminated-
#: prose grammar, the split law, the prose ledger; H0 temp 0 + H8
#: temp 0.8-seeded, both on the SAME main spawn as G) + the 0.4 knob
#: with its COST SIDE (RU04: the 12 Russian rows re-assembled at gate
#: 0.4 with the falsely-allowed-actions census; R04: the full English
#: corpus at 0.4, the same census — the row's machinery extended to
#: where the 87.1%@0.4 sweep number lives) + the det g/h digest lines
#: (the iter-361 instrument gap). The m4 v4.3 machinery rides
#: byte-verbatim below — only additions, no behavior change to the
#: r/g/ru arms.
#: v6.0 (iter-368): THE PROMOTION PACK — R AT THE DOOR, the owner's
#: «разрешаю promotion R» executing D-250's M3: (1) the DEFAULT
#: BATTERY IS THE PRODUCTION FORM — R (the verdict path) + the
#: narrate stage (the L12 TEMPLATE RUNG, the prose as a SEPARATE
#: surface — render/chronicle.py over the R run's logs, the md5
#: determinism proof live, the gold units rendered beside) + the G
#: anchor + the RU band + det; (2) H demoted to OPT-IN (--stages h —
#: never in the default; the aesthetic call the owner's); (3) RU04/
#: R04 REMOVED — the --gate profile knob replaces them (0.5 the
#: default, 0.4 the explicit recall-oriented deployment override per
#: D-250 M2, its measured cost in the help; the false-allow census
#: promoted to the STANDING WATCH on every R/RU cycle at any gate);
#: (4) THE BAND INSTRUMENT (KI#119): the band verdict DERIVED from
#: the server logs (the m5 run's logs carry zero CUDA lines — the
#: spawned servers never initialized CUDA; cuda_gate.bands was {} the
#: honest empty) — the loud run-end verdict, the final cuda_gate.json
#: rewrite, the report's band line. The r/g/ru arms ride m5-verbatim
#: (the census comparability law holds); only additions around them.
PACK_VERSION = "v6.0 (iter-368: THE PROMOTION PACK — R at the door " \
               "(D-250 M3, the owner's promotion permission) + the " \
               "L12 template rung as the narrate stage (the prose a " \
               "separate surface) + the --gate profile knob (0.5 the " \
               "default, 0.4 the explicit recall override) + the " \
               "false-allow census as the standing watch + the band " \
               "instrument (KI#119 — the verdict derived from the " \
               "server logs); H opt-in only, never in the default)"

#: the noul gate's threshold (the validity gate): P < gate -> the
#: router declines to route (a no_intent doc). 0.5 = the calibrated
#: midpoint AND the recorded owner default (D-250 M2: 0.5 THE
#: DEFAULT); the profile rides --gate.
NOUL_GATE = 0.5

#: THE RECALL-ORIENTED DEPLOYMENT OVERRIDE (D-250 M2, recorded
#: 2026-10-11): 0.4 — an explicit recall-oriented deployment profile,
#: NEVER a more-reliable mode. The measured cost rides verbatim (EN
#: correct_allow 15->20, blocked_miss 10->4, false_allow_nonintent
#: 4->7, precision-on-passed 60.0%->58.8%; no separating threshold
#: exists — the gate_p bands overlap). Chosen with --gate 0.4; the
#: false-allow census rides every gate-passed row at BOTH profiles
#: (the standing watch — the owner's recorded call: the growth of
#: accepted requests does not by itself prove the system more
#: reliable — the wrong-kind/wrong-object passes are counted, never
#: celebrated).
NOUL_GATE_LOOSE = 0.4

#: THE BATCH LAW (iter-358): /v1/systemone scores the WHOLE payload
#: (the state + every question's criteria) in ONE n_batch. The stock
#: n_batch is 512 — the tavern pack's 741-token set died on it (the
#: iter-357 station crash). Every spawn now carries an explicit -b;
#: the heal escalates it on any 400-class death (doubling + the
#: observed headroom; the ceiling below).
DEFAULT_SPAWN_BATCH = 2048
#: the MAIN's physical micro-batch: the chat route chunks internally,
#: so 512 keeps the compute buffer small. The ROUTER's ubatch RIDES
#: its batch instead — the embeddings path ties n_batch to n_ubatch
#: (b11541's own log: 'embeddings enabled: setting n_batch =
#: n_ubatch = 512'), so they move as a pair.
SPAWN_UBATCH = 512
#: the escalation ceiling for both -b and the ctx it drags along.
BATCH_CAP = 32768

#: the R-form's fixed field policy (the honest cost, documented):
#: the router ROUTES; it does not invent field VALUES. Where the
#: action needs a field, the door fills the deterministic default and
#: the census counts the divergence class 'fields'.
R_FIELD_DEFAULTS = {
    "wait": {"ticks": 30},          # the corpus's modal value
    "steal": {"method": "distraction"},  # the only legal methods key
    "drop_break": {"near": None},    # the position's first spot value
}


# -- the repo discovery (the v2 ladder law, iter-352 — verbatim) ----------

_REPO_REL = ("canonsim", "../canonsim", "../../canonsim", "../../../canonsim")
_HOME_REL = (
    "Desktop/repo/canonsim", "OneDrive/Desktop/repo/canonsim",
    "Desktop/canonsim", "OneDrive/Desktop/canonsim",
    "Documents/canonsim", "Documents/repo/canonsim",
    "repo/canonsim", "canonsim",
)


def find_repo(flagged: str | None) -> tuple[Path, list[str], bool]:
    """--repo > env CANONSIM_REPO > pack-relative (beside/above) >
    cwd-relative (the same four) > the 8 home paths. Two markers
    (brief/gbnf.py + core/pack.py); the refusal names every candidate
    tried — never a silent guess."""
    here = Path(__file__).resolve().parent
    candidates: list[Path] = []
    if flagged:
        candidates.append(Path(flagged))
    if os.environ.get("CANONSIM_REPO"):
        candidates.append(Path(os.environ["CANONSIM_REPO"]))
    candidates += [(here / rel).resolve() for rel in _REPO_REL]
    candidates += [(Path.cwd() / rel).resolve() for rel in _REPO_REL]
    home = Path.home()
    candidates += [home / rel for rel in _HOME_REL]
    ordered: list[Path] = []
    seen: set[str] = set()
    for c in candidates:
        if str(c) not in seen:
            seen.add(str(c))
            ordered.append(c)
    for c in ordered:
        if ((c / "brief" / "gbnf.py").is_file()
                and (c / "core" / "pack.py").is_file()):
            return c, [str(x) for x in ordered], True
    return (ordered[0] if ordered else Path("canonsim"),
            [str(x) for x in ordered], False)


# -- the census (the m3 classifier, verbatim — byte-comparable) -------------

TEXTURE_KEYS = ("entry", "scope", "slot", "value")


def _norm_fields(fields: Mapping[str, object] | None) -> dict[str, object]:
    out = dict(fields or {})
    tex = out.get("texture")
    if isinstance(tex, Mapping):
        out["texture"] = {k: tex.get(k) for k in TEXTURE_KEYS}
    return out


def census_class(
    reply_doc: object,
    expected_reply: Mapping[str, object] | None,
    pinned: Sequence[str],
    expected_pinned: Sequence[str],
) -> str:
    """One cycle's agreement class (disjoint), the m2 vocabulary with the
    m2's precedence: not_intent -> kind -> the TEXTURE-PIN FAMILY
    (no_pin: the expected texture path missed its pin, whatever the
    wrong path was) -> target -> fields -> full. The no_pin class is
    the texture family's own failure class (the station datum: pinned
    [] against the expected [tex_0000]). The m3 form VERBATIM (the
    cross-battery comparability law)."""
    exp = expected_reply or {}
    exp_intent = exp.get("intent") if isinstance(exp, dict) else None
    if not isinstance(exp_intent, Mapping):
        exp_alt = {k for k in exp if k in ("question", "no_intent")}
        if isinstance(reply_doc, Mapping):
            got_alt = {k for k in reply_doc
                       if k in ("question", "no_intent")}
            return "full" if got_alt == exp_alt and exp_alt else "not_intent"
        return "not_intent"
    if not isinstance(reply_doc, Mapping) or "intent" not in reply_doc:
        return "not_intent"
    got = reply_doc["intent"]
    if not isinstance(got, Mapping):
        return "not_intent"
    if got.get("kind") != exp_intent.get("kind"):
        return "kind"
    exp_fields = exp_intent.get("fields") or {}
    exp_texture = (exp_fields.get("texture")
                   if isinstance(exp_fields, Mapping) else None)
    if isinstance(exp_texture, Mapping):
        # the texture family: full ONLY on the verbatim texture path +
        # the fired pin; every other shape is the pin-miss class
        got_fields = got.get("fields") or {}
        got_texture = (got_fields.get("texture")
                       if isinstance(got_fields, Mapping) else None)
        if (isinstance(got_texture, Mapping)
                and _norm_fields(got_fields) == _norm_fields(exp_fields)
                and sorted(pinned) == sorted(expected_pinned or ())
                and got.get("target") is None):
            return "full"
        return "no_pin"
    if got.get("target") != exp_intent.get("target"):
        return "target"
    if _norm_fields(got.get("fields")) != _norm_fields(exp_fields):
        return "fields"
    if sorted(pinned) != sorted(expected_pinned or ()):
        return "no_pin"
    return "full"


def false_allow_class(assembled: object, gate: str | None,
                      gold: Mapping | None) -> str:
    """THE FALSE-ALLOW CENSUS (m5, the M2 knob's cost side — the owner's
    recorded call iter-364 §F: «the growth of accepted requests does
    not by itself prove the system more reliable»). Applied to every
    RU04/R04 row AGAINST its gold; a pass is CORRECT only when the
    action kind AND the acted-on object match the gold's. Disjoint
    classes:

      blocked               the gate said no (excluded from the
                            false-allow count; for an intent gold a
                            miss, for a non-intent gold the honest
                            rejection — the report splits these)
      correct_allow         kind matches AND the object matches (a
                            field-VALUE divergence may still ride here
                            — the census keeps it visible as its own
                            class; the ACTION was right)
      false_allow_kind      the gate passed a WRONG ACTION KIND
      false_allow_object    the kind matched but a DIFFERENT object
                            was committed (a canon target mismatch, or
                            the texture-gold shape committed as a
                            different target/slot — the ru_05 class)
      false_allow_nonintent the gold says the utterance carried NO
                            world-touching action, the gate committed
                            one anyway — the gravest class
      pass_no_action        the gate passed but the router returned no
                            usable action (impossible by construction;
                            recorded, never dropped)
    """
    if gate != "passed":
        return "blocked"
    gold_doc = gold if isinstance(gold, Mapping) else {}
    gold_intent = gold_doc.get("intent")
    a_intent = (assembled.get("intent")
                if isinstance(assembled, Mapping) else None)

    def _obj(intent: object) -> str | None:
        if not isinstance(intent, Mapping):
            return None
        tgt = intent.get("target")
        if tgt is not None:
            return f"id:{tgt}"
        fields = intent.get("fields")
        tex = (fields.get("texture")
               if isinstance(fields, Mapping) else None)
        if isinstance(tex, Mapping):
            return f"slot:{tex.get('slot')}"
        return None

    if not isinstance(gold_intent, Mapping):
        return ("false_allow_nonintent"
                if isinstance(a_intent, Mapping) else "pass_no_action")
    if not isinstance(a_intent, Mapping):
        return "pass_no_action"
    if a_intent.get("kind") != gold_intent.get("kind"):
        return "false_allow_kind"
    if _obj(gold_intent) is not None and _obj(a_intent) != _obj(gold_intent):
        return "false_allow_object"
    return "correct_allow"


# -- the transports ------------------------------------------------------------


class ChatResult:
    __slots__ = ("content", "finish_reason", "wall_s", "prompt_tokens",
                 "completion_tokens")

    def __init__(self, content, finish_reason, wall_s, prompt_tokens,
                 completion_tokens):
        self.content = content
        self.finish_reason = finish_reason
        self.wall_s = wall_s
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class ServerDown(RuntimeError):
    """The engine ladder's terminal signal: the server died or never
    came up (the mid-arm self-healing catches this)."""


class RouterDown(ServerDown):
    """The ROUTER server's terminal signal (the decision model — the
    m4 core). The battery DEGRADES on the MAIN (the G arm skips) but
    DIES on the router: the R arm IS the battery."""


_MODEL_IDS: dict[str, str] = {}


def _model_id_for(endpoint: str, fallback: str = "default") -> str:
    """The OAI `model` field law (the iter-353 station datum: the
    owner's ATTACHED b11490 rejects a chat body without it). The value
    is the server's own /v1/models report, cached per endpoint."""
    ep = endpoint.rstrip("/")
    if ep not in _MODEL_IDS:
        ids = LlamaClient(ep).list_models()
        _MODEL_IDS[ep] = ids[0] if ids else fallback
    return _MODEL_IDS[ep]


class LlamaClient:
    """The minimal llama-server chat transport (the m3 form verbatim:
    per-request grammar, seed, temperature; the OAI model field always
    sent)."""

    def __init__(self, endpoint: str, timeout_s: float = 300.0,
                 model_name: str | None = None) -> None:
        self.endpoint = endpoint.rstrip("/")
        self.timeout_s = timeout_s
        self.model_name = model_name

    def health(self) -> bool:
        try:
            with urllib.request.urlopen(
                self.endpoint + "/health", timeout=5.0
            ) as r:
                return r.status == 200
        except (urllib.error.URLError, OSError, ValueError):
            return False

    def props(self) -> dict:
        with urllib.request.urlopen(
            self.endpoint + "/props", timeout=10.0
        ) as r:
            return json.loads(r.read().decode("utf-8"))

    def list_models(self) -> list[str]:
        try:
            with urllib.request.urlopen(
                self.endpoint + "/v1/models", timeout=10.0
            ) as r:
                doc = json.loads(r.read().decode("utf-8"))
        except (urllib.error.URLError, OSError, ValueError):
            return []
        out: list[str] = []
        if isinstance(doc, dict):
            for m in doc.get("data", ()):
                if isinstance(m, dict) and m.get("id"):
                    out.append(str(m["id"]))
        return out

    def chat(
        self,
        messages: Sequence[Mapping[str, str]],
        *,
        grammar: str | None,
        temperature: float,
        max_tokens: int,
        seed: int = 42,
    ) -> ChatResult:
        if self.model_name is None:
            self.model_name = _model_id_for(self.endpoint)
        body: dict[str, object] = {
            "model": self.model_name,
            "messages": [
                {"role": str(m["role"]), "content": str(m["content"])}
                for m in messages
            ],
            "temperature": temperature,
            "max_tokens": max_tokens,
            "seed": seed,
            "chat_template_kwargs": {"enable_thinking": False},
        }
        if grammar is not None:
            body["grammar"] = grammar
        req = urllib.request.Request(
            self.endpoint + "/v1/chat/completions",
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        t0 = time.monotonic()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout_s) as r:
                doc = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:400]
            raise ServerDown(f"HTTP {exc.code}: {detail}") from exc
        except (urllib.error.URLError, OSError) as exc:
            raise ServerDown(f"unreachable: {exc}") from exc
        wall = time.monotonic() - t0
        try:
            choice = doc["choices"][0]
            content = choice["message"]["content"] or ""
            finish = str(choice.get("finish_reason") or "")
        except (KeyError, IndexError, TypeError) as exc:
            raise ServerDown(f"no usable completion: {exc}") from exc
        usage = doc.get("usage") or {}
        return ChatResult(
            content, finish, wall,
            int(usage.get("prompt_tokens", 0) or 0),
            int(usage.get("completion_tokens", 0) or 0),
        )


class SystemOneResult:
    __slots__ = ("answers", "wall_s", "input_tokens", "output_tokens")

    def __init__(self, answers, wall_s, input_tokens, output_tokens):
        self.answers = answers
        self.wall_s = wall_s
        self.input_tokens = input_tokens
        self.output_tokens = output_tokens


class SystemOneClient:
    """The /v1/systemone transport (the decision-model surface, PR
    #29818): {state, questions} -> {answers} in ONE forward pass. The
    questions ride per request (the answer space is the CALLER's — new
    schemas never need retraining). output_tokens stays 0 (the
    non-generativity proof rides every record)."""

    def __init__(self, endpoint: str, timeout_s: float = 300.0) -> None:
        self.endpoint = endpoint.rstrip("/")
        self.timeout_s = timeout_s

    def health(self) -> bool:
        return LlamaClient(self.endpoint).health()

    def ask(self, state: Mapping, questions: Mapping) -> SystemOneResult:
        body = json.dumps({"state": state, "questions": questions
                           }).encode("utf-8")
        req = urllib.request.Request(
            self.endpoint + "/v1/systemone", data=body,
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        t0 = time.monotonic()
        try:
            with urllib.request.urlopen(
                    req, timeout=self.timeout_s) as r:
                doc = json.loads(r.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", "replace")[:400]
            raise ServerDown(
                f"systemone HTTP {exc.code}: {detail}") from exc
        except (urllib.error.URLError, OSError) as exc:
            raise ServerDown(f"systemone unreachable: {exc}") from exc
        wall = time.monotonic() - t0
        usage = doc.get("usage") or {}
        return SystemOneResult(
            doc.get("answers") or {}, wall,
            int(usage.get("input_tokens", 0) or 0),
            int(usage.get("output_tokens", 0) or 0),
        )


# -- the engine discovery + the spawn machinery (the m3 laws) ----------------


def _exe_candidates(repo: Path) -> list[Path]:
    """The launcher law (iter-349) + THE PACK'S OWN BUILD FIRST (the
    m4 setup's install target — the owner's runtime/llama.cpp being
    a repo clone made the pack-local build the reliable path): the
    pack's llama.cpp root + one deep, then the repo's runtime folder
    the same way, then PATH, then the Windows station hint."""
    out: list[Path] = []
    here = Path(__file__).resolve().parent
    # THE SIBLING-PACK LAW (m5): the m4 pack's own llama.cpp/ beside
    # this one is searched BEFORE the repo's runtime folder — the
    # station already carries the pinned b11541 there; unpacking m6
    # beside m4 reuses the engine with no re-download (the setup's
    # idempotent skip stays the honest fallback).
    roots = [here / "llama.cpp"]
    roots += sorted(here.parent.glob("canonsim_m*_station_pack*/llama.cpp"))
    seen_roots: list[Path] = []
    for r in roots:
        if r not in seen_roots:
            seen_roots.append(r)
    for root in tuple(seen_roots) + (
            repo / "workbench" / "runtime" / "llama.cpp",):
        if root.is_dir():
            out.append(root / "llama-server")
            out.append(root / "llama-server.exe")
            for sub in sorted(root.iterdir()):
                if sub.is_dir():
                    out.append(sub / "llama-server")
                    out.append(sub / "llama-server.exe")
    which = shutil.which("llama-server")
    if which:
        out.append(Path(which))
    out.append(Path(r"D:\llama.cpp\llama-server.exe"))
    return [p for p in out if p.is_file()]


def _gguf_models(repo: Path) -> list[Path]:
    """The models-dir law (wb-9): every *.gguf under
    workbench/runtime/models, codepoint-sorted, the suffix
    case-insensitive; .part never matches."""
    d = repo / "workbench" / "runtime" / "models"
    if not d.is_dir():
        return []
    return sorted(
        (p for p in d.iterdir()
         if p.is_file() and p.suffix.lower() == ".gguf"),
        key=lambda p: p.name,
    )


def _free_port() -> int:
    import socket

    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def _gguf_sanity(model: Path) -> str | None:
    """The spawn pre-check (the iter-353 law: the OneDrive cloud-only
    placeholder and the broken download caught BEFORE the spawn, with
    a named reason)."""
    try:
        st = model.stat()
    except OSError as exc:
        return f"unreachable ({exc})"
    if st.st_size < 1_000_000:
        return (f"only {st.st_size} bytes — a placeholder or a failed "
                f"download, not a model")
    try:
        with open(model, "rb") as fh:
            head = fh.read(4)
    except OSError as exc:
        return (f"unreadable ({exc}) — an OneDrive cloud-only file? "
                f"Open/hydrate the models folder once, or move the "
                f"model to a local disk")
    if head != b"GGUF":
        return f"magic {head!r} is not b'GGUF' — corrupted or not a GGUF"
    return None


def _log_tail(log_path: Path | None, lines: int = 25) -> str:
    """The server log's last lines — embedded in every spawn failure
    (the iter-353 evidence law)."""
    if log_path is None:
        return "(no log path)"
    try:
        text = Path(log_path).read_text(encoding="utf-8", errors="replace")
    except OSError:
        return "(log unreadable)"
    tail = text.splitlines()[-lines:]
    return "\n".join(tail) if tail else "(log empty)"



def _flag_present(argv: Sequence[str], short: str, long_: str) -> bool:
    """True when the operator's own args already carry the flag — any
    spelling: '-b 512', '-b512', '-b=512', '--batch-size 512',
    '--batch-size=512'. The operator's call wins over the pack's."""
    for a in argv:
        if a == short or a.startswith(short + "=") or (
                a.startswith(short) and a[len(short):].isdigit()):
            return True
        if a == long_ or a.startswith(long_ + "="):
            return True
    return False


BATCH_TOKENS_RE = re.compile(r"\((\d+)\s*tokens?\)", re.I)


def _next_pow2(n: int) -> int:
    p = 1
    while p < n:
        p *= 2
    return p


def escalated_router_batch(current_b: int, current_ctx: int,
                           needed_tokens: int | None) -> tuple[int, int]:
    """THE 400-CLASS ESCALATION (iter-358): the systemone payload
    must fit in ONE n_batch <= n_ctx. Returns the next (batch, ctx)
    pair — strictly bigger than the current batch (doubling, or the
    observed need + a 12% headroom when the server named the token
    count), the ctx riding at the next power of two when the batch
    passes it; both stop at BATCH_CAP."""
    want = (needed_tokens + 256 + needed_tokens // 8
            if needed_tokens else current_b * 2)
    nb = min(max(current_b * 2, want), BATCH_CAP)
    nctx = current_ctx
    if nb > nctx:
        nctx = min(_next_pow2(nb), BATCH_CAP)
        nb = nctx
    return nb, nctx



def _probe_vram_mib(which: str) -> int | None:
    """nvidia-smi's live reading in MiB ('memory.free' or
    'memory.total'), or None when nvidia-smi is absent — NOT an
    error: the spawn keeps the engine's own offload default and the
    reactive ladder guards beneath."""
    try:
        r = subprocess.run(
            ["nvidia-smi", f"--query-gpu={which}",
             "--format=csv,noheader,nounits"],
            timeout=15, capture_output=True, text=True, errors="replace")
        if r.returncode != 0:
            return None
        lines = [ln.strip() for ln in (r.stdout or "").splitlines()
                 if ln.strip()]
        return int(lines[0]) if lines else None
    except (OSError, ValueError, subprocess.SubprocessError):
        return None



def _estimate_layers(weights_mib: int) -> int:
    """The layer-count estimate by file-size class (the GGUF file
    size is a weights proxy; a ±20% error moves the planned rung a
    couple of layers — the reserve absorbs it)."""
    if weights_mib <= 512:
        return 24
    if weights_mib <= 1024:
        return 28
    if weights_mib <= 2700:
        return 32
    if weights_mib <= 5800:
        return 36
    if weights_mib <= 8500:
        return 44
    if weights_mib <= 16000:
        return 64
    return 80



def plan_gpu_rung(model: Path, ctx: int, *,
                  free_mib: int | None = None) -> tuple[int | None, str]:
    """THE PLANNED OFFLOAD (iter-358 — the owner's commission: 'the
    layers set properly for a 3080 Ti, 12 GB, 32 GB RAM'). BEFORE the
    spawn the live free VRAM is read; the model's file size is the
    weight estimate; the rung is chosen so weights-on-GPU + the
    KV/compute reserve stay UNDER that reading. Full fit -> 999.
    Tight -> a partial rung (the rest rides RAM via mmap — the 32 GB
    law). No nvidia-smi -> None (the engine's own default stands; the
    reactive 24->8->0 ladder still guards beneath)."""
    if free_mib is None:
        free_mib = _probe_vram_mib("memory.free")
    if free_mib is None:
        return None, ("no live VRAM reading (nvidia-smi absent?) — "
                      "the engine's own default offload; the reactive "
                      "ladder guards beneath")
    try:
        weights_mib = int(model.stat().st_size // (1024 * 1024))
    except OSError:
        return None, "the model unreadable — the engine's default offload"
    if weights_mib <= 0:
        return None, "the model empty — the engine's default offload"
    # the KV cache (ctx-scaled) + the compute buffer (ubatch-scaled,
    # and the router's rides its 2048 batch) + the CUDA context +
    # fragmentation. Deliberately fat: the reserve IS the margin.
    reserve = 1400 + ctx // 8
    layers = _estimate_layers(weights_mib)
    if free_mib >= weights_mib + reserve:
        return 999, (f"free {free_mib} MiB >= weights {weights_mib} MiB "
                     f"+ reserve {reserve} MiB -> FULL offload "
                     f"(-ngl 999)")
    frac = (free_mib - reserve) / weights_mib
    frac = min(max(frac, 0.0), 1.0)
    ngl = int(frac * layers)
    return ngl, (f"free {free_mib} MiB < weights {weights_mib} MiB + "
                 f"reserve {reserve} MiB -> -ngl {ngl}/{layers} "
                 f"({round(frac * 100)}% on GPU; the rest rides "
                 f"RAM/mmap)")


#: the spawn GPU ladder (the iter-353 resilience law): the planned
#: rung's DESCENT when a planned spawn still dies — progressively
#: lower --n-gpu-layers down to CPU-only. An EXPLICIT -ngl in
#: --server-arg disables the ladder (the operator's call wins).
GPU_FALLBACKS: tuple[tuple[str, ...], ...] = (
    (),
    ("--n-gpu-layers", "24"),
    ("--n-gpu-layers", "8"),
    ("--n-gpu-layers", "0"),
)


class DeviceGate:
    """THE DEVICE-CLASS GATE (the iter-354 §B lesson, iter-355's kit
    law, now INSIDE the pack — the v4 row): the --list-devices
    precheck before the FIRST spawn (no CUDA -> the LOUD warning; a
    blind CPU run needs --yes-cpu or a TTY confirmation); the
    ggml_cuda_init/offload grep after the first health -> the band
    verdict in cuda_gate.json.

    THE v6.0 TOOTH (KI#119): the m5 station run's logs carried ZERO
    CUDA lines while cuda_gate.bands read {} — the instrument stayed
    silent exactly when it should have shouted. Now the negative
    verdict is RECORDED (a server whose log shows no init = the
    'cpu (no ggml_cuda_init)' band), and finalize() re-observes every
    server log at run end and prints the LOUD band verdict: cuda
    visible + no init = the CUDA DLL resolution failed — the run was
    the CPU band, the latency ledger reads CPU, re-run
    station_m6_setup.bat (the cudart companion)."""

    def __init__(self) -> None:
        self.checked = False
        self.cuda_visible: bool | None = None
        self.devices: list[str] = []
        self.bands: dict[str, str] = {}
        self.vram: dict[str, str] = {}
        #: one canonical name per server log (the health-time observe
        #: names the model; the finalize's role names reuse it — never
        #: two keys for one server)
        self._log_names: dict[str, str] = {}

    def precheck(self, exe: Path, *, allow_cpu: bool) -> None:
        if self.checked:
            return
        self.checked = True
        try:
            r = subprocess.run([str(exe), "--list-devices"], timeout=60,
                               capture_output=True, text=True,
                               errors="replace")
            blob = (r.stdout or "") + (r.stderr or "")
        except (OSError, subprocess.SubprocessError) as exc:
            print(f"[gate] --list-devices did not run: {exc}",
                  flush=True)
            self.cuda_visible = None
            return
        self.devices = [ln.strip() for ln in blob.splitlines()
                        if ln.strip()][:40]
        self.cuda_visible = bool(re.search(r"CUDA", blob)) and bool(
            re.search(r"device|GPU", blob, re.I))
        if self.cuda_visible:
            print("[gate] CUDA device(s) visible:", flush=True)
            for ln in self.devices[:6]:
                print("    " + ln, flush=True)
        else:
            print("=" * 62, flush=True)
            print("[gate] NO CUDA DEVICE VISIBLE to llama-server.", flush=True)
            print("  The engine will run on the CPU band — the R arm", flush=True)
            print("  works (one forward pass) but the latency ledger", flush=True)
            print("  will read CPU, not your 3080 Ti.", flush=True)
            if os.name == "nt":
                print("  Likely: the driver, or the CUDA DLLs did not", flush=True)
                print("  resolve — re-run station_m6_setup.bat.", flush=True)
            print("=" * 62, flush=True)
            if not allow_cpu:
                if sys.stdin.isatty():
                    try:
                        ans = input("[gate] run on CPU anyway? "
                                    "[y/N]: ").strip().lower()
                    except (EOFError, KeyboardInterrupt):
                        ans = "n"
                    if ans in ("y", "yes", "д", "да"):
                        return
                raise SystemExit(
                    "the no-CUDA refusal (pass --yes-cpu to override; "
                    "on the owner's 3080 Ti station this means the "
                    "driver/DLL resolution failed — re-run "
                    "station_m6_setup.bat)")

    def observe(self, name: str, log_path: Path | None) -> None:
        """After a server's first health: grep the log for the CUDA
        init + the offload lines -> the band verdict. THE v6.0 LAW:
        the NEGATIVE verdict is recorded too — a log with no init
        lines while the servers actually serve is the CPU band by
        evidence (the m5 lesson: silence was the bug)."""
        if log_path is None:
            return
        key = str(log_path.resolve())
        name = self._log_names.setdefault(key, name)
        try:
            text = log_path.read_text(encoding="utf-8",
                                      errors="replace")
        except OSError:
            return
        init = [ln for ln in text.splitlines()
                if "ggml_cuda_init" in ln or "offloaded" in ln]
        if init:
            band = ("cuda" if "ggml_cuda_init" in "\n".join(init)
                    else "unknown")
        else:
            band = "cpu (no ggml_cuda_init in log)"
        if self.bands.get(name) in (None, band, "cpu (no ggml_cuda_init in log)"):
            self.bands[name] = band
            print(f"[gate] {name}: band={band} "
                  f"({init[-1][:90] if init else 'no CUDA lines'})",
                  flush=True)

    def finalize(self, log_paths: Mapping[str, Path | None]) -> None:
        """THE RUN-END BAND VERDICT (v6.0, the KI#119 tooth): re-observe
        every server log (the init lines flush past the first health),
        then SAY the verdict loud. cuda visible + every band 'cpu' =
        the CUDA DLL resolution failed — the honest reading of the m5
        run (zero CUDA lines in both logs) made impossible to miss."""
        for name, path in log_paths.items():
            self.observe(name, path)
        cpu = [n for n, b in self.bands.items()
               if b.startswith("cpu")]
        cuda = [n for n, b in self.bands.items() if b == "cuda"]
        if not self.bands:
            return
        print("=" * 62, flush=True)
        if cuda:
            print(f"[band] VERDICT: CUDA band live for {', '.join(cuda)}.",
                  flush=True)
        if cpu:
            print(f"[band] VERDICT: {', '.join(cpu)} ran the CPU band "
                  f"(no ggml_cuda_init in the log).", flush=True)
            if self.cuda_visible:
                print("  CUDA devices WERE visible to --list-devices but", flush=True)
                print("  the server never initialized the CUDA backend —", flush=True)
                print("  the CUDA DLL resolution failed (cudart64_12 /", flush=True)
                print("  cublas64_12 / cublasLt64_12). Re-run", flush=True)
                print("  station_m6_setup.bat (it unpacks the cudart", flush=True)
                print("  companion beside llama-server.exe) and re-run", flush=True)
                print("  the battery. THE LATENCY LEDGER READS CPU —", flush=True)
                print("  the m5 run's numbers were the CPU band too", flush=True)
                print("  (its logs carry zero CUDA lines, KI#119).", flush=True)
            else:
                print("  No CUDA was visible at all — the CPU band is", flush=True)
                print("  the honest band for this machine.", flush=True)
        print("=" * 62, flush=True)

    def note_vram(self, name: str, note: str) -> None:
        """The planned-offload record (the iter-358 evidence law):
        every rung decision rides cuda_gate.json / preflight.json."""
        self.vram[name] = note

    def doc(self) -> dict:
        return {"cuda_visible": self.cuda_visible,
                "devices": self.devices[:20],
                "bands": self.bands,
                "vram_plan": self.vram,
                "checked": self.checked,
                "band_note": ("v6.0 (KI#119): the bands are DERIVED from "
                              "the server logs — 'cpu (no ggml_cuda_init "
                              "in log)' means the server ran the CPU band "
                              "even if --list-devices saw CUDA devices "
                              "(the m5 station run's shape; the DLL "
                              "resolution question)")}


DEVICE_GATE = DeviceGate()


class SpawnedServer:
    """One owned llama-server (the m3 spawn form verbatim + the device
    gate's first-health observation). The honest command line is
    printed; the heartbeat waits up to 900 s per attempt (the OneDrive
    cold-load law); a death retries the GPU ladder on a fresh port;
    every failure carries the log TAIL. The iter-358 additions: the
    BATCH LAW (an explicit -b/-ub on every spawn — the stock 512
    cannot host a systemone payload) and the PLANNED GPU RUNG (the
    deliberate -ngl from the live free VRAM, printed as [vram],
    recorded in cuda_gate.json — the reactive descent still guards
    beneath)."""

    def __init__(
        self,
        exe: Path,
        model: Path,
        *,
        ctx: int,
        extra: Sequence[str] = (),
        port: int | None = None,
        log_path: Path | None = None,
        jinja: bool = True,
        batch: int | None = None,
        ubatch: int | None = None,
    ) -> None:
        self.exe = exe
        self.model = model
        self.proc: subprocess.Popen | None = None
        self.port = port or _free_port()
        self.endpoint = f"http://127.0.0.1:{self.port}"
        self._ctx = ctx
        self._extra = [str(a) for a in extra]
        self._jinja = jinja
        self._batch = batch
        self._ubatch = ubatch
        self._argv = self._argv_for(self.port, ())
        self.log_path = log_path
        self.calls_since_spawn = 0

    def _argv_for(self, port: int, fb: Sequence[str]) -> list[str]:
        # THE BATCH LAW (iter-358): -b always rides (the systemone
        # payload must fit ONE n_batch; the stock 512 died on the
        # tavern set's 741 tokens). The ROUTER's ubatch RIDES its
        # batch — the embeddings path ties n_batch to n_ubatch; the
        # MAIN passes its own 512 (the chat route chunks internally).
        # An operator's own -b/-ub in extra wins (never duplicated).
        flags: list[str] = []
        if (self._batch is not None and not _flag_present(
                self._extra, "-b", "--batch-size")):
            flags += ["-b", str(self._batch)]
        if not _flag_present(self._extra, "-ub", "--ubatch-size"):
            ub = self._ubatch if self._ubatch is not None \
                else self._batch
            if ub is not None:
                flags += ["-ub", str(ub)]
        return ([str(self.exe), "-m", str(self.model),
                 "--port", str(port), "-c", str(self._ctx),
                 "-np", "1"] + flags
                + (["--jinja"] if self._jinja else [])
                + self._extra + list(fb))

    def argv(self) -> list[str]:
        return list(self._argv)

    def start(self) -> None:
        reason = _gguf_sanity(self.model)
        if reason:
            raise ServerDown(f"the model file failed the pre-check: {reason}")
        DEVICE_GATE.precheck(self.exe, allow_cpu=_ALLOW_CPU)
        explicit = _flag_present(self._extra, "-ngl", "--n-gpu-layers")
        ladder: tuple[tuple[str, ...], ...]
        if explicit:
            ladder = ((),)
        else:
            # THE PLANNED RUNG (iter-358): the live VRAM reading ->
            # the weight estimate -> the deliberate -ngl, printed and
            # recorded BEFORE the spawn. None (no nvidia-smi) keeps
            # the engine's own default as the first rung.
            ngl, note = plan_gpu_rung(self.model, self._ctx)
            print(f"[vram] {self.model.name}: {note}", flush=True)
            DEVICE_GATE.note_vram(self.model.name, note)
            if ngl is None:
                ladder = GPU_FALLBACKS
            else:
                ladder = (("--n-gpu-layers", str(ngl)),) \
                    + GPU_FALLBACKS[1:]
        tails: list[str] = []
        for i, fb in enumerate(ladder):
            if i > 0:
                self.port = _free_port()
                self.endpoint = f"http://127.0.0.1:{self.port}"
            self._argv = self._argv_for(self.port, fb)
            try:
                self._start_once()
                if i > 0:
                    print(f"[spawn] GPU fallback engaged: {' '.join(fb)}",
                          flush=True)
                DEVICE_GATE.observe(self.model.name, self.log_path)
                return
            except ServerDown as exc:
                tails.append(f"--- attempt {i + 1} "
                             f"({' '.join(fb) if fb else 'default'}):\n{exc}")
                if i + 1 < len(ladder):
                    print(f"[spawn] attempt {i + 1} died — retrying with "
                          f"a lower GPU offload", flush=True)
        raise ServerDown(
            "llama-server would not start (the GPU ladder exhausted) — "
            "the log tails:\n" + "\n".join(tails))

    def _start_once(self) -> None:
        log_handle = open(self.log_path, "ab") if self.log_path else None
        try:
            self.proc = subprocess.Popen(
                self.argv(),
                stdout=log_handle or subprocess.DEVNULL,
                stderr=subprocess.STDOUT,
                stdin=subprocess.DEVNULL,
                start_new_session=True,
            )
        finally:
            if log_handle:
                log_handle.close()
        print("[spawn] " + " ".join(self.argv()), flush=True)
        t0 = time.monotonic()
        while time.monotonic() - t0 < 900.0:
            if self.proc.poll() is not None:
                raise ServerDown(
                    f"llama-server died rc={self.proc.returncode}; "
                    f"log tail:\n{_log_tail(self.log_path)}")
            if LlamaClient(self.endpoint).health():
                return
            time.sleep(5.0)
        raise ServerDown(
            "llama-server never became healthy (900 s); "
            f"log tail:\n{_log_tail(self.log_path)}")

    def stop(self) -> None:
        if self.proc is None:
            return
        try:
            self.proc.terminate()
            self.proc.wait(timeout=10.0)
        except (subprocess.TimeoutExpired, OSError, ProcessLookupError):
            try:
                self.proc.kill()
            except OSError:
                pass
        self.proc = None


class LazyServer:
    """A memory-conscious owned server (the m3 form): spawns on FIRST
    USE, dies on stop() — the OOM law (two resident models + the
    grammar growth do not fit a 12 GB band). The iter-358 addition:
    batch/ubatch are MUTABLE — the router heal escalates them on the
    400-class death, so the respawn carries a bigger -b, never the
    same argv twice."""

    def __init__(self, exe: Path, model: Path, *, ctx: int,
                 log_path: Path, jinja: bool = True,
                 batch: int | None = None,
                 ubatch: int | None = None) -> None:
        self.exe = exe
        self.model = model
        self.ctx = ctx
        self.log_path = log_path
        self.jinja = jinja
        self.batch = batch
        self.ubatch = ubatch
        self.server: SpawnedServer | None = None

    def ensure(self) -> SpawnedServer:
        if self.server is None:
            spawned = SpawnedServer(
                self.exe, self.model, ctx=self.ctx,
                log_path=self.log_path, jinja=self.jinja,
                batch=self.batch, ubatch=self.ubatch)
            try:
                spawned.start()
            except ServerDown as exc:
                spawned.stop()
                raise RouterDown(
                    f"the router server would not start "
                    f"({self.model.name}):\n{exc}") from exc
            self.server = spawned
        return self.server

    def stop(self) -> None:
        if self.server is not None:
            self.server.stop()
            self.server = None

    def start(self) -> None:
        self.stop()
        self.ensure()

    @property
    def calls_since_spawn(self) -> int:
        return self.server.calls_since_spawn if self.server else 0

    @calls_since_spawn.setter
    def calls_since_spawn(self, value: int) -> None:
        if self.server is not None:
            self.server.calls_since_spawn = value


def _lazy_stop(lazy: "LazyServer | None") -> None:
    if lazy is not None:
        lazy.stop()


#: set by main() from --yes-cpu (the device gate's override)
_ALLOW_CPU = False


# == PART 2: the R-door (the deterministic intent assembler) =================
#
# THE OWNER'S ARCHITECTURE (iter-356 §E, the corrected semantics): the
# classifier ROUTES, never commits. The door assembles the intent
# document from KNOWN keys only — the pack's own action inventory,
# the live scene nouns, the fixed field policy — so a hallucinated
# document is PHYSICALLY IMPOSSIBLE (the invention check proves it on
# every cycle: 0 keys outside the pack's sets).


def build_state(say: str, events, pack, door) -> dict:
    """The systemone state: the utterance + the COMPACT live scene
    (the player's location + who/what is present — the same facts the
    grammar route's snapshot offers, folded here read-only)."""
    cs = _CS  # the repo namespace (set by main)
    state = cs.fold(events, cs.initial_projection(pack.entities))
    pos = state[pack.player_id()]["position"]
    present = sorted(
        eid for eid, doc in state.items()
        if isinstance(doc, Mapping) and doc.get("position") == pos
        and eid != pack.player_id()
    )
    return {
        "message": say,
        "scene": {
            "location": pos,
            "present": present[:24],
        },
    }


def build_questions(snapshot, pack) -> dict:
    """The four questions, ONE pass: the action (the pack's full 16 —
    the door rejects the impossible; the census counts them), the
    target (the LIVE scene nouns — canon entities + live textures,
    exactly the grammar route's own closed set), the validity gate
    (noul), the risk (score). The criteria are NEVER invented: labels
    + notes from actions.json, names from the snapshot nouns."""
    actions = pack.data["actions.json"]["actions"]
    crit: dict[str, dict] = {}
    for a in actions:
        notes = (a.get("notes") or "").strip().replace("\n", " ")
        crit[a["intent"]] = {
            "label": a["label"],
            "notes": notes[:180] if notes else a["label"],
        }
    nouns: dict[str, dict] = {}
    for n in snapshot.nouns:
        label = n.name if n.name else n.id
        nouns[n.id] = {"label": f"{label} ({n.kind})"}
    return {
        "action": {
            "type": "choice",
            "instructions": (
                "Which action does the player attempt right now? "
                "Pick the single best match from the criteria."),
            "criteria": crit,
        },
        "target": {
            "type": "choice",
            "instructions": (
                "Which entity, location, item or scene detail is the "
                "action directed at? Pick the best match (pick the "
                "player's current location for a non-directed action)."),
            "criteria": nouns,
        },
        "is_modeled": {
            "type": "noul",
            "instructions": (
                "Is a concrete, modeled action attempted in the "
                "message (as opposed to atmosphere, small talk, or a "
                "question to the narrator)?"),
        },
        "risk": {
            "type": "score",
            "instructions": "How risky is the attempted action?",
            "criteria": ["safe", "bold", "reckless"],
        },
    }


def _action_target_kind(action: Mapping) -> str | None:
    """The kind the action's `requires` demands of its target (the
    same derivation the door's shape gate uses)."""
    for cond in action.get("requires", ()):
        if cond.get("noun") == "target" and cond.get("test") == "kind":
            return cond.get("is")
    return None


def assemble_intent(answers: Mapping, snapshot, pack, *,
                    gate: float = NOUL_GATE) -> tuple[dict, dict]:
    """THE DETERMINISTIC DOOR. From the router's answers -> the intent
    document (the ParserDoor's own reply shape). Returns (doc, meta)
    where meta carries the routing facts for the record (the gate
    verdict, the top probabilities, the kind-aware target pick). The
    gate threshold is a PARAMETER (m5): 0.5 the recorded owner
    default, 0.4 the RU04/R04 recovery point — the ONLY variable the
    knob stages change (the router's answers are byte-reproducible,
    the det datum)."""
    meta: dict[str, object] = {}
    act = answers.get("action") or {}
    noul = answers.get("is_modeled") or {}
    gate_p = float(noul.get("noul", 0.0)) if isinstance(noul, Mapping) \
        else 0.0
    meta["gate_p"] = round(gate_p, 4)
    risk = answers.get("risk") or {}
    if isinstance(risk, Mapping):
        meta["risk"] = round(float(risk.get("score", 0.0)), 3)

    if gate_p < gate:
        meta["gate"] = "blocked"
        return ({"no_intent":
                 "the router's validity gate: no modeled action in "
                 "the utterance"}, meta)
    meta["gate"] = "passed"

    kind = act.get("choice")
    probs = act.get("probabilities") or {}
    if not isinstance(kind, str) or kind not in {
            a["intent"] for a in
            pack.data["actions.json"]["actions"]}:
        # impossible by construction (the criteria are the inventory);
        # recorded, never committed
        meta["gate"] = "no_action"
        return ({"no_intent": "the router returned no usable action"},
                meta)
    meta["action_p"] = round(float(probs.get(kind, 0.0)), 6)
    meta["action_top3"] = sorted(
        ((k, round(v, 6)) for k, v in probs.items()),
        key=lambda kv: -kv[1])[:3]

    doc: dict[str, object] = {"intent": {"kind": kind}}
    action = next(a for a in pack.data["actions.json"]["actions"]
                  if a["intent"] == kind)
    want_kind = _action_target_kind(action)
    if want_kind is not None:
        tgt = answers.get("target") or {}
        tprobs = (tgt.get("probabilities") or {}) \
            if isinstance(tgt, Mapping) else {}
        # the kind-aware pick: the best-scoring LIVE noun whose kind
        # matches the action's requirement (the grammar route enforces
        # the same constraint; the router picks within it). take is
        # the DUAL form: an item target OR a texture field (the
        # corpus's own two shapes) — the pool carries both.
        by_kind = {}
        for n in snapshot.nouns:
            by_kind.setdefault(n.kind, []).append(n)
        pool = list(by_kind.get(want_kind, ()))
        if want_kind == "item":
            pool += by_kind.get("texture", ())
        best, best_p = None, -1.0
        for n in pool:
            p = float(tprobs.get(n.id, 0.0))
            if p > best_p:
                best, best_p = n, p
        if best is not None:
            meta["target_p"] = round(best_p, 6)
            if best.kind == "texture":
                # the take-a-texture form (the corpus's shape): the
                # texture rides the FIELD, never a target — the door
                # and the census both expect the targetless form
                doc["intent"]["fields"] = {"texture": dict(best.texture
                                                           or {})}
            else:
                doc["intent"]["target"] = best.id
        else:
            meta["target_p"] = None

    # the fixed field policy (the honest cost: the router routes; the
    # field VALUES ride the documented defaults — the census counts
    # the divergence)
    for fname in action.get("fields", ()):
        if fname == "texture" and "fields" in doc["intent"]:
            continue  # already set by the texture-noun pick above
        if kind == "drop_break" and fname == "near":
            # iter-360: Verb's intent field is `intent` (brief/parser.py,
            # since iter-31) — `c.name` was a never-exercised typo that
            # lived until the first live router picked drop_break (the
            # owner's station run 2026-10-10, s4 cycle 2 "I smash the
            # lamp down against the woodpile").
            vals = []
            for c in snapshot.verbs:
                if c.intent == kind:
                    for fc in c.fields:
                        if fc.name == "near":
                            vals = list(fc.values or [])
            doc["intent"]["fields"] = {"near": vals[0] if vals else ""}
            continue
        defaults = R_FIELD_DEFAULTS.get(kind, {}).get(fname)
        if defaults is not None:
            doc["intent"].setdefault("fields", {})[fname] = defaults
    if not doc["intent"].get("fields"):
        doc["intent"].pop("fields", None)
    return doc, meta


def invention_check(doc: Mapping, snapshot, pack) -> list[str]:
    """The leak law, executable: every key of the assembled doc must
    come from the pack's own sets (the 16 intents, the live nouns, the
    known field names). Returns the list of inventions (expected:
    EMPTY — the R form's construction proof)."""
    inventions: list[str] = []
    acts = {a["intent"] for a in
            pack.data["actions.json"]["actions"]}
    nouns = {n.id for n in snapshot.nouns}
    if "no_intent" in doc:
        return inventions
    intent = doc.get("intent")
    if not isinstance(intent, Mapping):
        return ["doc-shape"]
    if intent.get("kind") not in acts:
        inventions.append(f"kind:{intent.get('kind')}")
    tgt = intent.get("target")
    if tgt is not None and tgt not in nouns:
        inventions.append(f"target:{tgt}")
    for f in (intent.get("fields") or {}):
        known = set()
        for a in pack.data["actions.json"]["actions"]:
            if a["intent"] == intent.get("kind"):
                known.update(a.get("fields", ()))
        if f not in known:
            inventions.append(f"field:{f}")
    return inventions


# -- the RU band (hand-authored, the honest card-limit measurement) ----------

#: The owner's language, the fork's first half: «the RU band measured
#: before trust». Gold by the pack author (marked in every record);
#: NOT a corpus fixture. Rows mirror the corpus's action families.
RU_ROWS: list[dict] = [
    {"say": "Я подхожу к стражнику у стойки и завязываю разговор.",
     "gold": {"intent": {"kind": "talk", "target": "npc_guard_01"}}},
    {"say": "Стражник отвернулся — я тихонько снимаю кошель с его пояса.",
     "gold": {"intent": {"kind": "steal", "target": "npc_guard_01",
                         "fields": {"method": "distraction"}}}},
    {"say": "Просто осмотрюсь вокруг, ничего не трогая.",
     "gold": {"intent": {"kind": "look_around"}}},
    {"say": "Подожду-ка я немного, пусть всё утихнет.",
     "gold": {"intent": {"kind": "wait", "fields": {"ticks": 30}}}},
    {"say": "Выйду через заднюю дверь во двор.",
     "gold": {"intent": {"kind": "move", "target": "loc_backyard"}}},
    {"say": "Возьму со стойки одну из свечей.",
     "gold": {"intent": {"kind": "take", "fields": {"texture": {
         "entry": "tex_0000", "scope": "scene:loc_tavern",
         "slot": "candles", "value": "lit"}}}}},
    {"say": "Огонь потрескивает в очаге, по стенам пляшут тени.",
     "gold": {"no_intent": "atmosphere"}},
    {"say": "Поговорю с пьяницей о том о сём, время убить.",
     "gold": {"intent": {"kind": "talk", "target": "npc_drunk_01"}}},
    {"say": "Возьму кружку эля со стойки.",
     "gold": {"intent": {"kind": "take", "target": "ale_mug_01"}}},
    {"say": "Изучу бармена внимательнее — что он за человек.",
     "gold": {"intent": {"kind": "examine", "target": "npc_barkeep_01"}}},
    {"say": "А что тут вообще можно сделать? Я не понимаю.",
     "gold": {"question": "unclear"}},
    {"say": "Отдохну в тихом уголке, ноги гудят.",
     "gold": {"intent": {"kind": "rest"}}},
]


# -- the H arm: the hybrid single-pass (the m3 form on the m4 corpus) -------

#: THE HYBRID PROTOCOL TAIL (the ONLY protocol edit — the m3 law): the
#: door's own call document ends with the repo's parse protocol; the
#: hybrid form appends this block. The model answers with the verdict
#: JSON, ONE blank line, then the prose — the grammar enforces the
#: shape, the protocol tells the model what the tail is FOR.
HYBRID_PROTOCOL_TAIL = """

## HYBRID REPLY FORM
First the JSON verdict exactly as the protocol above specifies.
Then exactly one blank line. Then two to four sentences of in-scene
narration prose in the narrator's voice: render the moment the
verdict describes as the player would read it; never invent
outcomes, dialogue or facts the JSON does not carry; no lists, no
JSON, no protocol words, no empty lines inside the prose. A final
blank line closes the reply.
"""


def hybrid_grammar(reply_grammar: str) -> str:
    """THE TERMINATED-PROSE LAW (iter-351 D.1, verbatim form) — the
    hybrid grammar wraps the repo's own reply grammar so ONE call
    carries the verdict AND the prose:

        root        ::= verdict-doc "\n\n" prose
        verdict-doc ::= intent-doc | question-doc | no-intent-doc
        prose       ::= prose-body "\n\n"
        prose-body  ::= prose-line ( "\n" prose-line )*
        prose-line  ::= prose-char ( prose-char )*
        prose-char  ::= [^\x00-\x1f\x7f]

    THE LAW: a starred tail (`[^\x00]*` and every sibling) parses but
    HOLDS the generation open — the grammar can always accept more, so
    the sampler never reaches a state where EOS is the only move and
    the run dies at max_tokens (finish 'length'). The terminated form
    instead makes the prose body UNABLE to contain an empty line
    (every line starts with a non-control char) — the first blank line
    after the body can only close the rule, root reaches its accept
    state, and EOS fires NATURALLY (finish 'stop', the live T-H datum
    of iter-351, re-proven live by this pack's validation).

    The blank line is BOTH the door's split point and the grammar's
    terminator — one byte, two laws. The verdict half rides the repo's
    grammar VERBATIM (root renamed, every other rule byte-identical):
    the JSON head of a hybrid answer is grammar-identical with the G
    arm's whole reply — the census comparison is like-for-like at the
    source. Pure: same reply grammar -> same hybrid bytes."""
    lines = reply_grammar.rstrip("\n").splitlines()
    out: list[str] = []
    for line in lines:
        if line.startswith("root ::= "):
            out.append("verdict-doc ::= " + line[len("root ::= "):])
        else:
            out.append(line)
    if out and not any(l.startswith("verdict-doc ::= ") for l in out):
        raise ValueError(
            "the reply grammar carries no root rule — the hybrid wrap "
            "needs the repo's own `root ::= ...` head")
    out += [
        'root ::= verdict-doc "\\n\\n" prose',
        'prose ::= prose-body "\\n\\n"',
        'prose-body ::= prose-line ( "\\n" prose-line )*',
        'prose-line ::= prose-char ( prose-char )*',
        "prose-char ::= [^\\x00-\\x1f\\x7f]",
    ]
    return "\n".join(out) + "\n"


#: the H arm's bound: the verdict JSON (~60 tokens at the corpus's
#: widest) + the 2-4-sentence prose tail — the m3-proven 416.
HYBRID_MAX_TOKENS = 416


# == PART 3: the battery ======================================================


class UnitBudget(Exception):
    """The time budget expired mid-battery — a clean checkpoint exit."""


class Battery:
    """The m4 battery over one run directory. The corpus sessions each
    boot a REAL Simulator + Mediator + ParserDoor (the shared ledger,
    D-49); the narrator half is pinned by the corpus (the m2/m3 form);
    the say half is answered by the arm's machinery — the G grammar
    route or the R systemone route."""

    def __init__(self, repo: Path, run_dir: Path, cs, smoke: bool = False
                 ) -> None:
        self.repo = repo
        self.run_dir = run_dir
        self.cs = cs
        self.smoke = smoke
        self.corpus = json.loads(
            (repo / "tests" / "fixtures" / "parse_replies.json").read_text(
                encoding="utf-8")
        )

    def boot(self, unit_dir: Path, seed: int, setup: Sequence[Mapping]):
        cs = self.cs
        log = unit_dir / "run.jsonl"
        sim = cs.Simulator(
            self.cs.PACK, seed, log, self.cs.SCHEMA, commit="m40000"
        )
        sim.open()
        if setup:
            sim.run_steps(list(setup))
        mediator = cs.Mediator(sim, self.cs.PACK, self.cs.SCHEMA, log,
                               unit_dir / "mediator")
        door = cs.ParserDoor(sim, self.cs.PACK, self.cs.SCHEMA, log,
                             mediator.ledger, unit_dir / "parser")
        return sim, mediator, door, log

    def state_fingerprint(self, door, log: Path) -> list:
        """The premise-drift fingerprint (the m3 form verbatim)."""
        _hdr, events = self.cs.read_log(log, self.cs.SCHEMA)
        types = [e.type for e in events[-5:]]
        live = sum(1 for e in door._ledger.entries
                   if e.status == self.cs.ACTIVE)
        return [len(events), types, live]

    # -- the G arm's cycle (the m3 law form, verbatim) -------------------

    def g_cycle(self, main_server, main_factory, door, unit_dir: Path,
                i: int, cycle: Mapping) -> dict:
        cs = self.cs
        t0 = time.monotonic()
        fp_start = self.state_fingerprint(door, unit_dir / "run.jsonl")
        call_path = door.emit_call(cycle["say"])
        doc = call_path.read_text(encoding="utf-8")
        _hdr, events = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
        snapshot = cs.grammar_snapshot(events, cs.PACK, door._ledger)
        reply_grammar = cs.gbnf_grammar(snapshot)
        result = self._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": doc}],
            grammar=reply_grammar, temp=0.0, max_tokens=160, seed=42)
        record: dict[str, object] = {
            "cycle": i, "say": cycle["say"],
            "expected": cycle.get("reply"),
            "fp_start": fp_start,
            "parse_wall_s": round(result.wall_s, 3),
            "parse_ptok": result.prompt_tokens,
            "parse_ctok": result.completion_tokens,
        }
        content = result.content
        reply_doc = None
        off_gr = False
        try:
            reply_doc = json.loads(content)
        except json.JSONDecodeError:
            off_gr = True
        applied = False
        result_door = None
        if not off_gr:
            reply_path = unit_dir / f"reply_{i}.json"
            reply_path.write_text(content, encoding="utf-8")
            try:
                result_door = door.apply_reply(reply_path)
                applied = True
            except cs.ParseError:
                off_gr = True
            except cs.RunnerError as exc:
                record["door_error"] = str(exc)[:300]
                applied = "runner_error"
        pinned = []
        door_outcome = ""
        if applied is True:
            if result_door.status == "intent":
                _h2, ev2 = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
                door_outcome = ev2[-1].type if ev2 else ""
                pinned = list(result_door.pinned)
            else:
                door_outcome = result_door.status
        expect = cycle.get("expect", {})
        cls = census_class(
            reply_doc if not off_gr else None, cycle.get("reply"),
            pinned, expect.get("pinned", ()),
        ) if cycle.get("reply") is not None else "n/a"
        if off_gr:
            cls = "off_gr"
        record.update({
            "census": cls, "pinned": pinned,
            "door_outcome": door_outcome,
            "wall_s": round(time.monotonic() - t0, 3),
        })
        return record

    # -- the R arm's cycle (THE m4 FORM) ----------------------------------

    def r_cycle(self, router_lazy, router_factory, door, unit_dir: Path,
                i: int, cycle: Mapping, *,
                gate: float = NOUL_GATE) -> dict:
        cs = self.cs
        t0 = time.monotonic()
        fp_start = self.state_fingerprint(door, unit_dir / "run.jsonl")
        # the door's own contract: one call awaits one reply (the m3
        # law — the emitted call doc rides the door's ledger even
        # though the systemone route builds its own state)
        door.emit_call(cycle["say"])
        _hdr, events = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
        snapshot = cs.grammar_snapshot(events, cs.PACK, door._ledger)

        state = build_state(cycle["say"], events, cs.PACK, door)
        questions = build_questions(snapshot, cs.PACK)

        server = router_lazy.ensure() if router_lazy is not None else None
        result = self._systemone_with_heal(
            router_lazy, router_factory, state, questions)
        if server is not None:
            server.calls_since_spawn += 1

        doc, meta = assemble_intent(result.answers, snapshot, cs.PACK,
                                    gate=gate)
        inventions = invention_check(doc, snapshot, cs.PACK)

        record: dict[str, object] = {
            "cycle": i, "say": cycle["say"],
            "expected": cycle.get("reply"),
            "fp_start": fp_start,
            "r_wall_s": round(result.wall_s, 3),
            "r_itok": result.input_tokens,
            "r_otok": result.output_tokens,
            "r_meta": meta,
            "gate_threshold": gate,
            "assembled": doc,
            "inventions": inventions,
        }

        # the door (the REAL ParserDoor — the same file contract as G)
        reply_path = unit_dir / f"reply_{i}.json"
        reply_path.write_text(json.dumps(doc), encoding="utf-8")
        applied = False
        result_door = None
        try:
            result_door = door.apply_reply(reply_path)
            applied = True
        except cs.ParseError as exc:
            record["door_error"] = str(exc)[:300]
            applied = "parse_error"
        except cs.RunnerError as exc:
            record["door_error"] = str(exc)[:300]
            applied = "runner_error"
        pinned = []
        door_outcome = ""
        if applied is True:
            if result_door.status == "intent":
                _h2, ev2 = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
                door_outcome = ev2[-1].type if ev2 else ""
                pinned = list(result_door.pinned)
            else:
                door_outcome = result_door.status
        expect = cycle.get("expect", {})
        cls = census_class(
            doc if applied is True else None, cycle.get("reply"),
            pinned, expect.get("pinned", ()),
        ) if cycle.get("reply") is not None else "n/a"
        if applied == "parse_error":
            cls = "parse_error"
        # the R-specific overlays: the gate's verdict vs the gold's form
        if cycle.get("reply") is not None:
            gold_form = set(cycle["reply"].keys())
            if meta.get("gate") == "blocked" and "intent" in gold_form:
                cls = "gate_blocked"
            elif meta.get("gate") == "passed" and "intent" not in gold_form:
                cls = "gate_false_positive"
        record.update({
            "census": cls, "pinned": pinned,
            "door_outcome": door_outcome,
            "wall_s": round(time.monotonic() - t0, 3),
        })
        return record

    # -- the H arm's cycle (THE M5 CORE — the hybrid single-pass) --------

    def h_cycle(self, main_server, main_factory, door, unit_dir: Path,
                i: int, cycle: Mapping, *, temp: float) -> dict:
        """ONE call, verdict AND prose (the m3 hybrid form on the m4
        corpus): the door's own call document + the hybrid protocol
        tail, the reply under the TERMINATED-PROSE hybrid grammar; the
        answer splits at the FIRST blank line — the JSON head goes
        through the SAME gate as G (door.apply_reply, byte-comparable
        census), the prose tail is the recorded surface (the m3
        ledger: length, json bleed, protocol echo, the eos-held flag;
        the verbatim text rides the record for the owner's reading)."""
        cs = self.cs
        t0 = time.monotonic()
        fp_start = self.state_fingerprint(door, unit_dir / "run.jsonl")
        call_path = door.emit_call(cycle["say"])
        doc = call_path.read_text(encoding="utf-8") + HYBRID_PROTOCOL_TAIL
        _hdr, events = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
        snapshot = cs.grammar_snapshot(events, cs.PACK, door._ledger)
        hybrid = hybrid_grammar(cs.gbnf_grammar(snapshot))
        result = self._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": doc}],
            grammar=hybrid, temp=temp, max_tokens=HYBRID_MAX_TOKENS,
            seed=42)
        record: dict[str, object] = {
            "cycle": i, "say": cycle["say"],
            "expected": cycle.get("reply"),
            "fp_start": fp_start,
            "h_temp": temp,
            "parse_wall_s": round(result.wall_s, 3),
            "parse_ptok": result.prompt_tokens,
            "parse_ctok": result.completion_tokens,
            "finish_reason": result.finish_reason,
        }
        content = result.content
        # THE SPLIT LAW: the first blank line separates the verdict
        # from the prose (the grammar guarantees the JSON head carries
        # no blank line — its literals are compact)
        head, _sep, tail = content.partition("\n\n")
        json_part = head.strip()
        prose = tail.rstrip("\n")
        record["prose"] = prose[:600]
        record["prose_len"] = len(prose)
        record["eos_held"] = result.finish_reason == "length"
        record["json_bleed"] = any(
            m in prose for m in ("{\"", '"kind"', '"target"',
                                 '"fields"', '"no_intent"', '"question"'))
        record["protocol_echo"] = any(
            m in prose for m in ("## ", "reply:", "ONE JSON", "verbs:",
                                 "nouns:", "texture entries"))
        reply_doc = None
        off_gr = False
        try:
            reply_doc = json.loads(json_part)
        except json.JSONDecodeError:
            off_gr = True
        applied = False
        result_door = None
        if not off_gr:
            reply_path = unit_dir / f"reply_{i}.json"
            reply_path.write_text(json_part, encoding="utf-8")
            try:
                result_door = door.apply_reply(reply_path)
                applied = True
            except cs.ParseError:
                off_gr = True
            except cs.RunnerError as exc:
                record["door_error"] = str(exc)[:300]
                applied = "runner_error"
        pinned = []
        door_outcome = ""
        if applied is True:
            if result_door.status == "intent":
                _h2, ev2 = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
                door_outcome = ev2[-1].type if ev2 else ""
                pinned = list(result_door.pinned)
            else:
                door_outcome = result_door.status
        expect = cycle.get("expect", {})
        cls = census_class(
            reply_doc if not off_gr else None, cycle.get("reply"),
            pinned, expect.get("pinned", ()),
        ) if cycle.get("reply") is not None else "n/a"
        if off_gr:
            cls = "off_gr"
        record.update({
            "census": cls, "pinned": pinned,
            "door_outcome": door_outcome,
            "wall_s": round(time.monotonic() - t0, 3),
        })
        return record

    def _chat_with_heal(self, server, client_factory, messages, *,
                        grammar, temp, max_tokens, seed, budget=3):
        """The m3 heal law verbatim: a dead server restarts, the call
        retries (budget 3); the attach form fails loud."""
        last: ServerDown | None = None
        for attempt in range(budget):
            client = client_factory()
            try:
                result = client.chat(
                    messages, grammar=grammar, temperature=temp,
                    max_tokens=max_tokens, seed=seed)
                if server is not None:
                    server.calls_since_spawn += 1
                return result
            except ServerDown as exc:
                if server is None:
                    raise
                last = exc
                print(f"[engine failure ({exc}) — restart {attempt + 1}]",
                      flush=True)
                server.stop()
                time.sleep(5.0)
                try:
                    server.start()
                except ServerDown:
                    continue
        raise ServerDown(f"engine failed after {budget} restarts") from last

    def _systemone_with_heal(self, router_lazy, router_factory, state,
                             questions, budget=3):
        """The router's heal law: the R arm DIES if the router is dead
        (it IS the battery) — but each death restarts once through the
        ladder before the terminal raise. THE ITER-358 FIX: the
        400-class 'batch size' death is a CONFIG death, not a server
        death — restarting the SAME argv is futile (the iter-357
        crash: three identical restarts, then RouterDown). The batch
        now ESCALATES before any such restart: doubling + the headroom
        the server itself named, the ubatch riding along (the
        embeddings tie) and the ctx pulled to the next power of two
        when the batch passes it."""
        last: ServerDown | None = None
        for attempt in range(budget):
            client = router_factory()
            try:
                return client.ask(state, questions)
            except ServerDown as exc:
                last = exc
                print(f"[router failure ({exc}) — restart {attempt + 1}]",
                      flush=True)
                if router_lazy is None:
                    raise
                if "batch size" in str(exc).lower():
                    need = BATCH_TOKENS_RE.search(str(exc))
                    need_tok = int(need.group(1)) if need else None
                    cur = router_lazy.batch or DEFAULT_SPAWN_BATCH
                    nb, nc = escalated_router_batch(
                        cur, router_lazy.ctx, need_tok)
                    if nb != cur:
                        router_lazy.batch = nb
                        router_lazy.ctx = nc
                        router_lazy.ubatch = None  # rides the new -b
                        print(f"[router] the batch law: respawning "
                              f"with -b {nb} (ctx {nc}, was "
                              f"-b {cur})", flush=True)
                router_lazy.stop()
                time.sleep(5.0)
                try:
                    router_lazy.ensure()
                except RouterDown:
                    continue
        raise RouterDown(
            f"the router failed after {budget} restarts") from last


# -- the stages (resumable: per-unit jsonl checkpointing — the m3 law) ----


def _load_units(path: Path) -> set[str]:
    done: set[str] = set()
    if not path.exists():
        return done
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            rec = json.loads(line)
        except json.JSONDecodeError:
            continue
        if rec.get("event") == "end":
            done.add(str(rec["unit"]))
    return done


def _append_jsonl(path: Path, record: Mapping) -> None:
    with open(path, "a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, ensure_ascii=False) + "\n")


def run_reference(battery: Battery, run_dir: Path) -> None:
    """The deterministic pass (the m3 form verbatim): the corpus's
    pinned replies through the real doors — the census ground truth +
    the premise fingerprint."""
    out = run_dir / "reference.jsonl"
    done = _load_units(out)
    for case in battery.corpus["cases"]:
        if case["name"] in done:
            continue
        unit = run_dir / "reference" / case["name"]
        unit.mkdir(parents=True, exist_ok=True)
        sim, mediator, door, log = battery.boot(
            unit, case["seed"], case.get("setup", ()))
        fp = []
        for i, cycle in enumerate(case["cycles"]):
            if "narrator" in cycle:
                mediator.emit_call()
                reply = unit / f"narrator_{i}.json"
                reply.write_text(json.dumps(cycle["narrator"]),
                                 encoding="utf-8")
                beat = mediator.apply_reply(reply)
                assert beat.status == "accepted", case["name"]
                continue
            if "double_apply_probe" in cycle:
                continue
            fp.append({"i": i, "fp": battery.state_fingerprint(door, log)})
            if "probes" in cycle:
                continue
            reply_path = unit / f"reply_{i}.json"
            reply_path.write_text(json.dumps(cycle["reply"]),
                                  encoding="utf-8")
            try:
                door.apply_reply(reply_path)
            except Exception:
                pass  # the reference tolerates world refusals
        _append_jsonl(out, {
            "event": "end", "unit": case["name"],
            "fingerprints": fp,
            "ledger": [e.id for e in mediator.ledger.entries],
        })
        sim.close()
        print(f"[reference] {case['name']} done", flush=True)


def run_arm(battery: Battery, arm: str, run_dir: Path,
            main_server, main_factory, router_lazy, router_factory,
            deadline: float | None, *,
            profile_gate: float = NOUL_GATE) -> str:
    """One arm's stage: g (the grammar control) / r (THE PRODUCTION
    FORM — the systemone router at the PROFILE gate; the false-allow
    census the standing watch on every gate-passed cycle) /
    h0, h8 (the hybrid single-pass, temp 0 / 0.8-seeded — the m5 core,
    OPT-IN via --stages h).
    Returns 'done' / 'budget' / 'skipped (...)'."""
    out = run_dir / f"arm_{arm}.jsonl"
    done = _load_units(out)
    for case in battery.corpus["cases"]:
        if case["name"] in done:
            continue
        if deadline is not None and time.monotonic() > deadline:
            return "budget"
        unit = run_dir / f"arm_{arm}" / case["name"]
        unit.mkdir(parents=True, exist_ok=True)
        sim, mediator, door, log = battery.boot(
            unit, case["seed"], case.get("setup", ()))
        cycle_records = []
        for i, cycle in enumerate(case["cycles"]):
            if "narrator" in cycle:
                mediator.emit_call()
                reply = unit / f"narrator_{i}.json"
                reply.write_text(json.dumps(cycle["narrator"]),
                                 encoding="utf-8")
                beat = mediator.apply_reply(reply)
                if beat.status != "accepted":
                    print(f"[{arm}] {case['name']} cycle {i}: narrator "
                          f"beat {beat.status} (premise drift)",
                          flush=True)
                continue
            if "double_apply_probe" in cycle or "probes" in cycle:
                continue
            if arm == "g":
                rec = battery.g_cycle(
                    main_server, main_factory, door, unit, i, cycle)
            elif arm == "r":
                rec = battery.r_cycle(
                    router_lazy, router_factory, door, unit, i, cycle,
                    gate=profile_gate)
                # THE STANDING WATCH (v6.0 -- the m5 r04 instrument
                # promoted to the permanent monitor per D-250 M2:
                # every gate-passed cycle checked against its gold,
                # at ANY profile gate; a wrong-kind or wrong-object
                # pass is a falsely-allowed action, never a win)
                rec["fa"] = false_allow_class(
                    rec.get("assembled"),
                    (rec.get("r_meta") or {}).get("gate"),
                    cycle.get("reply") or {})
            elif arm in ("h0", "h8"):
                rec = battery.h_cycle(
                    main_server, main_factory, door, unit, i, cycle,
                    temp=0.0 if arm == "h0" else 0.8)
            else:
                raise ValueError(arm)
            cycle_records.append(rec)
        # the premise-drift flags vs the reference (the m3 law)
        ref_line = None
        ref_path = run_dir / "reference.jsonl"
        if ref_path.exists():
            for line in ref_path.read_text(
                    encoding="utf-8").splitlines():
                rec = json.loads(line)
                if rec.get("unit") == case["name"]:
                    ref_line = rec
                    break
        for rec in cycle_records:
            rec["drift"] = None
        if ref_line:
            ref_fp = {d["i"]: d["fp"] for d in ref_line.get(
                "fingerprints", [])}
            for rec in cycle_records:
                ref = ref_fp.get(rec.get("cycle"))
                if ref is not None and rec.get("fp_start") is not None:
                    rec["drift"] = bool(rec["fp_start"] != ref)
        _append_jsonl(out, {
            "event": "end", "unit": case["name"],
            "cycles": cycle_records,
        })
        sim.close()
        print(f"[arm {arm}] {case['name']} done "
              f"({len(cycle_records)} cycles)", flush=True)
        # the grammar-growth wall (the G/H arms; the m3 recycle law —
        # the hybrid grammars grow on the same per-cycle snapshot
        # cadence, the recycle rides them identically)
        if arm in ("g", "h0", "h8") and main_server is not None and \
                main_server.calls_since_spawn >= 20:
            main_server.stop()
            time.sleep(3.0)
            main_server.start()
    return "done"


def run_ru(battery: Battery, run_dir: Path, router_lazy, router_factory,
           deadline: float | None, *, profile_gate: float = NOUL_GATE) -> str:
    """The RU band @0.5: the hand-authored Russian rows on the SAME
    router, a fresh boot per row (seed 125, the tavern-enter setup) —
    the same-session baseline the 0.4 stage is read against."""
    return _run_ru_band(battery, run_dir, router_lazy, router_factory,
                        deadline, gate=profile_gate, suffix="ru")


def _run_ru_band(battery: Battery, run_dir: Path, router_lazy,
                 router_factory, deadline: float | None, *, gate: float,
                 suffix: str) -> str:
    out = run_dir / f"{suffix}.jsonl"
    done = _load_units(out)
    setup = [{"intent": "move", "target": "loc_tavern"}]
    for idx, row in enumerate(RU_ROWS):
        name = f"ru_{idx:02d}"
        if name in done:
            continue
        if deadline is not None and time.monotonic() > deadline:
            return "budget"
        unit = run_dir / suffix / name
        unit.mkdir(parents=True, exist_ok=True)
        sim, mediator, door, log = battery.boot(unit, 125, setup)
        cycle = {"say": row["say"], "reply": row["gold"]}
        try:
            rec = battery.r_cycle(
                router_lazy, router_factory, door, unit, 0, cycle,
                gate=gate)
        except RouterDown as exc:
            _append_jsonl(out, {"event": "end", "unit": name,
                                "error": str(exc)[:400]})
            sim.close()
            return f"skipped (the router died: {str(exc)[:200]})"
        rec["ru_band"] = True
        rec["gold_is_hand_authored"] = True
        rec["gate_threshold"] = gate
        # THE FALSE-ALLOW CENSUS (the owner's recorded M2 call: the
        # growth of accepted requests is not by itself reliability —
        # every gate-passed row is checked against its gold)
        rec["fa"] = false_allow_class(
            rec.get("assembled"), (rec.get("r_meta") or {}).get("gate"),
            row["gold"])
        _append_jsonl(out, {"event": "end", "unit": name,
                            "cycles": [rec]})
        sim.close()
        print(f"[{suffix}] {name}: {rec['census']} fa={rec['fa']} "
              f"(wall {rec.get('r_wall_s')}s)", flush=True)
    return "done"


def run_det(battery: Battery, run_dir: Path, main_server,
            main_factory, router_lazy, router_factory) -> None:
    """The determinism mini: the SAME systemone call twice ->
    byte-identical distributions (the answer dict's json.dumps,
    sort_keys); the G route twice likewise (the m3 form)."""
    out = run_dir / "det.jsonl"
    done = _load_units(out)
    if "router" not in done:
        unit = run_dir / "det" / "router"
        unit.mkdir(parents=True, exist_ok=True)
        sim, mediator, door, log = battery.boot(unit, 125, ())
        door.emit_call("I look around the tavern")
        _hdr, events = battery.cs.read_log(unit / "run.jsonl",
                                           battery.cs.SCHEMA)
        snapshot = battery.cs.grammar_snapshot(
            events, battery.cs.PACK, door._ledger)
        state = build_state("I look around the tavern", events,
                            battery.cs.PACK, door)
        questions = build_questions(snapshot, battery.cs.PACK)
        r1 = battery._systemone_with_heal(
            router_lazy, router_factory, state, questions)
        r2 = battery._systemone_with_heal(
            router_lazy, router_factory, state, questions)
        s1 = json.dumps(r1.answers, sort_keys=True)
        s2 = json.dumps(r2.answers, sort_keys=True)
        _append_jsonl(out, {
            "event": "end", "unit": "router",
            "identical": s1 == s2,
            "wall1": round(r1.wall_s, 3), "wall2": round(r2.wall_s, 3),
            "answers_digest": hashlib_short(s1),
        })
        print(f"[det] router: identical={s1 == s2}", flush=True)
        sim.close()
    if "g" not in done and main_factory is not None:
        doc = ("Reply with ONE JSON object: "
               '{"intent": {"kind": "look_around"}}')
        c1 = battery._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": doc}],
            grammar=None, temp=0.0, max_tokens=60, seed=42)
        c2 = battery._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": doc}],
            grammar=None, temp=0.0, max_tokens=60, seed=42)
        _append_jsonl(out, {
            "event": "end", "unit": "g",
            "identical": c1.content == c2.content,
            "answers_digest": hashlib_short(c1.content),
        })
        print(f"[det] g: identical={c1.content == c2.content}",
              flush=True)
    if "h" not in done and main_factory is not None and \
            getattr(run_det, "want_h", False):
        # THE HYBRID DET (m5, OPT-IN -- runs only when --stages h
        # named the hybrid halves; never in the default battery): the same terminated-prose call twice at
        # temp 0 — the whole answer (verdict + blank line + prose)
        # byte-compared, the digest recorded. Closes the iter-361
        # instrument gap alongside the g digest line above.
        unit = run_dir / "det" / "hybrid"
        unit.mkdir(parents=True, exist_ok=True)
        sim, mediator, door, log = battery.boot(unit, 125, ())
        call_path = door.emit_call("I look around the tavern")
        call = call_path.read_text(
            encoding="utf-8") + HYBRID_PROTOCOL_TAIL
        _hdr, events = battery.cs.read_log(unit / "run.jsonl",
                                           battery.cs.SCHEMA)
        snapshot = battery.cs.grammar_snapshot(
            events, battery.cs.PACK, door._ledger)
        hybrid = hybrid_grammar(battery.cs.gbnf_grammar(snapshot))
        h1 = battery._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": call}],
            grammar=hybrid, temp=0.0, max_tokens=HYBRID_MAX_TOKENS,
            seed=42)
        h2 = battery._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": call}],
            grammar=hybrid, temp=0.0, max_tokens=HYBRID_MAX_TOKENS,
            seed=42)
        _append_jsonl(out, {
            "event": "end", "unit": "h",
            "identical": h1.content == h2.content,
            "answers_digest": hashlib_short(h1.content),
            "finish1": h1.finish_reason, "finish2": h2.finish_reason,
        })
        print(f"[det] h: identical={h1.content == h2.content} "
              f"(finish {h1.finish_reason})", flush=True)
        sim.close()


def hashlib_short(text: str) -> str:
    import hashlib

    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]



def run_narrate(battery: Battery, run_dir: Path) -> str:
    """THE L12 TEMPLATE RUNG (v6.0, the production prose surface —
    D-250 M3: prose a SEPARATE surface; the narrator's production form
    REMAINS the template rung, PRESENTATION_SPEC §7): every R-arm
    unit's log rendered through the repo's own chronicle renderer
    (render/chronicle.py — the tale as a pure function of the log,
    T1-covered, the renderer writes nothing back, INV-1). The
    reference (gold) units render beside the R units — the prose
    surface's own like-for-like. Each tale is rendered TWICE with the
    digests compared (the L12 rung's determinism proof, live — the
    same log renders to the same bytes); the full tales ship as
    narrate/<tag>_<unit>.txt for the owner's own reading."""
    out = run_dir / "narrate.jsonl"
    done = _load_units(out)
    chronicle = battery.cs.chronicle_from_log
    groups = (("r", run_dir / "arm_r"), ("gold", run_dir / "reference"))
    for tag, root in groups:
        if not root.is_dir():
            continue
        for unit_dir in sorted(root.iterdir()):
            if not unit_dir.is_dir():
                continue
            name = f"{tag}:{unit_dir.name}"
            if name in done:
                continue
            log = unit_dir / "run.jsonl"
            if not log.is_file():
                continue
            tale1 = chronicle(log, battery.cs.PACK, battery.cs.SCHEMA)
            tale2 = chronicle(log, battery.cs.PACK, battery.cs.SCHEMA)
            d1 = hashlib_short(tale1)
            d2 = hashlib_short(tale2)
            lines = tale1.splitlines()
            dest = run_dir / "narrate" / f"{tag}_{unit_dir.name}.txt"
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_text(tale1, encoding="utf-8")
            _append_jsonl(out, {
                "event": "end", "unit": name, "tag": tag,
                "case": unit_dir.name,
                "lines": len(lines), "chars": len(tale1),
                "digest": d1,
                "deterministic": d1 == d2,
                "head": lines[:3], "tail": lines[-3:],
            })
            print(f"[narrate] {name}: {len(lines)} lines, digest "
                  f"{d1}, deterministic={d1 == d2}", flush=True)
    return "done"


def run_preflight(battery: Battery, run_dir: Path, repo: Path,
                  main_props, router_props, models_report,
                  args=None) -> None:
    """The preflight record: the environment, the engines, the models'
    verdicts, the corpus shape."""
    doc = {
        "pack_version": PACK_VERSION,
        "time": datetime.now(timezone.utc).isoformat(),
        "repo": str(repo),
        "python": sys.version.split()[0],
        "platform": sys.platform,
        "noul_gate": NOUL_GATE,
        "noul_gate_loose": NOUL_GATE_LOOSE,
        "profile_gate": (getattr(args, "gate", NOUL_GATE)
                         if args is not None else NOUL_GATE),
        "field_policy": R_FIELD_DEFAULTS,
        "hybrid_max_tokens": HYBRID_MAX_TOKENS,
        "h_arms": (["h0", "h8"]
                   if "h" in getattr(args, "_stages_set", frozenset())
                   else []),  # v6.0: OPT-IN only (--stages h)
        "main_props": main_props,
        "router_props": router_props,
        "models": models_report,
        "corpus_cases": [c["name"] for c in battery.corpus["cases"]],
        "ru_rows": len(RU_ROWS),
        "device_gate": DEVICE_GATE.doc(),
    }
    (run_dir / "preflight.json").write_text(
        json.dumps(doc, indent=2, sort_keys=True, default=str),
        encoding="utf-8")
    print("[preflight] written", flush=True)


class RepoNS:
    """The repo's pure functions + doors, imported once (the m3 form).
    Extended: the scene fold (the R state's source) + the actions
    access (the criteria's source)."""

    def __init__(self, repo: Path) -> None:
        import importlib

        sys.path.insert(0, str(repo))
        self.load_pack = importlib.import_module("core.pack").load_pack
        self.read_log = importlib.import_module("core.log").read_log
        loop = importlib.import_module("core.loop")
        self.Simulator = loop.Simulator
        self.RunnerError = loop.RunnerError
        self.Mediator = importlib.import_module("cli.mediator").Mediator
        self.ParserDoor = importlib.import_module("cli.parser").ParserDoor
        parser = importlib.import_module("brief.parser")
        self.grammar_snapshot = parser.grammar_snapshot
        self.ParseError = parser.ParseError
        gbnf = importlib.import_module("brief.gbnf")
        self.gbnf_grammar = gbnf.gbnf_grammar
        self.grammar_fingerprint = gbnf.grammar_fingerprint
        ledger = importlib.import_module("brief.ledger")
        self.ACTIVE = ledger.ACTIVE
        # v6.0: the L12 template rung (render/chronicle.py) — the
        # production prose surface (D-250 M3: prose a SEPARATE surface;
        # the narrator's production form REMAINS the template rung)
        chron = importlib.import_module("render.chronicle")
        self.chronicle_from_log = chron.chronicle_from_log
        foldmod = importlib.import_module("core.fold")
        self.fold = foldmod.fold
        self.initial_projection = foldmod.initial_projection
        self.PACK = self.load_pack(repo / "content" / "tavern_pack")
        self.SCHEMA = json.loads(
            (repo / "schemas" / "event.schema.json").read_text(
                encoding="utf-8"))


#: the module-level namespace for build_state (set by main)
_CS = None


# -- main (the engine ladder, the stage driver, the packaging) ---------------


#: the m6 stage order (v6.0, THE PROMOTION BATTERY): the production
#: core first (r — R at the door, the profile gate; g — the anchor;
#: ru — the Russian band at the same profile), then narrate (the L12
#: template rung — the prose surface over the R run's logs), det,
#: package. The canonical order is fixed; --stages selects the
#: subset; 'h' (the hybrid halves) is OPT-IN ONLY — never in the
#: default battery (H not promoted, D-250; the aesthetic call the
#: owner's).
STAGES = ("preflight", "reference", "r", "g", "ru", "narrate", "det",
          "package")

#: the opt-in stage names --stages accepts beyond the default set:
#: 'h' runs the m5 hybrid halves (h0 + h8, the m5 core verbatim —
#: the instrument for the aesthetic call, never the default).
OPT_IN_STAGES = ("h",)

#: every name --stages may legally name (the loud-refusal list).
KNOWN_STAGES = STAGES + OPT_IN_STAGES


def _model_report(repo: Path) -> list[dict]:
    """The doctor's verdict table, embedded (the probe refuses a
    non-decision router with the reason, never a mid-run death)."""
    from station_m6_doctor import verdict_model

    return [verdict_model(p) for p in _gguf_models(repo)]


def _tty_model_choice(models: list[Path], what: str,
                      *, allow_none: bool = False) -> Path | str | None:
    """The TTY prompt (the m3 law): number / path; allow_none adds
    'none' (skip). Non-TTY is a LOUD refusal with the ready command
    lines — never a silent guess."""
    if not models:
        if allow_none:
            if not sys.stdin.isatty():
                print(f"[{what}] no .gguf candidates — the honest skip",
                      flush=True)
                return "none"
            print(f"[{what} model choice] no .gguf candidates found")
            while True:
                try:
                    answer = input(
                        f"[choose the {what} (none/path)]: ").strip()
                except (EOFError, KeyboardInterrupt):
                    return "none"
                if answer.lower() == "none":
                    return "none"
                p = Path(answer)
                if p.is_file():
                    return p
                print("  not understood — none or a full path")
        raise SystemExit(
            f"no .gguf models found for the {what} — drop one into "
            f"workbench/runtime/models/ or pass the flag")
    if len(models) == 1 and not allow_none:
        return models[0]
    if not sys.stdin.isatty():
        lines = "\n".join(f"  {i + 1}. {m}" for i, m in enumerate(models))
        raise SystemExit(
            f"{len(models)} models found for the {what} and no TTY:\n"
            f"{lines}\nPass the number as a flag instead.")
    print(f"[{what} model choice] available:")
    for i, m in enumerate(models, 1):
        print(f"  {i}. {m.name}  ({m.stat().st_size / 1e6:.0f} MB)")
    suffix = "  (also: 'none' = skip)" if allow_none else ""
    if suffix:
        print(suffix)
    while True:
        try:
            answer = input(
                f"[choose the {what} model (number or path)]: ").strip()
        except (EOFError, KeyboardInterrupt):
            raise SystemExit("no choice made — aborting") from None
        if allow_none and answer.lower() == "none":
            return "none"
        if answer.isdigit() and 1 <= int(answer) <= len(models):
            return models[int(answer) - 1]
        p = Path(answer)
        if p.is_file():
            return p
        print("  not understood — a number or a full path, please")


def _resolve_router(args, repo: Path, report: list[dict]):
    """THE ROUTER ladder (the m4 core): attach --router-endpoint if a
    live decision server answers there -> else autospawn, restricted
    to the GGUFs the doctor verdicted as decision models."""
    gate: dict[str, object] = {}
    if args.router_endpoint:
        if SystemOneClient(args.router_endpoint).health():
            gate["mode"] = "attach"
            gate["endpoint"] = args.router_endpoint
            print(f"[router] attach: {args.router_endpoint}", flush=True)
            factory = lambda: SystemOneClient(  # noqa: E731
                args.router_endpoint)
            return None, factory, gate
        raise SystemExit(
            f"--router-endpoint {args.router_endpoint} is dead")
    decision_rows = [r for r in report
                     if str(r.get("verdict", "")).startswith("decision:")]
    if args.router_model:
        model = Path(args.router_model)
        if not model.is_file():
            raise SystemExit(f"--router-model {model} not found")
        row = next((r for r in report
                    if r.get("file") == model.name), {})
        if not str(row.get("verdict", "")).startswith("decision:"):
            print(f"[router] WARNING: {model.name} is "
                  f"{row.get('verdict', 'unverdicted')} — not a "
                  f"decision model; /v1/systemone will refuse it",
                  flush=True)
    else:
        decision_models = [repo / "workbench" / "runtime" / "models"
                           / r["file"] for r in decision_rows]
        if not decision_models:
            raise SystemExit(
                "no decision model found in workbench/runtime/models/ "
                "— run station_m6_doctor.py --fetch-laya (450 MB, EN) "
                "or --fetch-kev (4.5 GB), or pass --router-model")
        model = _tty_model_choice(decision_models, "router")
    exes = _exe_candidates(repo)
    if not exes:
        raise SystemExit(
            "no llama-server found — run station_m6_setup.bat (the "
            "pack installs the pinned build into the pack's "
            "llama.cpp/)")
    exe = exes[0]
    gate["exe"] = str(exe)
    gate["exe_search"] = [str(p) for p in _exe_candidates(repo)]
    gate["model"] = str(model)
    gate["batch"] = args.router_batch
    gate["ubatch"] = args.router_batch  # rides -b (the embeddings tie)
    lazy = LazyServer(exe, Path(model), ctx=args.router_ctx,
                      log_path=Path("m6_llama_router.log"), jinja=False,
                      batch=args.router_batch, ubatch=None)
    gate["mode"] = "autospawn"
    factory = lambda: SystemOneClient(  # noqa: E731
        lazy.ensure().endpoint)
    return lazy, factory, gate


def _resolve_main(args, repo: Path, report: list[dict]):
    """The MAIN ladder (the G control — optional): attach --endpoint
    if live -> else autospawn among the causal-lm verdicts; --no-g
    skips the whole G arm (the R arm is self-sufficient)."""
    gate: dict[str, object] = {}
    if args.no_g and args.no_h:
        gate["mode"] = "none (--no-g --no-h)"
        return None, None, gate
    if args.no_g:
        gate["mode"] = "h-only (G skipped, the main rides the H arm)"
    elif args.no_h:
        gate["mode"] = "g-only (H skipped)"
    if LlamaClient(args.endpoint).health():
        gate["mode"] = "attach"
        gate["endpoint"] = args.endpoint
        mid = _model_id_for(args.endpoint)
        gate["attach_model_id"] = mid
        print(f"[main] attach: {args.endpoint} (model id {mid!r})",
              flush=True)
        factory = lambda: LlamaClient(  # noqa: E731
            args.endpoint, model_name=mid)
        return None, factory, gate
    if args.no_autospawn:
        gate["mode"] = "none (no --endpoint, --no-autospawn)"
        return None, None, gate
    exes = _exe_candidates(repo)
    if not exes:
        gate["mode"] = "none (no engine found)"
        return None, None, gate
    exe = exes[0]
    models = _gguf_models(repo)
    if args.model_file:
        model = Path(args.model_file)
        if not model.is_file():
            raise SystemExit(f"--model-file {model} not found")
    else:
        causal = [m for m in models
                  if next((r for r in report
                           if r.get("file") == m.name),
                          {}).get("verdict") == "causal-lm"]
        if not causal:
            gate["mode"] = ("none (no causal-lm model found — run "
                            "station_m6_doctor.py --fetch-qwen or pass "
                            "--model-file)")
            return None, None, gate
        model = _tty_model_choice(causal, "main")
    gate["mode"] = "autospawn"
    gate["model"] = str(model)
    gate["exe"] = str(exe)
    gate["batch"] = args.batch
    gate["ubatch"] = SPAWN_UBATCH
    server = SpawnedServer(exe, model, ctx=args.ctx,
                           extra=list(args.server_arg),
                           log_path=Path("m6_llama_main.log"),
                           batch=args.batch, ubatch=SPAWN_UBATCH)
    server.start()
    gate["endpoint"] = server.endpoint
    mid = _model_id_for(server.endpoint)
    factory = lambda: LlamaClient(  # noqa: E731
        server.endpoint, model_name=mid)
    return server, factory, gate


def _stage_done(run_dir: Path, stage: str, args=None,
                main_factory=None) -> bool:
    """The completeness law (the m3 form): a stage is done only when
    EVERY expected unit carries its end marker."""
    if stage in ("r", "g"):
        p = run_dir / f"arm_{stage}.jsonl"
        if not p.exists() or not p.read_text(encoding="utf-8").strip():
            return False
        if stage == "g" and (args is not None and args.no_g
                             or main_factory is None):
            return True
        done = _load_units(p)
        n_cases = 2 if (args is not None and args.smoke) else 10
        return len(done) >= n_cases
    if stage == "h":
        # both halves (h0 always; h8 unless --no-h8) must carry their
        # end markers — the completeness law per sub-arm
        n_cases = 2 if (args is not None and args.smoke) else 10
        halves = ("h0",) if (args is not None and args.no_h8) \
            else ("h0", "h8")
        if main_factory is None or "h" not in getattr(
                args, "_stages_set", frozenset(STAGES)):
            return True  # v6.0: h is opt-in — not selected = skipped
        for half in halves:
            p = run_dir / f"arm_{half}.jsonl"
            if not p.exists() \
                    or not p.read_text(encoding="utf-8").strip():
                return False
            if len(_load_units(p)) < n_cases:
                return False
        return True
    if stage in ("reference", "ru", "narrate", "det"):
        p = run_dir / f"{stage}.jsonl"
        if not p.exists() or not p.read_text(encoding="utf-8").strip():
            return False
        if stage == "reference":
            done = _load_units(p)
            n_cases = 2 if (args is not None and args.smoke) else 10
            return len(done) >= n_cases
        if stage == "ru":
            return len(_load_units(p)) >= len(RU_ROWS)
        return True  # det / narrate (the end markers carry it)
    if stage == "preflight":
        return (run_dir / "preflight.json").exists()
    if stage == "package":
        return False
    raise ValueError(stage)


def _collect_server_logs(run_dir: Path) -> None:
    """The llama-server logs ride the run dir (the iter-353 evidence
    law). Capped at 2 MB a file."""
    logs = run_dir / "logs"
    for name in ("m6_llama_main.log", "m6_llama_router.log"):
        src = Path.cwd() / name
        try:
            if src.is_file() and src.stat().st_size <= 2_000_000:
                logs.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src, logs / name)
        except OSError:
            pass


def _run_package(run_dir: Path, battery: Battery, gate: Mapping,
                 args) -> Path:
    """The analysis + the station zip (the m3 law: the run dir's
    evidence, the models excluded, the SERVER LOGS included)."""
    from m6_analysis import analyze_run

    _collect_server_logs(run_dir)
    report = analyze_run(run_dir, dict(gate))
    (run_dir / "m6_report.txt").write_text(report, encoding="utf-8")
    name = args.package_name or (
        "m6_" + datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S"))
    zip_path = run_dir.parent / f"{name}.zip"
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(run_dir.rglob("*")):
            if p.is_file() and p.suffix in (".json", ".jsonl", ".txt",
                                            ".md", ".log"):
                zf.write(p, p.relative_to(run_dir.parent))
    print(f"[package] {zip_path} "
          f"({zip_path.stat().st_size} bytes)", flush=True)
    return zip_path


def main(argv: Sequence[str] | None = None) -> int:
    global _CS, _ALLOW_CPU
    # allow_abbrev=False (iter-359): argparse's default prefix-match
    # made `--ru` collide with `--run-dir` and reported a confusing
    # "expected one argument" instead of "unrecognized argument".
    # With abbrev off, every flag must be named verbatim — the four
    # new no-op aliases (--g --ru --det --full-corpus) are accepted
    # alongside the law flags.
    ap = argparse.ArgumentParser(
        description=__doc__.splitlines()[0],
        allow_abbrev=False,
        add_help=True,
        epilog=(
            "v6.0 — THE PROMOTION PACK: R AT THE DOOR (D-250 M3, the\n"
            "owner's promotion permission) + the L12 template rung as the\n"
            "prose surface (narrate) + the --gate profile knob (D-250 M2).\n"
            "\n"
            "STAGES (run in this order, all ON by default):\n"
            "  preflight  the device-class gate + the cuda_gate.json\n"
            "  reference  the gold corpus (10 units, byte-pure)\n"
            "  r          THE PRODUCTION FORM — /v1/systemone per cycle at\n"
            "             the --gate profile, the false-allow census the\n"
            "             standing watch on every gate-passed cycle\n"
            "  g          the G control (skip with --no-g)\n"
            "  ru         the RU band at the --gate profile — 12 rows\n"
            "  narrate    THE L12 TEMPLATE RUNG — the prose surface: every\n"
            "             R unit's log through the repo's chronicle\n"
            "             renderer, each tale rendered twice (digest), the\n"
            "             gold units beside (the prose like-for-like)\n"
            "  det        the determinism mini (router/g digests)\n"
            "  package    the m6_*.zip (always ships, even on crash)\n"
            "\n"
            "OPT-IN stage (NEVER in the default battery — H is NOT\n"
            "promoted, D-250; the aesthetic call the owner's):\n"
            "  h          the hybrid single-pass halves: h0 (temp 0) +\n"
            "             h8 (temp 0.8-seeded) on the SAME main-model\n"
            "             spawn as G — the m5 instrument, kept for the\n"
            "             future call (--stages h to run it)\n"
            "\n"
            "DEFAULT = the production battery, FULL corpus (10 units).\n"
            "--smoke reduces every arm to s1+s2 only.\n"
            "--g/--ru/--det/--full-corpus are explicit no-op aliases\n"
            "for the default (the iter-359 law). --no-h/--no-h8 are now\n"
            "no-ops TOO (h is opt-in — it does not run unless --stages h;\n"
            "--no-h8 only shapes the h stage when it IS selected).\n"
            "\n"
            "THE GATE PROFILE (D-250 M2): --gate 0.5 the default;\n"
            "--gate 0.4 the explicit recall-oriented deployment override\n"
            "— NEVER a more-reliable mode (EN correct 15->20,\n"
            "blocked_miss 10->4, nonintent-false 4->7, precision\n"
            "60.0->58.8%; no separating threshold; the nonintent census\n"
            "the watch, never protection).\n"
            "\n"
            "THE BAND INSTRUMENT (KI#119): the band verdict is DERIVED\n"
            "from the server logs and said LOUD at run end — the m5\n"
            "station run was the CPU band by its own logs (zero CUDA\n"
            "lines; cuda_gate.bands was {} the honest empty).\n"
            "\n"
            "EXAMPLES:\n"
            "  station_m6_probe.bat                     (the production\n"
            "                                           battery, full)\n"
            "  station_m6_probe.bat --smoke             (all stages, s1+s2)\n"
            "  station_m6_probe.bat --gate 0.4          (the recall profile)\n"
            "  station_m6_probe.bat --stages h          (the hybrid halves —\n"
            "                                           the aesthetic call)\n"
            "  station_m6_probe.bat --no-g              (skip G control)\n"
            "  station_m6_probe.bat --time-budget 300   (clean stop at 5 min)"
        ),
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    ap.add_argument("--repo", default=None,
                    help="the canonsim repo path")
    ap.add_argument("--router-endpoint", default=None,
                    help="an ALREADY-RUNNING decision-model server "
                         "(attach form)")
    ap.add_argument("--router-model", default=None,
                    help="the decision model (spawn form; default: the "
                         "TTY choice over the doctor's decision "
                         "verdicts)")
    ap.add_argument("--router-ctx", type=int, default=4096,
                    help="the router context (default 4096)")
    ap.add_argument("--router-batch", type=int,
                    default=DEFAULT_SPAWN_BATCH,
                    help="the router's n_batch — the WHOLE systemone "
                         "payload must fit in ONE batch (default 2048; "
                         "the stock 512 died on the tavern set's 741 "
                         "tokens; auto-escalates on the 400 class; the "
                         "ubatch rides it)")
    ap.add_argument("--endpoint", default="http://127.0.0.1:8080",
                    help="an ALREADY-RUNNING generative server for the "
                         "G control arm (attach form)")
    ap.add_argument("--model-file", default=None,
                    help="the generative model (the G arm; default: "
                         "the TTY choice over the causal-lm verdicts)")
    ap.add_argument("--no-g", action="store_true",
                    help="skip the G control arm (the R arm is "
                         "self-sufficient)")
    ap.add_argument("--no-h", action="store_true",
                    help="no-op in v6.0 — the H arm is OPT-IN (never in "
                         "the default battery; run it with --stages h). "
                         "Kept for the m5 muscle memory, never an error.")
    ap.add_argument("--no-h8", action="store_true",
                    help="shapes the OPT-IN h stage when selected: skip "
                         "the h8 half (temp 0.8) — h0 (temp 0) still runs")
    ap.add_argument("--gate", type=float, default=NOUL_GATE,
                    choices=(NOUL_GATE, NOUL_GATE_LOOSE),
                    help="THE PROFILE GATE (D-250 M2): 0.5 the default; "
                         "0.4 the explicit recall-oriented deployment "
                         "override — NEVER a more-reliable mode (the "
                         "measured cost: EN correct_allow 15->20, "
                         "blocked_miss 10->4, false_allow_nonintent 4->7, "
                         "precision-on-passed 60.0->58.8%; no separating "
                         "threshold exists; the nonintent census the "
                         "honest watch, never protection)")
    ap.add_argument("--yes-cpu", action="store_true",
                    help="allow the CPU band without a TTY confirm "
                         "(the device gate's override)")
    ap.add_argument("--ctx", type=int, default=4096,
                    help="the main server context (default 4096)")
    ap.add_argument("--batch", type=int, default=DEFAULT_SPAWN_BATCH,
                    help="the main server's n_batch (default 2048; the "
                         "chat route chunks internally — consistency, "
                         "not necessity)")
    ap.add_argument("--server-arg", action="append", default=[],
                    help="extra llama-server args (repeatable)")
    ap.add_argument("--no-autospawn", action="store_true",
                    help="attach only (never spawn the main)")
    ap.add_argument("--run-dir", default=None,
                    help="the run directory (resume)")
    ap.add_argument("--time-budget", type=float, default=None,
                    help="stop cleanly after N seconds (checkpointed)")
    ap.add_argument("--smoke", action="store_true",
                    help="the reduced corpus (s1+s2 per arm)")
    ap.add_argument("--package-name", default=None)
    # iter-359: the four no-op aliases — the iter-358 chat guidance
    # named them, the owner tried them, they did not exist. They are
    # EXPLICIT forms of the default (all stages run, full corpus);
    # they document the intent in the cmd line, they do not toggle.
    # The real toggles stay --no-g (skip G) and --stages (pick a subset).
    ap.add_argument("--full-corpus", action="store_true",
                    help="no-op alias for the default — the full 10-"
                         "unit corpus (counterpart to --smoke; runs all "
                         "stages, no early stop)")
    ap.add_argument("--g", action="store_true",
                    help="no-op alias — the G control runs by default; "
                         "use --no-g to skip it")
    ap.add_argument("--ru", action="store_true",
                    help="no-op alias — the RU band runs by default")
    ap.add_argument("--det", action="store_true",
                    help="no-op alias — the det mini runs by default")
    # iter-359: the explicit stage selector — pick a subset of STAGES
    # (comma-separated, in any order; the run still respects the
    # canonical STAGES order). Useful for re-running only the legs a
    # prior run missed (e.g. --stages ru,det after r+g finished).
    ap.add_argument("--stages", default=None,
                    help="comma-separated subset to run (default: "
                         + ",".join(STAGES) + "; opt-in beyond the "
                         "default: " + ",".join(OPT_IN_STAGES)
                         + "; the order is always canonical, the subset "
                         "selects which fire)")
    args = ap.parse_args(argv)
    _ALLOW_CPU = args.yes_cpu

    # iter-359: validate --stages against the canonical STAGES list
    # (unknown names are a loud refusal — never a silent skip).
    if args.stages is not None:
        wanted = [s.strip() for s in args.stages.split(",") if s.strip()]
        unknown = [s for s in wanted if s not in KNOWN_STAGES]
        if unknown:
            ap.error(
                f"--stages: unknown name(s) {unknown}; "
                f"valid: {list(KNOWN_STAGES)} "
                f"(default set: {list(STAGES)}; opt-in: "
                f"{list(OPT_IN_STAGES)})")
        # 'package' is always implicit at the end (the always-a-zip
        # law) — the owner never needs to list it.
        args._stages_set = frozenset(wanted)
    else:
        args._stages_set = frozenset(STAGES)

    repo, repo_tried, repo_found = find_repo(args.repo)
    if not repo_found:
        lines = "\n".join(f"  {t}" for t in repo_tried)
        raise SystemExit(
            "the canonsim repo was not found. Tried:\n" + lines
            + "\nPass --repo <path>, set CANONSIM_REPO, or unpack the "
              "pack beside the repo.")
    ns = RepoNS(repo)
    _CS = ns
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    run_dir = (Path(args.run_dir) if args.run_dir
               else Path(f"m6_{ts}"))
    if args.smoke and "smoke" not in run_dir.name:
        run_dir = run_dir.with_name(run_dir.name + "_smoke")
    run_dir.mkdir(parents=True, exist_ok=True)
    battery = Battery(repo, run_dir, ns, smoke=args.smoke)
    if args.smoke:
        battery.corpus["cases"] = battery.corpus["cases"][:2]
    print(f"[m6] pack {PACK_VERSION}", flush=True)
    print(f"[m6] repo {repo} run {run_dir} "
          f"({'smoke' if args.smoke else 'full'} corpus)", flush=True)

    models_report = _model_report(repo)
    gate: dict[str, object] = {
        "repo": str(repo),
        "repo_tried": repo_tried,
        "pack_version": PACK_VERSION,
        "models": models_report,
        # v6.0: the profile record (D-250 M2 — the promotion's own
        # gate; 0.5 the default, 0.4 the recall-oriented override)
        "profile_gate": args.gate,
    }

    router_lazy, router_factory, router_gate = _resolve_router(
        args, repo, models_report)
    gate["router"] = router_gate
    main_server, main_factory, main_gate = _resolve_main(
        args, repo, models_report)
    gate["main"] = main_gate

    # the props probe: one honest startup check (the attach form
    # already proved itself; the spawn form gets its endpoint here)
    if router_lazy is not None:
        try:
            srv = router_lazy.ensure()
            router_props = dict(LlamaClient(srv.endpoint).props())
            gate["router"]["endpoint"] = srv.endpoint
        except RouterDown as exc:
            raise SystemExit(
                f"the router would not start:\n{exc}\n(the R arm IS "
                f"the battery — fix the model (the doctor) or the "
                f"engine (the setup) and re-run)") from exc
    main_props = {}
    if main_factory is not None and args.no_g is False and \
            main_gate.get("mode") == "autospawn":
        main_props = dict(LlamaClient(main_server.endpoint).props())
    elif main_gate.get("mode") == "attach":
        try:
            main_props = dict(
                LlamaClient(args.endpoint).props())
        except (urllib.error.URLError, OSError, ValueError):
            pass

    (run_dir / "cuda_gate.json").write_text(
        json.dumps(DEVICE_GATE.doc(), indent=2, sort_keys=True),
        encoding="utf-8")
    (run_dir / "gate.json").write_text(
        json.dumps(gate, indent=2, sort_keys=True, default=str),
        encoding="utf-8")

    deadline = (time.monotonic() + args.time_budget
                if args.time_budget else None)
    stage_status: dict[str, str] = {}

    def _budget_hit() -> bool:
        return deadline is not None and time.monotonic() > deadline

    crashed = False
    try:
        for stage in KNOWN_STAGES:
            # v6.0: the loop walks the canonical order over the default
            # set + the opt-ins. An OPT-IN stage (h) runs ONLY when
            # --stages named it — never by default (D-250: H not
            # promoted). 'package' is always allowed (the always-a-zip
            # law — the run ALWAYS ships its m6_*.zip, even on crash).
            if stage in OPT_IN_STAGES and stage not in args._stages_set:
                continue  # not an error: the default battery skips it
            if stage not in args._stages_set and stage != "package":
                stage_status[stage] = "skipped (--stages)"
                continue
            if stage == "g" and (args.no_g or main_factory is None):
                stage_status[stage] = ("skipped (--no-g)" if args.no_g
                                       else "skipped (no main engine)")
                continue
            if stage == "h" and main_factory is None:
                stage_status[stage] = ("skipped (no main engine)")
                continue
            if _stage_done(run_dir, stage, args, main_factory):
                stage_status[stage] = "done (resumed)"
                continue
            if _budget_hit():
                stage_status[stage] = "budget"
                break
            if stage == "preflight":
                run_preflight(battery, run_dir, repo, main_props,
                              router_props, models_report, args)
                stage_status[stage] = "done"
            elif stage == "reference":
                run_reference(battery, run_dir)
                stage_status[stage] = "done"
            elif stage in ("r", "g"):
                status = run_arm(battery, stage, run_dir, main_server,
                                 main_factory, router_lazy,
                                 router_factory, deadline,
                                 profile_gate=args.gate)
                stage_status[stage] = status
                if status == "budget":
                    break
            elif stage == "h":
                # both halves ride one stage: h0 (temp 0, the row R is
                # compared against) then h8 (temp 0.8-seeded, the prose
                # form) — each its own resumable jsonl
                status = run_arm(battery, "h0", run_dir, main_server,
                                 main_factory, router_lazy,
                                 router_factory, deadline)
                if status != "budget" and not args.no_h8:
                    status = run_arm(battery, "h8", run_dir,
                                     main_server, main_factory,
                                     router_lazy, router_factory,
                                     deadline)
                elif args.no_h8:
                    status = status + " (+h8 skipped (--no-h8))"
                stage_status[stage] = status
                if status == "budget":
                    break
            elif stage == "ru":
                status = run_ru(battery, run_dir, router_lazy,
                                router_factory, deadline,
                                profile_gate=args.gate)
                stage_status[stage] = status
                if status == "budget":
                    break
            elif stage == "narrate":
                status = run_narrate(battery, run_dir)
                stage_status[stage] = status
            elif stage == "det":
                # v6.0: the det h-half rides the opt-in flag (the
                # default battery carries no h measurements)
                run_det.want_h = "h" in args._stages_set
                try:
                    run_det(battery, run_dir, main_server, main_factory,
                            router_lazy, router_factory)
                    stage_status[stage] = "done"
                except RouterDown as exc:
                    stage_status[stage] = (
                        "partial (the router died: "
                        + str(exc)[:300] + ")")
            elif stage == "package":
                _run_package(run_dir, battery, gate, args)
                stage_status[stage] = "done"
        if not any(v.startswith("budget") for v in stage_status.values()):
            if "package" not in stage_status:
                _run_package(run_dir, battery, gate, args)
                stage_status["package"] = "done"
    except BaseException:
        # the always-a-zip law (iter-353): a crashed run still sends
        # its evidence home
        crashed = True
        raise
    finally:
        def _write_summary() -> None:
            summary = {
                "gate": gate,
                "stages": stage_status,
                "finished": all(
                    not v.startswith("budget")
                    for v in stage_status.values()),
                "time": datetime.now(timezone.utc).isoformat(),
            }
            (run_dir / "summary.json").write_text(
                json.dumps(summary, indent=2, sort_keys=True,
                           default=str),
                encoding="utf-8")

        # THE RUN-END BAND VERDICT (v6.0, KI#119): re-observe every
        # server log, say the verdict LOUD, rewrite cuda_gate.json —
        # the m5 {} gap closed: the bands are DERIVED from the logs,
        # the negative verdict recorded, never silence again.
        try:
            DEVICE_GATE.finalize({
                "router": Path("m6_llama_router.log"),
                "main": Path("m6_llama_main.log"),
            })
            (run_dir / "cuda_gate.json").write_text(
                json.dumps(DEVICE_GATE.doc(), indent=2, sort_keys=True),
                encoding="utf-8")
        except Exception as exc:  # noqa: BLE001
            print(f"[band] the final verdict failed: {exc}", flush=True)
        _write_summary()
        if crashed and "package" not in stage_status:
            try:
                _run_package(run_dir, battery, gate, args)
                stage_status["package"] = "done (diagnostic — after a crash)"
                _write_summary()
                print("[package] the diagnostic zip above carries the "
                      "run's evidence (the crash's server logs inside)",
                      flush=True)
            except Exception as exc:  # noqa: BLE001
                print(f"[package] the diagnostic packaging failed: {exc}",
                      flush=True)
        if main_server is not None:
            main_server.stop()
        if router_lazy is not None:
            router_lazy.stop()
    print(json.dumps(stage_status, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
