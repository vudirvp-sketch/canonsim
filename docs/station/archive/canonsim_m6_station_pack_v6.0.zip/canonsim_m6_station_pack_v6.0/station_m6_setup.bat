@echo off
rem ============================================================
rem  CANONSIM M6 SETUP — the pinned engine install (the m4
rem  iter-357 tool verbatim, renamed). If the m4 pack's
rem  llama.cpp/ folder sits BESIDE this pack, the probe finds it
rem  (no re-download needed) — this script stays the fallback.
rem   Downloads the OFFICIAL llama.cpp b11541 build for YOUR band:
rem     Windows + CUDA (the 3080 Ti form): win-cuda-12.4-x64
rem     + the official CUDA-runtime companion DLLs
rem   Idempotent (sha256 skip); a local archive beside the script
rem   wins (offline path). Installs into THIS pack's llama.cpp/.
rem   --swap : ALSO install into canonsim\workbench\runtime\llama.cpp
rem            (backs the current folder up whole; --restore undoes)
rem   Verifies the build carries /v1/systemone (the decision surface).
rem ============================================================
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 station_m6_setup.py %*
  goto done
)
where python >nul 2>nul
if %errorlevel%==0 (
  python station_m6_setup.py %*
  goto done
)
echo Python not found: install Python 3.11+ (python.org), re-run.
:done
echo.
echo ================= DONE =================
pause
