@echo off
rem ============================================================
rem  CANONSIM M6 DOCTOR — what ARE my models? (the m4 iter-357
rem tool verbatim, renamed). Reads every *.gguf in
rem canonsim\workbench\runtime\models LOCALLY (no server spawn)
rem and verdicts:
rem   decision:laya/kev/...  the classifier class (the R arm)
rem   causal-lm             a generative model (the G + H arms)
rem   broken                a placeholder / a stale conversion
rem Also verdicts the ENGINE (the pack's + the repo's llama.cpp)
rem and diagnoses workbench\runtime\llama.cpp (a repo clone is
rem NOT a build — the fix is --swap).
rem Optional fetches (pinned, hash-verified):
rem   --fetch-laya   Laya-Q8_0 (450 MB, EN decision model)
rem   --fetch-kev    Kev-4B-Q8_0 (4.5 GB — fixes the broken copy)
rem   --fetch-qwen   Qwen3-0.6B (484 MB, the G/H ultra-light)
rem ============================================================
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 station_m6_doctor.py %*
  goto done
)
where python >nul 2>nul
if %errorlevel%==0 (
  python station_m6_doctor.py %*
  goto done
)
echo Python not found: install Python 3.11+ (python.org), re-run.
:done
echo.
echo ================= DONE =================
pause
