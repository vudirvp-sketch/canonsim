#!/usr/bin/env python3
"""The hroom pack's unit checks (v2.1, the PURE halves; the engine
tests ride the battery itself — the live corpus run is the teeth).
Run from the hroom pack dir (the m6 v6.2 pack beside it, the repo in
the find_repo ladder):
    py -3 hroom_units.py

v2.0 laws (the owner's «вообще всё, что может потребовать
тестирования» for the station run):
  - the tail classifier: the four verdicts (LOOP / BLEED / BURN /
    LEGIT) + the precedence LOOP > BLEED > BURN + BOTH LOOP
    detectors (the trailing word n-gram, the vocabulary collapse);
  - the loop signature's edge shapes (a short text, no repetition);
  - the derived-416-view arithmetic: the arm ledger over a
    synthetic arm jsonl (the natural distribution, the over-416
    count, the hit classification, the walls);
  - the headroom verdict's three branches;
  - THE BAND LINE (the KI#122 lesson carried onto the hroom line):
    the four shapes — the CUDA markers (the owner's real v6.2
    window), the honest-cpu device_info block, the pre-v6.2
    window-less log (NOT derivable, never 'cpu' out of silence),
    and the attach form (no server log);
  - the det ledger read (the v2.0 datum's report shape);
  - the --help render (the KI#121 lesson carried onto this parser
    too: a bare % in a help string crashes argparse — none here).

v2.1 laws (the owner's H8 AESTHETIC VERDICT over the iter-389 run —
the three rejected meta-tail shapes reproduced as the pack's own
tests, plus the two halves of the fix):
  - THE TAIL-BREAK on the s2 shape (the HYBRID REPLY FORM
    re-emission + the second verdict-JSON): cut at the form, the
    clean prose kept, the whole leak verbatim in cut_text;
  - the s8 shape (the CHECKLIST header + the 'JSON Verdict:' body):
    cut by the same form marker;
  - the s10 shape (the '---' fence + the Self-Correction note): the
    fence goes out WITH the leak, the prose before it stays;
  - THE NO-BLIND-CUT LAW: a bare '---' with no marker after it is
    never touched (the exact blind cut the owner's verdict refused);
  - a clean tail and a double-leak text (the EARLIEST marker bounds
    the cut) + the _hybrid_clean form (the det datum's surface);
  - THE H SYSTEM PROMPT: the call form (the system role opens, the
    document rides the user message — same bytes every call) and
    the content law (the role, the shape, the STOP, the bans).
"""
from __future__ import annotations

import json
import subprocess
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import station_hroom as H  # noqa: E402

# the m6 probe (the machinery owner) — the same import law the runner
# itself uses; the v6.2 pack beside is the required base (-lv 4)
M6, _M6_DIR = H._import_m6(None)

_FAILED: list[str] = []


def _run(test) -> None:
    name = test.__name__
    try:
        test()
        print(f"ok: {name}", flush=True)
    except AssertionError as exc:
        _FAILED.append(f"{name}: {exc}")
        print(f"FAIL {name}: {exc}", flush=True)
    except Exception as exc:  # noqa: BLE001
        _FAILED.append(f"{name}: {type(exc).__name__}: {exc}")
        print(f"ERROR {name}: {type(exc).__name__}: {exc}", flush=True)


# -- the tail classifier ----------------------------------------------------


def test_classifier_verdicts() -> None:
    """The four disjoint verdicts at their own detectors."""
    # LOOP by the trailing word n-gram (k=1, r=5)
    rec = {"prose_full": "The night stretches long and cold. "
                         "again again again again again",
           "parse_ctok": 832, "head_chars": 60,
           "prose_len": 57, "json_bleed": False,
           "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["verdict"] == "LOOP", c
    assert c["loop_r"] >= 3, c
    # LOOP by the vocabulary collapse alone (no trailing n-gram:
    # the text ends mid-phrase, the ratio still collapsed)
    words = []
    for i in range(60):
        words += ["the", "man", "the", "saw", "the"]
    words += ["and", "then", "the"]
    rec = {"prose_full": " ".join(words), "parse_ctok": 832,
           "head_chars": 60, "prose_len": len(" ".join(words)),
           "json_bleed": False, "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["verdict"] == "LOOP", c
    assert c["vocab_ratio"] < H._LOOP_VOCAB, c
    # BLEED by the json_bleed flag (clean vocab, no loop)
    rec = {"prose_full": "He looks around the hall and finds a "
                         "quiet corner near the hearth to watch "
                         "the door while the evening crowd settles.",
           "parse_ctok": 120, "head_chars": 60,
           "prose_len": 130, "json_bleed": True,
           "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["verdict"] == "BLEED", c
    # BURN by the head burn (no blank line ever came)
    rec = {"prose_full": "", "parse_ctok": 832, "head_chars": 832 * 4,
           "prose_len": 0, "json_bleed": False,
           "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["verdict"] == "BURN", c
    # BURN by the tail chars/token (sub-word burn, the vocabulary
    # NOT collapsed — every word distinct, the tail still degenerate)
    burn_words = [f"w{i:03d}" for i in range(200)]
    rec = {"prose_full": " ".join(burn_words), "parse_ctok": 832,
           "head_chars": 76, "prose_len": len(" ".join(burn_words)),
           "json_bleed": False, "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["verdict"] == "BURN", c
    assert c["chars_per_tok"] < H._BURN_CPT, c
    # LEGIT: a clean long tail at prose-speed chars/token (the
    # vocabulary rich, no trailing loop)
    legit = ("The keeper sweeps the hearth while guests trade quiet "
             "words about roads, rain, bread, copper, lantern oil, "
             "wool, winter, ferrymen, orchards, salt, candles, boots, "
             "timber, harbor dues, old maps, young horses, cold "
             "mornings, long letters, small mercies, honest weights.")
    rec = {"prose_full": legit, "parse_ctok": 100,
           "head_chars": 76, "prose_len": len(legit),
           "json_bleed": False, "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["verdict"] == "LEGIT", c
    assert c["chars_per_tok"] > H._BURN_CPT, c
    print("  the four verdicts at their own detectors")


def test_classifier_precedence() -> None:
    """LOOP > BLEED > BURN: a looping tail that also bleeds is a
    LOOP; a BLEED-flagged clean-vocab tail that also burns its
    budget is a BLEED (the flag precedes the cpt line)."""
    rec = {"prose_full": "{\"kind\": \"no_intent\"} "
                         "again again again again again",
           "parse_ctok": 832, "head_chars": 60,
           "prose_len": 80, "json_bleed": True,
           "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["verdict"] == "LOOP", c
    # BLEED over BURN: the flags fire before the cpt line, so a
    # bleeding tail with a degenerate cpt still reads BLEED (the
    # precedence's own law, not an accident)
    words = [f"q{i:02d}" for i in range(120)]
    rec = {"prose_full": " ".join(words), "parse_ctok": 832,
           "head_chars": 76, "prose_len": len(" ".join(words)),
           "json_bleed": True, "protocol_echo": False}
    c = H._classify_tail(rec)
    assert c["chars_per_tok"] < H._BURN_CPT, c
    assert c["verdict"] == "BLEED", c
    print("  LOOP > BLEED > BURN held")


def test_loop_signature_edges() -> None:
    """A text under 6 words and a text without repetition carry no
    signature; a clean k=1 and k=3 trailing loop both fire."""
    assert H._loop_signature("a b c") == ("", 0)
    assert H._loop_signature("one two three four five six") == ("", 0)
    phrase, r = H._loop_signature("x y z end end end end")
    assert phrase == "end" and r >= 3, (phrase, r)
    text = "the fire spreads " * 3
    phrase, r = H._loop_signature(text.rstrip())
    assert phrase == "the fire spreads" and r >= 3, (phrase, r)
    print("  the signature edges held")


def test_vocab_ratio() -> None:
    assert H._vocab_ratio("") == 1.0
    assert H._vocab_ratio("a b c d") == 1.0
    assert H._vocab_ratio("the the the the") == 0.25
    print("  the vocab ratio held")


# -- the derived-view arithmetic --------------------------------------------


def test_arm_ledger() -> None:
    """The ledger over a synthetic arm jsonl: the natural-ctok
    distribution, the DERIVED over-416 count, the hit classes, the
    walls."""
    lines = [
        {"finish_reason": "stop", "parse_ctok": 66, "wall_s": 9.0,
         "cycle": 1, "say": "a"},
        {"finish_reason": "stop", "parse_ctok": 460, "wall_s": 30.0,
         "cycle": 2, "say": "b"},
        {"finish_reason": "length", "parse_ctok": 832,
         "wall_s": 76.0, "cycle": 3, "say": "c",
         "prose_full": "again " * 8,
         "prose_len": 48, "head_chars": 60},
    ]
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "arm_h0.jsonl"
        out.write_text(json.dumps(
            {"event": "end", "unit": "u1", "cycles": lines}) + "\n",
            encoding="utf-8")
        led = H._arm_ledger(Path(td), "h0", 416)
        assert led["n_lines"] == 3, led
        assert led["natural_stops"] == 2, led
        assert led["cap_hits"] == 1, led
        assert led["natural_ctok"]["min"] == 66, led
        assert led["natural_ctok"]["max"] == 460, led
        # THE DERIVED 416 VIEW: the natural 460 stop is the one line
        # the production cap would truncate
        assert led["prod_view_over"] == 1, led
        assert led["prod_view_over_lines"][0]["ctok"] == 460, led
        assert led["hit_classes"]["LOOP"] == 1, led
        assert led["walls"]["max_s"] == 76.0, led
        assert led["walls"]["hit_med_s"] == 76.0, led
    print("  the ledger arithmetic held (the derived 416 view exact)")


def test_verdict_branches() -> None:
    """The headroom verdict's three readings: the degenerate-only
    band (the cap NOT the missing headroom), the legit-exceeds band
    (the minimal all-natural cap), the wide-margin band."""
    deg = {
        "prod_view_over": 0, "cap_hits": 8, "natural_stops": 34,
        "natural_ctok": {"max": 138},
        "hit_classes": {"LOOP": 5, "BLEED": 0, "BURN": 3, "LEGIT": 0},
    }
    text = H._verdict_text([deg], 832, 416, "m", "cpu")
    assert "NOT the missing headroom" in text, text
    legit = {
        "prod_view_over": 2, "cap_hits": 3, "natural_stops": 40,
        "natural_ctok": {"max": 520},
        "hit_classes": {"LOOP": 0, "BLEED": 0, "BURN": 0, "LEGIT": 3},
    }
    text = H._verdict_text([legit], 832, 416, "m", "cuda")
    assert "exceeds 416" in text and "572" in text, text
    quiet = {
        "prod_view_over": 0, "cap_hits": 0, "natural_stops": 42,
        "natural_ctok": {"max": 90},
        "hit_classes": {"LOOP": 0, "BLEED": 0, "BURN": 0, "LEGIT": 0},
    }
    text = H._verdict_text([quiet], 832, 416, "m", "cuda")
    assert "wide margin" in text, text
    print("  the three verdict branches held")


def test_det_ledger() -> None:
    """The v2.0 det datum's report read."""
    with tempfile.TemporaryDirectory() as td:
        out = Path(td) / "det.jsonl"
        out.write_text(json.dumps({
            "event": "end", "unit": "h0", "temp": 0.0,
            "identical": False, "digest1": "aaaa", "digest2": "bbbb",
            "ctok1": 416, "ctok2": 416, "finish1": "length",
            "finish2": "length"}) + "\n", encoding="utf-8")
        rows = H._det_ledger(Path(td))
        assert len(rows) == 1 and rows[0]["unit"] == "h0", rows
        assert rows[0]["identical"] is False, rows
    print("  the det ledger read held")


# -- the band line (the KI#122 lesson on the hroom line) --------------------


def test_band_line() -> None:
    """THE v2.0 BAND LINE: derived from the -lv 4 window markers in
    hroom's own server log — the four shapes, NEVER the v1.0
    cuda_visible guess. The window-less log reads NOT derivable,
    never 'cpu' out of silence (the m6 lesson, KI#122)."""
    with tempfile.TemporaryDirectory() as td:
        root = Path(td)
        # the pre-v6.2 shape: no window, no markers — NOT derivable
        old_log = root / "old.log"
        old_log.write_text(
            "I srv llama_server: initializing ...\n"
            "I cmn init: llama threadpool init, n_threads = 8\n"
            "I srv llama_server: model loaded\n", encoding="utf-8")
        band, _mark = H._band_line(M6, old_log)
        assert band.startswith("cpu (no device_info"), band
        # the honest CPU machine: the window printed, no CUDA device
        cpu_log = root / "cpu.log"
        cpu_log.write_text(
            "I load_backend: loaded CPU backend from "
            "/llama.cpp/libggml-cpu-sapphirerapids.so\n"
            "I cmn common_param: device_info:\n"
            "I cmn common_param:   - CPU     : Intel(R) Xeon(R) "
            "Processor (4159 MiB, 4159 MiB free)\n"
            "I srv llama_server: model loaded\n", encoding="utf-8")
        band, _mark = H._band_line(M6, cpu_log)
        assert band == "cpu (device_info carries no CUDA device)", band
        # THE LIVE-CAUGHT FALSE POSITIVE: 'offloaded...to GPU' prints
        # on a PURE-CPU machine (CPU_Mapped buffers) — never a marker
        faux_log = root / "faux.log"
        faux_log.write_text(
            "I load_backend: loaded CPU backend from "
            "/llama.cpp/libggml-cpu-sapphirerapids.so\n"
            "I cmn common_param: device_info:\n"
            "I cmn common_param:   - CPU     : Intel(R) Xeon(R) "
            "Processor (4159 MiB, 4159 MiB free)\n"
            "I load_tensors: offloaded 29/29 layers to GPU\n"
            "I load_tensors:   CPU_Mapped model buffer size = "
            "332.71 MiB\n", encoding="utf-8")
        band, _mark = H._band_line(M6, faux_log)
        assert band == "cpu (device_info carries no CUDA device)", band
        # the CUDA machine: the owner's real v6.2 window shape
        cuda_log = root / "cuda.log"
        cuda_log.write_text(
            "I ggml_cuda_init: found 1 CUDA devices (Total VRAM: "
            "12287 MiB):\n"
            "I   Device 0: NVIDIA GeForce RTX 3080 Ti, compute "
            "capability 8.6, VMM: yes, VRAM: 12287 MiB\n"
            "I load_backend: loaded CUDA backend from "
            "C:\\llama.cpp\\ggml-cuda.dll\n"
            "I load_backend: loaded CPU backend from "
            "C:\\llama.cpp\\ggml-cpu-haswell.dll\n",
            encoding="utf-8")
        band, mark = H._band_line(M6, cuda_log)
        assert band == "cuda", band
        assert mark and "CUDA" in mark, mark
        # the attach form: no server log — honest, never a guess
        band, mark = H._band_line(M6, None)
        assert band.startswith("not derivable"), band
        # the unreadable log — honest too
        band, _mark = H._band_line(M6, root / "missing.log")
        assert band.startswith("not derivable"), band
    print("  the band line held on all four shapes (never the "
          "cuda_visible guess)")


# -- the parser render (the KI#121 lesson on this parser) -------------------


def test_help_renders() -> None:
    """--help renders (a bare % in a help string crashes argparse
    through help_string % params — KI#121; none may ride here)."""
    proc = subprocess.run(
        [sys.executable, str(Path(__file__).parent / "station_hroom.py"),
         "--help"], capture_output=True, text=True, timeout=60)
    assert proc.returncode == 0, proc.stderr[-400:]
    assert "station_hroom.py" in (proc.stdout or ""), proc.stdout[:200]
    assert "sweep cap" in (proc.stdout or ""), proc.stdout[:400]
    print("  --help rendered clean")


def test_knobs() -> None:
    """The instrument's own knobs: the sweep cap 2x the production
    cap (the v1.0 law), the burn/vocab lines at their recorded
    values."""
    assert H.HRM_CAP == 832, H.HRM_CAP
    assert H.PROD_CAP == 416, H.PROD_CAP
    assert H._BURN_CPT == 2.2 and H._LOOP_VOCAB == 0.35
    assert H._HEAD_CPT == 3.8
    print("  the knobs held (832 = 2x416, the recorded lines)")


# -- the v2.1 halves: the tail-break + the H system prompt ----------------


def test_tail_break_s2() -> None:
    """THE s2 SHAPE (the iter-389 leak, reproduced): after the clean
    prose the model re-emits '## HYBRID REPLY FORM' + a second
    verdict-JSON. The cut bounds at the form; the clean prose and
    its head stay; the whole leak rides cut_text verbatim."""
    prose = ("The keeper's rag slows on the hearthstone. \"Ale,\" he "
             "says, not looking up. The mug you take is cool, the "
             "bench by the door still warm from the afternoon crowd.")
    leak = ("\n\n## HYBRID REPLY FORM\n"
            "First the JSON verdict exactly as the protocol above "
            "specifies.\n"
            "{\"intent\": {\"kind\": \"take\", "
            "\"target\": \"ale_mug_01\"}}")
    tb = H._tail_break(prose + leak)
    assert tb["cut"] is True, tb
    assert tb["marker"] == "## HYBRID REPLY FORM", tb
    assert tb["clean"] == prose, tb
    assert tb["cut_text"] == leak, tb
    assert "## " not in tb["clean"] and "{" not in tb["clean"], tb
    print("  the s2 shape cut at the re-emitted form (the prose kept)")


def test_tail_break_s8() -> None:
    """THE s8 SHAPE: the CHECKLIST — '## HYBRID REPLY FORM CHECKLIST'
    with the 'JSON Verdict:' body. The same form marker bounds it."""
    prose = ("You finally allow the tension to bleed out of your "
             "shoulders, sinking into a worn wooden chair near the "
             "hearth. The room keeps its own quiet.")
    leak = ("\n\n## HYBRID REPLY FORM CHECKLIST\n"
            "JSON Verdict: Present and correct.\n"
            "Prose: Two to four sentences, narrator's voice.\n"
            "Blank lines: one before the prose, one after.")
    tb = H._tail_break(prose + leak)
    assert tb["cut"] is True, tb
    assert tb["marker"] == "## HYBRID REPLY FORM", tb
    assert tb["clean"] == prose, tb
    assert "CHECKLIST" not in tb["clean"], tb
    print("  the s8 shape cut at the checklist header")


def test_tail_break_s10() -> None:
    """THE s10 SHAPE: the '---' fence + the Self-Correction note. The
    fence goes out WITH the leak (it is the leak's own fence, never
    the prose); the prose before it stays whole."""
    prose = ("The withdrawal settles over the room like dust. The "
             "keeper says nothing; the fire says less. Your hands "
             "find the table's edge and stay there.")
    leak = ("\n\n---\n\n*(Self-Correction/Refinement Note: the "
            "original draft named a guard; removed — the JSON "
            "carries no such fact.)*")
    tb = H._tail_break(prose + leak)
    assert tb["cut"] is True, tb
    assert tb["marker"] == "*(Self-Correction", tb
    assert tb["clean"] == prose, tb
    assert tb["cut_text"] == leak, tb
    assert "---" not in tb["clean"], tb
    # the _hybrid_clean form (the det datum's surface): the head is
    # never touched, the prose half carries the same cut
    head = '{"intent": {"kind": "rest"}}'
    content = head + "\n\n" + prose + leak
    clean, tb2 = H._hybrid_clean(content)
    assert clean == head + "\n\n" + prose, clean
    assert tb2["cut"] is True, tb2
    assert tb2["marker"] == "*(Self-Correction", tb2
    print("  the s10 shape cut with its fence (the prose kept)")


def test_tail_break_no_blind() -> None:
    """THE NO-BLIND-CUT LAW (the owner's verdict verbatim): a bare
    '---' with NO marker after it is never touched — the bound is
    the recognized marker, never the separator alone."""
    prose = ("The stairs complain under your boots. At the landing "
             "you stop, listen, and go on.\n\n---")
    tb = H._tail_break(prose)
    assert tb["cut"] is False, tb
    assert tb["clean"] == prose, tb
    assert tb["marker"] is None and tb["cut_text"] == "", tb
    # a clean tail carries no cut either
    clean_prose = "Two sentences of ordinary narration. Nothing else."
    tb = H._tail_break(clean_prose)
    assert tb["cut"] is False and tb["clean"] == clean_prose, tb
    print("  the no-blind-cut law held (a bare '---' never cuts)")


def test_tail_break_earliest() -> None:
    """A double leak: the EARLIEST marker bounds the cut — the later
    leak rides inside cut_text untouched."""
    prose = "The door gives. The hall beyond is darker than the hour."
    leak = ("\n\n---\n\n*(Self-Correction/Refinement Note: first "
            "leak.)*\n\n## HYBRID REPLY FORM\nsecond leak")
    tb = H._tail_break(prose + leak)
    assert tb["cut"] is True, tb
    assert tb["marker"] == "*(Self-Correction", tb
    assert tb["clean"] == prose, tb
    assert "second leak" in tb["cut_text"], tb
    print("  the earliest marker bounded the double leak")


def test_hybrid_messages_law() -> None:
    """THE v2.1 CALL FORM: the system role opens, the document rides
    the user message — the same bytes on every call (the arms and the
    det datum share one form)."""
    msgs = H._hybrid_messages("DOC")
    assert len(msgs) == 2, msgs
    assert msgs[0]["role"] == "system", msgs
    assert msgs[0]["content"] == H.HYBRID_SYSTEM_PROMPT, msgs
    assert msgs[1] == {"role": "user", "content": "DOC"}, msgs
    assert H._hybrid_messages("DOC") == msgs   # pure: same bytes
    print("  the v2.1 call form held (the system role opens)")


def test_system_prompt_law() -> None:
    """THE H SYSTEM PROMPT's content law: the role, the shape, the
    STOP, the bans — and no JSON of its own."""
    p = H.HYBRID_SYSTEM_PROMPT
    assert 400 < len(p) < 2000, len(p)
    for needle in (
            "narrator",            # the role
            "JSON verdict",          # the shape (the protocol's own words)
            "one blank line",        # the split
            "two to four sentences",  # the prose law (the protocol's own words)
            "STOP",                 # the stop law
            "no second verdict",     # the s2 ban
            "no restatement of the reply form",  # the s2/s8 ban
            "no checklist",           # the s8 ban
            "no self-correction",     # the s10 ban
            "no separator",          # the s10 fence ban
    ):
        assert needle in p, needle
    assert "{" not in p, "the system prompt is prose, not JSON"
    print("  the system prompt's content law held (role/shape/STOP/bans)")


def main() -> int:
    print(f"[hroom_units] pack v2.1 · m6 probe: {_M6_DIR}", flush=True)
    for test in (
        test_classifier_verdicts,
        test_classifier_precedence,
        test_loop_signature_edges,
        test_vocab_ratio,
        test_arm_ledger,
        test_verdict_branches,
        test_det_ledger,
        test_band_line,
        test_help_renders,
        test_knobs,
        test_tail_break_s2,
        test_tail_break_s8,
        test_tail_break_s10,
        test_tail_break_no_blind,
        test_tail_break_earliest,
        test_hybrid_messages_law,
        test_system_prompt_law,
    ):
        _run(test)
    if _FAILED:
        print(f"\n{_FAILED.__len__()} FAILED", flush=True)
        return 1
    print("\nall hroom unit laws green (17/17)", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
