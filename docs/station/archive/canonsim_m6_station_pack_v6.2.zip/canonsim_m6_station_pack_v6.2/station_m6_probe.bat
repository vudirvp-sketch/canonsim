@echo off
rem ============================================================
rem  CANONSIM M6 PROBE (iter-373, v6.2) — TWO FIXES ON THE OWNER'S
rem  EVIDENCE: KI#121 (--help no longer crashes on the literal % in
rem  the --gate help; 58.8%% renders as 58.8%) + KI#122 (THE BAND
rem  INSTRUMENT'S FALSE NEGATIVE CLOSED: -lv 4 rides every spawn so
rem  the log carries load_backend + device_info; the verdict reads
rem  those markers — the m6 run rode the CUDA band by physics while
rem  the v6.1 instrument said 'cpu'). The v6.1 core rides beneath
rem  (iter-371, KI#120 CLOSED) over the v6.0 PROMOTION PACK (R AT
rem  THE DOOR, your "promotion R" permission, D-250 M3 executed):
rem    REFERENCE  the gold trajectory now COMMITS — the say-cycles
rem        honor the door's contract (emit_call -^> apply_reply,
rem        the parser test's own form); the drift column reads
rem        gold-path divergence (the m4/m5 numbers keep their
rem        narrowed pristine-premise reading — both documented).
rem    R   THE PRODUCTION FORM — the systemone router at the --gate
rem        profile (0.5 default / 0.4 the recall override), the
rem        false-allow census the STANDING WATCH on every row.
rem    NARRATE  the L12 template rung — the prose as a SEPARATE
rem        surface: every R unit's log through the repo's chronicle
rem        renderer, each tale rendered twice (the determinism
rem        digest), the gold units beside (now WITH the fire chain).
rem    THE BAND INSTRUMENT (KI#119): the run says its band verdict
rem    LOUD at the end — derived from the server logs. Your m5 run
rem    was the CPU band by its own logs (zero CUDA lines) — re-run
rem    station_m6_setup.bat first if you want the GPU band.
rem    H  OPT-IN ONLY (--stages h): the hybrid halves, NOT promoted
rem       (D-250; the aesthetic call open).
rem  Prerequisites: the engine (station_m6_setup.bat once — or the
rem  sibling pack's llama.cpp/ found beside this pack, no re-download)
rem  + a decision model + a generative model (the doctor verdicts).
rem  Prompts (TTY): the router model, then the main model.
rem  Arguments pass through, e.g.:  station_m6_probe.bat --smoke
rem ============================================================
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 station_m6_probe.py %*
  goto done
)
where python >nul 2>nul
if %errorlevel%==0 (
  python station_m6_probe.py %*
  goto done
)
echo Python not found: install Python 3.11+ (python.org), re-run.
:done
echo.
echo ================= DONE =================
echo The zip to send back is printed by [package] above (m6_*.zip).
echo (A crashed run still leaves its diagnostic m6_*.zip — with the
echo  server logs inside — check the folder if no [package] line.)
pause
