#!/usr/bin/env python3
"""The m5 pack's unit checks (the pure halves; the engine tests ride
the battery itself). Run from the m5 pack dir:
    py -3 m5_units.py"""
from __future__ import annotations

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
import station_m5_probe as P  # noqa: E402

# the repo ladder (the probe's own law — --repo/CANONSIM_REPO/beside/
# above/home), never a hardcoded layout
REPO, _tried, found = P.find_repo(None)
assert found, "the canonsim repo was not found (unpack beside it, or " \
    "set CANONSIM_REPO)"
sys.path.insert(0, str(REPO))

from brief.gbnf import gbnf_grammar, grammar_fingerprint  # noqa: E402
from brief.ledger import SceneLedger  # noqa: E402
from brief.parser import grammar_snapshot  # noqa: E402
from core.log import read_log  # noqa: E402
from core.pack import load_pack  # noqa: E402

PACK = load_pack(REPO / "content" / "tavern_pack")
SCHEMA = json.loads((REPO / "schemas" / "event.schema.json").read_text())


def _boot(seed: int = 125, setup=()):
    import tempfile

    from core.loop import Simulator

    td = tempfile.TemporaryDirectory()
    log = Path(td.name) / "run.jsonl"
    sim = Simulator(PACK, seed, log, SCHEMA, commit="unit000")
    sim.open()
    if setup:
        sim.run_steps(list(setup))
    return sim, log, td


def test_census() -> None:
    exp = {"intent": {"kind": "take", "fields": {"texture": {
        "entry": "tex_0000", "scope": "scene:loc_tavern",
        "slot": "candles", "value": "lit"}}}}
    good = {"intent": {"kind": "take", "fields": {"texture": {
        "entry": "tex_0000", "scope": "scene:loc_tavern",
        "slot": "candles", "value": "lit"}}}}
    assert P.census_class(good, exp, ["tex_0000"], ["tex_0000"]) == "full"
    no_pin = {"intent": {"kind": "take", "target": "purse_01"}}
    assert P.census_class(no_pin, exp, [], ["tex_0000"]) == "no_pin"
    assert P.census_class(good, exp, [], ["tex_0000"]) == "no_pin"
    assert P.census_class({"intent": {"kind": "look_around"}}, exp, [],
                          []) == "kind"
    exp2 = {"intent": {"kind": "move", "target": "loc_tavern"}}
    tgt = {"intent": {"kind": "move", "target": "loc_road"}}
    assert P.census_class(tgt, exp2, [], []) == "target"
    exp3 = {"intent": {"kind": "wait", "fields": {"ticks": 30}}}
    flds = {"intent": {"kind": "wait", "fields": {"ticks": 5}}}
    assert P.census_class(flds, exp3, [], []) == "fields"
    assert P.census_class({"question": "which?"}, exp, [], []) == \
        "not_intent"
    print("ok: census classifier (the m3 classes verbatim)")


def test_questions_and_assembly() -> None:
    sim, log, td = _boot(setup=[{"intent": "move",
                                 "target": "loc_tavern"}])
    _h, events = read_log(log, SCHEMA)
    snapshot = grammar_snapshot(events, PACK, SceneLedger())
    P._CS = _FakeNS()
    state = P.build_state("I look around", events, PACK, None)
    assert state["message"] == "I look around"
    assert state["scene"]["location"] == "loc_tavern"
    assert isinstance(state["scene"]["present"], list)

    questions = P.build_questions(snapshot, PACK)
    assert set(questions) == {"action", "target", "is_modeled", "risk"}
    assert questions["action"]["type"] == "choice"
    assert set(questions["action"]["criteria"]) == {
        a["intent"] for a in
        PACK.data["actions.json"]["actions"]}
    assert len(questions["action"]["criteria"]) == 16
    assert questions["is_modeled"]["type"] == "noul"
    assert questions["risk"]["type"] == "score"
    # the target criteria are the LIVE nouns (the same closed set the
    # grammar route offers)
    assert set(questions["target"]["criteria"]) == {
        n.id for n in snapshot.nouns}
    assert "npc_guard_01" in questions["target"]["criteria"]

    # the gate-blocked form
    answers = {"action": {"type": "choice", "choice": "talk",
                         "probabilities": {"talk": 0.6}},
               "is_modeled": {"type": "noul", "noul": 0.1},
               "risk": {"type": "score", "score": 0.5}}
    doc, meta = P.assemble_intent(answers, snapshot, PACK)
    assert doc == {"no_intent": mock_no_intent_text()} or \
        "no_intent" in doc
    assert meta["gate"] == "blocked"

    # the routed form: talk -> npc target kind-aware
    answers = {"action": {"type": "choice", "choice": "talk",
                          "probabilities": {"talk": 0.9}},
               "target": {"type": "choice", "choice": "loc_tavern",
                          "probabilities": {"loc_tavern": 0.5,
                                            "npc_guard_01": 0.3}},
               "is_modeled": {"type": "noul", "noul": 0.9},
               "risk": {"type": "score", "score": 1.0}}
    doc, meta = P.assemble_intent(answers, snapshot, PACK)
    assert doc["intent"]["kind"] == "talk"
    # kind-aware: talk requires an npc; the best-scoring NPC wins
    assert doc["intent"]["target"] == "npc_guard_01"
    assert meta["gate"] == "passed"
    assert meta["action_p"] == 0.9

    # the invention check: everything came from the pack's own sets
    assert P.invention_check(doc, snapshot, PACK) == []
    # a fabricated doc WOULD be caught
    bad = {"intent": {"kind": "teleport", "target": "atlantis",
                      "fields": {"magic": 1}}}
    inv = P.invention_check(bad, snapshot, PACK)
    assert any(s.startswith("kind:") for s in inv)
    assert any(s.startswith("target:") for s in inv)
    assert any(s.startswith("field:") for s in inv)

    # the wait fields policy
    answers = {"action": {"type": "choice", "choice": "wait",
                          "probabilities": {"wait": 1.0}},
               "is_modeled": {"type": "noul", "noul": 0.9},
               "risk": {"type": "score", "score": 0.0}}
    doc, meta = P.assemble_intent(answers, snapshot, PACK)
    assert doc["intent"]["fields"] == {"ticks": 30}

    # the take-texture dual form: the texture rides the FIELD, the
    # target stays ABSENT (the corpus's own shape; the census's full
    # class requires the targetless form). A live texture entry first
    # (the mediator's narrator form, the corpus's own delta shape).
    from cli.mediator import Mediator

    mediator = Mediator(sim, PACK, SCHEMA, log,
                        Path(td.name) / "mediator")
    mediator.emit_call()
    nreply = Path(td.name) / "narrator_0.json"
    nreply.write_text(json.dumps({
        "prose": "Tallow candles guttered on the bar.",
        "texture_delta": {
            "source": "turn:1",
            "established": [{
                "scope": "scene:loc_tavern", "slot": "candles",
                "value": "lit",
                "surface": "Tallow candles guttered on the bar."}],
        }}), encoding="utf-8")
    beat = mediator.apply_reply(nreply)
    assert beat.status == "accepted", beat.status
    _h, events = read_log(log, SCHEMA)
    snapshot = grammar_snapshot(events, PACK, mediator.ledger)
    tex = next(n for n in snapshot.nouns if n.kind == "texture")
    answers = {"action": {"type": "choice", "choice": "take",
                          "probabilities": {"take": 1.0}},
               "target": {"type": "choice", "choice": tex.id,
                          "probabilities": {tex.id: 0.9}},
               "is_modeled": {"type": "noul", "noul": 0.9},
               "risk": {"type": "score", "score": 1.0}}
    doc, meta = P.assemble_intent(answers, snapshot, PACK)
    assert doc["intent"]["kind"] == "take"
    assert "target" not in doc["intent"], doc
    assert doc["intent"]["fields"]["texture"]["entry"] == tex.id
    assert doc["intent"]["fields"]["texture"]["slot"] == "candles"
    assert P.invention_check(doc, snapshot, PACK) == []
    sim.close()
    td.cleanup()
    print("ok: questions, assembly, kind-aware target, inventions")


def mock_no_intent_text() -> str:
    return P.assemble_intent(
        {"action": {"type": "choice", "choice": "talk",
                    "probabilities": {"talk": 1.0}},
         "is_modeled": {"type": "noul", "noul": 0.0}},
        grammar_snapshot(
            *read_log_stub(), SceneLedger()), PACK)[0].get(
        "no_intent", "")


def read_log_stub():
    sim, log, td = _boot()
    _h, events = read_log(log, SCHEMA)
    sim.close()
    td.cleanup()
    return events, PACK


class _FakeNS:
    """build_state's namespace stand-in (the real one rides main()).
    staticmethod: plain functions, never bound methods."""

    from core.fold import fold as _fold, initial_projection as _ip  # noqa: E402

    @staticmethod
    def fold(events, initial):
        return _FakeNS._fold(events, initial)

    @staticmethod
    def initial_projection(entities):
        return _FakeNS._ip(entities)


def test_ru_rows_shape() -> None:
    assert len(P.RU_ROWS) >= 10
    for row in P.RU_ROWS:
        assert isinstance(row["say"], str) and row["say"]
        assert isinstance(row["gold"], dict)
        assert set(row["gold"]) <= {"intent", "no_intent", "question"}
    # the families coverage: talk, steal, look, wait, move, take,
    # atmosphere(no_intent), question, rest
    kinds = {r["gold"]["intent"]["kind"] for r in P.RU_ROWS
             if "intent" in r["gold"]}
    assert {"talk", "steal", "look_around", "wait", "move", "take",
            "rest"} <= kinds
    assert any("no_intent" in r["gold"] for r in P.RU_ROWS)
    assert any("question" in r["gold"] for r in P.RU_ROWS)
    print("ok: the RU band shape")


def test_batch_law() -> None:
    """THE BATCH LAW (iter-358): every spawn carries an explicit -b
    (the stock 512 died on the tavern set's 741-token systemone
    payload); the router's ubatch RIDES its batch (the embeddings
    tie), the main passes its own 512; an operator's own -b is never
    duplicated."""
    exe = Path("llama-server.exe")
    model = Path("Kev-4B-Q8_0.gguf")
    # the router form: -b and -ub ride together
    srv = P.SpawnedServer(exe, model, ctx=4096, batch=2048)
    argv = srv.argv()
    assert argv[argv.index("-b") + 1] == "2048"
    assert argv[argv.index("-ub") + 1] == "2048"
    # the main form: its own physical ubatch
    srv = P.SpawnedServer(exe, model, ctx=4096, batch=2048,
                          ubatch=P.SPAWN_UBATCH)
    argv = srv.argv()
    assert argv[argv.index("-ub") + 1] == "512"
    # the operator's own -b wins — never a duplicate
    srv = P.SpawnedServer(exe, model, ctx=4096, extra=["-b", "1024"],
                          batch=2048, ubatch=P.SPAWN_UBATCH)
    argv = srv.argv()
    assert argv.count("-b") == 1
    assert argv[argv.index("-b") + 1] == "1024"
    # every operator spelling is detected
    assert P._flag_present(["--batch-size=256"], "-b", "--batch-size")
    assert P._flag_present(["-b256"], "-b", "--batch-size")
    assert P._flag_present(["--ubatch-size", "64"], "-ub",
                           "--ubatch-size")
    assert P._flag_present(["-ngl", "30"], "-ngl", "--n-gpu-layers")
    assert not P._flag_present(["-c", "4096", "-np", "1"],
                              "-b", "--batch-size")
    # the stock 512 cannot host the observed payload; the default
    # clears it with headroom
    assert P.DEFAULT_SPAWN_BATCH > 741
    print("ok: the batch law argv (-b/-ub, the operator override)")


def test_batch_escalation() -> None:
    """THE 400-CLASS ESCALATION (iter-358): the iter-357 crash shape
    (741 tokens named against the stock 512) must produce a strictly
    bigger batch that COVERS the need; the ctx rides at the next
    power of two when the batch passes it; the cap holds."""
    eb = P.escalated_router_batch
    nb, nc = eb(512, 4096, 741)
    assert nb >= 741 and nb > 512 and nc >= nb
    assert eb(2048, 4096, None) == (4096, 4096)
    assert eb(4096, 4096, 5000) == (8192, 8192)
    nb, nc = eb(16384, 16384, 30000)
    assert nb <= P.BATCH_CAP and nc <= P.BATCH_CAP
    prev = 256
    for _ in range(6):  # strictly monotone, always
        nb, _nc = eb(prev, 1 << 20, None)
        assert nb > prev
        prev = nb
    print("ok: the 400-class batch escalation")


def test_vram_planner() -> None:
    """THE PLANNED GPU RUNG (iter-358 — the owner's 3080 Ti / 12 GB
    commission): full fit -> 999; the owner's shape (the main
    resident, ~5.1 GiB free against a 4.3 GiB router) -> a partial
    rung; starved -> CPU (0); no nvidia-smi -> None (the engine's own
    default stands)."""
    import tempfile

    td = tempfile.TemporaryDirectory()
    m = Path(td.name) / "Kev-4B-Q8_0.gguf"
    with open(m, "wb") as fh:
        fh.truncate(4_484_000_000)  # ~4276 MiB, sparse — stat reads it
    ngl, note = P.plan_gpu_rung(m, 4096, free_mib=11000)
    assert ngl == 999 and "FULL" in note
    ngl, note = P.plan_gpu_rung(m, 4096, free_mib=5100)
    assert ngl is not None and 0 < ngl < 999 and "RAM" in note
    ngl, note = P.plan_gpu_rung(m, 4096, free_mib=1000)
    assert ngl == 0
    real = P._probe_vram_mib
    P._probe_vram_mib = lambda which: None
    try:
        ngl, note = P.plan_gpu_rung(m, 4096)
        assert ngl is None
    finally:
        P._probe_vram_mib = real
    td.cleanup()
    print("ok: the planned GPU rung (full / partial / starved / blind)")


def test_hybrid_grammar() -> None:
    """THE TERMINATED-PROSE LAW (iter-351 D.1, the m5 core's form):
    the hybrid wrap renames the repo grammar's root to verdict-doc,
    appends the five terminated-prose rules, leaves every OTHER rule
    byte-identical; pure (same snapshot -> same hybrid bytes); the
    fingerprint differs from the base grammar's; a grammar with no
    root rule is a LOUD refusal, never a silent wrap."""
    sim, log, td = _boot(setup=[{"intent": "move",
                                 "target": "loc_tavern"}])
    _h, events = read_log(log, SCHEMA)
    snapshot = grammar_snapshot(events, PACK, SceneLedger())
    base = gbnf_grammar(snapshot)
    hy = P.hybrid_grammar(base)
    lines = hy.splitlines()
    # the wrap appends the five hybrid rules at the END; the renamed
    # verdict-doc rides where the base's root was
    assert lines[0] == \
        'verdict-doc ::= intent-doc | question-doc | no-intent-doc'
    assert 'root ::= verdict-doc "\\n\\n" prose' in lines
    assert 'prose ::= prose-body "\\n\\n"' in lines
    assert 'prose-body ::= prose-line ( "\\n" prose-line )*' in lines
    assert "prose-char ::= [^\\x00-\\x1f\\x7f]" in lines
    # every base rule except root rides byte-identical
    base_rules = [l for l in base.splitlines() if not
                  l.startswith("root ::= ")]
    for rule in base_rules:
        assert rule in lines, rule
    # pure: same snapshot -> same bytes (twice)
    assert P.hybrid_grammar(base) == hy
    # the pin differs from the base grammar's (the hybrid is its own
    # grammar — the m3 H-pin law)
    assert grammar_fingerprint(hy) != grammar_fingerprint(base)
    # the loud refusal on a rootless grammar
    try:
        P.hybrid_grammar('string ::= "x"\n')
        raise AssertionError("a rootless grammar must refuse loudly")
    except ValueError:
        pass
    # THE SPLIT LAW on a well-formed hybrid answer: the first blank
    # line separates the verdict from the prose; the prose carries no
    # empty line and the terminator is consumed
    answer = ('{\"intent\": {\"kind\": \"look_around\"}}\n\n'
              "The taproom holds its breath.\nSmoke curls.\n\n")
    head, _sep, tail = answer.partition("\n\n")
    json.loads(head.strip())
    prose = tail.rstrip("\n")
    assert "\n\n" not in prose and prose
    sim.close()
    td.cleanup()
    print("ok: the hybrid grammar (the terminated-prose law + the split)")


def test_false_allow() -> None:
    """THE FALSE-ALLOW CENSUS (the M2 knob's cost side): the disjoint
    classes against the hand-authored golds — the ru_05 shape (the
    texture gold committed as a different canon target = a wrong
    OBJECT, never a no_pin win), the kind/target mismatches, the
    correct allow, the gravest non-intent class, the honest block."""
    fa = P.false_allow_class
    gold_talk = {"intent": {"kind": "talk", "target": "npc_guard_01"}}
    # correct: kind + object match
    assert fa({"intent": {"kind": "talk",
                          "target": "npc_guard_01"}},
              "passed", gold_talk) == "correct_allow"
    # wrong kind
    assert fa({"intent": {"kind": "steal",
                          "target": "npc_guard_01"}},
              "passed", gold_talk) == "false_allow_kind"
    # wrong object (same kind)
    assert fa({"intent": {"kind": "talk",
                          "target": "npc_drunk_01"}},
              "passed", gold_talk) == "false_allow_object"
    # THE RU_05 SHAPE: the texture gold committed as a canon target
    gold_candle = {"intent": {"kind": "take", "fields": {"texture": {
        "entry": "tex_0000", "scope": "scene:loc_tavern",
        "slot": "candles", "value": "lit"}}}}
    assert fa({"intent": {"kind": "take",
                          "target": "oil_lamp_01"}},
              "passed", gold_candle) == "false_allow_object"
    # the same gold committed as the RIGHT texture slot: correct
    assert fa({"intent": {"kind": "take", "fields": {"texture": {
        "entry": "tex_0000", "scope": "scene:loc_tavern",
        "slot": "candles", "value": "lit"}}}},
        "passed", gold_candle) == "correct_allow"
    # no-object golds (look_around/wait/rest): kind is the only axis
    gold_look = {"intent": {"kind": "look_around"}}
    assert fa({"intent": {"kind": "look_around"}},
              "passed", gold_look) == "correct_allow"
    assert fa({"intent": {"kind": "wait", "fields": {"ticks": 30}}},
              "passed", gold_look) == "false_allow_kind"
    # the gravest class: a non-intent gold (atmosphere/question) that
    # the gate let through as an action
    assert fa({"intent": {"kind": "arson",
                          "target": "loc_tavern"}},
              "passed", {"no_intent": "atmosphere"}) \
        == "false_allow_nonintent"
    # the gate refused an atmosphere row: the honest block (never a
    # false allow — it is excluded from the cost count)
    assert fa({"no_intent": "x"}, "blocked",
              {"no_intent": "atmosphere"}) == "blocked"
    # a blocked intent gold is a MISS, also not a false allow
    assert fa({"no_intent": "x"}, "blocked", gold_talk) == "blocked"
    # the impossible-by-construction class still records
    assert fa({"no_intent": "x"}, "passed", gold_talk) == "pass_no_action"
    print("ok: the false-allow census classifier (the disjoint classes)")


def test_gate_knob() -> None:
    """THE 0.4 KNOB (the M2 machinery): the SAME router answers
    assemble differently at the two thresholds — the only changed
    variable; the 0.38-0.49 band the m4 run measured is exactly the
    band the knob recovers; the record carries the threshold used."""
    sim, log, td = _boot(setup=[{"intent": "move",
                                 "target": "loc_tavern"}])
    _h, events = read_log(log, SCHEMA)
    snapshot = grammar_snapshot(events, PACK, SceneLedger())
    # a low-agency verb just under the 0.5 line (the m4 RU pattern:
    # look_around at 0.423)
    answers = {"action": {"type": "choice", "choice": "look_around",
                          "probabilities": {"look_around": 0.8}},
               "is_modeled": {"type": "noul", "noul": 0.423},
               "risk": {"type": "score", "score": 0.0}}
    doc5, meta5 = P.assemble_intent(answers, snapshot, PACK,
                                    gate=P.NOUL_GATE)
    doc4, meta4 = P.assemble_intent(answers, snapshot, PACK,
                                    gate=P.NOUL_GATE_LOOSE)
    assert meta5["gate"] == "blocked" and "no_intent" in doc5
    assert meta4["gate"] == "passed"
    assert doc4["intent"]["kind"] == "look_around"
    assert meta4["gate_p"] == meta5["gate_p"] == 0.423
    # the same answers, both thresholds, the gate the only variable —
    # and a 0.38 answer stays blocked even at 0.4 (the honest floor)
    answers["is_modeled"]["noul"] = 0.38
    doc4b, meta4b = P.assemble_intent(answers, snapshot, PACK,
                                      gate=P.NOUL_GATE_LOOSE)
    assert meta4b["gate"] == "blocked"
    sim.close()
    td.cleanup()
    print("ok: the 0.4 gate knob (the same answers, the gate the only "
          "variable)")


if __name__ == "__main__":
    test_census()
    test_questions_and_assembly()
    test_ru_rows_shape()
    test_hybrid_grammar()
    test_false_allow()
    test_gate_knob()
    test_batch_law()
    test_batch_escalation()
    test_vram_planner()
    print("ALL UNITS GREEN")
