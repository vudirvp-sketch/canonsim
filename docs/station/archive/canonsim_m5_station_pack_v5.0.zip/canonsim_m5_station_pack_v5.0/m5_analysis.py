#!/usr/bin/env python3
"""m5_analysis.py — the m5 report generator (the m4_analysis role +
the m5 cores).

Reads a run directory and produces m5_report.txt:
  - THE M3 DECISION TABLE: R vs G vs H0 vs H8 on ONE corpus, ONE
    session, ONE main-model spawn — the like-for-like the iter-361 §G
    caveat asked for (H was the m3-battery leader on a DIFFERENT
    corpus; this table closes the question by measurement).
  - THE R CENSUS / THE INVENTION LEDGER / THE G CONTROL (m4 verbatim).
  - THE H ARMS: the census (the same classifier as G — the JSON head
    rides the repo's own grammar inside the hybrid wrap) + THE PROSE
    LEDGER (length, json bleed, protocol echo, the eos-held flag; the
    verbatim prose rides the jsonl for the owner's own reading).
  - THE LATENCY LEDGER: R systemone vs G parse vs H0/H8 parse walls —
    the single-pass question on one engine.
  - THE RU BAND @0.5 (the baseline) and THE RU-0.4 STAGE: the 12 rows
    side by side, the assembly census at both thresholds, and THE
    FALSE-ALLOW CENSUS — every gate-passed row checked against its
    gold; a wrong-kind or wrong-object pass counted as a falsely-
    allowed action, never as a win.
  - THE R04 (EN @0.4): the same census on the corpus the 87.1%@0.4
    sweep number lives on — the knob's cost side measured where its
    benefit was measured.
  - THE DETERMINISM MINI (router/g/h, digests recorded).

The analysis carries no decision — the owner's call.
"""
from __future__ import annotations

import json
from collections import Counter
from pathlib import Path


def _load(path: Path):
    if not path.exists():
        return []
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def _cycles(arm_file: Path):
    for unit in _load(arm_file):
        for rec in unit.get("cycles", ()):
            yield unit.get("unit", "?"), rec


def _pct(n: int, d: int) -> str:
    return f"{100.0 * n / d:5.1f}%" if d else "  n/a"


def _walls(recs, key) -> list[float]:
    return [r[key] for r in recs if isinstance(r.get(key), (int, float))]


def _stats(xs: list[float]) -> str:
    if not xs:
        return "n/a"
    xs = sorted(xs)
    n = len(xs)
    med = xs[n // 2] if n % 2 else (xs[n // 2 - 1] + xs[n // 2]) / 2
    return (f"med {med:6.3f}s  min {xs[0]:6.3f}s  max {xs[-1]:6.3f}s  "
            f"mean {sum(xs) / n:6.3f}s  n={n}")


def _arm_census(L: list[str], run_dir: Path, arm: str, title: str,
                *, raw_clean: bool = True) -> list[dict]:
    """One arm's census block (the m4 R form; H arms reuse it — their
    JSON heads ride the same census classifier)."""
    f = run_dir / f"arm_{arm}.jsonl"
    L.append(f"-- {title} " + "-" * max(0, 56 - len(title)))
    if not f.exists():
        L.append("  (did not run)")
        L.append("")
        return []
    recs = list(_cycles(f))
    if not raw_clean:
        rows = [r for _, r in recs]
        c = Counter(r.get("census", "?") for r in rows)
        n = len(rows)
        L.append(f"  {n} say-cycles: " + ", ".join(
            f"{k}={v}" for k, v in sorted(c.items())))
        L.append("")
        return recs
    raw = [r for _, r in recs]
    clean = [r for _, r in recs if not r.get("drift")]
    for label, rows in (("RAW", raw), ("CLEAN", clean)):
        n = len(rows)
        c = Counter(r.get("census", "?") for r in rows)
        full = c.get("full", 0)
        kind_ok = full + c.get("target", 0) + c.get("fields", 0) \
            + c.get("no_pin", 0)
        L.append(f"  {label}: {n} say-cycles")
        L.append(f"    full        {full:3d}  {_pct(full, n)}")
        L.append(f"    kind+       {kind_ok:3d}  {_pct(kind_ok, n)}"
                 f"   (full+target+fields+no_pin)")
        L.append(f"    kind        {c.get('kind', 0):3d}  "
                 f"{_pct(c.get('kind', 0), n)}")
        L.append(f"    target      {c.get('target', 0):3d}  "
                 f"{_pct(c.get('target', 0), n)}")
        L.append(f"    fields      {c.get('fields', 0):3d}  "
                 f"{_pct(c.get('fields', 0), n)}")
        L.append(f"    no_pin      {c.get('no_pin', 0):3d}  "
                 f"{_pct(c.get('no_pin', 0), n)}")
        others = {k: v for k, v in c.items() if k not in (
            "full", "target", "fields", "no_pin", "kind")}
        if others:
            L.append("    refusals/other: " + ", ".join(
                f"{k}={v}" for k, v in sorted(others.items())))
    dc = Counter(r.get("door_outcome", "?") for _, r in recs
                 if r.get("door_outcome"))
    if dc:
        L.append("  the door's own outcomes: " + ", ".join(
            f"{k}={v}" for k, v in sorted(dc.items())))
    L.append("")
    return recs


def _fa_block(L: list[str], rows: list[dict], title: str) -> None:
    """THE FALSE-ALLOW CENSUS (the M2 knob's cost side): the counts +
    the per-row table. Rows are (unit, rec) pairs carrying 'fa'."""
    L.append(f"-- {title} " + "-" * max(0, 56 - len(title)))
    if not rows:
        L.append("  (no rows)")
        L.append("")
        return
    c = Counter(r.get("fa", "?") for _, r in rows)
    n = len(rows)
    L.append(f"  {n} rows, the disjoint classes:")
    L.append(f"    correct_allow      {c.get('correct_allow', 0):3d}  "
             f"{_pct(c.get('correct_allow', 0), n)}"
             f"  (kind AND object match the gold)")
    L.append(f"    FALSE allows       "
             f"{sum(c.get(k, 0) for k in ('false_allow_kind', 'false_allow_object', 'false_allow_nonintent')):3d}"
             f"  {_pct(sum(c.get(k, 0) for k in ('false_allow_kind', 'false_allow_object', 'false_allow_nonintent')), n)}"
             f"  <- the knob's COST, never a win:")
    L.append(f"      false_allow_kind      {c.get('false_allow_kind', 0):3d}"
             f"  (a WRONG ACTION passed the gate)")
    L.append(f"      false_allow_object    {c.get('false_allow_object', 0):3d}"
             f"  (the kind matched, a DIFFERENT object committed)")
    L.append(f"      false_allow_nonintent {c.get('false_allow_nonintent', 0):3d}"
             f"  (the gold says NO action; one was committed)")
    L.append(f"    blocked            {c.get('blocked', 0):3d}  "
             f"{_pct(c.get('blocked', 0), n)}"
             f"  (the gate said no — a miss on intent golds,")
    L.append(f"                                          the honest "
             f"rejection on non-intent golds)")
    if c.get("pass_no_action"):
        L.append(f"    pass_no_action     {c['pass_no_action']:3d}"
                 f"  (impossible by construction — recorded, never dropped)")
    L.append("")
    L.append(f"  {'row':7s} {'fa':22s} {'census':10s} "
             f"{'gate':7s} {'P':>5s}  assembled vs gold")
    for unit, r in rows:
        meta = r.get("r_meta") or {}
        a = (r.get("assembled") or {}).get("intent", {})
        g = (r.get("expected") or {}).get("intent", {})
        g_tex = ((g.get("fields") or {}).get("texture") or {}) \
            if isinstance(g, dict) else {}
        gold_s = (f"{g.get('kind', '-')}/"
                  f"{g.get('target') or g_tex.get('slot', '-')}")
        L.append(f"  {unit:7s} {str(r.get('fa', '?')):22s} "
                 f"{str(r.get('census', '?'))[:10]:10s} "
                 f"{str(meta.get('gate', '-'))[:7]:7s} "
                 f"{meta.get('gate_p', 0):6.3f}  "
                 f"{a.get('kind', '-')}/{a.get('target') or '-'} "
                 f"vs gold {gold_s}")
    L.append("")


def analyze_run(run_dir: Path, gate: dict) -> str:
    L: list[str] = []
    L.append("CANONSIM M5 — THE SAME-CORPUS BATTERY REPORT")
    L.append("=" * 62)
    L.append(f"pack: {gate.get('pack_version', '?')}")
    L.append(f"repo: {gate.get('repo', '?')}")
    r_gate = gate.get("router") or {}
    L.append(f"router: {r_gate.get('mode', '?')} "
             f"model={r_gate.get('model', r_gate.get('endpoint', '?'))}")
    m_gate = gate.get("main") or {}
    L.append(f"main (G + H arms): {m_gate.get('mode', '?')} "
             f"model={m_gate.get('model', m_gate.get('endpoint', '?'))}")
    cg = {}
    cg_path = run_dir / "cuda_gate.json"
    if cg_path.exists():
        cg = json.loads(cg_path.read_text(encoding="utf-8"))
    if cg:
        L.append(f"device gate: cuda_visible={cg.get('cuda_visible')} "
                f"bands={cg.get('bands')}")
    L.append("")

    # -- the models verdict table --------------------------------------
    L.append("-- THE MODELS (the doctor's verdicts, at run time) ------")
    for row in gate.get("models", ()):
        L.append(f"  {row.get('file', '?'):36s} "
                 f"{row.get('verdict', '?'):22s} "
                 f"tensors={row.get('tensors', '-')}")
        if "reason" in row:
            L.append(f"      broken: {row['reason'][:100]}")
    L.append("")

    # -- the arms' censuses (loaded once, reused by the decision table)
    arm_r = run_dir / "arm_r.jsonl"
    arm_g = run_dir / "arm_g.jsonl"
    arm_h0 = run_dir / "arm_h0.jsonl"
    arm_h8 = run_dir / "arm_h8.jsonl"
    arm_r04 = run_dir / "arm_r04.jsonl"
    r_recs = list(_cycles(arm_r)) if arm_r.exists() else []
    g_recs = list(_cycles(arm_g)) if arm_g.exists() else []
    h0_recs = list(_cycles(arm_h0)) if arm_h0.exists() else []
    h8_recs = list(_cycles(arm_h8)) if arm_h8.exists() else []
    r04_recs = list(_cycles(arm_r04)) if arm_r04.exists() else []

    # -- THE M3 DECISION TABLE (the m5 headline) -------------------------
    L.append("-- THE M3 DECISION TABLE (one corpus, one session) ------")
    cols = (("R (router)", r_recs, "r_wall_s"),
            ("G (grammar)", g_recs, "parse_wall_s"),
            ("H0 (hybrid t0)", h0_recs, "parse_wall_s"),
            ("H8 (hybrid t0.8)", h8_recs, "parse_wall_s"))

    def _col(recs, key):
        if not recs:
            return "  n/a"
        rows = [r for _, r in recs]
        c = Counter(r.get("census", "?") for r in rows)
        n = len(rows)
        full = c.get("full", 0)
        kind_ok = full + c.get("target", 0) + c.get("fields", 0) \
            + c.get("no_pin", 0)
        if key == "full":
            return f"{full:3d} ({100.0 * full / n:4.1f}%)"
        if key == "kind+":
            return f"{kind_ok:3d} ({100.0 * kind_ok / n:4.1f}%)"
        if key == "refuse":
            ref = sum(v for k, v in c.items() if k in (
                "not_intent", "gate_blocked", "gate_false_positive",
                "off_gr", "parse_error"))
            return f"{ref:3d} ({100.0 * ref / n:4.1f}%)"
        if key in ("r_wall_s", "parse_wall_s"):
            ws = sorted(_walls(rows, key))
            if not ws:
                return "  n/a"
            med = ws[len(ws) // 2]
            return f"med {med:5.2f}s max {ws[-1]:5.2f}s"
        if key == "tok":
            ts = [r.get("parse_ctok") for _, r in recs
                  if isinstance(r.get("parse_ctok"), (int, float))]
            if recs and "r_otok" in recs[0][1]:
                ts = [r.get("r_otok") for _, r in recs
                      if isinstance(r.get("r_otok"), (int, float))]
            if not ts:
                return "  n/a"
            return f"out med {sorted(ts)[len(ts) // 2]}"
        if key == "prose":
            ps = [r.get("prose_len") for _, r in recs
                  if isinstance(r.get("prose_len"), (int, float))]
            if not ps:
                return "      -"
            med = sorted(ps)[len(ps) // 2]
            bad = sum(1 for _, r in recs if r.get("json_bleed")
                      or r.get("protocol_echo") or r.get("eos_held"))
            return f"med {med:3d} ch, flags {bad}"
        return "?"

    L.append(f"  {'metric':16s}" + "".join(f"{nm:24s}" for nm, _, _ in cols))
    for key, label in (("full", "full vs gold"), ("kind+", "kind+"),
                       ("refuse", "refusals"),
                       ("wall", "parse wall"), ("tok", "tokens"),
                       ("prose", "prose")):
        vals = [_col(recs, wkey if key == "wall" else key)
                for nm, recs, wkey in cols]
        L.append(f"  {label:16s}" + "".join(f"{v:24s}" for v in vals))
    L.append("  (R's wall = the systemone call; G/H = the chat call;")
    L.append("   G and H ride the SAME main-model spawn — like-for-like)")
    L.append("")

    # -- the R census -----------------------------------------------------
    _arm_census(L, run_dir, "r", "THE R CENSUS (the systemone route)")

    # -- the invention ledger ---------------------------------------------
    L.append("-- THE INVENTION LEDGER (the R form's proof) ------------")
    if r_recs:
        inv = [r for _, r in r_recs if r.get("inventions")]
        L.append(f"  assembled docs: {len(r_recs)}; with ANY key outside "
                 f"the pack's sets: {len(inv)}"
                 f"{'  <- THE PROOF: 0 inventions' if not inv else '  !! VIOLATION'}")
        for _, r in inv[:5]:
            L.append(f"    !! {r.get('inventions')}")
    else:
        L.append("  (the R arm did not run)")
    L.append("")

    # -- the G control census ----------------------------------------------
    _arm_census(L, run_dir, "g", "THE G CONTROL (the grammar route)")

    # -- the H arms ----------------------------------------------------------
    for arm, title in (("h0", "THE H0 ARM (hybrid single-pass, temp 0)"),
                       ("h8", "THE H8 ARM (hybrid, temp 0.8-seeded)")):
        recs = _arm_census(L, run_dir, arm, title)
        if recs:
            L.append(f"  THE PROSE LEDGER ({arm}):")
            ps = _walls([r for _, r in recs], "prose_len")
            if ps:
                p = sorted(ps)
                L.append(f"    length: med {p[len(p) // 2]} ch  "
                         f"min {p[0]}  max {p[-1]}")
            bleed = sum(1 for _, r in recs if r.get("json_bleed"))
            echo = sum(1 for _, r in recs if r.get("protocol_echo"))
            held = sum(1 for _, r in recs if r.get("eos_held"))
            n = len(recs)
            L.append(f"    json_bleed {bleed}/{n}  protocol_echo {echo}/{n}"
                     f"  eos_held {held}/{n}"
                     f"{'  <- the terminated-prose law HELD (finish stop)' if not held else '  !! EOS HELD — check max_tokens'}")
            ct = _walls([r for _, r in recs], "parse_ctok")
            if ct:
                L.append(f"    completion tokens: med "
                         f"{sorted(ct)[len(ct) // 2]}")
            L.append(f"    finish reasons: " + ", ".join(
                f"{k}={v}" for k, v in sorted(
                    Counter(str(r.get("finish_reason"))
                            for _, r in recs).items())))
            L.append("")

    # -- the latency ledger --------------------------------------------------
    L.append("-- THE LATENCY LEDGER ------------------------------------")
    if r_recs:
        recs = [r for _, r in r_recs]
        L.append(f"  R systemone call:  {_stats(_walls(recs, 'r_wall_s'))}")
        L.append(f"  R cycle end-to-end:{_stats(_walls(recs, 'wall_s'))}")
        otok = {r.get("r_otok") for r in recs}
        L.append(f"  output_tokens across the R calls: "
                 f"{sorted(otok) if otok else '?'}"
                 f"{'  (the non-generativity proof)' if otok == {0} else ''}")
        itok = _walls(recs, "r_itok")
        if itok:
            L.append(f"  input tokens:       med "
                     f"{sorted(itok)[len(itok) // 2]}")
    if g_recs:
        recs = [r for _, r in g_recs]
        L.append(f"  G parse call:       "
                 f"{_stats(_walls(recs, 'parse_wall_s'))}")
        L.append(f"  G cycle end-to-end: {_stats(_walls(recs, 'wall_s'))}")
    for arm, nm in (("h0", "H0"), ("h8", "H8")):
        f = run_dir / f"arm_{arm}.jsonl"
        if f.exists():
            recs = [r for _, r in _cycles(f)]
            L.append(f"  {nm} hybrid call:    "
                     f"{_stats(_walls(recs, 'parse_wall_s'))}")
            L.append(f"  {nm} cycle e2e:      {_stats(_walls(recs, 'wall_s'))}")
    L.append("")

    # -- the RU band @0.5 ------------------------------------------------------
    ru = run_dir / "ru.jsonl"
    L.append("-- THE RU BAND @0.5 (hand-authored gold; the baseline) --")
    ru_rows: list[tuple[str, dict]] = []
    if not ru.exists():
        L.append("  (the RU band did not run)")
    else:
        for unit in _load(ru):
            for r in unit.get("cycles", ()):
                ru_rows.append((unit.get("unit", "?"), r))
        n = len(ru_rows)
        c = Counter(r.get("census", "?") for _, r in ru_rows)
        L.append(f"  {n} rows: " + ", ".join(
            f"{k}={v}" for k, v in sorted(c.items())))
        for unit, r in ru_rows:
            meta = r.get("r_meta") or {}
            act = (r.get("assembled") or {}).get("intent", {})
            L.append(f"    [{unit}: {str(r.get('census', '?')):8s}] "
                     f"gate={meta.get('gate')} "
                     f"act={act.get('kind', '-')}"
                     f"/{act.get('target', '-')}  "
                     f"say={r.get('say', '')[:44]}")
        walls = _walls([r for _, r in ru_rows], "r_wall_s")
        if walls:
            L.append(f"  walls: {_stats(walls)}")
    L.append("")

    # -- THE RU-0.4 STAGE (the M2 knob, Russian side) --------------------------
    ru04 = run_dir / "ru04.jsonl"
    L.append("-- THE RU-0.4 STAGE (the M2 knob + its cost side) -------")
    ru04_rows: list[tuple[str, dict]] = []
    if not ru04.exists():
        L.append("  (the RU-0.4 stage did not run)")
        L.append("")
    else:
        for unit in _load(ru04):
            for r in unit.get("cycles", ()):
                ru04_rows.append((unit.get("unit", "?"), r))
        c = Counter(r.get("census", "?") for _, r in ru04_rows)
        L.append(f"  assembly census @0.4 ({len(ru04_rows)} rows): "
                 + ", ".join(f"{k}={v}" for k, v in sorted(c.items())))
        if ru_rows:
            c5 = Counter(r.get("census", "?") for _, r in ru_rows)
            L.append(f"  assembly census @0.5 (the baseline):    "
                     + ", ".join(f"{k}={v}" for k, v in sorted(c5.items())))
        L.append("")
    _fa_block(L, ru04_rows, "THE FALSE-ALLOW CENSUS, RUSSIAN @0.4")

    # -- THE R04 (EN @0.4) -------------------------------------------------------
    L.append("-- THE R04 (the English corpus at gate 0.4) -------------")
    if not r04_recs:
        L.append("  (the r04 arm did not run)")
        L.append("")
    else:
        rows = [r for _, r in r04_recs]
        c = Counter(r.get("census", "?") for r in rows)
        n = len(rows)
        L.append(f"  assembly census @0.4, {n} say-cycles: " + ", ".join(
            f"{k}={v}" for k, v in sorted(c.items())))
        if r_recs:
            c5 = Counter(r.get("census", "?") for _, r in r_recs)
            L.append(f"  assembly census @0.5 (the r arm):        "
                     + ", ".join(f"{k}={v}" for k, v in sorted(c5.items())))
        L.append("")
    _fa_block(L, r04_recs, "THE FALSE-ALLOW CENSUS, ENGLISH @0.4")

    # -- the determinism mini ---------------------------------------------
    det = run_dir / "det.jsonl"
    L.append("-- THE DETERMINISM MINI ---------------------------------")
    if not det.exists():
        L.append("  (the det stage did not run)")
    else:
        for rec in _load(det):
            L.append(f"  {rec.get('unit')}: identical="
                     f"{rec.get('identical')} "
                     f"digest={rec.get('answers_digest', '')} "
                     f"{('finish ' + str(rec.get('finish1'))) if rec.get('finish1') else ''}")
    L.append("")

    # -- the per-cycle tables ------------------------------------------------
    L.append("-- THE R ARM, PER CYCLE ---------------------------------")
    if r_recs:
        L.append(f"  {'case':26s} {'cy':>2s} {'census':10s} "
                 f"{'gate':7s} {'P(act)':>7s} {'door':18s} say")
        for case, r in r_recs:
            meta = r.get("r_meta") or {}
            L.append(f"  {case[:26]:26s} {r.get('cycle', 0):2d} "
                     f"{str(r.get('census', '?'))[:10]:10s} "
                     f"{str(meta.get('gate', '-'))[:7]:7s} "
                     f"{meta.get('action_p', 0) if isinstance(meta.get('action_p'), (int, float)) else 0:7.3f} "
                     f"{str(r.get('door_outcome', '-'))[:18]:18s} "
                     f"{r.get('say', '')[:40]}")
    L.append("")
    L.append("-- THE H0 ARM, PER CYCLE (the verdict + the prose) -------")
    if h0_recs:
        L.append(f"  {'case':26s} {'cy':>2s} {'census':10s} "
                 f"{'door':16s} {'len':>4s} prose")
        for case, r in h0_recs:
            L.append(f"  {case[:26]:26s} {r.get('cycle', 0):2d} "
                     f"{str(r.get('census', '?'))[:10]:10s} "
                     f"{str(r.get('door_outcome', '-'))[:16]:16s} "
                     f"{r.get('prose_len', 0):4d} "
                     f"{str(r.get('prose', ''))[:76]}")
    L.append("")
    return "\n".join(L)
