#!/usr/bin/env python3
"""station_m5_doctor.py — THE MODEL + ENGINE DOCTOR (m5 = the m4
iter-357 tool, renamed for the m5 pack; the verdicts and the pinned
fetches ride verbatim).

The owner's question, answered by metadata BEFORE any spawn:
  «Kev-4B / Decision-2.0-Nox-4B / decider-4b — что это вообще?»
  → every *.gguf in <repo>/workbench/runtime/models/ is read LOCALLY
    (header + metadata, no server, no full load) and verdicted:

  decision:<type>   a decision model — one of the llama.cpp five
                    (laya/julia-1/lev/openjev/kev): non-generative,
                    answers POST /v1/systemone (choice/noul/score) in
                    one forward pass, CANNOT generate text (a chat call
                    is refused by construction), CANNOT hallucinate a
                    document (it only picks from the keys you give it)
  causal-lm         a normal generative model — the G-arm / narrator
                    class; NOT a classifier (decider-4b's verdict: no
                    decision metadata, outside the five, unusable via
                    systemone today)
  broken            not a readable GGUF (a placeholder / a failed
                    download / a stale conversion — the station's
                    Kev-4B copy: 426 tensors where the fresh
                    ggml-org file carries 428 with kev metadata)

Plus the engine verdict (the pack's llama.cpp/ + the repo's
workbench/runtime/llama.cpp/): does the server exist, does the build
carry /v1/systemone, and IS THE FOLDER EVEN A LLAMA.CPP BUILD (the
owner's 2026-10-10 datum: workbench/runtime/llama.cpp was a canonsim
repo CLONE with stray exes at the root).

Plus the pinned fetches (each optional, each verified):
  --fetch-laya     Laya-Q8_0.gguf (449 MB) — the EN decision model
                   (the RU band: confidently wrong — the honest card
                   limit, measured before trust)
  --fetch-kev      Kev-4B-Q8_0.gguf (4.48 GB) — the RE-DOWNLOAD that
                   fixes the station's broken copy (428 tensors +
                   qwen35.decision.type=kev verified after download)
  --fetch-qwen     Qwen3-0.6B-Q4_K_M.gguf (484 MB) — the generative
                   ultra-light for the G control arm (md5-pinned)

Writes doctor.json beside the script. Never spawns a server. Never
touches the repo.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import struct
import sys
import time
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

HERE = Path(__file__).resolve().parent

# -- the GGUF metadata reader (self-contained; the array-consumption
#    law learned live on Laya's 50368-token tokenizer array: a partial
#    read desyncs every later key) ----------------------------------------


class GGUFReadError(ValueError):
    pass


def _u32(fh) -> int:
    return struct.unpack("<I", fh.read(4))[0]


def _u64(fh) -> int:
    return struct.unpack("<Q", fh.read(8))[0]


def _read_str(fh, wide: bool) -> str:
    n = _u64(fh) if wide else _u32(fh)
    if n > 10_000_000:
        raise GGUFReadError(f"unreasonable string length {n}")
    return fh.read(n).decode("utf-8", "replace")


def _read_val(fh, vtype: int, wide: bool):
    if vtype == 8:
        return _read_str(fh, wide)
    if vtype in (0, 1):
        return struct.unpack("<b" if vtype else "<B", fh.read(1))[0]
    if vtype in (2, 3):
        return struct.unpack("<h" if vtype == 3 else "<H",
                             fh.read(2))[0]
    if vtype in (4, 5):
        return struct.unpack("<i" if vtype == 5 else "<I",
                             fh.read(4))[0]
    if vtype == 6:
        return struct.unpack("<f", fh.read(4))[0]
    if vtype == 12:
        return struct.unpack("<d", fh.read(8))[0]
    if vtype == 7:
        return bool(fh.read(1)[0])
    if vtype in (10, 11):
        return struct.unpack("<q" if vtype == 11 else "<Q",
                             fh.read(8))[0]
    if vtype == 9:
        etype = _u32(fh)
        n = _u64(fh) if wide else _u32(fh)
        if n > 5_000_000:
            raise GGUFReadError(f"unreasonable array length {n}")
        if etype == 8:
            return [_read_str(fh, wide) for _ in range(n)]
        return [_read_val(fh, etype, wide) for _ in range(n)]
    raise GGUFReadError(f"unknown gguf value type {vtype}")


def gguf_meta(path: Path) -> dict:
    st = path.stat()
    if st.st_size < 1024:
        raise GGUFReadError(f"only {st.st_size} bytes — a placeholder, "
                            f"not a model")
    with open(path, "rb") as fh:
        magic = fh.read(4)
        if magic != b"GGUF":
            raise GGUFReadError(f"magic {magic!r} is not b'GGUF' — "
                                f"corrupted, or an OneDrive cloud-only "
                                f"stub (open/hydrate the folder once)")
        version = struct.unpack("<I", fh.read(4))[0]
        if version not in (1, 2, 3):
            raise GGUFReadError(f"unknown gguf version {version}")
        wide = version >= 3
        n_tensors = _u64(fh)
        n_kv = _u64(fh)
        if n_kv > 100_000:
            raise GGUFReadError(f"unreasonable kv count {n_kv}")
        kv: dict[str, object] = {}
        for _ in range(n_kv):
            key = _read_str(fh, wide)
            vt = _u32(fh)
            kv[key] = _read_val(fh, vt, wide)
    return {"version": version, "tensors": n_tensors, "kv": kv,
            "bytes": st.st_size}


#: the llama.cpp decision-model five (LLAMA_CPP_INFERENCE_CONTROL_LAW
#: §16; PR #29818's surface)
DECISION_FIVE = ("laya", "julia-1", "lev", "openjev", "kev")


def verdict_model(path: Path) -> dict:
    """The per-model verdict document (the census row)."""
    row: dict[str, object] = {"file": path.name, "path": str(path)}
    try:
        meta = gguf_meta(path)
    except GGUFReadError as exc:
        row["verdict"] = "broken"
        row["reason"] = str(exc)
        return row
    dtype = None
    for k, v in meta["kv"].items():
        if k.endswith(".decision.type"):
            dtype = str(v)
            break
    row.update({
        "tensors": meta["tensors"],
        "bytes": meta["bytes"],
        "arch": meta["kv"].get("general.architecture", "?"),
        "name": meta["kv"].get("general.name", ""),
        "decision_type": dtype,
        "decision_keys": {k: v for k, v in meta["kv"].items()
                          if ".decision." in k},
    })
    if dtype is None:
        # the known broken-family overlay: the station's Kev-4B copy
        # (426 tensors where the fresh ggml-org file carries 428 with
        # kev metadata) is BROKEN for every purpose — never offered as
        # a generative pick
        if path.name.startswith("Kev-4B"):
            row["verdict"] = "broken"
            row["reason"] = (
                f"a Kev-4B file WITHOUT kev decision metadata "
                f"({meta['tensors']} tensors) — the stale conversion "
                f"(the fresh file: 428 tensors, kev type)")
            row["known_fix"] = (
                "the pinned RE-DOWNLOAD from ggml-org/Kev-4B-GGUF "
                "(428 tensors, qwen35.decision.type=kev) — run "
                "--fetch-kev")
            return row
        # an implausible shape is BROKEN, not generative (a stub or a
        # truncated download: a real causal-LM carries hundreds of
        # tensors; the smallest known decision model carries 201)
        if meta["tensors"] < 50 or not meta["kv"].get(
                "general.architecture"):
            row["verdict"] = "broken"
            row["reason"] = (f"implausible shape: {meta['tensors']} "
                             f"tensors, arch="
                             f"{meta['kv'].get('general.architecture')!r}"
                             f" — a stub, a truncated download, or a "
                             f"stale conversion")
            return row
        row["verdict"] = "causal-lm"
    elif dtype in DECISION_FIVE:
        row["verdict"] = f"decision:{dtype}"
    else:
        row["verdict"] = f"decision:unknown({dtype})"
    # the known-file overlays (the station's live data)
    if path.name == "Kev-4B-Q8_0.gguf" and dtype != "kev":
        row["known_fix"] = (
            "the STATION COPY is the stale/broken conversion (426 "
            "tensors, no kev metadata): the fix is the pinned "
            "RE-DOWNLOAD from ggml-org/Kev-4B-GGUF (428 tensors, "
            "qwen35.decision.type=kev) — run --fetch-kev")
    if path.name.startswith("decider-") and dtype is None:
        row["known_fix"] = (
            "the Mapika decider class converts as a PLAIN causal-LM "
            "(no decision metadata) — outside the llama.cpp five, "
            "unusable via /v1/systemone today; usable only as a tiny "
            "generative model")
    return row


# -- the pinned fetches ----------------------------------------------------

FETCHES = {
    "laya": {
        "url": ("https://huggingface.co/ggml-org/Laya-GGUF/resolve/"
                "main/Laya-Q8_0.gguf"),
        "bytes": 449_397_600,
        "md5": "fb91a5f2454ddff1af91668a3415df82",
        "expect": {"tensors": 201, "decision_type": "laya"},
    },
    "kev": {
        "url": ("https://huggingface.co/ggml-org/Kev-4B-GGUF/"
                "resolve/main/Kev-4B-Q8_0.gguf"),
        "bytes": 4_483_801_504,
        # no md5 published — the pin is size + the metadata shape
        # (428 tensors + kev decision.type; the iter-356 live probe)
        "expect": {"tensors": 428, "decision_type": "kev"},
    },
    "qwen": {
        "url": ("https://huggingface.co/lmstudio-community/"
                "Qwen3-0.6B-GGUF/resolve/main/Qwen3-0.6B-Q4_K_M.gguf"),
        "bytes": 484_219_808,
        "md5": "541151b170814b2063fb8bc74073db7d",
        "expect": None,
    },
}


def md5_file(path: Path) -> str:
    h = hashlib.md5()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def fetch_one(which: str, models_dir: Path) -> dict:
    spec = FETCHES[which]
    dest = models_dir / Path(spec["url"]).name
    models_dir.mkdir(parents=True, exist_ok=True)
    if dest.is_file():
        st = dest.stat()
        size_ok = st.st_size == spec["bytes"]
        if size_ok and (spec.get("md5") is None
                        or md5_file(dest) == spec["md5"]):
            print(f"[fetch] {dest.name}: already present, hash "
                  f"matches — skip", flush=True)
            return {"fetched": dest.name, "status": "already-present"}
        print(f"[fetch] {dest.name}: present but wrong "
              f"({'size' if not size_ok else 'hash'}) — "
              f"re-downloading", flush=True)
        dest.unlink()
    part = dest.with_suffix(dest.suffix + ".part")
    last: Exception | None = None
    for attempt in range(1, 4):
        try:
            print(f"[fetch] {dest.name} "
                  f"({spec['bytes'] / 1e9:.2f} GB)\n  {spec['url']}",
                  flush=True)
            t0 = time.monotonic()
            req = urllib.request.Request(
                spec["url"], headers={"User-Agent": "canonsim-m5"})
            with urllib.request.urlopen(req, timeout=120) as r, \
                    open(part, "wb") as out:
                total = 0
                while True:
                    chunk = r.read(1 << 20)
                    if not chunk:
                        break
                    total += len(chunk)
                    out.write(chunk)
                    if total % (128 << 20) < (1 << 20):
                        mb = total / 1e6
                        rate = mb / max(time.monotonic() - t0, 0.1)
                        print(f"    {mb:8.0f} MB ({rate:5.1f} MB/s)",
                              flush=True)
            if total != spec["bytes"]:
                raise OSError(f"size {total} != pinned {spec['bytes']}")
            part.rename(dest)
            got = md5_file(dest)
            if spec.get("md5") and got != spec["md5"]:
                raise OSError(f"md5 {got} != pinned {spec['md5']}")
            print(f"[fetch] {dest.name}: {total / 1e6:.0f} MB "
                  f"downloaded, hash verified", flush=True)
            if spec["expect"]:
                row = verdict_model(dest)
                ok = (row.get("tensors") == spec["expect"]["tensors"]
                      and row.get("decision_type")
                      == spec["expect"]["decision_type"])
                if not ok:
                    raise OSError(
                        f"metadata mismatch: tensors="
                        f"{row.get('tensors')} decision_type="
                        f"{row.get('decision_type')} (expected "
                        f"{spec['expect']})")
                print(f"[fetch] metadata verified: "
                      f"{spec['expect']}", flush=True)
            return {"fetched": dest.name, "status": "downloaded"}
        except (OSError, urllib.error.URLError) as exc:
            last = exc
            print(f"[fetch] attempt {attempt} failed: {exc}", flush=True)
            if part.exists():
                part.unlink()
            time.sleep(3.0 * attempt)
    return {"fetched": dest.name, "status": f"FAILED: {last}"}


# -- the engine verdict -----------------------------------------------------


def engine_verdict(repo: Path) -> dict:
    out: dict[str, object] = {}
    name = "llama-server.exe" if os.name == "nt" else "llama-server"
    candidates: list[Path] = []
    # 1. the pack's own build (the setup's target)
    pack_root = HERE / "llama.cpp"
    if pack_root.is_dir():
        candidates += [pack_root / name] + \
            [p / name for p in pack_root.iterdir() if p.is_dir()]
    # 2. the repo's runtime drop folder
    rt = repo / "workbench" / "runtime" / "llama.cpp"
    if rt.is_dir():
        candidates += [rt / name] + \
            [p / name for p in rt.iterdir() if p.is_dir()]
    # 3. PATH
    which = shutil_which(name)
    if which:
        candidates.append(Path(which))
    found = [c for c in candidates if c.is_file()]
    out["exe_search"] = [str(c) for c in candidates]
    out["exe"] = str(found[0]) if found else None

    # the runtime-folder diagnosis (the owner's datum: a repo clone)
    if rt.exists():
        has_git = (rt / ".git").exists()
        has_cmake = (rt / "CMakeLists.txt").is_file()
        has_canonsim = ((rt / "AGENTS.md").is_file()
                        or (rt / "pyproject.toml").is_file())
        stray = sorted(p.name for p in rt.glob("llama-*.exe"))
        if has_git or has_canonsim:
            out["runtime_folder"] = {
                "verdict": "NOT A LLAMA.CPP BUILD — a canonsim repo "
                           "clone (git present, canonsim markers "
                           "present)",
                "stray_exes": stray,
                "fix": "run station_m5_setup.py --swap (the sibling "
                       "backup + the pinned install; --restore "
                       "reverses)",
            }
        elif found and any(str(rt) in str(f) for f in found):
            out["runtime_folder"] = {"verdict": "carries a server"}
        elif has_cmake:
            out["runtime_folder"] = {
                "verdict": "a llama.cpp SOURCE checkout (build it, or "
                           "--swap the pinned binary build in)"}
        else:
            out["runtime_folder"] = {
                "verdict": f"present, no server at root/one-deep "
                           f"(stray: {stray})"}

    if found:
        exe = found[0]
        try:
            blob = exe.read_bytes()
            out["systemone"] = b"/v1/systemone" in blob
            for lib in exe.parent.glob("libllama-server*"):
                if out["systemone"]:
                    break
                out["systemone"] = b"/v1/systemone" in lib.read_bytes()
        except OSError:
            out["systemone"] = None
        import subprocess as sp
        try:
            r = sp.run([str(exe), "--version"], timeout=30,
                       capture_output=True, text=True, errors="replace")
            out["version"] = ((r.stdout or "") + (r.stderr or "")
                              ).strip().splitlines()[:2]
        except (OSError, sp.SubprocessError) as exc:
            out["version_error"] = str(exc)[:200]
    return out


def shutil_which(name: str) -> str | None:
    import shutil

    return shutil.which(name)


def find_repo(flagged: str | None) -> Path:
    rel = ("canonsim", "../canonsim", "../../canonsim",
           "../../../canonsim")
    home_rel = ("Desktop/repo/canonsim", "OneDrive/Desktop/repo/canonsim",
                "Desktop/canonsim", "OneDrive/Desktop/canonsim",
                "Documents/canonsim", "Documents/repo/canonsim")
    cands = [Path(flagged)] if flagged else []
    if os.environ.get("CANONSIM_REPO"):
        cands.append(Path(os.environ["CANONSIM_REPO"]))
    cands += [(HERE / r).resolve() for r in rel]
    cands += [(Path.cwd() / r).resolve() for r in rel]
    cands += [Path.home() / r for r in home_rel]
    for c in cands:
        if (c / "core" / "pack.py").is_file():
            return c
    raise SystemExit(
        "the canonsim repo was not found — pass --repo <path> (the "
        "ladder checks beside/above the pack and the home paths)")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--repo", default=None)
    ap.add_argument("--fetch-laya", action="store_true",
                    help="download Laya-Q8_0 (the EN decision model)")
    ap.add_argument("--fetch-kev", action="store_true",
                    help="RE-DOWNLOAD Kev-4B-Q8_0 (fixes the station's "
                         "broken copy)")
    ap.add_argument("--fetch-qwen", action="store_true",
                    help="download Qwen3-0.6B-Q4_K_M (the generative "
                         "ultra-light for the G arm)")
    args = ap.parse_args(argv)

    repo = find_repo(args.repo)
    models_dir = repo / "workbench" / "runtime" / "models"
    print(f"[doctor] repo: {repo}", flush=True)
    print(f"[doctor] models: {models_dir}", flush=True)

    doc: dict[str, object] = {
        "time": datetime.now(timezone.utc).isoformat(),
        "repo": str(repo),
    }

    if args.fetch_laya:
        doc["fetch_laya"] = fetch_one("laya", models_dir)
    if args.fetch_kev:
        doc["fetch_kev"] = fetch_one("kev", models_dir)
    if args.fetch_qwen:
        doc["fetch_qwen"] = fetch_one("qwen", models_dir)

    rows: list[dict] = []
    ggufs = sorted((p for p in models_dir.iterdir()
                    if p.is_file() and p.suffix.lower() == ".gguf"),
                   key=lambda p: p.name) if models_dir.is_dir() else []
    print(f"\n[doctor] {len(ggufs)} model(s):", flush=True)
    for p in ggufs:
        row = verdict_model(p)
        rows.append(row)
        line = (f"  {p.name:36s} {row['verdict']:22s} "
                f"tensors={row.get('tensors', '-')} "
                f"({row.get('bytes', 0) / 1e9:.2f} GB)")
        print(line, flush=True)
        if "reason" in row:
            print(f"      BROKEN: {row['reason']}", flush=True)
        if "known_fix" in row:
            print(f"      FIX: {row['known_fix']}", flush=True)
    doc["models"] = rows

    print("\n[doctor] the engine:", flush=True)
    eng = engine_verdict(repo)
    doc["engine"] = eng
    print(f"  exe: {eng.get('exe')}", flush=True)
    print(f"  /v1/systemone in the binary: {eng.get('systemone')}",
          flush=True)
    print(f"  version: {eng.get('version')}", flush=True)
    rf = eng.get("runtime_folder")
    if rf:
        print(f"  runtime/llama.cpp: {rf.get('verdict')}", flush=True)
        if rf.get("fix"):
            print(f"      FIX: {rf['fix']}", flush=True)

    decision = [r for r in rows if str(r.get("verdict", "")
                                      ).startswith("decision:")]
    generative = [r for r in rows if r.get("verdict") == "causal-lm"]
    print("\n[doctor] THE BOTTOM LINE:", flush=True)
    d_list = [r["file"] for r in decision]
    print("  decision models (the R arm): "
          + (", ".join(d_list) if d_list else
             "NONE — fetch one: --fetch-laya (450 MB, EN) or "
             "--fetch-kev (4.5 GB)"), flush=True)
    g_list = [r["file"] for r in generative]
    print("  generative models (the G arm): "
          + (", ".join(g_list) if g_list else
             "NONE — --fetch-qwen (484 MB) or use your own"),
          flush=True)
    if eng.get("runtime_folder", {}).get("verdict", "").startswith(
            "NOT A LLAMA.CPP"):
        print("  THE ENGINE FOLDER IS BROKEN (a repo clone) — run:\n"
              "    py -3 station_m5_setup.py --swap", flush=True)
    elif not eng.get("exe"):
        print("  NO SERVER — run station_m5_setup.bat first", flush=True)
    elif not eng.get("systemone"):
        print("  the found build lacks /v1/systemone — run "
              "station_m5_setup.bat (the pinned b11541)", flush=True)

    (HERE / "doctor.json").write_text(
        json.dumps(doc, indent=2, sort_keys=True, default=str),
        encoding="utf-8")
    print(f"\n[doctor] written: {HERE / 'doctor.json'}", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
