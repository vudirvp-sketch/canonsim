@echo off
rem ============================================================
rem  CANONSIM M5 PROBE (iter-365) — THE SAME-CORPUS BATTERY
rem  Your two recorded decisions get their instrument:
rem    H  the hybrid single-pass (the m3 form ON THE M4 CORPUS):
rem       ONE call carries the verdict JSON AND the prose (the
rem       terminated-prose grammar; the door splits at the blank
rem       line). H0 = temp 0, H8 = temp 0.8 — both on the SAME
rem       main-model spawn as G. The R-vs-H like-for-like at last.
rem    RU04 / R04  the 0.4 gate knob WITH its cost side: every
rem       gate-passed row checked against its gold — a wrong-kind
rem       or wrong-object pass counted as a FALSELY-ALLOWED action,
rem       never as a win (Russian 12 rows + the English corpus).
rem  The m4 v4.3 arms ride verbatim (R, G, RU@0.5, det + digests).
rem  Prerequisites: the engine (station_m5_setup.bat once — or the
rem  m4 pack's llama.cpp/ found beside this pack, no re-download)
rem  + a decision model + a generative model (the doctor verdicts).
rem  Prompts (TTY): the router model, then the main model.
rem  Arguments pass through, e.g.:  station_m5_probe.bat --smoke
rem ============================================================
chcp 65001 >nul
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 station_m5_probe.py %*
  goto done
)
where python >nul 2>nul
if %errorlevel%==0 (
  python station_m5_probe.py %*
  goto done
)
echo Python not found: install Python 3.11+ (python.org), re-run.
:done
echo.
echo ================= DONE =================
echo The zip to send back is printed by [package] above (m5_*.zip).
echo (A crashed run still leaves its diagnostic m5_*.zip — with the
echo  server logs inside — check the folder if no [package] line.)
pause
