@echo off
rem station_hroom.bat — THE H-PROSE HEADROOM INSTRUMENT (v2.2, iter-392
rem — the STOP-literalization boundary: the line-shaped candidates
rem join the markers, the earliest of all bounds the cut; v2.1 was
rem iter-390 the H8 aesthetic fix, v2.0 iter-388 the station-run
rem form, v1.0 iter-386).
rem The owner's double-click form (the m6 pack laws: the TTY model
rem prompt, the engine in the m6 v6.2 pack's llama.cpp/ beside or the
rem repo runtime / PATH, the always-a-zip at the end).
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.11+ required on PATH ^(the m6 pack's own law^).
  pause
  exit /b 1
)
python station_hroom.py %*
pause
