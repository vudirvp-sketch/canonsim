@echo off
rem station_hroom.bat — THE H-PROSE HEADROOM INSTRUMENT (v1.0, iter-386)
rem The owner's double-click form (the m6 pack laws: the TTY model
rem prompt, the engine beside (llama.cpp/ in this folder or a sibling
rem pack's), the always-a-zip at the end).
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.11+ required on PATH ^(the m6 pack's own law^).
  pause
  exit /b 1
)
python station_hroom.py %*
pause
