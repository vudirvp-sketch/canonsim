@echo off
rem station_hroom.bat — THE H-PROSE HEADROOM INSTRUMENT (v2.0, iter-388
rem — the station-run form: the -lv 4 band window verdict + the det_h
rem re-call datum; v1.0 was iter-386).
rem The owner's double-click form (the m6 pack laws: the TTY model
rem prompt, the engine in the m6 v6.2 pack's llama.cpp/ beside or the
rem repo runtime / PATH, the always-a-zip at the end).
cd /d "%~dp0"
where python >nul 2>nul
if errorlevel 1 (
  echo Python 3.11+ required on PATH ^(the m6 pack's own law^).
  pause
  exit /b 1
)
python station_hroom.py %*
pause
