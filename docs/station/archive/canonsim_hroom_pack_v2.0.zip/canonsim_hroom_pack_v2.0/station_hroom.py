#!/usr/bin/env python3
"""station_hroom.py — THE H-PROSE HEADROOM INSTRUMENT (v2.0, iter-388
— the station-run form; v1.0 was iter-386).

The owner's standing H-prose follow-up #1 (STATUS Next, the first
answerable-by-work item): «the 416-token max_tokens headroom question».
The m5 station run raised it (iter-366 §B.3): both hybrid arms hit the
HYBRID_MAX_TOKENS=416 ceiling exactly once per arm (h0 s7cy0, h8 s8cy2,
finish=length) while the natural median sat at 84/85 tokens — is 416
enough headroom, or is the cap starving legitimate prose? The m5 report
recorded the question as «the pack's v5.1 token-headroom question, not a
law defect» — this instrument is the pack-side answer machinery.

WHAT IT RUNS: the m5 hybrid core VERBATIM (the m6 pack's own machinery,
imported — never rebuilt): the full 10-unit / 42-cycle corpus
(tests/fixtures/parse_replies.json, the repo's own committed fixture),
the reference (gold) pass, then BOTH hybrid halves — h0 (temp 0) and
h8 (temp 0.8-seeded) — each cycle ONE call to the MAIN model under the
terminated-prose hybrid grammar, the door applying the JSON head through
the same gate as G. THE ONLY behavioral delta: the cap. This runner
generates at --cap (default 832, 2x the production 416) so every line's
NATURAL end is observed; the production-416 view is then DERIVED exactly
(a fixed-seed token stream is identical under any higher cap — the cap
only truncates, never changes preceding tokens): a natural stop at
N <= 416 is unaffected at 416; a line past 416 is the production
truncation set.

WHAT IT CLASSIFIES: every ceiling-hit tail (the lines still running at
the cap) gets a verdict — LOOP (a trailing repeated word n-gram, r >= 3,
or a vocabulary-collapse ratio < 0.35), BLEED (the m3 json_bleed /
protocol_echo flags), BURN (tail chars/token < 2.2 — clean English prose
rides at ~3.5-4.5 chars/token; sub-word/repetitive burn is the
degenerate signature), or LEGIT (clean long prose — the only class a
cap-raise would actually fix). The m5 station arithmetic (581/658-char
tails at ctok 416 ≈ 1.6 chars/token) already suggests the two station
ceiling-hits were degenerate tails, not headroom starvation — the
station re-run of THIS instrument on Gemma-4-E4B settles it with the
tails recorded whole.

THE HONEST FORM: the ledger records the band (CPU/CUDA, the build id,
the model file) — a 0.6B CPU-band datum is the INSTRUMENT VALIDATION
(the iter-365 precedent: the m5 sandbox validated on Qwen3-0.6B where
the h0 greedy loops are KNOWN — 8/42 by the m5 sandbox report — the
classifier's teeth), never the production answer; the production band's
own distribution comes from the owner's station run of this same pack
(pick Gemma-4-E4B at the prompt). The H-promotion basis keeps its two
halves: this instrument closes the MEASURABLE half (headroom); the
aesthetic half stays the owner's call on the same tails.

Outside the repo by law (Rule 9 / D-046 — the m5/m6 pack form): the run
writes only into its own hroom_*/ folder; the analysis carries no
decision — the owner's call. The m6 probe module is IMPORTED from the
sibling pack folder (the m6's own precedent: it imports
station_m5_doctor from beside), never modified on disk; the two-delta
fork below rides in THIS process only, printed loud at start.

THE v2.0 DELTAS (the station-run form, iter-388 — the owner's explicit
call «подготовь прогон на моей машине: станционный прогон hroom, и
вообще всё, что может потребовать тестирования» over the uploaded
v6.2 base): exactly three, everything else v1.0 verbatim —

1. THE BAND WINDOW VERDICT (the KI#122 lesson applied to the hroom
   line): v1.0's band line read the --list-devices precheck
   (cuda_visible) — the same instrument class the m6 v6.2 fix retired
   ('cpu out of silence', 'cuda by precheck luck'; the precheck CANNOT
   see the server-side DLL resolution failure). v2.0 derives the band
   from the -lv 4 window markers in hroom's OWN server log (the
   imported v6.2 SpawnedServer carries -lv 4; m6._band_from_log reads
   the load_backend/device_info markers), records cuda_visible beside
   it as the precheck datum, and finalize()s the loud run-end verdict
   the m6 form prints. The attach form (no server log) reads honestly
   «not derivable», never a guess.
2. THE det_h DATUM (the m5 det-h lesson re-measured on the run's OWN
   band — the v1.0 honest-caveat #2 named the question): the same
   hybrid call twice per arm — h0 (temp 0, the m6 det-h form verbatim:
   the 'I look around the tavern' call, the seed-125 boot, seed 42,
   the whole answer byte-compared, the digests recorded) + the h8 twin
   (temp 0.8-seeded — the seeded arm's own re-call reproducibility).
   NEVER a gate on the derived 416 view (that law is within-call by
   construction — the cap only truncates); the datum answers whether
   a RE-RUN reproduces the prose byte-for-byte.
3. hroom_units.py — the pack's own pure-half laws (the m6_units
   pattern; the owner's «всё, что может потребовать тестирования»):
   the classifier verdicts + precedence, the loop signature, the
   derived-view arithmetic, the verdict branches, the band-line
   derivation on the three log shapes, and the --help render (the
   KI#121 lesson carried onto this parser too).
"""

from __future__ import annotations

import argparse
import json
import re
import sys
import time
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Mapping

# -- locate the m6 pack (the machinery owner) ---------------------------------

_HERE = Path(__file__).resolve().parent


def _import_m6(flagged: str | None):
    """Import station_m6_probe from the sibling pack folder (the
    sibling-pack law). Preference: an explicit --m6-pack dir, then the
    highest-version canonsim_m6_station_pack* beside this file, then
    beside the CWD. Loud refusal when absent."""
    import importlib

    candidates: list[Path] = []
    if flagged:
        candidates.append(Path(flagged))
    for root in (_HERE.parent, Path.cwd().parent):
        candidates += sorted(
            root.glob("canonsim_m6_station_pack*"),
            reverse=True)
        candidates += sorted(
            (p for g in root.glob("*/canonsim_m6_station_pack*")
             for p in [g]),
            reverse=True)
    for cand in candidates:
        probe = cand / "station_m6_probe.py"
        if probe.is_file():
            sys.path.insert(0, str(cand))
            mod = importlib.import_module("station_m6_probe")
            return mod, cand
    raise SystemExit(
        "station_m6_probe.py not found: unpack this pack BESIDE the m6 "
        "station pack folder (v6.2+ — the -lv 4 band window law), or "
        "pass --m6-pack <dir>")


# -- the instrument's own knobs ------------------------------------------------

#: the sweep cap (2x the production 416 — every natural end observable)
HRM_CAP = 832
#: the production cap the question is about (the derived view)
PROD_CAP = 416
#: chars/token of clean compact JSON (the head-token estimate)
_HEAD_CPT = 3.8
#: the degenerate-burn line (chars/token of the PROSE tail below it)
_BURN_CPT = 2.2
#: the vocabulary-collapse line (unique/total words of the tail)
_LOOP_VOCAB = 0.35


def _band_line(m6, log_path: Path | None) -> tuple[str, str]:
    """THE v2.0 BAND LINE (the KI#122 lesson on the hroom line): the
    band DERIVED from the -lv 4 window markers in hroom's own server
    log — m6._band_from_log (the imported v6.2 law: ggml_cuda_init /
    load_backend-loaded-CUDA / a '- CUDA' device line = cuda; a
    device_info block with no CUDA = the honest cpu; no window = NOT
    DERIVABLE, never the old false 'cpu' certainty). The attach form
    has no server log — it reads honestly «not derivable», never a
    guess. Returns (band, the last evidence line)."""
    if log_path is None:
        return ("not derivable (attach — no server log; the -lv 4 "
                "window is a spawn-side instrument)", "attach")
    try:
        text = log_path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return ("not derivable (the server log unreadable)",
                "unreadable")
    band, marks = m6._band_from_log(text)
    return band, (marks[-1][:110] if marks else "no band marks")


def h_cycle_full(self, main_server, main_factory, door, unit_dir: Path,
                 i: int, cycle: Mapping, *, temp: float) -> dict:
    """The m6 probe's Battery.h_cycle VERBATIM with exactly TWO delta
    classes (printed loud at start; the m6 file on disk is never
    touched — this override rides in this process only):

    1. THE CAP: max_tokens=HRM_CAP (the instrument's whole point —
       the m5 core's HYBRID_MAX_TOKENS stays the production constant,
       recorded beside every run).
    2. ADDITIVE RECORDS: prose_full (the WHOLE tail — the m5 record
       caps prose at 600 chars, enough for the m3 ledger, not for tail
       classification or the owner's aesthetic reading of exactly the
       long lines) + head_chars (the JSON head's length, for the
       chars/token arithmetic). Every m5 field is carried unchanged.
    """
    m6 = _M6
    cs = self.cs
    t0 = time.monotonic()
    fp_start = self.state_fingerprint(door, unit_dir / "run.jsonl")
    call_path = door.emit_call(cycle["say"])
    doc = call_path.read_text(encoding="utf-8") + m6.HYBRID_PROTOCOL_TAIL
    _hdr, events = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
    snapshot = cs.grammar_snapshot(events, cs.PACK, door._ledger)
    hybrid = m6.hybrid_grammar(cs.gbnf_grammar(snapshot))
    result = self._chat_with_heal(
        main_server, main_factory,
        [{"role": "user", "content": doc}],
        grammar=hybrid, temp=temp, max_tokens=HRM_CAP,
        seed=42)
    record: dict[str, object] = {
        "cycle": i, "say": cycle["say"],
        "expected": cycle.get("reply"),
        "fp_start": fp_start,
        "h_temp": temp,
        "parse_wall_s": round(result.wall_s, 3),
        "parse_ptok": result.prompt_tokens,
        "parse_ctok": result.completion_tokens,
        "finish_reason": result.finish_reason,
        "hroom_cap": HRM_CAP,
    }
    content = result.content
    # THE SPLIT LAW (verbatim): the first blank line separates the
    # verdict from the prose
    head, _sep, tail = content.partition("\n\n")
    json_part = head.strip()
    prose = tail.rstrip("\n")
    record["prose"] = prose[:600]
    record["prose_full"] = prose                      # delta 2
    record["head_chars"] = len(json_part)             # delta 2
    record["prose_len"] = len(prose)
    record["eos_held"] = result.finish_reason == "length"
    record["json_bleed"] = any(
        m in prose for m in ("{\"", '"kind"', '"target"',
                             '"fields"', '"no_intent"', '"question"'))
    record["protocol_echo"] = any(
        m in prose for m in ("## ", "reply:", "ONE JSON", "verbs:",
                             "nouns:", "texture entries"))
    reply_doc = None
    off_gr = False
    try:
        reply_doc = json.loads(json_part)
    except json.JSONDecodeError:
        off_gr = True
    applied = False
    result_door = None
    if not off_gr:
        reply_path = unit_dir / f"reply_{i}.json"
        reply_path.write_text(json_part, encoding="utf-8")
        try:
            result_door = door.apply_reply(reply_path)
            applied = True
        except cs.ParseError:
            off_gr = True
        except cs.RunnerError as exc:
            record["door_error"] = str(exc)[:300]
            applied = "runner_error"
    pinned: list = []
    door_outcome = ""
    if applied is True:
        if result_door.status == "intent":
            _h2, ev2 = cs.read_log(unit_dir / "run.jsonl", cs.SCHEMA)
            door_outcome = ev2[-1].type if ev2 else ""
            pinned = list(result_door.pinned)
        else:
            door_outcome = result_door.status
    expect = cycle.get("expect", {})
    cls = m6.census_class(
        reply_doc if not off_gr else None, cycle.get("reply"),
        pinned, expect.get("pinned", ()),
    ) if cycle.get("reply") is not None else "n/a"
    if off_gr:
        cls = "off_gr"
    record.update({
        "census": cls, "pinned": pinned,
        "door_outcome": door_outcome,
        "wall_s": round(time.monotonic() - t0, 3),
    })
    return record


# -- the tail classifier -------------------------------------------------------


def _loop_signature(text: str) -> tuple[str, int]:
    """The trailing-repetition signature: the longest word k-gram
    (k in 1..8) whose immediate repetition CLOSES the text with r >= 3,
    returned as (the repeated phrase, r). ('' , 0) when none."""
    words = text.split()
    if len(words) < 6:
        return "", 0
    tail = words[-64:]
    for k in range(1, 9):
        if len(tail) < k * 3:
            break
        unit = tail[-k:]
        # count trailing consecutive copies of `unit`
        r = 0
        pos = len(tail)
        while pos >= k and tail[pos - k:pos] == unit:
            r += 1
            pos -= k
        if r >= 3:
            return " ".join(unit), r
    return "", 0


def _vocab_ratio(text: str) -> float:
    words = [w.lower() for w in text.split()]
    if not words:
        return 1.0
    return len(set(words)) / len(words)


def _classify_tail(rec: Mapping) -> dict:
    """The ceiling-hit verdict: LOOP > BLEED > BURN > LEGIT (the
    precedence — a looping tail that also bleeds is a loop)."""
    prose = str(rec.get("prose_full") or rec.get("prose") or "")
    ctok = int(rec.get("parse_ctok") or 0)
    head_chars = int(rec.get("head_chars") or 0)
    prose_len = int(rec.get("prose_len") or len(prose))
    phrase, r = _loop_signature(prose)
    vocab = _vocab_ratio(prose) if prose else 1.0
    head_tok = head_chars / _HEAD_CPT if head_chars else 0
    tail_tok = max(1, ctok - head_tok)
    cpt = prose_len / tail_tok if tail_tok else 0.0
    bleed = bool(rec.get("json_bleed")) or bool(rec.get("protocol_echo"))
    if phrase and r >= 3:
        verdict = "LOOP"
        ev = f'trailing x{r} "{phrase}"' + (
            f' + vocab {vocab:.2f}' if vocab < _LOOP_VOCAB else "")
    elif vocab < _LOOP_VOCAB:
        verdict = "LOOP"
        ev = f"vocabulary collapse {vocab:.2f} ({len(set(w.lower() for w in prose.split()))} unique / {len(prose.split())} words)"
    elif bleed:
        verdict = "BLEED"
        ev = ("json_bleed" if rec.get("json_bleed") else "protocol_echo")
    elif prose_len == 0 and ctok:
        verdict = "BURN"
        ev = (f"the JSON HEAD consumed the whole {ctok}-token budget"
              " (no blank line ever came — a head burn, the cap-raise"
              " cannot fix it)")
    elif cpt < _BURN_CPT:
        verdict = "BURN"
        ev = f"{cpt:.2f} chars/token over the tail (clean prose rides 3.5-4.5)"
    else:
        verdict = "LEGIT"
        ev = f"clean tail, {cpt:.2f} chars/token"
    return {"verdict": verdict, "evidence": ev, "chars_per_tok": round(cpt, 2),
            "vocab_ratio": round(vocab, 3), "loop_phrase": phrase,
            "loop_r": r}


def _pct(sorted_vals: list[int], p: float) -> int:
    if not sorted_vals:
        return 0
    idx = min(len(sorted_vals) - 1, max(0, round(p * (len(sorted_vals) - 1))))
    return sorted_vals[idx]


# -- the ledger ----------------------------------------------------------------


def _arm_ledger(run_dir: Path, arm: str, prod_cap: int) -> dict:
    """Per-arm headroom ledger from the arm's jsonl: the natural-ctok
    distribution, the DERIVED production-cap view, the ceiling-hit
    classification, the walls."""
    path = run_dir / f"arm_{arm}.jsonl"
    lines: list[dict] = []
    if path.is_file():
        for blob in path.read_text(encoding="utf-8").splitlines():
            rec = json.loads(blob)
            if rec.get("event") == "end":
                lines += [c for c in rec.get("cycles", [])]
    natural = sorted(int(r["parse_ctok"]) for r in lines
                     if r.get("finish_reason") == "stop")
    hits = [r for r in lines if r.get("finish_reason") == "length"]
    over = [r for r in lines
            if r.get("finish_reason") == "stop"
            and int(r.get("parse_ctok") or 0) > prod_cap]
    walls = sorted(float(r.get("wall_s") or 0) for r in lines)
    hit_walls = sorted(float(r.get("wall_s") or 0) for r in hits)
    med_wall = _pct([int(w * 1000) for w in walls], 0.5) / 1000 if walls else 0
    classified = []
    for r in hits:
        c = _classify_tail(r)
        tag = f"{r.get('say', '')[:26]}"
        classified.append({
            "unit_cycle": r.get("cycle"), "say": tag,
            "ctok": r.get("parse_ctok"), "prose_len": r.get("prose_len"),
            **c})
    return {
        "arm": arm, "n_lines": len(lines),
        "natural_stops": len(natural), "cap_hits": len(hits),
        "natural_ctok": {
            "min": natural[0] if natural else 0,
            "p25": _pct(natural, 0.25), "med": _pct(natural, 0.5),
            "p75": _pct(natural, 0.75), "p90": _pct(natural, 0.90),
            "max": natural[-1] if natural else 0},
        "prod_cap": prod_cap,
        "prod_view_over": len(over),
        "prod_view_over_lines": [
            {"cycle": r.get("cycle"), "ctok": r.get("parse_ctok"),
             "prose_len": r.get("prose_len")} for r in over],
        "hit_classification": classified,
        "hit_classes": {
            v: sum(1 for c in classified if c["verdict"] == v)
            for v in ("LOOP", "BLEED", "BURN", "LEGIT")},
        "walls": {
            "med_s": med_wall,
            "max_s": walls[-1] if walls else 0,
            "hit_med_s": (_pct([int(w * 1000) for w in hit_walls], 0.5)
                          / 1000 if hit_walls else 0)},
    }


# -- the det_h datum (v2.0 delta 2) --------------------------------------------


def _run_det_h(m6, battery, run_dir: Path, main_server, main_factory,
               deadline: float | None, arms: tuple[str, ...]) -> str:
    """THE det_h DATUM (v2.0 — the m5 det-h lesson re-measured on THIS
    run's own band): the same terminated-prose hybrid call twice per
    arm — h0 (temp 0, the m6 run_det h-half form VERBATIM: the 'I look
    around the tavern' call, the seed-125 boot, seed 42, the whole
    answer byte-compared, the digest recorded) and the h8 twin (temp
    0.8-seeded — the seeded arm's own re-call reproducibility datum).
    NEVER a gate on the derived 416 view (the within-call
    cap-invariance law needs no re-call); the datum answers whether a
    RE-RUN of the pack reproduces the prose byte-for-byte. Resumable
    per arm (det.jsonl, the m6 _load_units law)."""
    out = run_dir / "det.jsonl"
    done = m6._load_units(out)
    for arm, temp in (("h0", 0.0), ("h8", 0.8)):
        if arm not in arms or arm in done:
            continue
        if deadline is not None and time.monotonic() > deadline:
            return "budget"
        unit = run_dir / "det" / arm
        unit.mkdir(parents=True, exist_ok=True)
        sim, mediator, door, log = battery.boot(unit, 125, ())
        call_path = door.emit_call("I look around the tavern")
        call = call_path.read_text(
            encoding="utf-8") + m6.HYBRID_PROTOCOL_TAIL
        _hdr, events = battery.cs.read_log(
            unit / "run.jsonl", battery.cs.SCHEMA)
        snapshot = battery.cs.grammar_snapshot(
            events, battery.cs.PACK, door._ledger)
        hybrid = m6.hybrid_grammar(battery.cs.gbnf_grammar(snapshot))
        r1 = battery._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": call}],
            grammar=hybrid, temp=temp, max_tokens=HRM_CAP, seed=42)
        r2 = battery._chat_with_heal(
            main_server, main_factory,
            [{"role": "user", "content": call}],
            grammar=hybrid, temp=temp, max_tokens=HRM_CAP, seed=42)
        m6._append_jsonl(out, {
            "event": "end", "unit": arm, "temp": temp,
            "identical": r1.content == r2.content,
            "digest1": m6.hashlib_short(r1.content),
            "digest2": m6.hashlib_short(r2.content),
            "ctok1": r1.completion_tokens,
            "ctok2": r2.completion_tokens,
            "finish1": r1.finish_reason, "finish2": r2.finish_reason,
        })
        print(f"[det_h] {arm}: identical={r1.content == r2.content} "
              f"(ctok {r1.completion_tokens}/{r2.completion_tokens}, "
              f"finish {r1.finish_reason})", flush=True)
        sim.close()
    return "done"


def _det_ledger(run_dir: Path) -> list[dict]:
    """The det.jsonl read for the report's DET DATUM section."""
    path = run_dir / "det.jsonl"
    rows: list[dict] = []
    if path.is_file():
        for blob in path.read_text(encoding="utf-8").splitlines():
            rec = json.loads(blob)
            if rec.get("event") == "end":
                rows.append(rec)
    return rows


def _verdict_text(ledgers: list[dict], cap: int, prod_cap: int,
                  model: str, band: str) -> str:
    """THE HEADROOM VERDICT — the ledger's own reading, honestly scoped
    to the band it was measured on."""
    all_over = sum(l["prod_view_over"] for l in ledgers)
    all_hits = sum(l["cap_hits"] for l in ledgers)
    degenerate = sum(l["hit_classes"]["LOOP"] + l["hit_classes"]["BLEED"]
                     + l["hit_classes"]["BURN"] for l in ledgers)
    legit = sum(l["hit_classes"]["LEGIT"] for l in ledgers)
    max_nat = max((l["natural_ctok"]["max"] for l in ledgers), default=0)
    lines = [
        f"THE HEADROOM VERDICT (cap {cap}, band {band}, model {model}):",
        f"  natural stops: {sum(l['natural_stops'] for l in ledgers)}"
        f" lines, max natural ctok {max_nat} — the production cap"
        f" {prod_cap} covers {'100%' if all_over == 0 else 'NOT all'}"
        " of the natural prose"
        + ("" if all_over == 0 else
           f" ({all_over} natural line(s) exceed it)"),
        f"  ceiling-hits at {cap}: {all_hits} — classified"
        f" LOOP/BLEED/BURN {degenerate}, LEGIT {legit}",
    ]
    if all_over == 0 and degenerate > 0 and legit == 0:
        lines.append(
            f"  -> on THIS band the cap {prod_cap} is NOT the missing"
            " headroom: every ceiling-hit is a degenerate tail a"
            " cap-raise cannot fix (the fix class is tail-breaking or"
            " accept-and-flag). The station run on the production model"
            " settles the production band's own distribution.")
    elif legit > 0 or all_over > 0:
        need = max(max_nat, prod_cap)
        lines.append(
            f"  -> legitimate prose exceeds {prod_cap} on this band;"
            f" the minimal all-natural cap is ~{int(need * 1.1)}"
            f" (max natural {max_nat} + 10% margin).")
    else:
        lines.append(
            "  -> no ceiling pressure observed on this band; the"
            " production cap stands with wide margin.")
    return "\n".join(lines)


def _write_report(run_dir: Path, ledgers: list[dict], verdict: str,
                  head: dict) -> None:
    out = [f"HROOM REPORT — the hybrid prose headroom instrument",
           f"pack v2.0 (iter-388, the station-run form) · {head['time']}",
           f"engine: {head['engine']}",
           f"model: {head['model']}",
           f"band: {head['band']} (mark: {head.get('band_mark', '')})",
           f"cuda_visible (the precheck datum): {head.get('cuda_visible')}",
           f"corpus: {head['corpus']}",
           f"sweep cap: {head['cap']} · production cap: {head['prod_cap']}",
           ""]
    for l in ledgers:
        nat = l["natural_ctok"]
        out += [
            f"ARM {l['arm']} — {l['n_lines']} lines"
            f" (natural {l['natural_stops']}, cap-hit {l['cap_hits']})",
            f"  natural ctok: min {nat['min']} · p25 {nat['p25']}"
            f" · med {nat['med']} · p75 {nat['p75']} · p90 {nat['p90']}"
            f" · max {nat['max']}",
            f"  THE {l['prod_cap']} VIEW (derived): natural lines over"
            f" the production cap: {l['prod_view_over']}"
            + ("" if not l["prod_view_over_lines"] else
               " — " + ", ".join(
                   f"c{d['cycle']}@{d['ctok']}tok" for d
                   in l["prod_view_over_lines"])),
            f"  ceiling-hit classes: {l['hit_classes']}",
        ]
        for c in l["hit_classification"]:
            out.append(f"    [{c['verdict']}] c{c['unit_cycle']}"
                       f" ctok {c['ctok']} prose {c['prose_len']}ch"
                       f" — {c['evidence']}")
        out += [
            f"  walls: med {l['walls']['med_s']}s · max"
            f" {l['walls']['max_s']}s · cap-hit med"
            f" {l['walls']['hit_med_s']}s",
            "",
        ]
    det_rows = _det_ledger(run_dir)
    if det_rows:
        out += ["THE DET DATUM (v2.0 — the re-call law on THIS band, the",
                "  m5 det-h lesson re-measured; NEVER a gate on the",
                "  derived 416 view — that law is within-call):", ""]
        for r in det_rows:
            out.append(
                f"  {r.get('unit')} (temp {r.get('temp')}):"
                f" identical={r.get('identical')} — digests"
                f" {r.get('digest1')}/{r.get('digest2')},"
                f" ctok {r.get('ctok1')}/{r.get('ctok2')},"
                f" finish {r.get('finish1')}/{r.get('finish2')}")
        out += ["  -> identical=False does NOT undermine the derived 416", 
                "     view (the cap-invariance law is within-call by",
                "     construction); the datum answers whether a RE-RUN of",
                "     the pack reproduces the prose byte-for-byte.", ""]
    out += [verdict, "",
            "The analysis carries no decision — the owner's call.",
            "The aesthetic half of the H-promotion basis rides the same"
            " tails (prose_full in the jsonl)."]
    (run_dir / "hroom_report.txt").write_text(
        "\n".join(out), encoding="utf-8")


def _package(run_dir: Path, crashed: bool) -> Path:
    """The always-a-zip law (iter-353, the m3 form: the run dir's
    evidence, the models excluded, the SERVER LOGS included): the run
    ALWAYS ships its evidence home, crashed or not."""
    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    zip_path = run_dir.parent / (
        f"hroom_{ts}{'_CRASH' if crashed else ''}.zip")
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for p in sorted(run_dir.rglob("*")):
            if p.is_file() and p.suffix in (".json", ".jsonl", ".txt",
                                            ".md", ".log"):
                zf.write(p, p.relative_to(run_dir.parent))
    print(f"[package] {zip_path} "
          f"({zip_path.stat().st_size} bytes)", flush=True)
    return zip_path


_M6 = None  # set by main (the imported m6 probe module)


def main(argv=None) -> int:
    global _M6, HRM_CAP
    ap = argparse.ArgumentParser(
        prog="station_hroom.py",
        description="the H-prose headroom instrument (iter-386 v1.0;"
                    " the v2.0 station-run form iter-388): the m5"
                    " hybrid core at a raised cap, the natural-end"
                    " distribution + the tail classification — the"
                    " 416-token question's answer machinery")
    ap.add_argument("--m6-pack", default=None,
                    help="the m6 pack FOLDER (station_m6_probe.py);"
                         " default: the sibling canonsim_m6_* beside")
    ap.add_argument("--repo", default=None,
                    help="the canonsim repo (else the m6 discovery law)")
    ap.add_argument("--cap", type=int, default=HRM_CAP,
                    help=f"the sweep cap (default {HRM_CAP} = 2x416)")
    ap.add_argument("--prod-cap", type=int, default=PROD_CAP,
                    help=f"the production cap (default {PROD_CAP})")
    ap.add_argument("--model-file", default=None,
                    help="the MAIN model gguf (required without --endpoint"
                         " on a non-TTY; the TTY form prompts)")
    ap.add_argument("--endpoint", default=None,
                    help="ATTACH to a live llama-server (no spawn)")
    ap.add_argument("--ctx", type=int, default=4096)
    ap.add_argument("--batch", type=int, default=2048,
                    help="the spawn -b (the m6 batch law)")
    ap.add_argument("--ubatch", type=int, default=512)
    ap.add_argument("--server-arg", action="append", default=[],
                    help="extra llama-server args (repeatable)")
    ap.add_argument("--no-h8", action="store_true",
                    help="h0 only")
    ap.add_argument("--run-dir", default=None)
    ap.add_argument("--time-budget", type=int, default=None,
                    help="clean exit through N seconds (resumable)")
    ap.add_argument("--smoke", action="store_true",
                    help="2 units only (the chain check)")
    ap.add_argument("--yes-cpu", action="store_true",
                    help="the device gate's CPU override")
    args = ap.parse_args(argv)

    HRM_CAP = args.cap
    m6, m6_dir = _import_m6(args.m6_pack)
    _M6 = m6
    if not hasattr(m6, "_band_from_log"):
        # the v2.0 band window needs the v6.2 spawn (-lv 4); an older
        # sibling pack degrades the verdict honestly — say it LOUD
        print("[hroom] WARNING: the imported m6 pack predates v6.2 —"
              " no -lv 4 band window; the band verdict will read"
              " 'not derivable' (the m6 v6.2+ pack is the required"
              " base, the uploaded station copy)", flush=True)

    repo, _tried, found = m6.find_repo(args.repo)
    if not found:
        raise SystemExit("the canonsim repo was not found — pass --repo")
    ns = m6.RepoNS(repo)

    ts = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    run_dir = (Path(args.run_dir) if args.run_dir
               else Path(f"hroom_{ts}"))
    if args.smoke and "smoke" not in run_dir.name:
        run_dir = run_dir.with_name(run_dir.name + "_smoke")
    run_dir.mkdir(parents=True, exist_ok=True)
    battery = m6.Battery(repo, run_dir, ns, smoke=args.smoke)
    if args.smoke:
        battery.corpus["cases"] = battery.corpus["cases"][:2]
    n_cases = len(battery.corpus["cases"])

    if args.yes_cpu:
        m6._ALLOW_CPU = True  # the device gate's override (module global)

    # THE FORK, printed loud (the m6 file on disk is never touched)
    m6.Battery.h_cycle = h_cycle_full
    m6.HYBRID_MAX_TOKENS = HRM_CAP
    print(f"[hroom] pack v2.0 (the station-run form) · m6 probe:"
          f" {m6_dir}", flush=True)
    print(f"[hroom] repo {repo} · run {run_dir}"
          f" ({'smoke' if args.smoke else 'full'} corpus,"
          f" {n_cases} units)", flush=True)
    print(f"[hroom] FORK: Battery.h_cycle -> h_cycle_full"
          f" (2 deltas: cap {HRM_CAP} + full-tail records;"
          " the m6 form verbatim otherwise)", flush=True)

    # -- the engine ladder (attach | autospawn) ------------------------------
    if args.endpoint:
        if not m6.LlamaClient(args.endpoint).health():
            raise SystemExit(f"--endpoint {args.endpoint} is dead")
        main_server, main_factory = None, (
            lambda: m6.LlamaClient(args.endpoint))
        engine = f"attach {args.endpoint}"
        model = str(m6._model_id_for(args.endpoint))
    else:
        exes = m6._exe_candidates(repo)
        if not exes:
            raise SystemExit(
                "no llama-server found — unpack the engine into this"
                " pack's llama.cpp/ or extend PATH")
        exe = exes[0]
        models = m6._gguf_models(repo)
        if args.model_file:
            model_path = Path(args.model_file)
            if not model_path.is_file():
                raise SystemExit(f"--model-file {model_path} not found")
        elif models and sys.stdin.isatty():
            model_path = m6._tty_model_choice(models, "main (the H prose)")
        else:
            raise SystemExit(
                "no --model-file and no TTY — pass --model-file"
                " (the main model, e.g. the station's Gemma-4-E4B)")
        main_server = m6.SpawnedServer(
            exe, model_path, ctx=args.ctx, extra=list(args.server_arg),
            log_path=run_dir / "hroom_llama_main.log",
            batch=args.batch, ubatch=args.ubatch)
        main_server.start()
        main_factory = lambda: m6.LlamaClient(main_server.endpoint)
        engine = f"{exe} (ctx {args.ctx}, -b {args.batch})"
        model = model_path.name

    # THE v2.0 BAND LINE (delta 1): derived from the -lv 4 window
    # markers in hroom's own server log — NEVER the v1.0 cuda_visible
    # guess; cuda_visible rides beside it as the precheck datum.
    main_log = (run_dir / "hroom_llama_main.log"
                if main_server is not None else None)
    band, band_mark = _band_line(m6, main_log)
    cuda_visible = m6.DEVICE_GATE.cuda_visible
    print(f"[hroom] band: {band} (mark: {band_mark}) · cuda_visible:"
          f" {cuda_visible}", flush=True)
    head = {
        "time": datetime.now(timezone.utc).isoformat(),
        "engine": engine, "model": model, "band": band,
        "band_mark": band_mark, "cuda_visible": cuda_visible,
        "corpus": f"{n_cases} units",
        "cap": HRM_CAP, "prod_cap": args.prod_cap,
        "m6_pack": str(m6_dir), "repo": str(repo),
    }
    (run_dir / "hroom_preflight.json").write_text(
        json.dumps(head, indent=2, sort_keys=True), encoding="utf-8")

    deadline = (time.monotonic() + args.time_budget
                if args.time_budget else None)
    crashed = False
    status: dict[str, str] = {}
    try:
        print("[hroom] stage reference (the gold pass, CPU)...",
              flush=True)
        m6.run_reference(battery, run_dir)
        status["reference"] = "done"

        for arm in ("h0", "h8"):
            if arm == "h8" and args.no_h8:
                status[arm] = "skipped (--no-h8)"
                continue
            print(f"[hroom] stage {arm} at cap {HRM_CAP}...",
                  flush=True)
            st = m6.run_arm(battery, arm, run_dir, main_server,
                            main_factory, None, None, deadline)
            status[arm] = st
            if st == "budget":
                break
        if not any(v == "budget" for v in status.values()):
            print("[hroom] stage det_h (the re-call datum)...",
                  flush=True)
            status["det_h"] = _run_det_h(
                m6, battery, run_dir, main_server, main_factory,
                deadline,
                ("h0",) if args.no_h8 else ("h0", "h8"))
    except BaseException:
        crashed = True
        raise
    finally:
        # THE v2.0 RUN-END BAND VERDICT (the m6 form, delta 1):
        # re-observe the server log, say the verdict LOUD, re-derive
        # the report's band from the markers (never the precheck).
        try:
            if main_server is not None:
                m6.DEVICE_GATE.finalize(
                    {"main": run_dir / "hroom_llama_main.log"})
                band, band_mark = _band_line(
                    m6, run_dir / "hroom_llama_main.log")
                head["band"] = band
                head["band_mark"] = band_mark
                head["cuda_visible"] = m6.DEVICE_GATE.cuda_visible
        except Exception as exc:  # noqa: BLE001
            print(f"[hroom] the band finalize failed: {exc}",
                  flush=True)
        if main_server is not None:
            main_server.stop()
        ledgers = []
        try:
            for arm in ("h0", "h8"):
                if (run_dir / f"arm_{arm}.jsonl").is_file():
                    ledgers.append(
                        _arm_ledger(run_dir, arm, args.prod_cap))
            if ledgers:
                verdict = _verdict_text(ledgers, HRM_CAP, args.prod_cap,
                                        model, band)
                head["stages"] = status
                _write_report(run_dir, ledgers, verdict, head)
                print("\n" + verdict + "\n", flush=True)
        except Exception as exc:  # the ledger never blocks the zip
            print(f"[hroom] ledger pass failed: {exc}", flush=True)
        zip_path = _package(run_dir, crashed)
        print(f"[hroom] package: {zip_path}", flush=True)
        print(f"[hroom] stages: {status}", flush=True)
        if crashed:
            print("[hroom] CRASHED — the zip carries the evidence",
                  flush=True)
    return 0 if not crashed else 1


if __name__ == "__main__":
    raise SystemExit(main())
