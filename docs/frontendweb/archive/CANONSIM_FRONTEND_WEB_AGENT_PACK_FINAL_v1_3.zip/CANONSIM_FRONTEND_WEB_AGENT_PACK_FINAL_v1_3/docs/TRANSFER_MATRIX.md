# Transfer Matrix — Workbench → Active Web Frontend

| Source capability | Transfer into web stack | Ownership | Status |
|---|---|---|---|
| composition root / ownership law | exact transfer | frontend | mandatory |
| typed gateway contract + runtime validation | exact transfer | frontend/api | mandatory |
| operation/execution identity | expose and preserve | application-owned | mandatory |
| deadlines / cancellation / terminality | render truthful state; no reimplementation | application-owned | mandatory |
| execution artifact / provenance | read-only display/reproduction linkage | application-owned | mandatory |
| session sequence / replay / RESYNC_REQUIRED | client reconnect/resync adapter | gateway-owned | mandatory |
| shared semantic selection | transfer | frontend/observatory | when read-side supports it |
| context identity strip | transfer | frontend/observatory | mandatory for analytical surfaces |
| semantic zoom | transfer | frontend/observatory | when view supports it |
| compare BASE/PERTURBED | transfer | frontend/observatory | when read-side supports it |
| timeline / bounded graph policy | transfer | frontend/observatory | as analytical views land |
| evidence ladder / epistemic grammar | transfer | frontend/observatory | mandatory for evidence surfaces |
| empty/no-result distinctions | transfer | frontend | mandatory |
| persistent analytical workspace | transfer | frontend/session | when investigative surface exists |
| Evidence Capsule | transfer as read-only artifact | application/read-side | contract-gated |
| Scene IR | preserve renderer neutrality | Workbench/read-side | mandatory |
| asset manifest / identity / lifecycle | transfer | scene/assets | scene-gated |
| camera semantic vs presentation split | transfer | scene | scene-gated |
| screenshot-driven development | transfer | tests/proof | mandatory |
| static/runtime/task proof separation | transfer | tests/proof | mandatory |
| graceful degradation / boundedness | transfer | frontend | mandatory |
| native OS affordances | preserve principle, use web-native equivalent where appropriate | frontend | heuristic/gated |
| active repo binding laws | route implementation through current repo owners before historical source documents | repo ownership | mandatory |
| requested/accepted/effective/observed/presented closure | preserve distinction and display only application-backed effective/observed state | application-owned | mandatory |
| model lifecycle | expose discovery/validation/selection/loading/loaded/active/failure/eviction states where exposed | application-owned | mandatory when surfaced |
| prompt/profile composition | preserve application-owned composition and frozen execution inputs | application-owned | mandatory when surfaced |
| simulation pack identity | preserve logical id + revision/schema/content/compatibility where exposed; path is locator only | application/read-side | mandatory when surfaced |
| Trajectory / ordered trace view | transfer as analytical surface | frontend/observatory | when investigative surface exists |
| Surface module boundaries | transfer | frontend | mandatory |
| Multi-tab independent clients | transfer (browser-specific) | frontend | mandatory |
| Gateway client transport isolation | transfer | frontend/api | mandatory |
| Bounded list virtualization | transfer | frontend | mandatory for large read models |
| PWA/offline stale marking | transfer when PWA shipped | frontend | gated |
| Harness-quality failure presentation | transfer | frontend | mandatory for material ops |
| Dual-read LIVE vs HISTORY | transfer | frontend/observatory | mandatory when both exist |
| Connection budget / focused-tab stream policy | transfer (browser-specific) | frontend | mandatory before multi-tab SSE |
| Skeleton S0 gate | process | frontend | mandatory before full matrix |
| Tooling floor (boundaries, runtime validation, virtualization proof) | transfer | frontend/ci | post-S0 then mandatory |
| Layout manifest / schema settings | optional P1 | frontend | gated |

