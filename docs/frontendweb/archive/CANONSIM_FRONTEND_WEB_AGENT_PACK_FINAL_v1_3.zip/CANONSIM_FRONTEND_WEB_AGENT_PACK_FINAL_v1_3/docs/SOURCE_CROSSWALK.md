# Source Crosswalk

| Source | Use |
|---|---|
| `CANONSIM_WORKBENCH_APPLICATION_ARCHITECTURE_V5_2.md` | ownership, execution, persistence, gateway, lifecycle, failure matrix |
| `CANONSIM_FRONTEND_UI_VISUAL_ENGINEERING_SPEC_V5_2.md` | UI/UX, accessibility, responsive, state honesty, proof/agent workflow |
| `CANONSIM_VISUAL_PRESENTATION_RUNTIME_ARCHITECTURE_V5_2.md` | Scene IR, assets, camera, bounded rendering, visual proof |
| `CANONSIM_WORLD_OBSERVATORY_AND_CONTROL_PLANE_V5_2.md` | analytical/read-side semantics and evidence model |
| `canonsim_workbench_ultimate_frontend_ui_ux_visual_architecture_2026-09-25.md` | integrated analytical UX, selection, compare, evidence, workspace model |
| `repo-ground-truth/workbench/api/contract.py` | actual gateway envelope fields/vocabularies |
| `repo-ground-truth/workbench/api/transport.py` | actual current transport route |
| `repo-ground-truth/workbench/application/artifact.py` | actual execution artifact/provenance seam |
| `repo-ground-truth/workbench/application/operations/execution.py` | actual deadline/cancellation/progress/execution lifecycle |
| `repo-ground-truth/workbench/scene_ir.py` | actual Scene IR implementation |
| `repo-ground-truth/workbench/observatory_read.py` | actual bounded Observatory read model/cursors |
| relevant tests | executable evidence of current backend seam behaviour |


## Active repository law (higher priority than historical source-workbench)

| Source | Use |
|---|---|
| `repo/docs/AGENT_NAVIGATION.md` | current repository routing / reading gradient |
| `repo/docs/FRONTEND_UIUX_LAW.md` | active frontend interaction / IA / accessibility law |
| `repo/docs/VISUAL_SYSTEM_UI.md` | active surface/container/token/visual-state law |
| `repo/docs/WORKBENCH_APP_LAW.md` | active application/runtime ownership, model lifecycle, prompt/reproduction/resource contracts |
| `repo/docs/OBSERVATORY_LAW.md` | active analytical/read-side/evidence law |
| `repo/docs/WORLD_PRESENTATION_LAW.md` | active Scene IR/world-presentation law |
| `repo/docs/LLAMA_CPP_INFERENCE_CONTROL_LAW.md` | active inference-control semantics |
| `repo/docs/REDOT_ENGINE_INDEX.md` | historical/reference-only Redot routing |
| `repo/docs/SSI_TOPOLOGY.md` | current ownership/topology evidence |
| `repo/docs/ssi/SSI_OVERLAY.md` | current risk/negative-rule/owner-gating discipline |

These active owner documents supersede conflicting historical statements in `source-workbench/`. The web pack remains a derived implementation aid.
