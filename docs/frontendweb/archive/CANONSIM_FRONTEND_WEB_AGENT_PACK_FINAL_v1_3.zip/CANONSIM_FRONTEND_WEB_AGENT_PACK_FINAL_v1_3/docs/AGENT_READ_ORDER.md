# Agent read order

## Phase S0 (walking skeleton) — read only these first
1. `SKELETON_ACCEPTANCE.md` — **primary gate until green**
2. `00_FRONTEND_STACK_DECISION_v1_5.md` (decision + non-goals only; skip deep visual essays)
3. `SEAM_CONTRACTS.md` (gateway POST /op, dual-read summary)
4. `EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md` (do not collapse requested→effective)
5. `BROWSER_RUNTIME_AND_SCALABILITY_CONTRACT.md` § multi-tab + §9 stream summary
6. `REPO_GROUND_TRUTH.md` (snapshot vs live repo)

Do **not** start S0 by reading source-workbench V5.2, full ACCEPTANCE_MATRIX, layout manifest, or SSE design.

## After S0 green — full order
1. `00_FRONTEND_STACK_DECISION_v1_5.md`
2. `ACTIVE_REPO_ROUTING.md`
3. `EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md`
4. `SKELETON_ACCEPTANCE.md` (keep as historical gate record)
5. `HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md`
6. `BROWSER_RUNTIME_AND_SCALABILITY_CONTRACT.md`
7. `STREAM_AND_CONNECTION_BUDGET_CONTRACT.md`
8. `SURFACE_MODULE_CONTRACT.md`
9. `TRANSFER_MATRIX.md`
10. `SEAM_CONTRACTS.md`
11. `OBSERVATORY_UX_CONTRACT.md`
12. `VISUAL_PROOF_CONTRACT.md`
13. `ACCEPTANCE_MATRIX.md`
14. `HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md` (optional P1 only)
15. `REPO_GROUND_TRUTH.md`
16. Expand `source-workbench/`, `repo-ground-truth/`, or `legacy-redot-reference/` only for the exact seam being changed.

Do not invent a React-specific semantic authority, second event bus, or browser-side execution engine.
Do not implement SSE/WebSocket routes before their gateway contract exists.
Treat multi-tab clients as independent; never promote browser storage to canon.
Live session tail ≠ durable history.
