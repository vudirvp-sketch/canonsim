# Repository Ground Truth Snapshot

Snapshot source: supplied `canonsim(1).zip`, inspected on 2026-09-28.

## Current active implementation
- Python Workbench application exists under `workbench/`.
- Gateway contract exists under `workbench/api/contract.py`.
- Current HTTP transport is `workbench/api/transport.py` with `POST /op`.
- Gateway owns per-session ordered events and bounded `session.events` replay with `RESYNC_REQUIRED` semantics.
- Execution runtime includes operation/execution identity, deadlines, cooperative cancellation, progress and truthful UNKNOWN handling.
- `ExecutionArtifact` exists with frozen inputs, provenance, capability snapshot and reproducibility vocabulary.
- Visual Scene IR exists in `workbench/scene_ir.py`.
- Observatory read-side exists in `workbench/observatory_read.py` and uses bounded windows / event-id cursors.
- Existing CI is `.github/workflows/ci.yml`: Python 3.12.14, ruff, pytest.
- No React/Vite frontend is present in the supplied repo snapshot.
- Redot presentation tree exists historically under `workbench/presentation/redot/`.

## Snapshot provenance
- Git `HEAD`: `cd84069436187279b8e92b22f03169904a422f11`
- `BASE_COMMIT.txt`: `8ec6442d8406d901a0605175474bbd61dd3954da`
- Working tree: dirty at capture time
- `git status --porcelain` entries: 131 (`124` tracked modified, `7` untracked)

This pack therefore captures a working-tree checkpoint, not a clean HEAD-only repository.

## Implication for agents
Do not describe future browser SSE/WebSocket as already implemented.
Do not treat `source-workbench/` as the current architectural owner when an active `repo/docs/*_LAW.md` file covers the same concern; route through `ACTIVE_REPO_ROUTING.md`. Do not build a second execution engine in React. Do not replace the Python verification stack; add web verification alongside it.
