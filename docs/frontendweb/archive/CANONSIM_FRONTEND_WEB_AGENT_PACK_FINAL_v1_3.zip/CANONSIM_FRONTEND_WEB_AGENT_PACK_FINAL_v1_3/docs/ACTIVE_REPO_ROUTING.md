# Active Repository Routing

## Purpose

This file is the web-agent's compact routing map for the supplied CanonSim repository snapshot.
It prevents archived Workbench documents, Redot references, and the web pack itself from being mistaken for the live repository's binding owner.

## Authority precedence

For a question about the implementation that is currently active in the repository, use this order:

```text
ACTIVE REPO BINDING LAW
    > current executable implementation/tests
    > this pack's derived web contract
    > selected historical Workbench source
    > Redot reference
```

This pack is a derived implementation aid. It is not a second source of truth.
When an active repository law is updated, the web-agent must re-check this routing map and the affected derived contract before changing frontend architecture.

## Binding owners

| Question / area | First active owner | What the web agent may take from it |
|---|---|---|
| Agent navigation / where things are | `docs/AGENT_NAVIGATION.md` | current repo map, ownership/routing, reading gradient |
| Frontend interaction / IA / UX | `docs/FRONTEND_UIUX_LAW.md` | information architecture, task grammar, accessibility, proof workflow, analytical interaction law |
| Visual system / containers / visual states | `docs/VISUAL_SYSTEM_UI.md` | surface/container grammar, token/dimension rules, visual state matrix, functional-first delivery |
| Application/runtime ownership | `docs/WORKBENCH_APP_LAW.md` | authority boundaries, execution/lifecycle, prompt ownership, model lifecycle, reproducibility, resource admission |
| Observatory analytical semantics | `docs/OBSERVATORY_LAW.md` | run identity, questions, evidence, projections, observation boundaries, read-side ownership |
| World presentation / Scene IR | `docs/WORLD_PRESENTATION_LAW.md` | Scene IR, composition, asset identity, camera separation, degradation, performance |
| Inference control | `docs/LLAMA_CPP_INFERENCE_CONTROL_LAW.md` | effective-state semantics, control ownership, per-control state vocabulary; not backend implementation in React |
| Redot version/reference status | `docs/REDOT_ENGINE_INDEX.md` | historical/reference information only; never active frontend authority |
| ownership/topology | `docs/SSI_TOPOLOGY.md` | current owner/reads/writes map; first stop for cross-boundary ownership questions |
| SSI control/risk overlay | `docs/ssi/SSI_OVERLAY.md` | negative rules, risk ladder, PCC/deletion forms, owner-gated phase discipline |

## Current checkpoint

Snapshot source: supplied `canonsim(1).zip`, inspected 2026-09-28.

```text
HEAD:                  cd84069436187279b8e92b22f03169904a422f11
BASE_COMMIT.txt:       8ec6442d8406d901a0605175474bbd61dd3954da
WORKTREE:              dirty
STATUS ENTRIES:        131
  tracked modified:   124
  untracked:             7
REACT FRONTEND:        not present in supplied snapshot
PYTHON WORKBENCH:      active
REDOT PRESENTATION:    historical/reference tree present
```

The snapshot therefore represents a working-tree checkpoint, not a clean HEAD-only source state.
Do not infer that a file is absent from HEAD merely because it is modified here, and do not infer that a working-tree observation is already committed product law.

## Routing rules

1. Read this file before changing frontend ownership or architecture.
2. Read the active owner document before the derived web-pack section that depends on it.
3. Treat `source-workbench/` as historical source material, not the active owner.
4. Treat `repo-ground-truth/` as pinned executable evidence, not a substitute for the live repository.
5. If an active owner and the web pack disagree, stop at the seam, identify the exact contradiction, and update the derived contract before implementing.
6. Do not import an owner document's backend/platform mechanism into React merely because the frontend must display its state.
7. Preserve the owner's authority boundary: display/interaction may cross a seam; ownership does not.

## Required active frontend re-home

The repository decision already calls for active frontend routing away from Redot. The web implementation is therefore the first active browser frontend; Redot remains an archive/reference surface.

The web agent must not treat these historical documents as a competing active architecture:

```text
source-workbench/CANONSIM_WORKBENCH_APPLICATION_ARCHITECTURE_V5_2.md
source-workbench/CANONSIM_FRONTEND_UI_VISUAL_ENGINEERING_SPEC_V5_2.md
source-workbench/CANONSIM_VISUAL_PRESENTATION_RUNTIME_ARCHITECTURE_V5_2.md
source-workbench/CANONSIM_WORLD_OBSERVATORY_AND_CONTROL_PLANE_V5_2.md
```

Use them for provenance and historical rationale only after routing through the active repo owners above.
