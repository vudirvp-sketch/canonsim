# Harness Surface and Traceability Contract

**Status:** ACTIVE (web frontend law)  
**Audience:** Coding agents / maintainers  
**Intent:** Give the web client DeepSeek-Harness-class observability and composability **without** importing a second plugin runtime, Cordis kernel, or browser-side execution engine.

## 1. Design intent (not a dependency)

DeepSeek Harness quality target, mapped to CanonSim ownership:

| Harness idea | CanonSim / web ownership |
|---|---|
| Everything is a plugin | Surfaces are composition modules; capabilities stay on Workbench/gateway |
| Every run is traceable | `session.events` + execution artifacts + provenance + Observatory |
| Resume / fork / search / replay | Application-owned identities; UI only presents and dispatches |
| Trajectory view | First-class analytical surface over ordered event/execution evidence |
| Models, tools, sessions, UI swappable | UI surfaces swappable; semantic plugins stay server-side |
| Append-only session log | Backend event log + retained sequence; browser never authors canon |

**Rule:** Import the *quality bar*, not the *runtime*. Do not port Cordis, dsh plugin mounting, or a browser agent loop.

## 2. Trajectory surface (mandatory analytical class)

When an investigative or control-plane surface exists, provide a **Trajectory** view (name may vary) that is a read-only projection of application evidence:

```text
ordered session/event stream
+ execution identities
+ material input freeze points
+ model/runtime capability snapshots where exposed
+ acceptance / rejection / UNKNOWN outcomes
+ cancellation and resource-pressure outcomes
+ provenance / replay_of lineage
```

Requirements:

1. Primary cursor is a semantic id (event id, execution id, sequence), never row index.
2. Resume/reconnect uses retained sequence + `RESYNC_REQUIRED`; never blind duplicate dispatch.
3. Search/filter is a client query over a bounded read-side window, not a second log store.
4. Fork/replay UI always creates or requests a **new** execution identity; lineage via `replay_of` when exposed.
5. Trajectory never mutates canon. Mutations go only through gateway ops.

Empty-state grammar applies: `NO DATA ≠ NO MATCH ≠ STALE ≠ FAILED ≠ PARTIAL ≠ OUT OF SCOPE`.

## 3. Surface module contract (composability without a plugin kernel)

Each material Workbench surface is a **surface module**:

```text
surface module =
  ownership id
  + typed gateway adapters used
  + local presentation state only
  + declared honest state matrix
  + entry points (routes/commands)
  + tests/fixtures/proof hooks
```

Rules:

1. One visible composition root for the app; surface modules mount under it.
2. Surface modules may not own canonical state, event buses, or retry/deadline policy.
3. Cross-surface communication uses shared selection identity and gateway-backed evidence — not a private event bus, not `localStorage` as authority, not ad-hoc globals.
4. Adding a surface must not require rewriting gateway transport or inventing a second envelope.
5. Optional later: a surface registry (id → loader) for code-splitting. That is packaging, not a semantic plugin system.

Recommended first-class surfaces (land as read-side/ops support them):

| Surface | Primary evidence |
|---|---|
| Shell / navigation | session + composition root |
| Models | model lifecycle + resource admission |
| Settings | backend.settings + launch identity |
| Chat / control | chat.send + execution progress |
| Observatory | bounded runs/events + selection |
| Trajectory | ordered events + executions + lineage |
| Chronicle / world | Scene IR + read models |
| Diagnostics | structured failure/recovery only |

## 4. Traceability axes the UI must preserve

Where the application exposes them, the UI must keep distinct and visible:

```text
SESSION / SEQUENCE
OPERATION / EXECUTION ID
REQUESTED → ACCEPTED/REJECTED → EFFECTIVE → OBSERVED → PRESENTED
MODEL LIFECYCLE STATE
RESOURCE ADMISSION OUTCOME
PACK / PROMPT / PROFILE IDENTITY (frozen at execution boundary)
REPLAY_OF LINEAGE
SOURCE / RESULT REVISION
CORRELATION ID FOR FAILURES
```

A green button, a selected dropdown, or a successful HTTP status is not traceability.

## 5. Anti-patterns (harness-shaped failures)

- Browser-side agent loop that calls tools without gateway mediation.
- Client-authored “trajectory log” that diverges from `session.events`.
- Plugin system that mounts semantic capabilities in React.
- Treating Trajectory as a chat transcript only (must include ops, models, admissions, failures).
- Hiding UNKNOWN / QUEUE / EVICT behind generic “Error”.
- Using multi-tab `BroadcastChannel` / `localStorage` as a second event bus or truth store.

## 6. Acceptance hooks

See `ACCEPTANCE_MATRIX.md` § Harness / Traceability. Minimum proof:

1. Trajectory (or equivalent) can show ordered evidence with semantic cursor.
2. Replay UI produces distinct execution identity when application supports replay.
3. Model lifecycle and resource-pressure states remain distinguishable in UI.
4. No surface module imports raw `fetch` JSON into components (gateway-client boundary).
5. Failure view exposes what failed / cause / intact remainder / known effect / next action / correlation id.

## 7. Dual-read (live tail vs durable history)

Trajectory quality requires honesty about evidence source:

| Mode | Source | UI obligation |
|---|---|---|
| LIVE | gateway session.events (FIFO/retention, sequenced) | Label LIVE; do not claim full archive |
| HISTORY | Observatory / committed logs / execution artifacts | Label HISTORY; bounded query pages |

A client-side buffer of the live tail is not a substitute for durable history. See `STREAM_AND_CONNECTION_BUDGET_CONTRACT.md` §1.

## 8. Optional configurability (P1)

Layout manifest, Capabilities/Config screen, and schema-driven settings are **optional after S0**. Spec: `HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md`. Semantic plugins remain server-side.

