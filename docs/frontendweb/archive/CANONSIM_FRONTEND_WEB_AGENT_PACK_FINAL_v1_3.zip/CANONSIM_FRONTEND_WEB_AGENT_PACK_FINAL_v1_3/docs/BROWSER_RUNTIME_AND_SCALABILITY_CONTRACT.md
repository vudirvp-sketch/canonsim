# Browser Runtime and Scalability Contract

**Status:** ACTIVE (web frontend law)  
**Audience:** Coding agents / maintainers  
**Intent:** Bound how the React/Vite client behaves under real browser conditions — multi-tab, memory pressure, rendering cost, PWA updates — without turning the browser into a second simulator.

## 1. Process and tab model (facts the UI must respect)

Modern Chromium-family browsers isolate tabs (site isolation). On Windows:

- Each tab is typically a separate renderer process (or share group under memory pressure).
- CPU, RAM, and GPU are scheduled by the OS across processes; the browser does **not** “pin work to one tab” as a single shared heap for all tabs of an origin in the general case.
- One heavy tab can consume large RAM/GPU without freezing other tabs, but can still pressure the machine.

Frontend rules:

1. Treat **each tab as an independent client** of the gateway.
2. Do not assume shared in-memory React state across tabs.
3. Do not elect a “leader tab” that owns semantics (semantics stay on the Python gateway).
4. Optional cross-tab UX (e.g. “already open”) may use `BroadcastChannel` or similar **only** for non-authoritative hints (focus another tab, show badge). Never for event ordering, canon, or execution identity.

## 2. Multi-tab anti-patterns

Forbidden:

```text
localStorage / sessionStorage as operation log or effective-state store
BroadcastChannel as second event bus or command bus
SharedWorker as hidden semantic authority
Service Worker cache as canonical run/result store
Optimistic multi-tab writes without gateway round-trip
```

Allowed:

```text
per-tab gateway client + validated session sequence
BroadcastChannel for UX hints only (non-authoritative)
PWA cache for static assets and explicit offline shells
```

## 3. Performance and bounded rendering

### Split of responsibility

```text
DOM/CSS  → ordinary Workbench chrome, forms, lists, inspectors
Canvas/WebGL → world/scene only when Visual Scene IR workload requires it
```

### Hard rules

1. Do not permanently materialize unbounded history as a live React tree. Use virtualization / windowing / progressive fetch.
2. Read models are bounded queries over application/read-side evidence, not full-log mirrors.
3. Animation and high-frequency visual updates must respect reduced-motion and a declared interaction-cost budget (see active visual / UIUX law). Prefer passive updates on evidence arrival over polling storms.
4. Heavy scene surfaces should be **single-instance per user intent** when possible (warn or reuse rather than silently opening N WebGL contexts across tabs).
5. Cache keys must include revision/identity; cache miss ≠ data loss; stale cache ≠ effective state.

### Suggested engineering budgets (targets, not marketing)

| Class | Target guidance |
|---|---|
| Shell interaction | Input→paint felt < 100ms for ordinary chrome |
| List virtualization | Activate for large event/run lists (order 10³+) |
| Scene frame budget | Prefer stable lower FPS over unbounded quality spikes |
| Payload validation | Validate at boundary; never block UI thread on huge JSON without chunking/workers if measured need |
| Diagnostic logs | Bounded size/lifetime; redaction policy |

Measure before optimizing. Do not invent WebWorkers or WebGPU “because scale”.

## 4. Gateway client structure (future streaming without UI rewrite)

Structure the client so transport can evolve without rewriting surfaces:

```text
UI surfaces
    ↓
typed gateway client API (ops + subscribe/resync)
    ↓
transport adapter (POST /op now; SSE/fetch-stream later)
    ↓
runtime validators (unknown → typed)
```

Rules:

1. Surfaces call the typed client only.
2. Transport adapter owns reconnect, sequence, `RESYNC_REQUIRED`.
3. No surface opens raw `EventSource` or WebSocket.
4. Do not implement `/events` or WebSocket until the gateway contract and acceptance tests exist.
5. Auth material never lands in stream URLs.

## 5. PWA / offline / update

Web/PWA-first means:

1. Static shell may cache; **semantic authority does not**.
2. Offline mode may show last-known presentation with explicit `STALE` / `DISCONNECTED` — never silent “success”.
3. PWA updates must not wipe in-flight operation identity without recovery path.
4. Incompatible asset or shell update is a first-class failure class (`incompatible PWA update`).

## 6. Resource pressure presentation

When the application exposes admission evidence, UI preserves:

```text
ACCEPT | QUEUE | REJECT | EVICT | RELOAD
```

Dimensions may include CPU, RAM, VRAM, model slots, context budget, queue capacity, stream capacity — **only when exposed**. The browser does not invent admission policy.

## 7. Scalability of the codebase (agent editability)

For maintainability under agent/human edit:

1. One composition root; surface modules with clear ownership.
2. No mandatory global state framework; local presentation state + gateway evidence.
3. Forbidden dependency edges enforceable in CI (e.g. components → raw fetch).
4. Deterministic commands for typecheck, unit/contract tests, lint, visual proof hooks.
5. Prefer small, reversible PRs: one owner, one surface, one proof class at a time.

## 8. Acceptance hooks

See `ACCEPTANCE_MATRIX.md` § Browser runtime. Minimum proof:

1. Two tabs can attach as independent clients without shared mutable semantic store.
2. Large event lists use windowing/virtualization (or documented bound).
3. Gateway client boundary exists; surfaces do not import transport details.
4. Disconnect / stale / resync states are distinct in UI.
5. PWA/offline path (if shipped) marks stale presentation explicitly.

## 9. Stream transport and connection budget

Normative detail lives in `STREAM_AND_CONNECTION_BUDGET_CONTRACT.md`.

Summary binding on this document:

1. **Dual-read:** live `session.events` tail ≠ durable Observatory/history over logs/artifacts. Label LIVE vs HISTORY.
2. **Connection budget:** HTTP/1.1 ~6 connections/origin; loopback ThreadingHTTPServer does not remove that limit. Unbounded per-tab SSE is forbidden without an admission policy.
3. **Default recommendation before HTTP/2 / server fan-out:** focused-tab stream only; background tabs poll or show STALE.
4. **S0:** no SSE/WebSocket; POST /op only. See `SKELETON_ACCEPTANCE.md`.
5. Failure class `connection budget exhausted / stream not admitted` must remain distinct from gateway process failure.
6. SharedWorker is not an allowed semantic stream hub.

