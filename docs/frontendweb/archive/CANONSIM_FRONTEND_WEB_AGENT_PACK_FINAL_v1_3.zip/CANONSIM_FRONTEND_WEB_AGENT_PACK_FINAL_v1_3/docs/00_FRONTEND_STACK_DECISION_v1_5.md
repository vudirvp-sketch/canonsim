# CanonSim Frontend Stack Decision v1.5
**Status:** DECIDED  
**Revision:** v1.7 — Skeleton S0 gate, dual-read, connection budget/focused-tab stream policy, optional config P1, tooling floor (pack v1.3)
**Audience:** Coding agents / software agents / maintainers  
**Supersedes:** `CANONSIM_FRONTEND_STACK_DECISION_v1.md`, `CANONSIM_FRONTEND_STACK_DECISION_v1.1`
**Decision:** Use **React + TypeScript + Vite + Web/PWA-first** as the only active frontend path. Keep **Tauri 2** optional and future-facing. **Freeze Redot and archive its implementation as historical/reference material.**
## 1. Decision
Active architecture:

```text
CanonSim simulation core
        |
        v
Python Workbench application + Gateway
        |
        +--> canonical/read-side contracts
        |
        +--> Visual Scene IR
                    |
                    v
             React + TypeScript
                    |
                   Vite
                    |
             Web / PWA-first
              /           \
         DOM/CSS       Canvas/WebGL
          UI             world/scene
                    |
              optional later
                    v
                  Tauri 2
```
Core rule:
> **Semantics stay in CanonSim/Python. Presentation and interaction stay downstream, typed, replaceable, and non-authoritative.**
The React frontend is a client/presentation layer. It must never become a second simulator, canonical state authority, event-log authority, hidden rules engine, or LLM semantic authority.
## 2. What this decision changes
### Active
- React
- TypeScript
- Vite
- browser Web APIs
- Web/PWA as the first-class product target
- DOM/CSS for ordinary Workbench surfaces
- Canvas/WebGL only where visual workload requires it
- existing Workbench application/gateway contracts
- existing renderer-neutral Visual Scene IR
### Optional / deferred
- Tauri 2 as a thin packaging shell
- WebGPU as measured acceleration
- additional renderer(s) only after a concrete consumer + measured limitation + acceptance proof
### Frozen
- Redot Workbench UI
- Redot application shell
- Redot-specific presentation code
- Redot-specific visual experiments
- Redot feature parity work
- new Redot semantic or application logic
Do not maintain React and Redot as parallel product implementations.
## 3. Architectural authority
The active repository law is the first routing authority for frontend implementation. This pack is a derived implementation contract, not a competing source of truth.

```text
ACTIVE REPO BINDING LAW
    > current executable implementation/tests
    > this web pack's derived contract
    > selected historical Workbench source
    > Redot reference
```

See `docs/ACTIVE_REPO_ROUTING.md` for the compact owner map. The binding repo-side owners are `FRONTEND_UIUX_LAW.md`, `VISUAL_SYSTEM_UI.md`, `WORKBENCH_APP_LAW.md`, `OBSERVATORY_LAW.md`, `WORLD_PRESENTATION_LAW.md`, `LLAMA_CPP_INFERENCE_CONTROL_LAW.md`, `AGENT_NAVIGATION.md`, `SSI_TOPOLOGY.md`, and `ssi/SSI_OVERLAY.md` for their respective concerns. Historical `source-workbench/` documents are provenance/derivation material, not current owners.

Ownership remains:

```text
CanonSim
  = canonical events / truth / simulation semantics
Workbench application
  = operations / lifecycle / sessions / persistence policy /
    inference/backend integration / application gateway
Frontend
  = interaction / presentation / client state / visual projection
Visual Scene IR
  = renderer-neutral presentation contract
```
The frontend may hold:
- view state;
- selection/focus/context;
- draft input;
- pagination;
- connection state;
- local layout/preferences;
- bounded display cache;
- restorable client session state.
The frontend may not own:
- CanonSim truth;
- canonical event log;
- simulation scheduler;
- world rules;
- canonical time;
- backend process control;
- semantic validation authority;
- permanent truth cache that can disagree with the backend.
Existing authority classes remain distinct:

```text
CANONICAL
OBSERVED
DERIVED
INFERRED / MODEL_CLAIM
HYPOTHETICAL
UNKNOWN
STALE
CONFLICT
PRESENTATION
CACHE
```
Visual appearance must never be used as evidence that a semantic fact exists, does not exist, or succeeded.
## 4. Backend boundary and gateway contract
The browser talks to the **Workbench application gateway**, not directly to:
- CanonSim internals;
- `core/`;
- `sim/`;
- llama.cpp;
- persistence internals;
- model files;
- filesystem APIs.
Existing application operations remain the semantic API. HTTP/SSE/WebSocket are only delivery mechanisms.
The frontend must consume the existing typed envelope model, including where applicable:

```text
RequestEnvelope
ResponseDocument
EventEnvelope
session identity
operation/execution identity
revision
sequence
dispatch status
rejection/failure class
idempotency key
lease / exclusive-control state
```
Frontend code must preserve the gateway's distinctions such as:

```text
OK
REJECTED
FAILED
UNKNOWN
STALE_REVISION
DUPLICATE_REQUEST
AUTH_FAILED
AUTHZ_DENIED
RUNTIME_FAILED
SENT_OUTCOME_UNKNOWN
```
A pressed button is not a successful operation. The UI must display the actual backend outcome and recovery state.
### Streaming policy
- HTTP request/response remains valid for bounded operations.
- **SSE is the default one-way event-stream mechanism.**
- **WebSocket is admitted only for a concrete bidirectional requirement.**
- Streaming remains bounded and reconnectable.
- Reconnect uses retained session sequence / replay semantics, not blind duplication.
- The browser must not invent a second event bus.
- The browser transport adapter may use native `EventSource` only where the gateway authentication/session model is compatible; otherwise it may use fetch-based streaming or another explicitly admitted delivery mechanism.
- Authentication material must not be moved into event-stream URLs merely to satisfy a browser transport API.
No new backend network server is created merely because the frontend moved to the browser. The existing gateway/network ownership law remains binding.

### Current implementation vs target browser contract
At this decision point, the repository's shipped transport is **loopback HTTP `POST /op` only**. The gateway core already owns ordered per-session events and bounded replay (`session.events`); browser SSE/WebSocket delivery is a future transport row, not an existing browser capability.

The implementation boundary is therefore:

```text
LANDED NOW
Python gateway semantic dispatch
+ typed Request/Response/Event envelopes
+ per-session sequence
+ retained replay / RESYNC_REQUIRED semantics
+ loopback HTTP POST /op

FUTURE BROWSER DELIVERY
HTTP/SSE (default one-way stream)
+ reconnect using retained sequence
+ explicit browser authentication/session handling
+ bounded streaming tests
```

Do not implement browser code against an imagined `/events` or WebSocket route until that transport has its own explicit gateway contract and acceptance tests.

### Wire contract and runtime validation
TypeScript is compile-time typing, not runtime trust. Every network payload enters the frontend as `unknown` and is validated by the gateway client/contract adapter before UI code consumes it.

Rules:
1. The wire format is the existing Workbench JSON contract; the frontend does not invent a second semantic envelope.
2. Python remains the producer/authority for gateway contract shape.
3. TypeScript types must be generated from, derived from, or mechanically checked against a machine-readable contract/fixture set rather than independently retyped by hand without verification.
4. Runtime validation must reject malformed, incompatible, or unexpected payloads loudly.
5. Raw network JSON never crosses from transport code directly into React components.
6. Contract fixtures must include accepted, rejected, failed, unknown, stale, duplicate, lease, and replay/resync cases.
7. Contract/schema identity is part of compatibility checking, not presentation state.
## 5. Browser hosting and transport topology
Preferred topology:

```text
Production:
Browser/PWA
   -> HTTPS
   -> Workbench gateway
   -> application operations
   -> CanonSim / backend
Development:
Vite dev server
   -> same-origin proxy
   -> loopback Workbench gateway
```
Rules:
1. Prefer same-origin deployment for the local packaged/served product where practical.
2. Use a Vite proxy during development rather than weakening gateway security for CORS convenience.
3. Remote/LAN/TUNNEL exposure remains explicit and authenticated.
4. Never expose the llama.cpp endpoint directly to the browser.
5. Never ship credentials or secrets in the Vite bundle.
6. Values exposed as client build configuration are public by definition.
7. Remote production traffic uses secure transport.
8. The raw loopback gateway remains the safe default until remote transport is deliberately implemented.
The exact remote transport is an application/gateway concern, not a React-specific protocol.
### 5.1 Hosting contract
The web frontend has one deployable static product surface. Vite produces the browser build; **`vite preview` is a local preview tool, not the production server**. Production hosting must provide the static frontend assets and route the application's gateway paths according to the same-origin topology below.

```text
SAME-ORIGIN LOCAL/PRODUCTION TARGET

Browser
  |
  +--> /                static React/Vite build
  |
  +--> /op              Workbench gateway operations
  |
  +--> /stream/*        explicitly admitted streaming transport (future)
  |
  +--> /assets/*        versioned presentation assets
  |
  v
Workbench application / gateway
```

Requirements:
- The active deployment must define who serves the Vite `dist/` output.
- SPA deep links must resolve to the application entry document rather than 404 on browser refresh.
- The static asset base path must be explicit and tested when the application is not served from `/`.
- The production serving layer may be a future application-owned static host/reverse proxy, but it must not become a second semantic backend.
- `vite preview` may be used for build smoke testing only.

Development remains:

```text
Browser -> Vite dev server -> same-origin proxy -> loopback Workbench gateway
```

The dev proxy must cover every browser delivery path used by the frontend; development CORS exceptions are not the production architecture.

### 5.2 Browser trust boundary
**Loopback is a network placement, not an authentication mechanism.** A browser page is not trusted merely because the gateway binds `127.0.0.1`/`localhost`.

Preferred rule: keep the packaged/local product same-origin so browser requests do not require permissive cross-origin access. When cross-origin browser access is deliberately enabled, the gateway/application must explicitly validate the allowed origin set and apply the appropriate CSRF/credential protections.

Never rely on browser Local Network Access / Private Network Access behaviour as the application's authorization layer.

Never:
- use wildcard CORS for an authenticated browser client;
- treat `Origin` absence/presence as application authorization by itself;
- place credentials, lease tokens, or bearer secrets in URLs;
- expose the llama.cpp endpoint to the browser;
- assume local storage/URL state is trustworthy because the client is local.
## 6. PWA policy
PWA is a delivery capability, not a second application.
The service worker may cache:
- static frontend assets;
- fonts/icons;
- explicitly versioned presentation assets;
- other rebuildable client resources.
It must not silently turn cached data into authoritative CanonSim state.
### 6.1 Service-worker exclusion and update law
A service worker is a presentation/cache mechanism only. It must not cache, replay, synthesize, or intercept as authoritative: canonical mutations, live event streams, runtime process state, model lifecycle state, lease state, or mutable session truth.

The service worker must not create silent protocol skew between a cached frontend and a live gateway. The frontend therefore exposes and verifies a compatibility identity covering at minimum:

```text
frontend build identity
gateway contract identity
application/read-model contract identity where applicable
Scene IR schema identity
asset-manifest identity where scene assets are used
capability/feature set where applicable
```

Compatibility law:

```text
compatible -> run
incompatible -> explicit reload/upgrade/error
never -> silent best-effort interpretation
```

Service-worker update/activation behaviour must preserve this rule for a running session; a newly activated frontend must not silently reinterpret an incompatible live session.

The browser-side caches are disposable and rebuildable.
Offline policy:

```text
static shell available
        |
        +--> cached/read-only views where explicitly valid
        |
        +--> stale/unknown status when authority is unavailable
        |
        +--> no fake successful mutations
```
Canonical simulation mutations require a live authoritative backend unless an explicit future operation contract says otherwise.
Offline caches are disposable. Cache invalidation, schema/version mismatches, and stale data must be visible rather than silently normalized.
## 7. State and persistence split
Frontend implementation must preserve the Workbench state taxonomy:

```text
CONFIGURATION = durable user preferences
SESSION       = restorable working context
WIDGET        = ephemeral local interaction
RUNTIME       = live process/model/execution state
OBSERVATION   = freshness/provenance/evidence
HISTORY       = operational indexed record
CACHE         = rebuildable acceleration
BACKUP        = explicit recovery artifact
```
Do not collapse these into one global React store.
Use local feature ownership. A feature may own local UI state only when that state has no application semantic authority.
No global "everything store" and no `App.tsx` state monolith.
### 7.1 State-vocabulary separation
Do not encode unrelated truths into one generic `status` field. At minimum keep these axes distinct:

```text
OPERATION OUTCOME
  OK / REJECTED / FAILED / UNKNOWN / ...

CONNECTION STATE
  CONNECTING / ONLINE / DEGRADED / RECONNECTING / OFFLINE

DATA FRESHNESS
  FRESH / STALE / UNKNOWN

AUTHORITY CLASS
  CANONICAL / OBSERVED / DERIVED / INFERRED / HYPOTHETICAL / UNKNOWN
```

A connection state does not determine an operation outcome; freshness does not determine semantic truth; presentation state never upgrades authority.

### 7.2 Effective-state closure
For consequential controls and operations, preserve:

```text
REQUESTED → ACCEPTED / REJECTED → EFFECTIVE → OBSERVED → PRESENTED
```

A draft value or optimistic click is never treated as effective or observed truth. See `docs/EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md`.

### 7.3 Model lifecycle
Where exposed by the application, preserve discovery/validation/selection/loading/loaded/active/failure/eviction distinctions. `SELECTED` does not imply `ACTIVE`. Model loading and admission remain application-owned.

### 7.4 Prompt/profile and reproduction identity
Preserve material composition as:

```text
BASE PROFILE → SESSION OVERRIDE → CALL-LOCAL OVERRIDE
→ VALIDATION / CLAMP / NORMALIZATION → EFFECTIVE → OBSERVED
```

A replay is a new execution identity. Material packs are identified by logical id + revision/schema/content/compatibility metadata where exposed; path/URL/display label is only a locator.

### 7.5 Resource-pressure presentation
Where exposed, preserve application states such as `ACCEPT`, `QUEUE`, `REJECT`, `EVICT`, and `RELOAD`. The browser reports admission evidence; it does not implement admission policy.

## 8. Visual Scene IR
Retain the existing Visual Scene IR as the shared presentation contract.
Required properties:
- renderer-neutral;
- typed;
- deterministic where deterministic output is required;
- provenance-aware where applicable;
- independent of React internals;
- free of CanonSim write authority;
- stable enough for fixtures and visual regression.
The web renderer consumes the IR:

```text
CanonSim/read model
      |
      v
Visual Scene IR
      |
      v
web scene/compositor
      |
      +--> Canvas/WebGL
      +--> DOM overlays/UI
```
Do not recreate Redot node hierarchy semantics in React.
Do not turn Scene IR into a universal scene DSL before a real consumer requires additional capability.
Scene composition remains deterministic from declared inputs where regression requires determinism:

```text
semantic/read input + seed + composition policy + asset manifest
    -> deterministic presentation
```
## 9. Rendering strategy
### React DOM/CSS
Use for:
- application shell;
- navigation;
- forms;
- settings;
- chat;
- tables;
- panels;
- inspectors;
- status/error/recovery surfaces;
- accessibility-critical controls.
### Canvas/WebGL
Use only for:
- world view;
- maps;
- dense scene visualization;
- high-frequency visual layers;
- visual workloads that become measurably unsuitable for DOM.
### WebGPU
Optional acceleration only after:

```text
real consumer
+ measured limitation
+ acceptable browser/runtime support
+ bounded resource cost
+ testable fallback
```
Do not select a renderer or graphics abstraction "just in case".
## 10. Responsive, accessibility, localization
These remain hard requirements after the Redot freeze.
The active web frontend must preserve the existing interaction laws for:
- keyboard/focus order and restoration;
- reduced motion;
- accessibility semantics;
- responsive viewport classes;
- high-DPI behavior;
- multi-monitor/large viewport behavior;
- localization-ready layout;
- Cyrillic-safe typography and wrapping;
- non-color-only status communication;
- readable critical information without silent clipping.
The web implementation must not inherit Redot's fixed-runtime assumptions merely because the archived implementation used them.
Browser acceptance must cover representative desktop and narrow/mobile viewports.
## 11. Performance and resource policy
The real workload is:

```text
frontend alone
frontend + simulation
frontend + local LLM
frontend + simulation + local LLM
world view + local LLM
remote mobile session + simulation
```
Measure at minimum:
- startup/cold-warm behavior;
- RAM and browser JS heap;
- CPU;
- GPU where relevant;
- frame time / drops;
- main-thread blocking / input responsiveness;
- network latency and payload size;
- stream buffer size/update rate;
- history/query rendering cost;
- scene rebuild cost;
- asset memory;
- reconnect/recovery behavior.
Shared-resource rule:
> A visual optimization that materially harms local inference or simulation responsiveness is a regression.
Use bounded rendering, virtualization, incremental updates, and explicit degradation. Do not solve every performance problem by growing caches.
## 12. Web-specific architectural rules
1. Keep feature ownership local.
2. Keep API adapters separate from UI components.
3. Keep browser transport code behind a gateway client boundary.
4. Keep semantic contracts in typed modules, not ad-hoc component objects.
5. Avoid `any` at backend/Scene IR boundaries.
6. Avoid giant context/provider stacks that become hidden global state.
7. Avoid unbounded subscriptions and animation loops.
8. Use stable identity for list/rendering and semantic selection.
9. Do not use DOM structure or CSS classes as a semantic authority.
10. Do not let browser storage become a canonical data store.
11. Do not silently convert `UNKNOWN`, `STALE`, `DEGRADED`, or `OFFLINE` into success.
12. Do not add a new abstraction without a named consumer, problem, owner, and test.
13. Do not introduce a large UI/component framework unless its admitted value exceeds its dependency and control cost.
14. The exact state/query/router/component libraries are implementation choices, not hidden parts of this architectural decision; each later dependency must pass the normal admission rules.
15. The default rendering/application model is a browser client application. Do not introduce SSR, SSG, React Server Components, Server Functions, server actions, or a React meta-framework unless a concrete consumer, problem, owner, and acceptance proof justify the extra runtime.
16. Use one declared package manager and one committed lockfile. CI must perform locked/frozen dependency installation.
17. Browser-side persistence is never a substitute for gateway/session authority.
18. Frontend diagnostics must use correlation identifiers and must redact credentials, lease tokens, secrets, and other explicitly sensitive payloads.
19. Feature/module boundaries are ownership boundaries, not merely folder groupings. A module earns existence through independent state/lifecycle, a stable external contract, meaningful change locality, persistence, or tests; do not create empty architecture scaffolding.
20. Frontend wiring has one visible composition root. It constructs concrete adapters/providers, validates configuration, and starts client lifecycle; it is not a service locator, global registry, semantic owner, or hidden dependency injector.
21. Components consume typed feature/read contracts and local presentation state. They must not discover backend clients, read browser storage directly for semantic state, or reach into another feature's private state.
22. Every consequential feature has one state/operation owner. Shared state is created only for a real cross-feature contract; otherwise keep state local.
23. Architecture tests should mechanically reject forbidden dependency directions and direct imports across ownership boundaries where feasible.
24. Every feature with long-running work defines explicit initiation, progress, interruption, terminal, stale/unknown, and recovery states. UI events are not operation outcomes.
25. Frontend caches require identity/dependencies, a validity rule, and a rebuild/invalidation path. No cache is the sole copy of durable user data or canonical truth.
26. Large histories, event streams, result sets, and diagnostic lists must use paging, virtualization, bounded windows, or progressive detail rather than permanently materializing the full dataset.
27. Client diagnostics/telemetry are bounded and privacy-safe. Diagnostic records should preserve source/component, operation/execution/session correlation, severity, code/category, structured context, and redaction status where applicable. Raw prompt/response payloads are never ordinary logs.
28. Developer/assurance/debug surfaces may expose deeper provenance and rendering/runtime metadata than the normal product UI, but they remain read-only with respect to semantic authority and must not create a hidden data-exfiltration path.
29. Frontend visual containers exist to establish semantic grouping or interaction ownership. Do not turn every field, message, or primitive into a nested card; prefer meaningful surfaces such as panels, lanes, rows, inspectors, timelines, drawers, and evidence strips.
30. Failure UX must preserve what failed, best-known cause, what remains intact, whether semantic effect is known, available recovery actions, and relevant diagnostic identity. Never replace actionable failure state with a generic error surface.
31. Reproduction/assurance artifacts should carry enough stable identity to reconnect the visible result to the underlying request, run, revision, or read-side source. A screenshot alone is not a semantic evidence artifact.
32. Frontend automated evidence should be agent-operable: fixtures, contract cases, screenshots/visual diffs, accessibility checks, state-transition checks, and browser smoke paths must have explicit commands and bounded outputs.
## 12.1 Frontend module and ownership law

The Workbench pack's modularity rules carry over to the web frontend, with frontend ownership kept distinct from the application layer.

```text
composition root
      ↓
application shell / routing / providers
      ↓
feature modules
      ↓
feature-local presentation state + typed application contracts
      ↓
shared primitives / design system
```

Dependency direction:

```text
components/pages
    → feature presentation
    → typed client/read contracts
    → gateway client / application contract adapters

shared primitives/design system
    ← feature composition

features
    → application contracts
    ↛ another feature's private state
    ↛ raw transport
    ↛ CanonSim internals
```

Rules:
- `frontend/app` owns composition and startup wiring only.
- `frontend/api` owns browser transport and wire decoding only.
- `frontend/features/*` own feature flow and feature-local state.
- `frontend/scene` owns Scene IR mapping/composition and web rendering adapters.
- `frontend/design-system` owns visual primitives/tokens, not feature semantics.
- `frontend/tests` owns verification harnesses and fixtures, not production state.
- No `globalStore`/service registry is introduced merely to avoid explicit ownership.
- A feature boundary should be obvious enough that an agent can locate `owner | contract | state | side effects | tests` without traversing the entire app.

### 12.2 Composition root

The web client has one explicit composition root responsible for selecting concrete implementations and wiring runtime services:

```text
construct → validate config → wire adapters/providers → establish connection/session → start app
```

It must not own:
- CanonSim semantics;
- backend retry semantics;
- feature-private state;
- persistence meaning;
- hidden global mutable state;
- ad-hoc dependency lookup.

Tests must be able to compose a feature/client subset without booting the whole application.

### 12.3 Frontend runtime lifecycle and operation state

Do not collapse application connection, session, stream, operation, data freshness, and authority into one `status` field.

Minimum conceptual axes:

```text
CONNECTION: DISCONNECTED → CONNECTING → CONNECTED → DEGRADED → RECONNECTING
SESSION:    DETACHED → ATTACHING → ATTACHED → STALE/REQUIRES_RESYNC → DETACHED
OPERATION:  IDLE → DISPATCHING → RUNNING → COMPLETING → COMPLETED
                         ↘ REJECTED / FAILED / CANCELED / UNKNOWN
STREAM:     IDLE → ACTIVE → ENDED / DISCONNECTED → RESYNC_REQUIRED
FRESHNESS:  FRESH | REFRESHING | STALE | INVALIDATED | UNKNOWN
AUTHORITY:  CANONICAL | OBSERVED | DERIVED | INFERRED | ...
```

These are vocabulary contracts, not mandatory one-class-per-state implementations. Illegal transitions and state combinations that could mislead the user should be covered by tests.

A frontend action follows:

```text
intent → validate draft → dispatch → observe outcome → reconcile view
```

Never:

```text
click → assume success → repaint as truth
```

For operations with ambiguous post-dispatch outcome, preserve `UNKNOWN` and require explicit backend evidence or safe idempotent retry semantics before presenting success.

### 12.3.1 Application execution / deadline / cancellation / provenance seam

The Workbench application already has stronger execution contracts than the browser should recreate. The frontend consumes those contracts; it does not implement a second operation engine.

For consequential or long-running work, preserve when supplied:

```text
operation_id
execution_id
run/session identity
client request / idempotency identity where exposed
current lifecycle state
progress / phase / blocking reason where exposed
deadline / remaining budget where exposed
cancellation state
terminal outcome
execution-artifact identity / replay lineage where exposed
reproducibility scope where exposed
capability / runtime / model provenance where exposed
```

Rules:
- The frontend may render a deadline, remaining budget, progress or cancellation affordance, but must not invent backend retry/deadline semantics.
- `CANCEL_REQUESTED`, terminal `CANCELED`, failed cancellation, and unknown post-dispatch outcome remain distinct wherever the gateway/application exposes them.
- A replay is a new execution identity; the frontend must not collapse replay lineage into the original execution.
- Provenance fields are evidence about the operation/read-side result, not client-owned semantic state.
- The frontend must preserve identity continuity across progress, reconnect, detail views, history and reproduction/assurance surfaces.
- A lost transport after dispatch must not cause the browser to mint a new operation identity merely because the first outcome is unknown.

The exact operation/deadline/cancellation vocabulary remains application-owned; the frontend mirrors it through typed adapters.

### 12.4 Diagnostics, debug and logging contract

Diagnostics are a first-class frontend capability, not scattered `console.log` statements.

Structured diagnostic record, where applicable:

```text
timestamp
source/component
severity
code/category
message
session_id
operation_id / execution_id
revision / sequence
resource or entity identity
state/freshness
structured context
redaction status
```

Recommended observation profiles:

```text
MINIMAL  = operator-useful lifecycle/error evidence
STANDARD = normal diagnostics and recovery context
DEV      = explicitly enabled, bounded deep evidence
```

Rules:
- `console.*` is development plumbing, not the application diagnostic contract.
- Production diagnostics are structured and filterable.
- Diagnostic correlation uses stable identities already present in gateway/application contracts.
- Secrets, auth/lease credentials, private headers, and unrestricted raw model payloads never enter ordinary logs.
- DEV raw evidence is bounded by size/lifetime and has an explicit export/redaction policy.
- Debug/assurance views are read-only projections over application/read-side evidence.
- Debug metadata may include `entity_id`, `source_revision`, `scene seed`, `composition rule`, visual LOD, cache key/identity, and observation scope when relevant.
- Diagnostics must never become an implicit second persistence authority.
- Scene/visual assets used by the web renderer should have stable logical identity plus revision/content identity where material; path/URL alone is not identity.
- Asset manifests are presentation inputs with explicit compatibility/provenance metadata; an invalid or incompatible asset is rejected or safely substituted, never silently treated as canonical semantic state.

Browser-native observability should remain deliberately small: structured diagnostics, correlation IDs, bounded performance marks/measures, and explicit error/recovery evidence are preferred over a generic telemetry framework.

### 12.5 Failure, recovery and boundedness law

Every important frontend failure must preserve:

```text
WHAT FAILED
→ BEST-KNOWN CAUSE
→ WHAT REMAINS INTACT
→ WHETHER EFFECT IS KNOWN
→ WHAT CAN BE DONE NOW
→ CORRELATION / OPERATION ID
```

Representative failure classes:

```text
transport unavailable
malformed payload
protocol incompatibility
stale revision
lease/auth rejection
stream disconnect
request outcome unknown
missing/invalid scene asset
scene revision stale
render/resource pressure
cache invalidation
incompatible PWA update
```

Required default behaviour:

```text
unknown ≠ failed
stale ≠ absent
disconnected ≠ completed
cache miss ≠ data loss
render failure ≠ semantic failure
```

A frontend boundary is production-ready only when its relevant failure states have bounded recovery behaviour and executable tests.

### 12.6 Read models, history, evidence and reproduction

History and analytical/read surfaces should follow:

```text
application/read-side source
→ bounded query/page
→ typed frontend read model
→ virtualized/progressive renderer
→ detail-on-demand
```

Do not permanently materialize every historical message/event/query result as a live React tree.

Where the product exposes an Observatory or investigation workflow, stable identifiers should remain visible/recoverable:

```text
QUERY ID
RUN / EXECUTION ID
RESULT REVISION
SOURCE REVISION
```

A frontend evidence/reproduction artifact may package:

```text
question/scope
source/run identity
result/revision
selected evidence
uncertainty/disposition where applicable
analysis/view revision
provenance
```

A screenshot is a visual artifact, not proof of semantic truth.

### 12.7 Visual container / surface law
The active visual owner is `docs/VISUAL_SYSTEM_UI.md`. Its rule is structural: a container is a rectangle with a role, not decorative card chrome. Prefer `CANVAS → SURFACE → CONTAINER → CONTENT → ACTION` and semantic roles such as `surface`, `row`, `field`, `lane`, `panel`, `drawer`, `inspector`, `timeline`, and `evidence strip`.

Every material surface should declare its honest state matrix. Do not let visual calm suppress effective-state, stale/degraded, or failure evidence. Functional correctness closes before visual refinement: one owner-gated functional row is completed and verified before visual polish is promoted. Use the smallest meaningful visual change that improves task performance; do not create parallel style tracks.


“Containers” are useful, but the Workbench pack's lesson is to make them semantic rather than decorative.

Prefer a vocabulary such as:

```text
surface | divider | row | field | lane | panel | drawer | inspector | timeline | evidence strip
```

over:

```text
card → card → card → card
```

A container is justified when it establishes one of:
- semantic grouping;
- interaction ownership;
- comparison boundary;
- lifecycle/status boundary;
- scroll/virtualization boundary;
- inspection/context boundary.

Do not create a component solely because a rectangle can be drawn around some content. Avoid nested-container depth that obscures the information architecture.

### 12.8 Agent-operable verification and change locality

For every material frontend feature, an agent should be able to locate:

```text
owner
→ typed contract
→ state/lifecycle
→ side effects
→ persistence/session interaction
→ tests/fixtures
→ visual proof where applicable
```

Automated checks should cover, where relevant:

```text
contract decoding
state transitions
forbidden dependency/import edges
unknown/stale handling
duplicate-dispatch protection
focus/accessibility
responsive/DPI layouts
visual regression
stream/reconnect behaviour
performance ceilings
redaction/diagnostic safety
```

The frontend repository should expose deterministic commands for these checks. Avoid manual “open the editor and see if it looks right” as the only acceptance path.

### 12.9 Observatory / analytical interaction contract

The Workbench's analytical interaction model is part of the frontend contract, not merely optional page design. When an Observatory/read-side surface is present, preserve these reusable primitives:

```text
CONTEXT
QUERY / SCOPE
PRIMARY VIEW
INSPECTOR
EVIDENCE / PROVENANCE
```

High-consequence analytical surfaces should expose enough context to answer:

```text
run / execution identity
seed where relevant
time window / scope
observation profile
result / source revision
freshness
```

Selection is a shared semantic identity, not widget-local selection. A selected event/actor/object/relation must remain stable across compatible view switches, drill-down, filters, semantic zoom and compare, and cross-highlighting must use canonical/typed read-model identity rather than labels, row numbers or display strings.

Analytical views should support, where the owning read model provides the semantics:

```text
semantic zoom       event → cluster → regime → world
compare             BASE ↔ PERTURBED on shared semantic/time coordinates
timeline            bounded primary temporal view with source/evidence jumps
graph               bounded contextual microscope, never an unbounded hairball
semantic navigation scope → target → evidence → source
persistent workspace query / scope / selection / filters / view / compare context
```

A semantic breadcrumb is preferred to a screen-history breadcrumb for analytical work.

### 12.10 Epistemic, empty-state and evidence contract

The frontend must not collapse analytically different states into generic “empty” or “failed” UI. At minimum distinguish where the read model supports them:

```text
NO DATA
NO MATCH
NO EVIDENCE
UNKNOWN
OUT OF SCOPE
BLOCKED
PARTIAL
STALE
FAILED
```

Likewise, evidence strength must remain separate from visual relationship or prose confidence. A graph edge, `cause_id`, highlighted row or generated narration must not visually imply a causal conclusion by itself.

For research/assurance workflows, support a first-class read-only evidence/reproduction artifact when the backend contract admits one, with enough identity to reopen the analytical context:

```text
question / scope
run(s) / execution identity
result / source revision
selected evidence / causal slice
uncertainty / disposition
next discriminator where applicable
analysis/view revision
provenance
```

A screenshot is a visual artifact, not semantic proof.

### 12.11 Frontend proof classes

Frontend verification must distinguish evidence classes instead of treating every green check as equivalent:

```text
STATIC_VERIFIED
RUNTIME_VERIFIED
TASK_VERIFIED
VISUAL_VERIFIED
MANUALLY_VERIFIED
DEFERRED
NOT_VERIFIED
```

Static architecture/contract proof cannot claim runtime execution; runtime execution cannot claim successful human task completion. Runtime-unavailable states must remain explicit. Important screenshot artifacts should carry, where applicable:

```text
build identity
frontend/gateway/Scene-IR compatibility identity
route/surface identity
state/context identity
seed or fixture identity where relevant
result/revision identity
```

This proof vocabulary is an assurance contract, not a replacement for the backend/application acceptance suites.

## 13. Recommended active repository structure

```text
frontend/
  app/
    composition/
    routes/
    providers/
    app-shell/
  components/
    primitives/
    layout/
    navigation/
    feedback/
  features/
    observatory/
      query/
      selection/
      context/
      evidence/
    inference/
    simulation/
    world/
    chat/
    settings/
    history/
    runs/
  scene/
    scene-ir/
    renderer-web/
    layers/
  state/
    session/
    connection/
    preferences/
  api/
    gateway/
    contracts/
    diagnostics/
  design-system/
    tokens/
    typography/
    surfaces/
    motion/
    themes/
  tests/
    unit/
    integration/
    contract/
    architecture/
    visual/
    e2e/
    proof/
    fixtures/
  public/
  vite.config.*
  tsconfig.*
  package.json
```
Exact names may change. Boundary ownership may not.
## 14. Design-system direction
The new UI is a new product surface, not a Redot skin.
The design system owns:

```text
typography
spacing/density
surfaces/elevation
borders
interaction states
semantic status
motion
responsive rules
data visualization language
world visualization language
```
Avoid default dashboard composition and gratuitous:
- card-within-card nesting;
- gradients/glass effects without purpose;
- oversized empty areas;
- arbitrary badges/chips;
- decorative noise;
- component-library styling that weakens CanonSim identity.
Visual quality must come from coherent hierarchy, typography, geometry, interaction, and semantic notation.
## 15. Security and trust boundary
The browser is an untrusted presentation client.
The backend/application validates every semantic capability. The frontend is allowed to improve UX, not to widen authority.

Never trust:
- browser state;
- URL parameters;
- local storage;
- imported assets;
- client-side capability claims;
- model output;
- client-computed semantic results.
Server/application validation remains authoritative.
Remote mode requires:

```text
explicit exposure
+ authentication
+ authorization
+ secure transport
+ session/reconnect handling
+ origin/CSRF protections where applicable
+ rate/size limits where appropriate
```
Do not put privileged credentials into source control or public client configuration.

### Credential and diagnostics law
- Do not persist auth or lease credentials in `localStorage`/IndexedDB by default.
- Do not put credentials or lease tokens in URLs, route state, analytics events, or crash reports.
- Frontend logs may correlate using `session_id`, `operation_id`, `revision`, and `sequence` where permitted, but must not log secrets or unrestricted raw inference payloads.
- Client-side capability claims are hints for UX only; authorization is server-side.

### Future Tauri security law
If Tauri 2 is later adopted, its native capabilities must remain minimal and explicit. The Tauri shell may provide packaging/native integration only; it must not become a semantic authority. File-system, process, shell, network, or plugin permissions require explicit capability/permission admission and scoped tests.

## 16. Repository-grounded transition notes
The current repository is not yet the finished web application described by this decision. At the decision point, its active Workbench transport is a loopback-only HTTP binding with a single `POST /op` route, while the gateway core already provides typed envelopes, session sequence, retained replay, and `RESYNC_REQUIRED` semantics. The active GitHub Actions workflow is Python-only (ruff + pytest).

Therefore:
- do not describe SSE/WebSocket browser transport as already implemented;
- do not remove the current Python gateway tests when the web client is introduced;
- add web CI as a new verification layer rather than replacing Python semantic verification;
- migrate launcher/operator documentation from the Redot shell to the web entry point only after the web vertical slice has an accepted local serving path;
- preserve the gateway's byte/semantic parity tests as backend contract evidence.

This is a migration fact, not a permission to redesign the backend.

At the current repository checkpoint, the application already contains executable concepts for operation identity, bounded execution, deadlines, cooperative cancellation, ordered session events, execution artifacts/provenance, and bounded Observatory read windows. The React migration must consume these existing seams through typed adapters rather than reproduce them in browser state.

The repository's current browser-facing transport remains `POST /op`; future browser streaming must be admitted separately. Likewise, there is currently no active React frontend to preserve by compatibility: the migration creates the first active web implementation while retaining the Redot tree as reference material only.

## 17. Redot freeze and archive
Redot is retained only as a historical/reference implementation.
### Preserve
- useful UI implementation;
- Visual Scene IR integration experiments;
- gateway client behavior;
- Observatory experiments;
- screenshots and proofs;
- tests/fixtures;
- theme/layout research;
- engine/version notes;
- implementation decisions that can inform the web renderer.
### Archive cleanly
Archive source and evidence needed for reconstruction, but do not treat generated caches as source:

```text
archive/frontend-redot-freeze/
```
Generated `.godot` caches, build artifacts, temporary files, and other disposable outputs should be excluded unless they are intentionally retained as forensic evidence.
### After freeze
- no new Redot features;
- no Redot redesign;
- no Redot feature parity;
- no new Redot semantic logic;
- no new Redot-specific contracts;
- no React implementation depending on Redot runtime behavior.
The archive must stay outside the normal active-agent implementation path.
## 18. Documentation re-homing requirement
This decision is incomplete until the repository's Redot-centered routing is re-homed. The active repo laws must be used before historical V5.2/Redot material.
Required follow-up:
| Owner | Required change |
|---|---|
| `docs/FRONTEND_UIUX_LAW.md` | Keep interaction law; replace Redot runtime assumptions with web-runtime verification and rules |
| `docs/WORLD_PRESENTATION_LAW.md` | Keep Scene IR/composition/asset law; make web renderer the active consumer |
| `docs/WORKBENCH_APP_LAW.md` | Make Web/PWA the active frontend companion; retain application/gateway ownership |
| `docs/REDOT_ENGINE_INDEX.md` | Mark historical/reference-only; no longer active frontend routing |
| `docs/AGENT_NAVIGATION.md` | Route active frontend work to React/Web docs first |
| `README.md` / repo map | Stop presenting Redot as the active Workbench frontend |
| launcher scripts / `.bat` | Re-home the active operator entry point from Redot to the web frontend |
| frontend tests/CI | Make React type/build/browser checks the active frontend verification path; add locked dependency install, typecheck, build, contract fixtures, and browser smoke/E2E once `frontend/` lands |
| `docs/ACTIVE_REPO_ROUTING.md` | Maintain active owner precedence and routing when repo structure/laws change |
| `docs/EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md` | Keep requested/effective/observed closure, lifecycle and reproduction semantics synchronized with the application owner |
| Redot tests | Preserve only tests still useful as archive/reference evidence |
This is a **documentation/architecture migration obligation**, not permission to expand scope into unrelated backend redesign.
## 19. Migration sequence
### Phase 0 — Freeze
- freeze Redot;
- archive it cleanly;
- preserve evidence;
- remove it from the active agent path.
### Phase 1 — Re-home the laws
- update routing/ownership docs listed in §17;
- establish browser verification terminology;
- remove Redot from active acceptance gates unless the gate is explicitly marked historical/archive.
### Phase 2 — Frontend foundation
Create React/TypeScript/Vite with:
- app shell;
- typed gateway client;
- runtime validation of wire payloads;
- explicit operation / connection / freshness state models;
- session/connection layer;
- contract identity / compatibility gate;
- design tokens;
- routing;
- SPA fallback/deep-link verification;
- test harness;
- visual regression harness;
- accessibility baseline;
- responsive viewport baseline;
- locked dependency install and reproducible production build;
- explicit frontend composition root;
- feature ownership/change-locality map;
- structured diagnostic envelope and DEV/assurance path;
- architecture/dependency-direction checks;
- bounded history/stream rendering harness.
### Phase 3 — Workbench vertical slice
Implement:
- shell/navigation;
- connection state;
- Chat/Inference;
- Settings/Appearance;
- Observatory/read-side entry;
- lifecycle/error/reconnect states.
### Phase 4 — Simulation and world
Integrate:
- simulation controls/read models;
- run/session surfaces;
- Visual Scene IR;
- web scene renderer;
- deterministic fixtures and visual proofs.
### Phase 5 — Remote/PWA
Validate:
- desktop browser;
- narrow/mobile browser;
- PWA install/update/activation;
- service-worker cache exclusions;
- frontend/gateway/Scene IR compatibility handling;
- secure remote transport;
- reconnect using retained sequence / replay or explicit resync;
- degraded/offline behavior;
- deep-link reloads;
- same-origin and deliberate cross-origin security behaviour;
- no false success while disconnected.
### Phase 6 — Optional Tauri
Only after web acceptance:
- package the same frontend with Tauri 2 if a native shell has proven value;
- keep Tauri thin;
- keep the web product fully functional without it.
## 20. Acceptance criteria
The decision is established when:
1. React/TypeScript/Vite is the only active frontend implementation.
2. CanonSim remains the semantic authority.
3. Workbench application/gateway remains the application boundary.
4. Visual Scene IR remains renderer-neutral and tested.
5. Redot is frozen and cleanly archived.
6. Active routing docs no longer require Redot for normal frontend work.
7. Browser frontend uses typed gateway/application contracts.
8. No frontend path bypasses the application/semantic boundary.
9. Desktop browser use works without Tauri.
10. Mobile/PWA use works against the same backend contract.
11. Stream/reconnect/error semantics preserve backend truth.
12. Offline/cache behavior cannot fabricate canonical state.
13. Accessibility, responsive/DPI, localization-ready layout, and reduced-motion rules are tested on the web target.
14. Important screens have visual regression coverage.
15. Frontend resource use is measured with simulation and local LLM load.
16. No monolithic `App.tsx` or equivalent God Component exists.
17. No secret is embedded in the client bundle.
18. Remote exposure is explicit, authenticated, and securely transported.
19. Dependencies are admitted by named consumer/problem/verification, not by fashion.
20. Tauri, if added later, remains an optional thin shell.
21. Production hosting serves the Vite build through an explicit, tested topology; `vite preview` is not used as the production server.
22. Browser network payloads are runtime-validated before reaching UI code.
23. Frontend/gateway/Scene IR compatibility identities are checked before using persisted/cached client data.
24. The current `/op` loopback transport remains the reference implementation until an explicit browser streaming transport is landed and tested.
25. Service-worker caches cannot become semantic authority and incompatible updates produce an explicit upgrade/reload path.
26. Frontend builds are reproducible from a committed lockfile using the declared package manager.
27. Browser authentication/session handling never requires secrets in URLs.
28. Operation outcome, connection state, freshness, and authority class remain separate state axes.
29. Frontend CI covers typecheck, build, unit/integration, browser smoke/E2E, and contract fixtures once the web app lands; Python gateway acceptance remains active in parallel.
30. Frontend composition has one explicit wiring root and no service-locator/global-registry architecture.
31. Every consequential feature has one state/operation owner and explicit feature change locality.
32. Connection, session, operation, stream, freshness, and authority state axes are not collapsed into one frontend status.
33. Structured diagnostics preserve correlation identity and bounded recovery evidence without logging secrets.
34. Large histories/results/streams are bounded by paging, virtualization, or progressive detail.
35. Visual containers establish semantic grouping or interaction boundaries rather than generic nested-card decoration.
36. Architecture tests or equivalent mechanical checks enforce forbidden frontend dependency directions.
37. Important frontend failures have executable recovery tests and do not fabricate success from UNKNOWN/STALE/OFFLINE states.
38. Debug/assurance surfaces are read-only projections and cannot create a semantic or data-exfiltration bypass.
39. Consequential frontend views preserve backend operation/execution identity, progress/terminality, cancellation truth and replay lineage where exposed.
40. The frontend does not reimplement backend deadline, retry, cancellation or idempotency policy.
41. High-consequence analytical surfaces have explicit context identity and shared semantic selection where the corresponding read-side semantics exist.
42. Analytical empty/no-result states preserve `NO DATA`, `NO MATCH`, `NO EVIDENCE`, `UNKNOWN`, `OUT OF SCOPE`, `BLOCKED`, `PARTIAL`, `STALE` and `FAILED` distinctions where applicable.
43. Compare, semantic zoom, timeline, bounded graph and evidence/provenance surfaces use stable semantic identities rather than display labels or row positions.
44. Research/assurance evidence can be reopened with sufficient run/result/provenance context when the backend/read-side contract provides such an artifact.
45. Visual/runtime/task/static proof classes are kept distinct and runtime-unavailable evidence never masquerades as a runtime pass.
46. Asset-manifest identity, Scene IR identity and application/read-model identity participate in compatibility checks when those surfaces are active.
47. Active repository binding laws are consulted before historical source-workbench material.
48. Consequential controls distinguish REQUESTED, ACCEPTED/REJECTED, EFFECTIVE, OBSERVED and PRESENTED states where the application exposes the distinction.
49. Model presentation distinguishes lifecycle stages; `selected` does not imply `active`.
50. Material prompt/profile and simulation-pack identity preserve reproducibility/lineage metadata where exposed; path/label alone is insufficient.
51. Resource-pressure states exposed by the application remain distinct rather than becoming generic frontend errors.
52. Snapshot provenance records HEAD, base commit and dirty/untracked status.

## 20c. Skeleton gate, dual-read, connection budget (v1.7)

Normative compact docs:

- `SKELETON_ACCEPTANCE.md` — **first walking client only**; four criteria; blocks full-matrix thrash.
- `STREAM_AND_CONNECTION_BUDGET_CONTRACT.md` — LIVE vs HISTORY dual-read; HTTP/1.1 connection budget; focused-tab stream default; failure class for budget exhaustion.
- `HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md` — optional P1 layout manifest / Capabilities screen / schema-driven settings (after S0).

Binding rules:

1. Implement S0 on `POST /op` only; no SSE/WebSocket in S0.
2. Live `session.events` tail is not durable history; label LIVE vs HISTORY.
3. Do not open unbounded per-tab streams against loopback HTTP/1.1 without an admission policy.
4. Tooling floor (typecheck, boundary lint, runtime validation, virtualization proof, multi-tab smoke) is expected after S0 for material surfaces.
5. Optional config/layout is presentation composition only — not a browser plugin kernel.

## 20b. Harness quality, browser runtime, and surface modules (v1.6)

These laws are normative for the web client and live in compact contracts:

- `HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md` — Trajectory surface, traceability axes, surface-level composability **without** a Cordis/dsh plugin kernel or browser agent loop. Import the quality bar, not the runtime.
- `BROWSER_RUNTIME_AND_SCALABILITY_CONTRACT.md` — multi-tab independent clients, process model, performance bounds, transport-adapter isolation, PWA/offline stale marking.
- `SURFACE_MODULE_CONTRACT.md` — how React surfaces are owned, mounted, and extended under one composition root.

Core rules added by v1.6:

1. Each browser tab is an independent gateway client; browser storage is never canon or an operation log.
2. Trajectory is a read-only projection of gateway/session evidence, not a client-authored log.
3. Surfaces talk only through a typed gateway client; transport (POST now, SSE later) is swappable behind that boundary.
4. Do not port a plugin runtime, second event bus, or tool-calling agent loop into the browser.
5. Large read models must be virtualized or explicitly bounded.

## 21. Non-goals
- Redot and React feature parity.
- Pixel parity with the Redot UI.
- A separate native mobile UI.
- Electron.
- Moving CanonSim semantics into the browser.
- Browser-side model inference by default.
- WebGPU before a measured need.
- A large generic visualization DSL.
- A mandatory global state-management framework.
- A mandatory UI/component framework.
- Rebuilding the backend merely to make the web frontend "cleaner".
- Porting DeepSeek Harness / Cordis plugin kernel into the browser.
- A client-authored trajectory or event log that diverges from gateway `session.events`.
- Multi-tab leader election or browser storage as semantic authority.

## 22. Final architecture

```text
ACTIVE
======
CanonSim
Python Workbench application
Workbench Gateway / typed application contracts
Visual Scene IR
React
TypeScript
Vite
Web / PWA
DOM/CSS + Canvas/WebGL as justified
browser-native transport APIs behind a gateway client boundary
explicit static-hosting / SPA-fallback deployment contract
runtime-validated wire payloads + compatibility gate
OPTIONAL FUTURE
===============
Tauri 2
WebGPU
additional renderer(s)
FROZEN / ARCHIVED
=================
Redot Workbench frontend
Redot-specific shell/UI
Redot-specific visual/runtime experiments

WEB CLIENT LAW (v1.6+)
======================
Harness-quality Trajectory + traceability (no Cordis port)
Surface modules under one composition root
Multi-tab independent clients
Bounded rendering + transport-adapter isolation

SKELETON / STREAM (v1.7)
========================
S0 gate before full matrix
Dual-read LIVE vs HISTORY
Connection budget + focused-tab stream policy
Optional layout/config P1 after S0
Tooling floor post-S0
```
### Final agent rule
**Build forward only on React + TypeScript + Vite + Web/PWA-first. Treat Redot as archived reference material. Preserve CanonSim, Workbench application/gateway, typed contracts, renderer-neutral Visual Scene IR, execution/provenance identity and read-side analytical contracts as the stable backbone. Do not create a second semantic authority, second transport/server, or parallel frontend product. Apply the Workbench engineering laws to the web client: one owner per consequential feature, one visible composition root, explicit state/lifecycle axes, structured bounded diagnostics, truthful recovery, bounded read rendering/caching, semantic rather than decorative containers, shared semantic selection/context for analytical surfaces, explicit epistemic/empty-state grammar, and agent-operable verification. Treat the browser as untrusted, validate every wire payload at the gateway-client boundary, keep static hosting and browser transport explicitly bounded, and never allow cache, UI state, client inference, or presentation state to become canonical truth. Route conflicts through `ACTIVE_REPO_ROUTING.md`; preserve effective-state closure, lifecycle truth, resource-admission evidence and reproduction identity.**
