# Stream and Connection Budget Contract

**Status:** ACTIVE (web frontend law)  
**When to implement:** After Skeleton S0 is green. S0 stays on `POST /op` only.

## 1. Dual-read law (session tail vs durable history)

Two different evidence worlds exist. The UI must not merge them into one silent cursor.

```text
LIVE SESSION TAIL
  source: gateway session.events (or equivalent ordered live surface)
  properties: volatile, FIFO/retention limited, sequenced, RESYNC_REQUIRED
  UI label: LIVE / SESSION
  use: current run progress, live Trajectory tail, reconnect

DURABLE HISTORY
  source: Observatory read-side over committed logs (logs/*.jsonl), execution artifacts, provenance
  properties: durable, queryable, bounded pages, pack/run identity
  UI label: HISTORY / ARCHIVE
  use: past runs, full Trajectory across sessions, replay lineage
```

Rules:

1. A Trajectory surface that only reads the live tail must be titled/labelled as live session evidence, not “all history”.
2. Cross-run / past-run Trajectory requires durable Observatory (or equivalent) read models — not an ever-growing client buffer of session.events.
3. Cursors, selection ids, and “load more” tokens must not be mixed across LIVE and HISTORY without an explicit mode switch.
4. FIFO eviction in the live tail is not data loss of canon; durable logs remain the historical authority when the application provides them.

## 2. Connection budget (browser + loopback server)

Facts:

- HTTP/1.1 browsers typically allow on the order of **six concurrent connections per origin**.
- The current gateway transport is loopback HTTP (`ThreadingHTTPServer`-class). It is not automatically HTTP/2.
- N tabs each holding a long-lived stream can exhaust the budget; further tabs then stall.

Frontend laws:

1. Do not open unbounded streams (one SSE/EventSource per tab × many tabs) without an admission policy.
2. Treat **connection budget exhausted** as a first-class failure/degradation class, distinct from “gateway dead”:

```text
transport unavailable
stream disconnect
connection budget exhausted / stream not admitted
stale / resync required
```

3. Preferred defaults **before** HTTP/2 or a server-side fan-out exists:

| Policy | Behaviour |
|---|---|
| **Focused-tab stream (default recommendation)** | Only the focused tab may hold a live stream; background tabs use poll, last-known snapshot, or explicit refresh and show STALE |
| Cap streams per origin | e.g. at most 1–2 live streams; additional tabs degrade honestly |
| POST-only | Always valid; S0 mandate |

4. **SharedWorker / Service Worker must not** become a hidden stream multiplexer that owns semantics or a second event bus. Packaging-only shared transport, if ever admitted, requires its own gateway contract and tests — not an agent improvisation.

5. Auth material never appears in stream URLs.

## 3. Stream transport admission order

```text
1. POST /op only (landed; S0)
2. Explicit gateway contract for one-way stream (SSE or fetch-stream) + tests
3. Browser adapter behind typed gateway client
4. Focused-tab or budget policy enforced in UI
5. HTTP/2 or server fan-out only if measured need
6. WebSocket only for a concrete bidirectional requirement
```

Do not skip to step 6. Do not implement step 2–4 during S0.

## 4. Acceptance hooks

- Dual-read: UI copy or mode distinguishes LIVE vs HISTORY when both exist.
- Multi-tab: at least one test or recorded note that extra tabs degrade without corrupting another tab’s client state.
- No stream implementation without gateway contract + budget policy note in the PR.
- Failure UI can represent connection-budget exhaustion without claiming the backend process is down.
