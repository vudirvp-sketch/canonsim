# Seam Contracts

## Gateway
- Existing semantic entry is `POST /op`.
- Payloads use RequestEnvelope / ResponseDocument / EventEnvelope.
- Closed vocabularies and unknown-key rejection are backend-owned.
- Browser consumes typed/validated adapters; raw JSON never reaches components.

## Session stream
- `session.events` is an ordered per-session replay surface.
- Retained sequence + `RESYNC_REQUIRED` semantics are existing backend law.
- Browser transport for future SSE/WebSocket is not yet landed and must be separately admitted/tested.
- Client architecture must isolate transport adapters so surfaces do not hard-code POST-only assumptions beyond the typed client API.

## Execution
- Long-running work already has execution identity, deadline, cancellation and progress concepts.
- Ambiguous post-dispatch results remain UNKNOWN.
- Cancellation must not be visually treated as completed merely because a request was sent.

## Provenance
- Execution artifacts freeze material inputs/identities and may include capability/runtime/model/protocol/reproducibility information.
- Replay creates a new execution identity and keeps lineage via `replay_of`.

## Observatory / Trajectory
- Current read-side already supports bounded run listing and bounded event windows.
- Event ids are semantic cursor/selection identities.
- NO DATA / NO MATCH / stale cursor / corrupt log are distinct observations.
- Trajectory is a presentation of the same evidence class, not a second store.

## Scene
- Visual Scene IR is renderer-neutral.
- Scene composition identity must remain distinct from canonical semantic identity.
- Asset identity/provenance is presentation metadata, not canonical truth.

## Effective-state closure
Consequential controls preserve `REQUESTED → ACCEPTED/REJECTED → EFFECTIVE → OBSERVED → PRESENTED` where the application exposes the distinction. A widget value is not evidence of effective application state.

## Model / resource lifecycle
A selected model is not necessarily loaded or active. Where exposed, preserve discovery/validation/selection/loading/loaded/active/failure/eviction and resource `ACCEPT/QUEUE/REJECT/EVICT/RELOAD` distinctions.

## Reproduction identity
Replay uses a new execution identity. Material simulation packs are not identified by path/display label alone; preserve logical/revision/schema/content/compatibility identity where exposed.

## Multi-tab / browser process
Each browser tab is an independent gateway client. Cross-tab channels (if any) are non-authoritative UX hints only. Browser storage is never the operation log or effective-state authority. See `BROWSER_RUNTIME_AND_SCALABILITY_CONTRACT.md`.

## Surface modules
Material UI areas mount as surface modules under one composition root. See `SURFACE_MODULE_CONTRACT.md`.

## Dual-read (session vs durable)
- `session.events` is the live ordered tail (volatile, retention-limited).
- Durable Trajectory/history uses Observatory read-side over committed logs and execution artifacts.
- UI must not present the live tail as complete historical Trajectory.
- See `STREAM_AND_CONNECTION_BUDGET_CONTRACT.md`.

## Connection budget / stream admission
- Unbounded per-tab long-lived streams against HTTP/1.1 loopback are not admitted.
- Preferred interim policy: focused-tab stream; background tabs degrade to poll/STALE.
- `connection budget exhausted` is distinct from transport unavailable.
- No SSE/WebSocket until gateway contract + tests exist; S0 is POST-only (`SKELETON_ACCEPTANCE.md`).

