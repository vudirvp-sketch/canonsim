# Acceptance Matrix

## Phase gate
- **Skeleton S0** (`SKELETON_ACCEPTANCE.md`) must pass before treating this full matrix as the active implementation backlog.
- S0 deliberately ignores most rows below; do not block the skeleton on visual system completeness or SSE.

# Acceptance Matrix

## Foundation
- React/TypeScript/Vite build reproducible from one committed lockfile.
- One visible composition root.
- No feature-private-state bypasses.
- Runtime schema validation at the gateway-client boundary.
- Surface modules follow `SURFACE_MODULE_CONTRACT.md` (ownership, state matrix, no raw fetch in components).

## Routing / snapshot truth
- active repo law is consulted before historical source-workbench material;
- snapshot provenance records HEAD/base/dirty status;
- historical Redot material cannot override active repo owners.

## Application truth
- operation/execution identity preserved;
- UNKNOWN remains UNKNOWN;
- cancellation terminality truthful;
- stale/reconnect/resync truthful;
- credentials absent from URLs/logs/bundle;
- frontend does not reimplement backend retry/deadline/idempotency policy;
- requested/accepted/effective/observed/presented states remain distinct where exposed;
- model lifecycle and resource admission are displayed from application evidence, not inferred from widget selection;
- replay identity and material input/pack identity are preserved where exposed;
- material adapters have contract tests for capabilities/defaults/errors/cancel/stream/UNKNOWN.

## Harness / Traceability
- Trajectory (or equivalent analytical surface) can present ordered session/execution evidence with semantic cursor;
- replay UI requests/creates distinct execution identity when application supports replay;
- failure presentation includes what failed / best-known cause / what remains intact / whether effect is known / next action / correlation id;
- no client-authored trajectory log that diverges from gateway `session.events`;
- no browser-side agent/tool loop outside gateway mediation.

## Dual-read / stream budget
- LIVE session tail vs HISTORY durable Observatory are distinguishable in UI when both exist;
- live tail is not presented as complete historical Trajectory;
- no SSE/WebSocket without gateway contract + connection admission policy;
- connection budget exhaustion is distinct from gateway-down;
- focused-tab (or documented cap) policy when streams exist.

## Browser runtime
- two tabs behave as independent clients (no shared mutable semantic store);
- cross-tab messaging, if present, is non-authoritative UX only;
- large lists use virtualization/windowing or a documented hard bound;
- gateway client isolates transport; surfaces do not open raw EventSource/WebSocket;
- disconnect / stale / resync states remain distinct;
- PWA/offline (if shipped) marks stale presentation explicitly;
- DOM vs Canvas/WebGL split respected; no unbounded live React trees of full history.

## Analytical UX
- context strip / identity recovery;
- semantic shared selection;
- query lifecycle;
- empty/no-result distinction;
- evidence/provenance reachability;
- bounded compare/timeline/graph/trajectory where admitted;
- reopenable analytical context where session/read-side supports it.

## Visual
- each material surface has an explicit honest state matrix;
- functional correctness is accepted before visual refinement is promoted;
- Scene IR contract tests;
- visual regression;
- bounded rendering;
- compatibility identity check;
- missing/stale/incompatible asset degradation;
- semantic-vs-presentation camera separation.

## Proof
- static/runtime/task/visual proof classes distinct;
- runtime-unavailable never reported as runtime-pass;
- evidence artifact can reconnect visible result to run/revision/source where supported.

## Current repository truth
- Current browser-facing transport is `/op`.
- Current active CI is Python-only; frontend CI is an added verification layer, not a replacement.
- React frontend does not yet exist in the supplied repository snapshot; this pack is the implementation contract for adding it.
- SSE/WebSocket delivery is not landed; do not code against imagined routes.

## Tooling floor (post-S0 recommendation, then mandatory for material surfaces)
- Deterministic `typecheck` + unit/contract tests for gateway client.
- Dependency boundary check (e.g. eslint-boundaries or dependency-cruiser): components must not import raw transport/fetch.
- Runtime validators (e.g. zod/valibot) with types derived from or checked against Python contract fixtures — not hand-retyped in isolation.
- Virtualization proof for large event/run lists.
- Playwright (or equivalent) smoke: multi-tab independent clients, reconnect/STALE path, UNKNOWN outcome path.
- Frontend CI is additive; it does not replace Python CI.

## Optional P1 (not blocking)
- Layout manifest / Capabilities screen / schema-driven settings per `HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md`.
