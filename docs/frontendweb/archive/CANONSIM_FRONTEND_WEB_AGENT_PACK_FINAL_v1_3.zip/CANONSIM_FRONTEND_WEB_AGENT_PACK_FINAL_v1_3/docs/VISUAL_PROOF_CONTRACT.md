# Visual / Proof Contract

## Scene
Visual Scene IR is renderer-neutral, typed and non-authoritative.

## Composition identity
Where applicable, material identity should include semantic/read input identity, seed, composition policy version, Scene IR schema identity and asset-manifest identity.

## Assets
Use logical identity + revision/content identity. Invalid/stale/incompatible assets must fail visibly or degrade safely; asset paths/URLs are not semantic identity.

## Camera
Semantic focus/target ≠ presentation camera ≠ user camera state.

## Boundedness
No unbounded history tree, stream buffer, graph, scene allocation or asset cache.

## Degradation
Missing asset → placeholder/diagnostic; stale scene → rebuild/refresh; backend loss → preserve local UI state and show unavailable; render failure ≠ semantic failure.

## Surface state honesty
Every material surface should declare the states it can truthfully present (for example `EMPTY`, `LOADING/DISCOVERING`, `ACTIVE/RESOLVED`, `STALE/DEGRADED`, `FAILED` as applicable). A missing state in the matrix is an explicit gap, not an invitation to invent a generic spinner/error. The active visual owner is the repository's `docs/VISUAL_SYSTEM_UI.md`.

## Proof classes
STATIC_VERIFIED / RUNTIME_VERIFIED / TASK_VERIFIED / VISUAL_VERIFIED / MANUALLY_VERIFIED / DEFERRED / NOT_VERIFIED.

A screenshot is visual evidence, not semantic proof.

## Screenshot artifact
Where useful include build identity, surface/state identity, fixture/seed, revision/compatibility identity and bounded debug metadata.
