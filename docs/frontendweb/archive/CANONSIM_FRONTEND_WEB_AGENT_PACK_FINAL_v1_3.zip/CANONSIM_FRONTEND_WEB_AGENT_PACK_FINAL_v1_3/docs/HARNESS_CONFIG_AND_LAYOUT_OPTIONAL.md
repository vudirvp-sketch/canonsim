# Harness Config and Layout (Optional P1)

**Status:** OPTIONAL — open only after Skeleton S0 is green  
**Intent:** DeepSeek-like *configurability* without a browser plugin kernel or Cordis port.

## What this is

Presentation-side composition and visibility of application-owned effective state — not semantic plugins in React.

## P1-A — Layout manifest (config instead of code)

A declarative, runtime-validated manifest listing which surfaces/panels/modes are available and how they arrange, for example:

```text
surfaces[]: id, enabled, route, default panel role
panels[]: id, surface, region (context | primary | inspector | …)
modes[]: id, visible surfaces, default selection policy
```

Rules:

1. Manifest is presentation composition only. It cannot grant new gateway ops or invent semantics.
2. Validate at runtime; invalid manifest → safe default shell + explicit error, not a blank app.
3. Version the manifest; incompatible manifest is a first-class failure class.
4. Surface modules still follow `SURFACE_MODULE_CONTRACT.md`; the manifest only selects/mounts them.

## P1-B — Capabilities / Config screen

A read-mostly surface that shows:

```text
BASE PROFILE
→ SESSION OVERRIDE
→ CALL-LOCAL OVERRIDE
→ VALIDATION / CLAMP
→ EFFECTIVE
→ OBSERVED
```

plus backend capability/status rows the gateway already exposes (models, admission, transport mode).

Rules:

1. Values come from application evidence, not widget defaults.
2. Edits go through gateway ops; the screen does not compute effective state itself.
3. Align with `EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md`.

## P1-C — Settings from schema

Where Python owns “setting as data” (packs, backend.settings, launch settings), prefer generating or driving form UI from a machine-readable schema/fixture exported or mirrored from the application — not a second hand-maintained React form model.

Rules:

1. Schema is application-owned; frontend may not extend semantic enums unilaterally.
2. Unknown fields rejected or shown as non-editable evidence.
3. Ties to existing pack/settings identity rules (path is locator, not identity).

## Non-goals

- Cordis / dsh plugin mounting in the browser
- User-loadable semantic plugins that bypass the gateway
- Replacing Workbench operations with client-side workflows

## Acceptance (when P1 is opened)

- Manifest invalid path safe.
- Config screen shows at least one requested≠effective example.
- Schema-driven settings path has a contract test against a frozen fixture.
