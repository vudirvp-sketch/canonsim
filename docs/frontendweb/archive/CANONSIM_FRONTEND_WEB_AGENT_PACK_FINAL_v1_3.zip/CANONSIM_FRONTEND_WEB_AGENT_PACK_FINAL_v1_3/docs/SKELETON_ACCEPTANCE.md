# Skeleton Acceptance (Phase S0)

**Status:** ACTIVE for the first walking client only  
**Rule:** During S0, agents MUST NOT expand into full ACCEPTANCE_MATRIX, source-workbench V5.2 trees, SSE implementation, surface registry, layout manifest, or Redot parity. Those gates open only after S0 is green.

## Goal

A minimal React + TypeScript + Vite client that talks to the existing loopback gateway, proves multi-tab and large-list behaviour, and measures cost next to a live sim/LLM — in about 1–2 weeks of focused work.

## In scope (exactly four criteria)

### S0-1 — Gateway client
- One Vite + React + TypeScript app with a single composition root.
- Typed `POST /op` client; every payload enters as `unknown` and is runtime-validated before UI use.
- At least one successful op round-trip and one honest UNKNOWN/rejection path in UI.
- No raw `fetch` JSON into components; no second envelope; no browser-side semantics.

### S0-2 — Trajectory over live session tail
- A Trajectory (or equivalent) surface renders ordered evidence from `session.events` (or the current bounded session read the gateway exposes).
- Virtualization or an explicit hard window: prove UI remains usable with **≥ 10_000** synthetic/appended events (scroll, select by semantic id, no full-tree mount).
- Cursor is semantic id/sequence, not row index.
- UI must label this view as **live session tail** (volatile), not durable history.

### S0-3 — Multi-tab / connection behaviour
- Two browser tabs act as **independent** gateway clients (no shared mutable semantic store; no `localStorage` / `BroadcastChannel` as truth).
- Document observed behaviour under concurrent use (including any connection pressure).
- **Do not implement SSE/WebSocket in S0.** Stay on `POST /op` (poll or explicit refresh is allowed and must show STALE/freshness).
- If a third+ tab is opened, UI must not silently corrupt state; degradation may be coarse but must be truthful.

### S0-4 — Measurement under load
- With simulation and/or local LLM active on the Python side, record rough numbers: UI interaction feel, memory of the tab, and whether a scene/WebGL path is off by default.
- Scene/WebGL is **optional and default-off** in S0. Prefer a feature flag `scene=off`.
- Write results into a short note (even a markdown snippet in the PR); no need for a full perf lab.

## Explicitly out of scope for S0

```text
SSE / WebSocket
layout manifest / surface registry
full Observatory compare/graph suite
PWA offline package
Tauri
Redot changes or deletion
reading source-workbench V5.2 for implementation detail
closing the full ACCEPTANCE_MATRIX
JSON-Schema-driven settings UI
dependency-cruiser CI (recommended immediately after S0, not blocking S0 green)
```

## Dual-read reminder (even in S0)

```text
session.events / live tail  →  volatile, sequenced, resync — label as LIVE
durable logs / artifacts    →  Observatory history — not required in S0 UI
```

Do not present the live tail as the full durable Trajectory of past runs.

## Pass / fail

S0 passes when S0-1..S0-4 are evidenced (demo or short notes + tests where cheap).  
Only then open the broader pack gates (streaming policy, harness config, full acceptance).

## Agent discipline

1. Prefer this file over `ACCEPTANCE_MATRIX.md` until S0 is green.
2. Do not invent gateway routes.
3. Do not “complete” visual system or V5.2 polish in S0.
4. One PR theme at a time: client shell → trajectory virtualized → multi-tab note → load note.
