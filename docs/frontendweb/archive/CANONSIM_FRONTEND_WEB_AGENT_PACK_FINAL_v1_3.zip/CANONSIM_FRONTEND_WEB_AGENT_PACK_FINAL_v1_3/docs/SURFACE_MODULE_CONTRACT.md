# Surface Module Contract

**Status:** ACTIVE (web frontend law)  
**Audience:** Coding agents / maintainers  

## Purpose

Define how React surfaces are added and extended so the frontend stays editable, scalable, and harness-shaped — without a browser plugin kernel.

## Module shape

```text
surfaces/<surface_id>/
  index (mount API)
  state matrix (honest UI states)
  adapters (typed gateway client usage only)
  components (presentation)
  tests / fixtures / proof hooks
```

Required metadata (in code or adjacent manifest as preferred by repo layout):

```text
surface_id
owner
gateway ops / read models consumed
local presentation state only (explicit)
honest state matrix
entry routes / commands
```

## Allowed local state

```text
draft form fields
UI open/closed, tab, scroll restore
pending optimistic markers (must reconcile)
view preferences that are not semantic authority
```

## Forbidden in a surface module

```text
canonical event log
retry / deadline / idempotency policy
second transport or event bus
raw network JSON into components
model load/evict policy
admission policy
pack identity invention from path alone
```

## Mounting

- App has one composition root.
- Surfaces register or are imported under that root.
- Code-splitting via dynamic import is packaging, not semantics.
- Shared selection and context strips are shared facilities, not owned by one surface as hidden globals.

## Extension checklist (agent)

Before adding a surface:

1. Confirm read-side / gateway ops already expose needed evidence (or land backend first).
2. Declare state matrix including empty/stale/failed/partial.
3. Wire only through gateway client + validators.
4. Add contract tests for UNKNOWN / cancel / rejection paths.
5. Add visual proof hooks if the surface is material.
6. Update transfer/acceptance only if a new class of capability is introduced.

## Relation to Harness contract

Surface modules are the UI half of “everything is a plugin”. Semantic plugins remain Workbench/gateway-owned. See `HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md`.
