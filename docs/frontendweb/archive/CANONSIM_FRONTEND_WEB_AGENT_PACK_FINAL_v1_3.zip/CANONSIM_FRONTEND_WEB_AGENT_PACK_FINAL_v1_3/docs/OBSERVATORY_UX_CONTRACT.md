# Observatory UX Contract

Analytical frontend surfaces use semantic roles, not screen-history semantics:

```text
CONTEXT → QUERY/SCOPE → PRIMARY VIEW → INSPECTOR → EVIDENCE/PROVENANCE
```

Trajectory (ordered run/event/execution evidence) is a first-class analytical primary view. See `HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md`.

## Shared selection
One canonical/typed identity must drive cross-highlighting. Never synchronize by row index, display text or local widget ids.

## Context
At minimum, show/recover run/execution identity, scope/time, seed where relevant, observation profile, revision and freshness for high-consequence surfaces.

## Semantic navigation
Prefer scope → target → evidence → source. Preserve Back/Forward and prior focus without requiring manual id copying.

## Compare
BASE and PERTURBED share semantic/time coordinates. Differences are anchored to identity/time, not color alone.

## Semantic zoom
Aggregation/label density may change by level; underlying semantic identity must not silently change.

## Timeline
Primary bounded temporal view; should support selection, range, focus, compare alignment and source/evidence jumps where read-side semantics exist.

## Trajectory
Ordered projection of session events, executions, admissions, cancellations, and lineage (`replay_of`) where exposed. Cursor is semantic id/sequence. Search is bounded read-side query, not a second log. Never client-authored canon.

## Graph
Contextual microscope. Bound nodes, edges, depth, labels and layout scope.

## Evidence
Evidence strength is independent from mere graphical adjacency or generated prose.

## Empty states
`NO DATA ≠ NO MATCH ≠ NO EVIDENCE ≠ UNKNOWN ≠ OUT OF SCOPE ≠ BLOCKED ≠ PARTIAL ≠ STALE ≠ FAILED`.

## Reopening
Persistent analytical state should be reopenable when the application/session contract supports it.

## Multi-surface coordination
Observatory, Trajectory, Inspector, and Chronicle share selection identity. They must not invent a private cross-surface event bus; use shared selection + gateway evidence only.

## Dual-read modes
- **LIVE** — current session tail (`session.events`); volatile; label explicitly.
- **HISTORY** — durable runs via Observatory read-side (logs/artifacts); bounded queries.
- Do not mix cursors across modes without an explicit mode control.
- Full past-run Trajectory is HISTORY, not an infinite LIVE buffer.

