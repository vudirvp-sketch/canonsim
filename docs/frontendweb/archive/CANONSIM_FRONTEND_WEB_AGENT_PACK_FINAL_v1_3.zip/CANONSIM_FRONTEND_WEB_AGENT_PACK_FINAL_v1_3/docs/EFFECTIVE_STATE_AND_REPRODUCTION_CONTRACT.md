# Effective State, Lifecycle and Reproduction Contract

## Purpose

The frontend must never turn an editable/requested value into a claim that the application actually accepted, applied, or observed it.
This contract concentrates the Workbench rules that are easy to lose when moving from a stateful desktop UI to a browser client.

## 1. State closure

For material controls and consequential operations, keep these stages distinct:

```text
REQUESTED
  ↓
ACCEPTED / REJECTED
  ↓
EFFECTIVE
  ↓
OBSERVED
  ↓
PRESENTED
```

Meaning:

- `REQUESTED` — what the user or client asked for.
- `ACCEPTED` — the application/gateway accepted the request for processing.
- `EFFECTIVE` — the application resolved the actual value/setting used by the runtime.
- `OBSERVED` — the result/state actually reported by the application/backend.
- `PRESENTED` — what the current frontend surface is rendering.

These stages may coincide, but they are never assumed equivalent.

### Forbidden collapse

```text
input.value === EFFECTIVE
click === success
selected === loaded
profile label === execution identity
HTTP 200 === semantic success
tab local state === shared truth across tabs
```

The frontend mirrors application evidence; it does not promote a draft or optimistic projection into semantic truth.

## 2. Inference/profile composition

For settings and inference controls, preserve the application-owned composition path:

```text
BASE PROFILE
→ SESSION OVERRIDE
→ CALL-LOCAL OVERRIDE
→ VALIDATION / CLAMP / NORMALIZATION
→ EFFECTIVE CONTROL STATE
→ OBSERVED RUNTIME STATE
→ PRESENTATION
```

The UI may edit the first three layers according to the exposed contract. It must not silently replace the effective-state calculation.

A control with `AUTO`, an explicit value, `DISABLED`, `INEFFECTIVE`, or another owner-defined state must render the state and reason supplied by the application. Do not infer it from the widget value alone.

## 3. Model lifecycle

A model's lifecycle is not one boolean.

```text
DISCOVERED
→ VALIDATED
→ SELECTED
→ LOADING
→ LOADED
→ ACTIVE
→ UNLOADING / EVICTED
→ FAILED
```

UI implications (presentation only):

| Observed state | Typical affordances |
|---|---|
| DISCOVERED / VALIDATED | may offer select |
| SELECTED | may offer load; must not claim loaded |
| LOADING | progress + cancel if application supports it |
| LOADED | may offer activate / unload |
| ACTIVE | primary inference target; unload/evict paths honest |
| FAILED / EVICTED | show application reason + recoverable action |

A file existing on disk is not proof that it is valid, selected, loaded, or active.
The frontend displays the application-owned lifecycle and may expose user actions appropriate to each observed state; it does not implement model loading semantics.

## 4. Resource admission

Where the backend/application exposes resource pressure, preserve its distinction rather than rendering every non-running request as an error:

```text
ACCEPT
QUEUE
REJECT
EVICT
RELOAD
```

Useful material dimensions may include CPU, RAM, VRAM, model slots, context budget, queue capacity, or stream capacity when actually exposed by the application.

The browser does not decide admission policy. It reports the owner-provided blocking reason and current recoverable action.

## 5. Prompt and input ownership

Editable prompt/profile controls are client interaction surfaces, not semantic authority.

For a consequential execution, freeze material inputs at the execution boundary and preserve their identity in the execution/reproduction artifact when supplied.
A later UI edit must not retroactively rewrite an already-created execution's effective inputs.

## 6. Simulation Pack identity

Never identify a material simulation/content pack by path or display label alone.
When the application exposes the fields, preserve:

```text
logical_pack_id
+ pack_revision
+ schema_identity
+ content_identity
+ compatibility
+ location / source metadata
```

Path/URL is a locator. It is not identity.

## 7. Replay and reproduction

A replay/re-run is a new execution identity.
Preserve lineage such as `replay_of` where the application exposes it.
Do not reuse the original operation/execution identity merely because the inputs are intended to match.

A browser-displayed reproduction view must retain enough run/result/source/provenance identity to reconnect the visible evidence to the owning read-side/application artifact when that artifact exists.

Trajectory and Observatory surfaces must be able to navigate lineage without inventing a client-side log. See `HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md`.

## 8. UI truth rule

The frontend may optimistically reflect an interaction as `PENDING` or equivalent local presentation state, but it must reconcile to application evidence before presenting semantic success.

```text
LOCAL INTENT / DRAFT
        ≠
APPLICATION ACCEPTANCE
        ≠
EFFECTIVE VALUE
        ≠
OBSERVED RESULT
        ≠
CURRENT PRESENTATION
```

Per-tab presentation may differ; application evidence remains the reconciliation source for each client independently.

## 9. Verification requirements

Tests for consequential features should include at least one case where:

1. requested value differs from effective value;
2. selected model is not yet loaded;
3. transport succeeds but semantic outcome is rejected/unknown;
4. resource pressure queues or rejects an operation;
5. a replay gets a distinct execution identity;
6. stale/old presentation cannot overwrite a newer observed state;
7. two independent clients (e.g. two tabs) do not share a mutable semantic store.

The exact application vocabulary remains owned by `docs/WORKBENCH_APP_LAW.md` and the relevant domain law.
