# Changelog — Frontend Web Agent Pack

## v1.3 (2026-09-28)

### Added
- `docs/SKELETON_ACCEPTANCE.md` — Phase S0 walking-client gate (4 criteria: gateway client, virtualized live Trajectory ≥10k events, multi-tab independence on POST/op, load measurement). Blocks full-matrix / V5.2 thrash.
- `docs/STREAM_AND_CONNECTION_BUDGET_CONTRACT.md` — dual-read LIVE vs HISTORY; HTTP/1.1 connection budget; focused-tab stream default; failure class `connection budget exhausted`; admission order for streaming.
- `docs/HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md` — optional P1 layout manifest, Capabilities/Config screen, schema-driven settings (presentation only).
- Acceptance: phase gate, dual-read/stream budget section, tooling floor (boundaries, runtime validation, virtualization, multi-tab smoke).
- Agent read order: S0 subset vs post-S0 full list.
- Stack decision content revision **v1.7** (section 20c, non-goals, architecture box).

### Corrected / tightened
- Harness + Observatory + Seam: live session tail must not be presented as durable Trajectory; FIFO retention ≠ loss of canon.
- Browser runtime §9 points at stream/budget contract.
- Transfer matrix rows for dual-read, connection budget, S0 gate, tooling floor, optional layout.

### Intentionally not added
- No SSE/WebSocket implementation.
- No SharedWorker multiplexer.
- No Cordis/dsh dependency.
- No mandatory layout manifest in S0.
- No Redot deletion requirement in S0.

## v1.2
See `CHANGELOG_v1_2.md`.

## v1.1
See `CHANGELOG_v1_1.md`.
