# Legacy Redot Transfer Notes

These files are selected reference evidence only. They are not an instruction to preserve Redot structure.

## Transfer directly in concept
- `gateway_client.gd`: one frontend transport boundary; UI surfaces emit requests instead of opening transport themselves.
- `observatory.gd`: semantic context strip, shared semantic selection, bounded pagination, semantic breadcrumb, inspector, evidence ladder, truthful empty/read states.
- `seam_proof.gd`: deterministic fixture/IR → render → screenshot + metadata → terminal exit proof pattern.
- `strings.gd`: one explicit translation boundary; user-facing strings are keyed, not scattered literals.
- `workbench_theme.tres`: semantic token source / component-state token discipline; in React this becomes typed design tokens/CSS variables/theme modules.

## Do not port literally
- Redot node hierarchy or `.tscn` structure.
- `shell.gd` as a composition pattern: the historical shell is a large integration object; the web decision explicitly requires one visible composition root plus bounded feature ownership instead.
- `.godot` caches, generated artifacts, or engine/editor metadata.
- Engine-specific focus, scene-tree or resource APIs.

## Practical web translation
```text
gateway_client.gd  → frontend/api/gateway client + contract decoder
observatory.gd     → features/observatory/{query,context,selection,evidence,views}
seam_proof.gd      → tests/proof + Playwright/browser capture harness
strings.gd         → i18n adapter + message catalog boundary
theme.tres         → design-system tokens + CSS variables + component states
```
