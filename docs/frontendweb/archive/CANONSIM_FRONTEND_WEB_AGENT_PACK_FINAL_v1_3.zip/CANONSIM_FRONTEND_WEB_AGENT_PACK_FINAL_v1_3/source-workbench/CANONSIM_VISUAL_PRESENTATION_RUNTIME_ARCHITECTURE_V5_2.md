# CanonSim — Visual / Presentation Runtime Architecture v5.2 (Redot)
> **Роль в архитектуре:** этот документ является подробным source/research companion по визуальному runtime, Redot, 2D/2.5D, ассетам и procedural composition. Нормативным frontend/UI документом является `CANONSIM_FRONTEND_UI_VISUAL_ENGINEERING_SPEC_V5_2.md`; нормативной application/runtime границей является `CANONSIM_WORKBENCH_APPLICATION_ARCHITECTURE_V5_2.md`. При расхождении действуют owner-документы, а этот файл сохраняет исследовательскую детализацию и rationale.
>
> **Новые контракты, которые должны оставаться синхронизированными с v5.2:** composition identity, Visual Scene IR schema identity, Asset Manifest identity/lifecycle, scene invalidation/rebuild, semantic-vs-presentation camera separation, shared-GPU admission и observation-profile-scoped rendering of derived Observatory evidence.


## 0. Статус и назначение документа

**Статус:** v5.2 Redot runtime architecture; direction is fixed, while exact engine/API/runtime behaviour is mechanically verified on the vertical proof.


Этот документ описывает не «рендерер ради рендера», а визуальный и интерактивный runtime CanonSim/Workbench как единого продукта.

Главный вывод после уточнения целевой модели продукта:

> **Workbench и «игра» — один продукт и один frontend.**
>
> Workbench-функциональность (чат, модели, inference, prompts, history, diagnostics, simulation, settings, developer surfaces и т.п.) не должна существовать как отдельное desktop-приложение, которое позже обрастает игрой. Она должна жить внутри того же application/frontend runtime, в котором пользователь наблюдает и исследует мир CanonSim.

Поэтому текущим основным frontend/runtime является **Redot 26.2 LTS**; на дату этой редакции подтверждён stable-релиз **Redot 26.2 LTS**. Визуальная задача на первом этапе — **2D/2.5D procedural composition + sprites/animated sprites + effects + UI**, а не полноценный 3D game renderer.

Panda3D, ModernGL, wgpu и другие graphics stacks не являются обязательными runtime-зависимостями текущей архитектуры. Они остаются research/fallback options только при появлении доказанной потребности, которую текущий Redot 2D/2.5D путь не закрывает.

---

## 1. Реальная постановка задачи

CanonSim — детерминированный симулятор мира с LLM как renderer/interpreter текста и Workbench как основной пользовательской поверхностью. Визуальная часть не должна превращать проект в классический AAA/gameplay engine.

Целевая модель:

```text
                         CANONSIM PRODUCT
                                │
              ┌─────────────────┴─────────────────┐
              │                                   │
       Python application/core               Redot frontend
              │                                   │
   ┌──────────┼──────────┐             ┌──────────┼───────────┐
   │          │          │             │          │           │
CanonSim   llama.cpp   persistence    world      chat       tools/UI
   │          │          │             │          │           │
   └──────────┴──────────┘             └──────────┴───────────┘
                    │                          │
                    └──────── typed application /
                         presentation boundary
```

Redot frontend должен одновременно уметь быть:

```text
игровой экран
chat surface
inventory
map
compass
journal / notes
notice boards
simulation controls
history
model/inference controls
settings
runtime diagnostics
developer/assurance surfaces
```

Это не взаимоисключающие режимы. Они являются разными presentation surfaces одного продукта.

---

## 2. Главный архитектурный принцип

### 2.1 CanonSim остаётся единственным владельцем мира

Нельзя строить вторую simulation engine внутри Redot.

Правильная цепочка:

```text
seed
→ deterministic generation
→ events
→ canonical state
→ semantic products
→ Visual Scene IR
→ Redot presentation
```

Неправильная цепочка:

```text
seed
→ CanonSim
→ Redot world model
→ Redot simulation
→ visual result
```

Redot может владеть:

```text
camera state
UI state
animation playback state
hover/focus/selection state
transient visual effects
render caches
local presentation state
```

Redot не владеет:

```text
canonical world state
canonical entity facts
canonical event log
simulation outcomes
semantic validation
LLM truth about the world
```

Любая мутация мира должна идти через существующую application/semantic operation CanonSim.

---

## 3. Workbench = игра/application frontend

### 3.1 Не создавать два продукта

Нельзя планировать:

```text
Workbench.exe
+
FutureGame.exe
```

как два независимых продукта, если единственная причина разделения — наличие visual world.

Целевая модель:

```text
CanonSim application
      │
      ├── headless / service mode
      ├── CLI / batch
      ├── external control/API
      └── Redot frontend
             ├── game/world presentation
             └── full Workbench surface
```

### 3.2 UI и игра не конкурируют за экранную роль

Основной UX может быть, например:

```text
┌────────────────────────────────────────────────────────────┐
│ status / location / time / world context                  │
├──────────────────────────────┬─────────────────────────────┤
│                              │                             │
│        WORLD VIEW            │           CHAT              │
│                              │                             │
│ background composition       │ conversation                │
│ actors / sprites             │ streaming output            │
│ props / effects              │ input                       │
│                              │ history                     │
│                              │                             │
├──────────────────────────────┴─────────────────────────────┤
│ inventory | map | compass | journal | notices | controls  │
└────────────────────────────────────────────────────────────┘
```

Это только пример компоновки. Архитектура не диктует фиксированную раскладку.

Главное правило:

> **Redot предоставляет layout/input/rendering infrastructure; визуальный язык и UX CanonSim определяем сами.**

---

## 4. Почему Redot является текущим основным frontend/runtime

**Redot 26.2 LTS** is the pinned frontend/runtime baseline. It covers the required combination of application UI, 2D/2.5D presentation, animation/effects, input/focus/navigation, offscreen composition, packaging and CLI/headless verification without adding a second GUI toolkit and a second graphics framework.

Redot 26.2 LTS is the production baseline because it is a stable LTS release. The newer 26.3 line is treated as research until separately admitted; its additional language/engine features must not silently become project prerequisites.

The initial renderer baseline is **Compatibility** for the first real 2D/2.5D slice. This is a measured product choice, not a permanent prohibition on Forward+/other modes. Any renderer change must pass the shared-GPU benchmark with the local LLM active.

### 4.1 Redot project vs Redot toolchain

```text
CanonSim Git repo
    └── workbench/presentation/redot/   ← committed project, code, scenes, themes, project config

Developer machine
    └── external Redot 26.2 LTS binary  ← toolchain/editor, not vendored
```

The project stores enough information to identify the required engine line; the editor executable itself stays outside the repository. Export templates are installed as toolchain dependencies and are not copied into Git.

### 4.2 Redot does NOT mean

```text
standard Redot UI
3D-first development
physics/gameplay semantics
SceneTree as world database
editor-only authoring
Redot-owned canonical identity
```

Redot is the presentation/application runtime. CanonSim remains the only semantic authority.

## 5. Целевой graphics scope: 2D / 2.5D, не 3D-first

### 5.1 Базовый рендер

Основной visual runtime должен предполагать:

```text
static/procedural background
+ composited world layers
+ sprite actors
+ animated sprite states
+ small transient effects
+ UI overlays
```

Ожидаемый визуальный характер ближе к:

```text
illustrated / stylized 2D
high-value composition
strong silhouettes
material/style variation
layered depth
parallax where useful
lightweight animation
```

Возможна эстетика уровня «тактическая/иллюстрированная RPG-подача»; референс класса Heroes of Might and Magic III уместен только как описание композиционного поведения, а не как требование копировать его конкретную графику.

### 5.2 Чего базовая архитектура не требует

Не закладывать обязательной частью runtime:

```text
physics world
rigid bodies
collision simulation
ragdolls
large 3D terrain
path-traced lighting
ray tracing
heavy GI
volumetrics
high-end screen-space effects
massive 3D skeletal animation
GPU-heavy world simulation
```

Если впоследствии понадобится какой-либо из этих классов возможностей, решение должно пройти отдельный dependency/runtime admission gate.

---

## 6. Presentation pipeline

```text
                CANONSIM
                   │
          semantic/read products
                   │
             Visual Scene IR
                   │
          scene composition policy
                   │
         asset selection / variation
                   │
         presentation read model
                   │
              REDOT runtime
                   │
        Canvas / sprites / effects / UI
                   │
                 GPU
```

Важно различать два уровня процедурности:

```text
semantic procedural generation
```

и

```text
visual procedural composition
```

CanonSim определяет, **что семантически существует / актуально / наблюдаемо**.

Visual compositor определяет, **каким набором визуальных компонентов это экономно и связно показать**.

Compositor не может добавлять миру новые canonical facts.

---

## 7. Visual Scene IR

Visual Scene IR — renderer-independent read-side format. Он не должен содержать Redot `Node`, `Texture2D`, resource paths как семантическую идентичность, GPU ids и другие renderer-specific objects.

Минимальная концептуальная форма:

```text
Scene
├── scene_identity
├── source_revision
├── observation_profile
├── camera
├── background
├── layers[]
├── props[]
├── actors[]
├── effects[]
├── overlays[]
├── interaction_hints[]
└── provenance
```

Visual instance:

```text
asset_id
variant_id
position
rotation
scale
layer
visibility
animation/state
material/palette variant
semantic status
source/provenance reference
```

Допустимые semantic statuses должны быть различимы:

```text
CANONICAL
DERIVED
OBSERVED
UNKNOWN
HIDDEN
TEXTURE / PURELY VISUAL
```

Не допустимо молча делать:

```text
UNKNOWN → ABSENT
HIDDEN  → ABSENT
VISUAL  → CANONICAL
LLM text → CANONICAL
```

### 7.1 Зачем IR нужен даже при Redot-first

Даже если Redot — основной и единственный реально используемый runtime на старте, IR нужен потому что он:

```text
отделяет semantics от rendering
даёт тестируемый output compositor
облегчает screenshot regression
упрощает agent-driven scene generation
позволяет переиспользовать scene description в debug/CLI/offline tooling
не запирает CanonSim внутри Redot
```

IR не должен превращаться в заранее созданный универсальный scene DSL. Нужен минимальный набор полей, который реально используется.

---

## 8. Как должна строиться визуальная сцена

Основной паттерн:

```text
local semantic context
+
seed
+
style profile
+
asset vocabulary
+
placement constraints
+
visibility / observation rules
        ↓
visual composition
        ↓
Redot drawables
```

Вместо ручного размещения каждой вещи допускается алгоритмическая сборка:

```text
region / scene type
→ structural grammar
→ compatible asset families
→ neighbor / anchor constraints
→ deterministic variation
→ occlusion/layer rules
→ density rules
→ final composition
```

Подход уровня Townscaper полезен как инженерная идея:

> **не делать бесконечную коллекцию вручную законченных сцен; сделать небольшую, совместимую, хорошо размеченную библиотеку компонентов и мощные правила их композиции.**

Не копировать конкретную реализацию Townscaper; переносится принцип компактного vocabulary + constraints + deterministic generation.

---

## 9. Asset-first, но не asset-heavy

### 9.1 Основной bottleneck

Для такой игры труднее создать и привести в порядок хороший визуальный vocabulary, чем «научить renderer рисовать картинку».

Поэтому pipeline:

```text
semantic asset specification
→ generation / acquisition
→ cleanup / normalization
→ validation
→ variant generation
→ atlas/spritesheet packaging
→ asset manifest
→ content identity
→ runtime load
```

AI image generation, ComfyUI и Qwen Image относятся к этому pipeline, а не к runtime CanonSim.

### 9.2 Что генерирует AI, а что генерирует procedural system

AI / offline tooling:

```text
base visual asset
texture / sprite source
style variants
material variants
pose variants
expression variants
background fragments
prop families
```

Procedural system:

```text
placement
rotation
scale
variant selection
neighbor compatibility
density
layer order
occlusion
scene composition
local clutter
weather overlays
style-consistent recombination
```

CanonSim:

```text
semantic existence
world state
actor state
location
relations
events
knowledge/perception
canonical consequences
```

Redot:

```text
final draw
animation playback
particles
shader execution
input
camera
UI interaction
```

---

## 10. Начальный asset vocabulary

Цель — малое количество reusable компонентов с большим числом детерминированных вариаций.

### 10.1 Scene/background kit

```text
terrain/ground pieces
roads / paths
walls
floors
roofs
windows
doors
stairs
fences
arches
pillars
signs
lamps
pipes
vegetation
rocks
water/terrain accents
sky/background layers
weather layers
```

Не требуется вручную рисовать каждый законченный background.

### 10.2 Props

```text
crates
barrels
bags
tables
chairs
tools
baskets
books
bottles
plants
miscellaneous clutter
```

### 10.3 Actors

Минимальная модель:

```text
base sprite/portrait
pose set
idle animation
expression set
state variants
```

Примеры состояний могут зависеть от того, что реально предоставляет CanonSim:

```text
idle
walking / transitioning
speaking
alert
angry
sad
happy
injured
busy
sleeping
other canonical/derived presentation states
```

Renderer не должен придумывать состояние, которого нет в semantic source, если это не явно обозначенная чисто визуальная idle-анимация без semantic claim.

### 10.4 UI / diegetic objects

```text
inventory icons
map
compass
notes
journal pages
notice-board cards
resource markers
status icons
```

Эти элементы могут быть либо обычным UI, либо diegetic presentation внутри world layer. Semantic ownership остаётся у соответствующего application feature.

---

## 11. Procedural composition вместо полного визуального мира

Для текущей игры не требуется держать дорогое полное визуальное представление всей симуляции.

Предпочтительно:

```text
full semantic world
        ↓
local visual context around player / focus
        ↓
procedural composition
        ↓
current scene
```

Видимый кадр может зависеть от:

```text
current location
local neighbors
focal point
scene type
time
weather
local density
known/observed entities
style profile
seed
```

При смене контекста композиция может пересчитываться детерминированно из того же semantic input.

Это позволяет избегать:

```text
ручного хранения всех промежуточных visual instances

и

загрузки огромного мира в GPU только ради текущего экрана.
```

---

## 12. Уровни детализации для 2D/2.5D

Нельзя переносить 3D LOD буквально; нужен собственный presentation LOD.

Например:

```text
FULL
    actor sprite + animation
    local props
    effects

REDUCED
    simpler sprite
    reduced animation
    fewer props

IMPOSTOR / COMPOSITE
    precomposed layer / simplified visual

ABSTRACT
    icon / silhouette / map symbol
```

При этом semantic LOD и visual LOD различны:

```text
semantic LOD:
    сколько semantic detail реально требуется simulation/application

visual LOD:
    сколько visual detail нужно для текущего представления
```

Visual LOD не должен изменять semantic truth.

---

## 13. Redot UI: свобода и ограничения

Redot не заставляет CanonSim использовать стандартный внешний вид.

Производственный UI должен иметь собственный:

```text
typography
semantic color system
spacing scale
layout rules
density modes
component geometry
icons
borders
shadows/elevation
motion language
focus states
selection states
error/warning states
```

Используется:

```text
Redot Control/Container infrastructure
+
CanonSim custom theme
+
CanonSim custom controls/components
```

### 13.1 Запрещённая практика

Не размножать по feature-файлам:

```text
#101010
#8D8D8D
random font sizes
random margins
random animation durations
```

Использовать semantic tokens:

```text
background.primary
background.secondary
surface.panel
surface.elevated
text.primary
text.secondary
text.muted
accent
success
warning
error
selection
focus
border
```

### 13.2 Собственные компоненты

Кандидатный набор:

```text
CanonPanel
CanonButton
CanonIconButton
CanonInput
CanonSelect
CanonTabs
CanonModal
CanonToast
CanonChatMessage
CanonConversation
CanonInventorySlot
CanonMap
CanonCompass
CanonJournalEntry
CanonNoticeBoard
CanonMetric
CanonDiagnosticRow
```

Компонент отвечает за presentation/interaction. Он не должен становиться semantic super-object или самостоятельно вызывать backend, если это не его реальная bounded responsibility.

---

## 14. Агент-first UI development

Основное правило:

> **GUI editor — инспектор и вспомогательный инструмент, а не обязательный production workflow агента.**

Предпочтительная цепочка:

```text
agent
→ code/config/resource files
→ Redot CLI/headless run
→ deterministic test
→ screenshot / artifact
→ agent inspection
→ patch
→ rerun
```

### 14.1 Не заставлять агента постоянно править сложные `.tscn`

Стабильные базовые сцены допустимы.

Но динамический и повторяемый UI лучше строить через:

```text
GDScript/components
+
small stable scene resources
+
external typed/config data where it is actually data
```

Не создавать giant scene files только ради визуального расположения каждого элемента.

### 14.2 Тестируемость

Каждая значимая visual surface должна по возможности иметь:

```text
known input state
known output state
reproducible seed
optional screenshot
optional semantic overlay
```

Это позволяет агенту проверять не только текст/код, но и визуальный результат.

---

## 15. Первый vertical proof: без ассетов

Первая implementation surface не должна начинаться с world art.

Минимум:

```text
Redot frontend
├── application shell
├── chat
├── streaming output
├── input box
├── conversation history
├── settings
├── model selection
├── inference controls
├── simulation selection
├── diagnostics
├── developer/debug surface
└── placeholder world view
```

Placeholder world может быть:

```text
flat background
simple geometric blocks
colored placeholders
text labels
semantic IDs
```

Никаких требований к final art.

### 15.1 Что именно должен доказать vertical proof

```text
Redot starts
→ connects to Workbench application boundary
→ reads typed state
→ sends user intent
→ receives streaming response
→ persists/reloads relevant state
→ reflects CanonSim state
→ shows errors/degraded states
→ supports cancellation
→ remains usable during LLM streaming
```

Дополнительно:

```text
CLI
GUI
agent/API
```

должны приходить к одним application operations, как требует v4.4.

---

## 16. Local runtime topology

Целевая desktop topology:

```text
                    USER
                     │
                 REDOT UI
                     │
             local gateway / API
                     │
             Workbench operations
                     │
        ┌────────────┴─────────────┐
        │                          │
    CanonSim                  llama.cpp adapter
        │                          │
   canonical truth          inference/backend
```

Redot не должен напрямую обращаться к:

```text
CanonSim internals
llama.cpp transport internals
persistence internals
secret-bearing stores
```

если для этого уже существует application/adapter boundary.

Для headless/server mode Redot GUI может отсутствовать:

```text
headless Workbench
→ application operations
→ API/CLI/agent clients
```

Это не создаёт второй semantic path.

---

## 17. Protocol boundary

В desktop/local deployment допустимы локальные transport mechanisms, но логический контракт должен оставаться typed.

Практически подходит:

```text
HTTP:
    request/response state and commands

WebSocket or equivalent stream:
    token/event stream
    live session updates
    ordered notifications
```

Логический контракт:

```text
Client intent
→ application operation
→ operation/execution identity
→ ordered events
→ terminal disposition
```

Визуальный runtime не должен напрямую подменять application semantics.

---

## 18. Chat как центральная игровая поверхность

Chat — не второстепенное меню. В текущем продукте он является одним из основных способов воздействия пользователя на simulation/application.

Цепочка:

```text
user message
→ Workbench operation
→ prompt/context composition
→ LLM
→ candidate response / structured proposal
→ CanonSim/application validation boundary
→ canonical/derived effect
→ updated read model
→ chat + visual update
```

Важно:

```text
LLM response != world truth
chat text != canonical state
presentation animation != semantic event
```

### 18.1 Streaming

Presentation может:

```text
coalesce tokens
animate text
control scroll
show typing state
show timing metrics
```

но не может менять semantic meaning ради красивой анимации.

### 18.2 Very large history

Не делать:

```text
10 000+ messages
→ 10 000+ permanently active UI nodes
```

Нужен bounded read surface / paging / virtualization strategy.

---

## 19. Inventory / map / compass / journal / notice boards

Эти surface types не требуют отдельного graphics engine.

### Inventory

```text
semantic item list
→ icon / sprite identity
→ state/quantity
→ interaction
```

### Map

```text
world/region/local semantic graph
→ visual map projection
```

Не обязательно использовать 3D. Предпочтительно layered 2D.

### Compass

```text
semantic heading / bearing
→ procedural needle / dial rendering
```

### Journal / notes

```text
persisted text/records
→ custom UI surface
```

### Notice board

```text
world-backed notices
→ procedural card/paper layout
```

Сами visual objects могут быть generated/composited, но их semantic source должен быть понятен.

---

## 20. Static backgrounds are a feature, not a limitation

Если большая часть scene background статична, это позволяет использовать aggressive caching.

Предпочтительная цепочка:

```text
semantic local context
→ deterministic composition
→ render/cache background
→ overlay dynamic actors/effects/UI
```

Динамически обновлять только то, что действительно изменилось.

Например:

```text
background: cached
midground props: cached until context change
actors: dynamic
weather: dynamic/lightweight
UI/chat: dynamic
```

Это уменьшает:

```text
CPU work
GPU work
draw complexity
asset churn
```

и особенно полезно при одновременной LLM inference на той же GPU.

---

## 21. Effects

Effects — presentation only, если они не представляют отдельную semantic entity.

Допустимы:

```text
rain
fog
snow
wind motion
dust
spark/glow
fire-like ambience
ink/splatter
screen transitions
focus highlights
selection effects
```

Для baseline предпочитать:

```text
2D particles
animated textures
sprite sequences
small custom shaders
```

Не превращать обычные effects в GPU-heavy simulation systems без измеренной необходимости.

---

## 22. Stylistic rendering

Качество должно преимущественно идти от:

```text
asset vocabulary
composition
silhouette
layering
palette/value design
controlled procedural variation
lighting/gradient decisions baked into art where practical
small shaders/effects
```

а не от:

```text
brute-force geometry
RT
GI
massive post-processing
```

Для CanonSim особенно полезен stylized pipeline:

```text
strong silhouettes
high contrast
controlled material separation
limited/intentional shading
palette consistency
graphic overlays
```

Стили типа urban junkpunk / graffiti ink / stencil / screenprint могут быть реализованы главным образом через asset language, palette, masks, compositing and bounded shaders, а не через дорогую физически корректную графику.

---

## 23. Asset identity и provenance

Visual asset identity не равна filesystem path.

Минимально различать:

```text
AssetId
ContentIdentity / digest
Location
Version / compatibility
Lifecycle state
Variant
Source asset
Derived asset
Runtime artifact
```

Например:

```text
AssetId: actor.blacksmith
Variant: angry_02
ContentDigest: ...
Source: generated/source/or/hand-authored
LOD/presentation tier: ...
Compatibility: canon_visual_v1
```

Путь:

```text
assets/characters/blacksmith_02.png
```

является только location, а не всей identity.

---

## 24. Форматы

### 24.1 Для текущего 2D/2.5D pipeline

Предпочтительно:

```text
PNG/WebP or equivalent raster runtime assets
sprite sheets / texture atlases
JSON-compatible asset manifests
small declarative metadata
```

Точный набор форматов должен быть подтверждён реальным Redot import/build pipeline.

### 24.2 Если появится 3D/2.5D asset class

Основной interchange contract:

```text
glTF 2.0 / GLB
```

Это позволяет при необходимости использовать те же visual assets в Redot и иных downstream tools без изменения CanonSim semantics.

### 24.3 3D не становится обязательным

Даже при появлении отдельных 3D assets они могут оставаться:

```text
billboard
pre-rendered layer
limited depth object
offscreen generated visual
```

без превращения всего world runtime в полноценную 3D simulation.

---

## 25. Offline asset tooling

Допустимы отдельные offline dependencies:

```text
ComfyUI / Qwen Image
Blender headless
trimesh
Pillow
image/atlas utilities
custom validation scripts
```

Но они не должны проникать в CanonSim core.

Разделение:

```text
Canonical core
    stdlib-only

Visual tooling
    optional dependencies

Runtime frontend
    Redot
```

AI generation and offline compilation are content-production concerns, not canonical simulation concerns.

---

## 26. Performance model

### 26.1 Что важно на самом деле

Базовый сценарий:

```text
Redot UI
+
large chat/history surface
+
static or mostly static scene
+
small number of animated actors
+
light effects
+
local LLM inference on same GPU
```

Поэтому benchmark должен измерять не «максимум FPS игры», а совместную рабочую нагрузку.

### 26.2 Обязательные метрики

Для vertical proof:

```text
cold startup time
warm startup time
RAM idle
RAM active
VRAM idle
VRAM active
CPU idle
CPU during chat streaming
GPU utilization during static scene
GPU utilization during active scene/effects
frame time p50/p95/p99
UI latency during streaming
history rendering cost
scene rebuild cost
asset load cost
peak memory
shutdown/reconnect behavior
```

Два отдельных режима:

```text
A: frontend alone
B: frontend + simultaneous local LLM inference
```

### 26.3 Redot vs «обычный Python UI»

Минимальный Python/Tkinter-процесс обычно имеет значительно меньший runtime footprint, чем полноценный Redot runtime. Это ожидаемая цена за game/UI runtime, rendering backend, scene/input/animation infrastructure.

Но сравнение должно быть по product-equivalent workload, а не по пустому процессу:

```text
Python GUI + chat + settings + history
vs
Redot UI + chat + settings + history + world presentation
```

Для CanonSim минимальный memory overhead сам по себе не является достаточным основанием отказываться от Redot, если он заменяет отдельный GUI toolkit и отдельный graphics stack.

### 26.4 Целевые рамки

Старые гипотезы вида:

```text
128–256 MiB
256–512 MiB
>512 MiB requires explanation
```

остаются только research envelopes до фактического benchmark.

Они не являются acceptance guarantees конкретного Redot project.

---

## 27. Resource policy

Renderer/frontend должен быть **bounded**.

Обязательны budget categories:

```text
active texture memory
cached texture memory
asset count
atlas size
simultaneously active actors
simultaneously active effects
scene rebuild frequency
UI history materialisation
pending stream buffers
GPU frame budget
CPU frame budget
```

При превышении budget должна существовать явная degradation policy:

```text
reduce visual detail
reduce effects
reduce off-screen/cache size
collapse distant layers
switch presentation LOD
page history
```

Не следует автоматически «чинить» превышение добавлением бесконечных caches.

---

## 28. UI readability / ergonomics

Визуальная архитектура обязана поддерживать:

```text
font scaling
UI scale
density modes
high contrast
focus indication
keyboard navigation
text selection/copy
reduced motion
clear loading/partial/stale/degraded/failed states
OLED-friendly dark theme
```

Это часть архитектуры, а не polishing после feature completion.

### 28.1 Semantic operational states

Visual system должна различать:

```text
EMPTY
LOADING
READY
PARTIAL
STALE
DEGRADED
BLOCKED
FAILED
CANCEL_REQUESTED
CANCELLED
UNAVAILABLE
RECOVERABLE
```

Нельзя сводить их в один универсальный «busy/error» status.

---

## 29. Animation policy

Пусть animation принадлежит presentation layer.

Например:

```text
application event:
    actor_state_changed

presentation:
    choose animation clip
    choose interpolation
    choose transition duration
```

Не делать:

```text
animation finished
→ therefore canonical event happened
```

Правильнее:

```text
canonical/read-side state
→ visual animation
```

а не наоборот.

---

## 30. Camera and composition

Camera должна быть presentation concern.

Параметры могут зависеть от:

```text
scene type
focal actor
UI mode
user preference
zoom level
map vs local view
```

Но camera не должна менять semantic world state.

Допустимы несколько presentation profiles:

```text
LOCAL_SCENE
MAP
CHARACTER_FOCUS
INSPECTION
DEBUG
```

---

## 31. Debug / assurance views

Нужны отдельные режимы, позволяющие агенту и разработчику видеть:

```text
asset_id
entity_id
layer
presentation LOD
semantic status
source revision
scene seed
composition rule
unknown/hidden markers
provenance
```

Например:

```text
CANON VIEW
    показывает обычную world presentation

PERCEPTION VIEW
    показывает viewpoint/knowledge конкретного actor/profile

ASSURANCE VIEW
    показывает provenance/semantic status/derived vs canonical

DEBUG VIEW
    показывает renderer/compositor mechanics
```

Диагностический вид может быть более информативным, чем обычный игровой вид, но это не создаёт дополнительную authority.

---

## 32. Observation boundary

Обычный gameplay view не должен автоматически быть omniscient.

Нужно явно определять:

```text
what is in world
what is visible
what is known
what is only derived for presentation
what is intentionally hidden
```

Визуальная система должна следовать выбранному observation profile.
### 32.1 Observatory presentation binding

The visual runtime may render Observatory outputs, but it never owns Observatory truth. Analytical data arrives as a typed read-side projection.

Allowed presentation inputs include:

```text
world profile vectors
trajectory/regime summaries
relation/object lifecycle traces
causal slices
residue chains
first divergence / persistence
counterexample capsules
World Question evidence + uncertainty
```

Visual assurance must retain:

```text
observation profile
source identity/revision
run_id / execution identity
analysis version
claim/evidence class
unknown/hidden markers
provenance
```

Never visualize a derived relation as canonical merely because it has a graph edge. Never turn `read dependency`, `cause_id`, event adjacency, or a regime label into a canonical causal/world-state assertion.

For player/reader surfaces:

```text
CANON VIEW      ordinary permitted world presentation
PERCEPTION VIEW actor/profile-limited observation
ASSURANCE VIEW  evidence/provenance/semantic status
DEBUG VIEW      compositor/renderer mechanics
```

The same world truth may yield different lawful views under different observation scopes. Visual rendering is evidence delivery; it does not widen the observer's legal knowledge surface.


---

## 33. Map architecture

Карта не должна автоматически означать 3D world map.

Предпочтительная hierarchy:

```text
WORLD MAP
    regions / routes / major places

REGIONAL MAP
    settlement / terrain / local connections

LOCAL MAP
    streets / rooms / nearby objects

SCENE VIEW
    current composition around focal point
```

Каждый уровень может иметь свой visual vocabulary и resolution.

Это presentation projection одного semantic source, а не четыре независимых world models.

---

## 34. Procedural constraints / Townscaper-like philosophy

Для scene composition полезно иметь data-driven rules:

```text
compatible neighbors
allowed anchors
orientation constraints
minimum/maximum density
scene-type compatibility
biome compatibility
weather compatibility
style family
occlusion class
layer class
variant compatibility
rarity
```

Алгоритм может использовать:

```text
weighted selection
constraint propagation
WFC-like composition
graph grammar
local search/backtracking
seeded randomization
```

Конкретный алгоритм не фиксировать заранее. Выбирать по representative scenes и доказанной change locality.

Ключевое требование:

```text
same semantic input
+
same seed
+
same asset manifest
→ same visual composition
```

если профиль не объявляет намеренную nondeterminism.

---

## 35. Procedural asset variants

Вариация должна быть дешёвой и воспроизводимой.

Примеры:

```text
mirror
rotation
scale range
palette variant
weather variant
damage variant
wear variant
occupancy variant
material variant
expression variant
pose variant
small decal variation
```

Нельзя для каждой вариации создавать полностью независимый asset, если достаточно параметризованной композиции.

---

## 36. UI and world share the same visual language, but not the same semantics

Общий visual system:

```text
theme tokens
typography
spacing
density
motion
iconography
focus/selection
```

Но world and UI остаются разными semantic surfaces.

Например:

```text
world barrel
≠
Inventory barrel icon
```

даже если они используют одну source image family.

У world object есть world semantics; у inventory item есть application/data semantics.

---

## 37. Dependencies: what to admit now

### Admit now / target runtime

```text
Redot 26.2 LTS
```

Required verification:

```text
repository project opens from workbench/presentation/redot/
Redot version is pinned to 26.2 LTS
Compatibility renderer baseline works
local Workbench API integration works
CLI/headless/screenshot path works
packaging/export path works for admitted targets
license/provenance inventory is complete
concurrent local LLM GPU benchmark passes
```

### External tooling only

```text
ComfyUI/Qwen Image
Blender headless
Pillow/trimesh or equivalent
other asset-generation/conversion tools
```

These tools create or validate content; they are not runtime semantic authorities.

### Do not admit by default

```text
Panda3D
pyglet
ModernGL
wgpu-py
NumPy
OpenGL bindings
custom graphics framework
second GUI toolkit
```

No second runtime is admitted merely for capability overlap.

## 38. Когда снова рассматривать другой renderer/runtime

A different engine/runtime becomes admissible only after a representative CanonSim proof demonstrates a material gap: required visual class cannot be represented; a required asset/runtime class is materially blocked; measured CPU/GPU/RAM/VRAM cost breaks the product envelope; agent automation cannot reliably implement/verify required changes; or packaging/deployment creates an unacceptable constraint.

Candidates are compared against the actual Redot baseline using the same scenes, assets, UI workload, instrumentation, concurrent local LLM load and acceptance tests. Demo quality alone is not evidence.
---

## 39. Acceptance benchmark

Representative scene для текущего baseline:

```text
mostly static background
procedurally composed props
several animated actors
small effects
chat panel
large-ish history surface
map/inventory interaction
LLM streaming simulation
```

Параметрические runs:

```text
small scene
medium scene
dense scene
many repeated props
many visible actors
history-heavy UI
effects-heavy UI
```

Измерять:

```text
startup
RAM
VRAM
CPU
GPU
frame time
input latency
chat smoothness
history cost
scene regeneration cost
asset load/reload
reconnect after backend loss
```

Сравнивать:

```text
frontend alone
frontend + local LLM
```

---

## 40. Visual regression / agent testing

Минимальный automated loop:

```text
fixture / seed
→ build Visual Scene IR
→ launch headless/frontend
→ render screenshot
→ compare invariant regions / pixel or perceptual tolerance
→ inspect semantic overlay
→ exit with terminal result
```

Нужны два класса tests:

```text
semantic visual tests
    «asset/entity/status/layer is correct»

presentation regression tests
    «layout/theme/composition remains within expected bounds»
```

Нельзя заменить semantic assertion одним screenshot diff.

---

## 41. Screenshot-driven development

Поскольку агенту трудно «видеть» UI как человек, production loop должен поддерживать artifacts:

```text
PNG screenshot
optional debug overlay
metadata JSON
source seed
scene revision
build/version identity
```

Это позволяет агенту анализировать:

```text
layout mistakes
text overflow
incorrect layering
unexpected sprite placement
missing elements
wrong semantic state
```

и затем исправлять их через code/config.

---

## 42. Failure and degradation behavior

Visual runtime обязан иметь graceful degradation.

Примеры:

```text
missing asset
→ placeholder + diagnostic

invalid asset manifest
→ reject affected asset set, preserve usable scene

stale scene revision
→ refresh / rebuild

backend disconnected
→ preserve local UI state and show unavailable state

LLM streaming stall
→ keep terminality/timeout semantics explicit; presentation must not fake completion

history over budget
→ page/virtualize, not unbounded allocation
```

Нельзя скрывать canonical/backend failures красивой визуальной маскировкой.

---

## 43. Save / persistence relationship

Redot UI state and Workbench persistence must remain distinct.

Разделять:

```text
application config
session state
chat/history
simulation checkpoint/cursor
visual cache
asset cache
UI-local state
```

Visual caches can be rebuilt.

Canonical/persistent state cannot be treated as disposable render cache.

---

## 44. Packaging model

Пользователь должен видеть единый продукт, а не внутреннюю многопроцессную топологию.

Пример:

```text
CanonSim application package
├── Redot frontend
├── Python backend/runtime
├── models (separate location)
├── simulation packs
├── asset catalogue
└── user data
```

Actual packaging strategy must follow v4.4 runtime distribution contract and repository owner decisions.

---

## 45. Licensing

Current preferred runtime:

```text
Redot — MIT
```

Все third-party assets/plugins/codecs/importers должны быть отдельно inventory-checked перед redistribution.

Content-generation tooling может иметь иные licences; это не должно автоматически попадать в shipped runtime.

Не считать «движок permissive» достаточной проверкой коммерциализации всего bundle.

---

## 46. Security / trust boundary

Redot client input, imported assets and externally supplied metadata являются untrusted data до application validation.

Минимальные правила:

```text
path != command
import != execution
model output != authority
asset metadata != executable code
UI command != direct CanonSim mutation
```

Remote API/agent access не должен обходить application/semantic seam.

---

## 47. Research / implementation order

### Phase A — runtime proof

```text
1. Redot shell
2. custom theme
3. chat
4. settings
5. model/inference controls
6. history
7. diagnostics
8. simulation placeholder surface
9. local backend/application connection
10. automated CLI/headless run
11. screenshot artifact
```

### Phase B — canonical visual seam

```text
1. minimal Visual Scene IR
2. CanonSim semantic read model
3. placeholder scene compositor
4. semantic/visual status overlay
5. deterministic seed/replay proof
```

### Phase C — procedural visual vocabulary

```text
1. asset manifest
2. identity/provenance
3. small reusable asset kit
4. deterministic variants
5. placement constraints
6. background composition
7. sprite actor presentation
8. effects
```

### Phase D — visual UX expansion

```text
map
inventory
compass
journal
notice boards
perception views
assurance/debug views
```

### Phase E — optimization

```text
atlas/caching
visual LOD
scene rebuild limits
history virtualization
GPU/CPU budgets
concurrent LLM benchmark
```

Do not start Phase C before Phase A/B establish the seam.

---

## 48. Architecture anti-patterns

Не делать:

```text
Redot node tree as canonical world state

Redot-specific resource IDs inside CanonSim entities

LLM text directly spawning canonical objects without validation

UI widgets calling CanonSim internals directly

separate game semantics and Workbench semantics for the same operation

second LLM transport path hidden in frontend

unbounded history node trees

unbounded asset cache

manual scene authoring as required agent workflow

3D engine dependency solely «на будущее»

renderer-specific abstraction before a real renderer need exists

huge generic Visual DSL before the first real scene exists
```

---

## 49. Target directory/ownership shape

Exact repository placement must follow v4.4 skeleton and repository conventions. Conceptual ownership:

```text
CanonSim core
    canonical simulation / semantics

Workbench application
    operations / state / persistence / API / inference

Presentation contract
    Visual Scene IR + read models

Redot frontend
    views / controls / scene composition / rendering / input

Visual asset tooling
    generation / validation / compilation / manifests

Observatory / analytical read-side
    run manifests / projections / experiments / World Questions
    no canonical ownership

Tests
    semantic boundary
    analytical derivation / mutation / causal-scope checks
    visual regression
    integration
    performance
```

Не создавать физические модули только потому, что они красиво выглядят на схеме. Каждый runtime boundary должен иметь реального consumer, owner, test contract и dependency justification.

---

## 49.1 Нормативные v5.2 seam-контракты

Этот source-документ не создаёт альтернативную архитектуру. Для реализации v5.2 зафиксированы следующие shared seams:

```text
Visual Scene IR:
  scene_ir_schema_identity + scene_composition_version + asset_manifest_identity
  + semantic_input_identity/source_revision + composition_seed

Composition identity:
  semantic_input_identity + seed + asset_manifest_identity
  + composition_policy_version + scene_ir_schema_identity

Asset lifecycle:
  DISCOVERED → IDENTITY_VERIFIED → FORMAT_VALID → COMPATIBLE
  → VISUALLY_VALID → RUNTIME_READY
  failures = MISSING | INVALID | INCOMPATIBLE | STALE | CORRUPT | UNKNOWN

Camera:
  semantic focus/target ≠ presentation camera ≠ user camera state

GPU:
  visual acceptance includes concurrent local-LLM load; optional expensive effects degrade explicitly
```

These contracts are implementation seams, not suggestions. Detailed UX, accessibility, interaction and acceptance policy lives in the v5.2 frontend specification. Application ownership, execution identity, persistence and backend boundaries live in the v5.2 application architecture.

## 50. Final architecture

```text
                              CANONSIM
                                 │
                     canonical simulation/events
                                 │
                        semantic read products
                                 │
                         Workbench application
                                 │
             ┌───────────────────┼───────────────────┐
             │                   │                   │
         CLI / agent        local API          persistence
             │                   │                   │
             └───────────────────┬───────────────────┘
                                 │
                         typed presentation data
                                 │
                         Visual Scene IR
                                 │
                    procedural visual composer
                                 │
                              REDOT
                                 │
         ┌───────────────────────┼────────────────────────┐
         │                       │                        │
      World view              Chat/UI                 Effects
         │                       │                        │
 backgrounds                history                  particles
 sprites                    settings                 shaders
 actors                     inventory                transitions
 map                        journal                  audio later
```

Redot — **единый основной frontend/runtime**, а Python — **владелец application/semantic/backend side**.

---

## 51. Core design rules

1. **Workbench и game presentation — один продукт, а не два приложения.**
2. **Redot является текущим основным frontend/runtime; Panda3D больше не является baseline.**
3. **Текущая graphics задача — 2D/2.5D, а не 3D-first.**
4. **CanonSim остаётся единственным владельцем canonical world truth.**
5. **Visual Scene IR является read-side contract между semantics и renderer.**
6. **Redot node tree не является canonical state store.**
7. **UI может быть полностью уникальным; default Redot appearance не является частью CanonSim.**
8. **Агент должен уметь создавать/менять/тестировать frontend через code/config/CLI; GUI editor — вспомогательный инспектор.**
9. **Первый vertical proof начинается с чата, settings, history, diagnostics и placeholder world, без дорогих ассетов.**
10. **Основной asset strategy: небольшой reusable vocabulary + детерминированные вариации + procedural composition.**
11. **AI генерирует/расширяет asset vocabulary; procedural system композирует его; CanonSim определяет semantic truth.**
12. **Static backgrounds и local scene reconstruction используются как optimization strategy, а не как архитектурный компромисс.**
13. **Semantic LOD и visual LOD различны.**
14. **UNKNOWN/HIDDEN/ABSENT и CANONICAL/DERIVED/OBSERVED/VISUAL нельзя молча смешивать.**
15. **Любая оптимизация должна иметь измеримый budget и degradation policy.**
16. **Benchmark обязателен в режиме frontend alone и frontend + concurrent local LLM.**
17. **Новая graphics dependency допускается только после real consumer + benchmark + licence/runtime boundary.**
18. **3D/другой renderer возвращается в scope только после появления доказанной продуктовой потребности.**

---

## 52. Однострочная формула

> **CanonSim решает, что существует и что происходит; Workbench application решает, какие операции доступны; Visual Scene IR описывает, что нужно показать; procedural compositor собирает локальную композицию из маленького asset vocabulary; Redot отображает и обслуживает весь пользовательский frontend — игру, чат и инструменты — без превращения visual runtime в второй симулятор.**

---

## 53. Verification gates before implementation promotion

До того как визуальный runtime считается архитектурно закреплённым, должны быть доказаны:

```text
G1  Redot startup/packaging works in repository runtime envelope
G2  chat/settings/history work through shared application operations
G3  local backend reconnect/cancellation semantics remain correct
G4  CanonSim read-side seam is explicit and renderer-independent
G5  minimal Visual Scene IR has deterministic fixture output
G6  placeholder world renders from IR without hand-authored per-instance scene work
G7  screenshot/headless regression path works
G8  frontend does not bypass application/semantic boundaries
G9  resource budgets are measured
G10 concurrent LLM + frontend behavior is measured
G11 dependency/license inventory is complete for admitted runtime
G12 asset identity/provenance contract exists before large asset ingestion
G13 Observatory projections are read-only, regenerable and observation-profile scoped
G14 World Question / causal-slice rendering preserves evidence class, uncertainty and scope
```

Until these gates are passed, do not expand the visual stack merely for feature completeness.

---

## 54. Source / technology notes

Primary architectural basis:

```text
canonsim_engine_presentation_design_brief_v4.4.md
canonsim_inference_workbench_architecture_skeleton_v4.4.md
```

Relevant Redot capabilities for the chosen frontend/runtime include its Control/UI system, custom GUI controls, themes, 2D rendering, AnimatedSprite2D, particles and CLI/headless workflows. Exact project-level performance must be measured on the actual target machine and workload rather than inferred from engine-level marketing figures.

For future 3D/2.5D interchange, glTF 2.0 / GLB remains the preferred engine-neutral asset interchange direction.

Current-version note for this revision:

```text
Date: 2026-09-24
Redot stable line checked: 26.2 LTS
Current stable referenced here: 26.2 LTS
```

This section is a technology note, not a substitute for repository dependency admission or release-time licence verification.


## Appendix B — Redot installation / repository contract

### B.1 Required toolchain

Use **Redot 26.2 LTS stable**. Keep the executable outside the Git repository, for example:

```text
D:\Tools\Redot\26.2\
    <Redot executable>
```

Do not copy the executable or export-template bundle into `canonsim/`. The project itself lives at:

```text
<repo>/workbench/presentation/redot/
```

### B.2 Git-owned files

```text
project.godot
export_presets.cfg
*.gd
*.tscn
*.tres
*.res
*.svg
*.png / other source assets as admitted
*.import when generated/required by the pinned asset workflow
```

Ignore generated project cache/state:

```gitignore
.godot/
```

Do not globally ignore `.import` metadata unless the pinned asset workflow proves it is generated-only for a specific asset class.

### B.3 First-run acceptance

```text
Redot executable starts
→ project.godot opens from repository path
→ Compatibility renderer starts
→ custom shell scene loads
→ deterministic fixture renders
→ CLI/headless validation succeeds
→ screenshot artifact is reproducible
```

### B.4 Version discipline

`redot-26.2-stable` is the production baseline. A version upgrade is a repository-level engineering change requiring: migration check, project open/save test, scene/resource import verification, screenshot regression, performance comparison, packaging test and update of this contract.

### B.5 Sources

Redot 26.2 LTS release: https://github.com/Redot-Engine/redot-engine/releases/tag/redot-26.2-stable
Redot documentation: https://docs.redotengine.org/
