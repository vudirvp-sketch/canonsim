# CanonSim Frontend / UI / Visual Engineering Specification v5.2 (Redot)

> **Role:** full replacement for the previous frontend/UI/visual v5 draft. Consolidates `WORKBENCH_UI_UX_ERGONOMICS_ENGINEERING_SPEC` + `про визуал.md` + durable frontend material from v4.4. It owns human factors, interaction, UI system, Redot presentation, Visual Scene IR, visual composition/assets and frontend validation; it does not own CanonSim semantics, application operations, backend protocol or persistence policy.
> **Companions:** `CANONSIM_WORKBENCH_APPLICATION_ARCHITECTURE_V5_2.md` owns application/read-side operations and lifecycle; `CANONSIM_WORLD_OBSERVATORY_AND_CONTROL_PLANE_V5_2.md` owns analytical evidence and World Question semantics. `docs/PRESENTATION_SPEC.md` remains a separate model-facing CanonSim contract.
## 0. Core boundary

```text
CANONSIM = canonical meaning/events/fold ; WORKBENCH APPLICATION = operations, runtime state, inference, persistence, gateway ; THIS DOCUMENT = how application/read-side facts become perceivable, controllable and visual ; REDOT = primary frontend/runtime; presentation infrastructure, not semantic authority
```

The UI is a control/read surface over authoritative state, not a second semantic store. Visual presentation may derive/collapse information for the current task but cannot silently upgrade authority or invent canonical facts.
## 1. Evidence, authority and claim status

Separate source type from claim status.

```text
Authority/source: NORMATIVE | PLATFORM | RESEARCH | MODEL | HEURISTIC | PRODUCT | STYLE ; Claim: FACT | INFERENCE | HYPOTHESIS | PROPOSAL | UNKNOWN ; Disposition: CONFIRMED | PARTIALLY_CONFIRMED | REJECTED | UNRESOLVED | DEFERRED
```

Rules: `NORMATIVE ≠ empirically optimal`; `COMPLIANT ≠ usable`; `MODEL ≠ universal law`; `PREFERRED ≠ proven`; `CORRELATED ≠ causal`. Material decisions record source/authority and current disposition. This preserves the repository's fact/inference/hypothesis/proposal/unknown discipline.
## 2. Product model: Workbench and game are one frontend

The target is one product/frontend capable of:

```text
world view · chat · models · inference · prompts · history · diagnostics ; simulation controls · inventory · map · compass · journal · notices ; settings · appearance · developer/assurance surfaces · runs/jobs
```

Do not create separate `Workbench.exe + Game.exe` merely because a world view exists. UI/game surfaces are different presentation modes of the same application.
Typical composition is not prescribed; architecture requires only that layout be task-driven and configurable.
## 3. Human-centred design loop

Primary loop:

```text
context of use → users/goals/constraints → tasks/workflows ; → information architecture → interaction model → visual/type system ; → prototype → usability evaluation → implementation → measurement → iteration
```

Never reverse this into `visual style → screens → invent tasks`. For every major surface define:

```text
USER · GOAL · TASK · CONTEXT · INPUT · DECISION · ACTION ; SYSTEM FEEDBACK · SUCCESS · FAILURE · RECOVERY ; ACCESSIBILITY/CAPABILITY · INPUT MODALITY · INTERRUPTION/RESUMPTION
```

Use ISO 9241-11 concepts: effectiveness, efficiency, satisfaction; usability is contextual.
## 4. Design the task, not the screen

A screen is a projection of a workflow. Model task graphs:

```text
Goal → choose → inspect → decide → act → verify → recover/continue
```

For each task account for frequency, importance, time sensitivity, error severity/reversibility, prerequisite knowledge, data needed, interruption points, recovery method and completion evidence. Optimise high-frequency/high-cost/high-risk/high-load workflows before decoration.
For long-running work:

```text
initiate → work → feedback → interruption → resume/abandon → verify → recover
```

## 5. Information architecture/navigation

Useful conceptual hierarchy:

```text
context/purpose → goal/workflow → task → object/information → action → detail
```

Use recognition over recall: visible current state, labels at decisions, recent items, safe defaults, contextual actions, previews, search and remembered preferences. Do not force memory of hidden modes/parameters/panel locations/status.
Progressive disclosure:

```text
QUICK    = common decisions ; ADVANCED = less frequent normal expert controls ; EXPERT   = backend/diagnostic/research controls
```

Do not enforce arbitrary control-count rules. Navigation must answer: `Where am I? What can I do? What changed? How do I return? What is the likely next action?` Avoid competing navigation systems representing the same hierarchy.
## 6. Interaction contracts

### 6.1 System status

Consequential operations expose enough state to distinguish:

```text
IDLE · READY · QUEUED · RUNNING · WAITING · BLOCKED · SUCCEEDED ; FAILED · CANCELED · RECOVERING · STALE · DEGRADED · OFFLINE · PARTIAL · UNKNOWN
```

Long-running work shows current phase, measurable progress, useful elapsed time, cancellation, blocking reason and terminal state.
### 6.2 Action → feedback

Every consequential/state-changing action produces timely, local, persistent-enough, interpretable feedback or an explicit no-op explanation. Global/operational status may supplement local feedback.
### 6.3 Prevent before explaining

```text
constraint → preview → confirmation only when needed → commit → verify
```

Destructive/irreversible actions receive stronger friction; reversible actions should remain cheap.
### 6.4 Error recovery

Every important failure exposes:

```text
WHAT FAILED · WHY/BEST AVAILABLE CAUSE · WHAT REMAINS INTACT ; WHAT CAN BE DONE NOW · WHETHER SEMANTIC EFFECT IS KNOWN ; RETRY / UNDO / BACK / RESET / EXPORT / RECONCILE where applicable
```

Never hide actionable diagnostics behind “Something went wrong”.
### 6.5 Commit semantics

The UI distinguishes draft/edit from actual system effect:

```text
EDIT → VALIDATE → APPLY → COMMIT → OBSERVE
```

Requested state is never silently presented as effective state.
## 7. Motor ergonomics

Fitts' law is a model for acquisition, not a universal formula. Practical consequences: enlarge/fix high-frequency targets, reduce repeated pointer travel, cluster paired controls, keep frequent controls spatially stable, avoid adjacent tiny consequential targets and measure travel/acquisition/misclick/retry behaviour.
WCAG 2.2 SC 2.5.8 gives a 24×24 CSS-pixel target-size requirement for applicable web content with exceptions; it is not a universal native-desktop minimum. Product-level 44–48 px hit areas can be useful for many primary controls but are heuristics, not physiological laws. Separate visual compactness from hit-area size when necessary. Essential drag operations should have a non-drag alternative when dragging is not inherently required.
## 8. Cognitive ergonomics

Hick-Hyman supports grouping, defaults, search, presets and progressive disclosure; it does not justify arbitrary menu limits. The “7±2” rule is not a universal interface capacity law. Design for recognizable chunks.
Reduce unnecessary cognitive load by:

```text
externalize state → reduce recall → reduce branching → group related information ; → expose defaults/dependencies → preserve context → make recovery obvious
```

Do not hide information required for correct decisions. Account for context switching, state/mode reconstruction, cross-panel comparison and interruption recovery.
Every dense screen needs an attention hierarchy:

```text
primary task → current state → key decisions → supporting detail → diagnostics/edge cases
```

## 9. Gestalt and spatial organisation

Use proximity, similarity, continuity, common region and figure/ground. Related items are closer than unrelated items; component internals are tighter than section boundaries; meaningful ownership gets meaningful boundaries; decorative containers without semantic purpose are avoided; whitespace is structural information.
Design-system starting scale (tunable, not law): `2–4 optical | 8–16 component | 24–32 section | 40–64+ major`. Alignment is grouping; borders support rather than dominate information architecture. Stable spatial location supports recognition and expert motor memory.
## 10. Shared visual design system

Single source of truth:

```text
primitives → semantic tokens → component tokens → component states → composition
```

Never scatter raw colors/radii/spacing/durations/type sizes. Separate primitive color from semantic role, component role and state role.
Component states where relevant:

```text
default · hover · focus · active/pressed · selected · disabled · loading ; success · warning · error · readonly · busy
```

Data/authority states where relevant:

```text
current · refreshing · stale · invalidated · unavailable · unknown · conflict ; requested · accepted · effective · observed
```

A function-changing state must be perceivable and not color-only. Variants encode stable semantic/behavioural differences (`size | intent | mode | density | content type`), not screenshot accidents. Use a common-vs-variation analysis before abstraction.
## 11. Typography and localisation

Desktop/body baseline: roughly `16 px`, `~1.5` line-height, sans-serif UI font; normal prose target `~45–75 chars/line` with `~60–66` as a useful reading target. Dense application UI may use smaller text selectively with compensating contrast/spacing.
Roles: display/page title, section title, control label, body, secondary/metadata, caption, monospace for code/logs/identifiers/diagnostics.
Long-form prose can start near `65ch`; line-height guidance: UI ~1.5, prose 1.5–1.7, headings 1.2–1.35; tune to actual font metrics/language.
Design for long/short labels, Cyrillic, German-like compounds, mixed scripts, pluralisation, decimal formats, RTL where relevant, font fallback, numeric/tabular alignment, fractional DPI and text scaling. Never size a layout from English labels alone.
## 12. Colour, dark mode and semantic status

Where WCAG 2.2 applies, baseline contrast is `≥4.5:1` normal text, `≥3:1` large text and `≥3:1` applicable non-text operational components/graphics. Contrast math is a constraint, not a complete attention/noise model.
Dark mode should not mean pure black. Use layered dark surfaces with sufficient luminance separation; off-white text may be preferable when validated. APCA may be used as additional perceptual analysis but is not the WCAG 2.2 conformance formula.
Color encodes semantic state, not decoration. Critical states should use at least two independent channels when feasible (`color+icon`, `color+text`, `color+shape`, `color+position`); never rely on red/green alone. Validate color-vision deficiency and supported forced/high-contrast modes.
## 13. Keyboard, focus and input

Keyboard is a first-class path: logical tab order, visible focus, focus not hidden by overlays, predictable Enter/Space where applicable, Escape for dismissible transient layers, shortcuts for frequent expert tasks, no traps, and core task capability without pointer-only interaction.
Composite widgets define `focus owner | focus scope | movement model | restoration target | keyboard command ownership`. Closing a modal/panel restores focus to the invoking context unless the task intentionally transfers it. Focus must survive scrolling/docking/overlays/layout changes.
## 14. Motion

Animation communicates state, continuity, hierarchy or causality. Reusable grammar:

```text
micro feedback · standard state transition · smooth structural transition ; entrance · exit · selection · state change · expansion · collapse · loading · success · error
```

Prefer composited properties where appropriate; avoid expensive continuous layout animation without perceptual value. Reduced-motion is a real mode, not a cosmetic afterthought. Motion never becomes the sole carrier of state and should not steal attention unless attention transfer is intentional.
## 15. Density/data surfaces/forms/search

Density is task-dependent:

```text
reading = low/medium ; authoring/chat = medium ; data grid/diagnostics = high + strong hierarchy ; expert configuration = high + progressive disclosure
```

The criterion is how much information can be correctly perceived, located and manipulated for the task.
Tables are for row/column comparison, not arbitrary layout. Dense surfaces support `find → compare → inspect/edit → act`; stable columns, numeric alignment, row grouping, sticky/frozen headers where useful, sorting/filtering near data, visible selection, predictable actions, keyboard semantics, accessible headers and stable identity. Virtualization policy is explicit.
Forms follow user reasoning rather than DB schema:

```text
identity/target → essential choice → dependent choices → optional detail ; → advanced → validation → commit
```

Preserve input on recoverable errors; distinguish invalid/incomplete/unavailable. Complex configuration supports `preset → inspect effective values → modify → apply → verify → save profile`. Search supports partial knowledge, preserved query, result context, why-match where useful, filters and actionable empty state.
Modals interrupt only when justified. Prefer inline/drawer/dockable surfaces for compare-heavy work. Define modal focus entry/confinement, Escape, outside click where used and restoration. Avoid modal chains and dialogs as a substitute for IA.
## 16. Status, authority, provenance and trust UX

AI surfaces explicitly separate:

```text
USER INPUT · SYSTEM/DEVELOPER POLICY · MODEL INPUT ; RESOLVED CONFIGURATION · MODEL OUTPUT · OBSERVED RUNTIME · DIAGNOSTICS
```

Consequential information may need:

```text
CANONICAL · OBSERVED · DERIVED · INFERRED · MODEL CLAIM ; HYPOTHETICAL · STALE · UNKNOWN · CONFLICT · HIDDEN · PRESENTATION
```

Non-negotiable distinctions:

```text
model narration ≠ canonical fact ; UI state ≠ canonical store ; derived ≠ observed ; requested ≠ accepted ≠ effective ≠ observed ≠ presented ; assigned ≠ realised ; current ≠ stale ; unknown ≠ failed ; diagnostic ≠ semantic authority
```

Derived read-side state carries enough `source identity | source revision | observation time where relevant | freshness | invalidating event | refresh/recompute path` to establish currency. Conflicts expose sources, effective resolution basis, reason, consequence and re-read/resolution path.
## 17. Desktop/local-AI Workbench information architecture

The product may expose orthogonal axes because they answer different intents:

```text
Chat · Models · Inference · Prompts · History · Diagnostics ; Simulation · Observatory/World Questions · Settings · Appearance · Workspace/Layout · Runs/Jobs
```

Feature task definitions: Chat = converse/inspect/continue/stop/regenerate/copy/export/recover; Models = discover/inspect/validate/load/switch; Inference = understand generation behaviour; Prompts = author/inspect/version/apply; History = find/compare/reopen/reproduce; Diagnostics = explain attempt/outcome/cause; Simulation = select pack/seed/run/inspect/save/restore/events; Settings = global behaviour/appearance/localisation/accessibility/storage/backend policy; Workspace = arrange/preserve/restore context; Runs = inspect/cancel/reproduce/compare/recover long work.
## 18. AI-specific interaction

Never hide effective backend state. Presets are named by intent, inspectable, editable, versioned when persistence matters and explicit about changes. Streaming exposes operational state while active and keeps Stop discoverable. Errors distinguish user input, configuration incompatibility, backend/model, resource, transport, cancellation and internal failure.
For expensive/state-changing commands preserve enough identity to distinguish a new command from retry. Unknown post-dispatch outcome must be surfaced, not blindly retried. Reproduction records model/backend/config/prompt/seed/run identity plus relevant diagnostics. Do not claim bitwise reproduction without backend guarantees.
### 18.1 Observatory / World Question surface

The Workbench may expose an **Observatory** surface alongside Simulation and Diagnostics. It is a read/experiment surface over derived evidence, not a second world model.

Primary tasks:

```text
observe ensemble / trajectory / relation / object / regime
explain event / dependency / downstream consumer
search reachability / missing consumer
archaeologize a present blocker into verified historical residue
compare BASE vs PERTURBED futures
align a trajectory against a declared World Envelope
review calibration / research-rollout evidence
```

Results use the World Question contract:

```text
QUESTION · CLASS · TARGET · SCOPE · KNOWN · UNKNOWN
COMPETING_HYPOTHESES · OBSERVABLES · PRIMARY_DISCRIMINANT
EVIDENCE · MINIMAL CAUSAL SLICE · UNCERTAINTY
NEXT DISCRIMINATOR · DISPOSITION
```

UI must preserve:

```text
FACT / INFERENCE / HYPOTHESIS / PROPOSAL / UNKNOWN
CONFIRMED / PARTIALLY_CONFIRMED / REJECTED / UNRESOLVED / DEFERRED
```

Never flatten derived evidence, causal hypotheses and canonical facts into one status style. A World Profile is a vector of observables, not a “world quality” score.

Observer/assurance controls must expose the selected observation scope and may distinguish `CANON VIEW`, `PERCEPTION VIEW`, `ASSURANCE VIEW`, and `DEBUG VIEW`. Player-facing presentation may not become omniscient merely because the Observatory can query deeper evidence.

## 19. Accessibility engineering

Baseline: applicable WCAG 2.2 + platform requirements + ISO 9241-171:2025 as the primary software-accessibility reference in the source specification.
Minimum engineering expectations:

```text
keyboard operability · visible focus · contrast · text scaling/reflow where applicable ; non-color state communication · accessible names/roles · logical reading/navigation order ; reduced motion · error/recovery semantics · accessibility-tree exposure ; state-change notification · screen-reader interoperability where supported ; forced/high-contrast behaviour where supported
```

Accessibility defects blocking task completion are functional defects. Automated checks cover only a subset; keyboard-focusability or contrast math alone does not prove good accessibility.
## 20. Responsive, DPI and multi-monitor

Survive small/large windows, 125–200% scaling where applicable, long localized strings, multi-monitor layouts, docking/undocking and restored window state. Prefer resilient constraints over fixed geometry; avoid truncating fixed-width text, fixed-height text regions and orphaned secondary windows.
Test mixed-DPI monitors, per-monitor scaling changes, monitor disconnect/reorder, primary-monitor changes, fullscreen transitions, restore to an unavailable monitor and fractional DPI. Saved layout restoration must validate monitor topology and repair impossible geometry without losing logical workspace ownership.
## 21. Redot decision and freedom

**Redot 26.2 LTS is the pinned primary frontend/runtime for CanonSim Workbench.** The production baseline is the stable LTS line, not a moving development build. Redot 26.2 is the second LTS release and its stable release/tag is `redot-26.2-stable`. The project may evolve with Redot only through an explicit version-admission change recorded in repository authority.

Redot provides the required presentation primitives: 2D canvas/layers, sprites, animated sprites, particles, shaders, cameras, animation/tweening, `Control`/containers/layout, scrolling, rich text, keyboard navigation, themes, custom controls, subviewports/offscreen rendering, CLI/headless execution and packaging/export.

CanonSim does not adopt the default Redot visual language. Typography, tokens, geometry, density, colour, focus, selection, motion, error states, navigation and interaction grammar are product-owned.

### 21.1 Redot-specific engineering rules

```text
Redot = presentation/runtime only ; CanonSim/application = semantic and operational authority
Redot SceneTree = presentation graph, never canonical world state
Redot resource paths/UIDs = presentation asset references, never CanonSim entity identity
GDScript = default frontend language; avoid language/runtime multiplication
Compatibility renderer = initial 2D/2.5D baseline
Redot 26.3+ features = not baseline until separately proven and version-admitted
Redot editor = support tool; CLI/headless = canonical agent-verification route
Redot executable/templates = external toolchain; Redot project/config/assets = repository content
```

Do not use engine-specific features merely because they exist. Prefer stable APIs present in the pinned LTS. A feature that materially couples the product to Redot must have a real consumer, a bounded owner, a regression test and a migration/rejection criterion.

### 21.2 Repository location

The committed Redot project lives at:

```text
workbench/
presentation/
redot/
├── project.godot
├── export_presets.cfg
├── scenes/
├── scripts/
├── ui/
├── visual/
├── themes/
├── assets/
└── tests/
```

The Redot executable is **not** vendored into the repository. A developer may keep it in a stable external location such as `D:\Tools\Redot\26.2\`, with repository tooling selecting that executable explicitly.

## 22. Visual scope

Baseline renderer scope:

```text
static/procedural background + layered world + sprite actors ; + animated sprite states + lightweight effects + UI overlays
```

Target character: illustrated/stylised 2D/2.5D, high-value composition, strong silhouettes, material/style variation, layered depth/parallax where useful and lightweight animation. 3D-first, physics worlds, ragdolls, large terrain, path-traced lighting, RT/GI, volumetrics, heavy post-processing and massive skeletal animation are not baseline requirements.
If future need crosses this scope, use a dependency/runtime admission gate rather than expanding by anticipation. Panda3D/ModernGL/wgpu remain research/fallback options unless a measured need defeats Redot.
## 23. Presentation pipeline and Visual Scene IR

```text
CanonSim semantic/read products ; → Visual Scene IR ; → scene composition policy ; → asset selection/variation ; → frontend read model ; → Redot
```

Visual Scene IR is engine-independent and read-side. It must not contain Redot `Node`, `Texture2D`, GPU IDs, renderer-specific resource paths as identity or renderer internals.
Conceptual structure:

```text
Scene = scene_identity + source_revision + observation_profile + camera ; + background + layers[] + props[] + actors[] + effects[] ; + overlays[] + interaction_hints[] + provenance ; Instance = asset_id + variant_id + position + rotation + scale + layer ; + visibility + animation/state + material/palette variant ; + semantic status + source/provenance reference
```

Allowed presentation semantics distinguish at least `CANONICAL | DERIVED | OBSERVED | UNKNOWN | HIDDEN | TEXTURE/PURELY_VISUAL`.
Never silently perform `UNKNOWN→ABSENT`, `HIDDEN→ABSENT`, `VISUAL→CANONICAL` or `LLM text→CANONICAL`.
IR exists because it separates semantics from rendering, makes compositor output testable, enables screenshot regression/CLI/debug reuse and keeps Redot from becoming CanonSim. Keep IR minimal; it is not a universal scene DSL.
## 23.1 Visual reproducibility closure

A Visual Scene IR is reproducible only when the presentation algorithm and material inputs are identified, not merely the semantic snapshot.

```text
composition_identity = semantic_input_identity
                    + composition_seed
                    + asset_manifest_identity
                    + composition_policy_version
                    + scene_ir_schema_identity
                    + source_revision where material
```

The Scene IR should expose, where material:

```text
scene_ir_schema_identity
scene_composition_version
asset_manifest_identity
semantic_input_identity/source revision
composition seed
observation/freshness metadata
```

Rules:
- Same semantic input does not imply same visual output when composition policy/assets change; identity must reveal that.
- Visual caches may be invalidated/rebuilt without changing semantic state.
- A screenshot is evidence of a rendered result, not a canonical state source.
- Runtime renderer implementation may change while the IR contract remains stable.

## 24. ViewModel/read-model boundary

Application contract:

```text
application operation / ordered event ; → typed semantic read model ; → ViewModel only when presentation derivation/local state is real ; → UI state / Visual Scene IR ; → Redot
```

A ViewModel is not mandatory ceremony. If a view can consume an immutable read model without losing distinctions or adding presentation state, the extra layer is unnecessary.
## 24.1 Scene invalidation and rebuild contract

Presentation state has explicit invalidation causes.

```text
SEMANTIC_CHANGE        → rebuild affected semantic projections
ASSET_MANIFEST_CHANGE  → invalidate affected asset bindings/composition
COMPOSITION_POLICY_CHANGE → rebuild visual composition
SCHEMA_CHANGE          → migrate/reject Scene IR according to schema contract
CAMERA_ONLY_CHANGE     → presentation update; no semantic rebuild
UI_THEME_CHANGE        → UI restyle; no semantic rebuild
CACHE_EVICTION         → rebuild from authoritative/read-side inputs
```

The frontend must not use stale visual cache as if it were current semantic state. Rebuild operations are bounded and observable; failed rebuilds preserve the last known valid presentation when safe and expose stale/degraded status rather than silently fabricating replacement content.

## 25. Visual procedural composition

Separate two forms of procedurality:

```text
semantic procedural generation = what semantically exists/matters/is observable ; visual procedural composition   = how existing semantics are shown
```

Composition input:

```text
local semantic context + seed + style profile + asset vocabulary ; + placement/visibility constraints ; → deterministic composition
```

Useful grammar: region/scene type → structural grammar → compatible asset families → neighbour/anchor constraints → deterministic variation → occlusion/layer rules → density → final composition.
Candidate algorithms include weighted selection, graph grammar, constraint propagation, WFC-like methods and local search/backtracking. Select empirically from representative scenes; do not freeze an algorithm because it is fashionable.
Determinism target:

```text
same semantic input + same seed + same asset manifest → same composition
```

unless intentional nondeterminism is declared. A Townscaper-like **principle** is useful: small compatible vocabulary + strong composition rules > thousands of hand-authored finished scenes; do not copy its implementation.
## 26. Asset-first, not asset-heavy

Primary visual bottleneck is a coherent vocabulary, not a renderer.

```text
semantic asset specification → generation/acquisition → cleanup/normalisation ; → validation → variants → atlas/spritesheet → manifest ; → content identity → runtime load
```

AI/offline content tooling may produce base sprites/textures, style/material variants, pose/expression variants, prop families and background fragments. Runtime procedural composition owns placement, transforms, variant choice, compatibility, density, layering, occlusion, clutter and lightweight effects. CanonSim owns semantic existence/state.
Initial reusable vocabulary:

```text
terrain/ground · roads/paths · walls/floors/roofs · windows/doors/stairs ; fences/arches/pillars · signs/lamps/pipes · vegetation/rocks/water accents ; crates/barrels/bags/tables/chairs/tools/baskets/books/bottles/clutter ; actor base + pose + idle + expression + state variants ; inventory/map/compass/journal/notice/status icons
```

Prefer parameterized variants when adequate: mirror/rotation/scale, palette/material, weather, wear/damage, occupancy, expression/pose, decals. Do not create a full independent asset for every variation when composition parameters suffice.
## 27. Asset identity/provenance

Filesystem path is location only. Distinguish:

```text
AssetId · ContentIdentity/digest · Location · Version/compatibility ; Lifecycle state · Variant · Source asset · Derived asset · Runtime artifact
```

Example identity: `actor.blacksmith + variant angry_02 + content digest + compatibility`. Same path with changed bytes is a new content identity. Multi-file/sharded assets use deterministic composite identity over material constituents plus relevant metadata/schema.
AI-generated/offline provenance should be available to the asset manifest; filesystem path alone is never sufficient for reproducibility.
## 27.1 Asset Manifest contract and lifecycle

Assets are consumed through an explicit manifest rather than ad-hoc file paths. A material asset entry should expose:

```text
asset_id
asset_revision/content_identity
format + dimensions + colour/alpha metadata where relevant
semantic/visual role
licence/provenance
compatibility/runtime requirements
source/tool/version where material
validation status
```

Lifecycle:

```text
DISCOVERED → IDENTITY_VERIFIED → FORMAT_VALID → COMPATIBLE → VISUALLY_VALID → RUNTIME_READY
```

Failure states:

```text
MISSING | INVALID | INCOMPATIBLE | STALE | CORRUPT | UNKNOWN
```

A bad asset is not silently replaced by an arbitrary visually similar asset when that would change reproducibility or semantic presentation. Fallbacks must be explicit and typed.

## 28. Camera, map and world surfaces

Camera state has separate layers:

```text
SEMANTIC FOCUS/TARGET = read-side consequence of the current task/world view
PRESENTATION CAMERA   = framing/composition chosen to make that focus legible
USER CAMERA STATE     = user-controlled navigation/zoom/pan context
```

Changing the presentation camera must not mutate semantic focus. A camera target derived from canonical/read-side facts is not itself a canonical fact.

Camera is presentation state; it can depend on scene type, focal actor, UI mode, preferences and zoom, but never mutates world semantics. Useful profiles:

```text
LOCAL_SCENE · MAP · CHARACTER_FOCUS · INSPECTION · DEBUG
```

Map projection levels:

```text
WORLD → REGIONAL → LOCAL → SCENE
```

Each level may have different visual vocabulary/resolution. Inventory maps semantic items to icons/state/quantity; compass maps semantic heading/bearing to UI; journal/notes maps persisted records to a surface; notice boards map world-backed notices to procedural cards. None requires another graphics engine.
## 29. Observation boundary and assurance views

Future CanonSim presentation must respect the selected observation scope:

```text
CANON VIEW · PERCEPTION VIEW · ASSURANCE VIEW · DEBUG VIEW
```

Distinguish what exists, what is visible, what is known/observed, what is derived only for presentation and what is intentionally hidden. The visual system may only show information permitted by the chosen observation profile.
Assurance/debug metadata may include:

```text
asset_id · entity_id · layer · visual LOD · semantic status ; source revision · scene seed · composition rule · unknown/hidden markers · provenance
```

Debug may be more informative than player-facing UI without creating additional authority.
## 30. Static backgrounds, LOD and effects

Static background is an optimization feature:

```text
semantic local context → deterministic composition → cached background ; → dynamic actors/effects/UI
```

Update only changed layers. Avoid storing/reloading the entire visual world merely for the current viewport.
2D/2.5D visual LOD:

```text
FULL = actor animation + local props + effects ; REDUCED = simpler sprite + reduced animation + fewer props ; IMPOSTOR/COMPOSITE = precomposed/simplified layer ; ABSTRACT = icon/silhouette/map symbol
```

Semantic LOD and visual LOD are independent; visual LOD cannot alter semantic truth.
Effects are presentation unless they represent a semantic entity: rain/fog/snow/wind/dust/spark/glow/fire ambience/ink/splatter/transitions/focus/selection. Prefer particles, animated textures, sprite sequences and small shaders; do not turn ordinary effects into GPU-heavy simulations without measured need.
## 31. Performance/resource model

### 31.0 Shared-GPU admission rule

The visual runtime MUST assume that the same machine/GPU may concurrently host a local LLM. Therefore visual capacity is not treated as dedicated headroom. Acceptance uses measured profiles for:

```text
visual-only
visual + representative local-LLM load
peak asset/scene transition
worst supported window/DPI case where material
```

The baseline renderer must remain useful without requiring ray tracing, heavy compute, volumetrics, expensive global illumination, large particle simulation or aggressive post-processing. Optional effects require an explicit degradation path.

The benchmark must match the real product: `Redot UI + large history + mostly static scene + several animated actors + light effects + concurrent local LLM on same GPU`.
Measure both frontend alone and frontend + concurrent LLM:

```text
startup · RAM/VRAM · CPU/GPU contention ; frame p50/p95/p99 · input/UI latency during streaming ; history/query/render cost · scene rebuild frequency ; asset load/reload · texture/cache memory · active actors/effects ; stream buffer size/update cadence · reconnect/shutdown
```

Budget categories include active texture memory, cached texture memory, asset count, atlas/texture size as relevant, active actors, active effects, scene rebuild frequency, history materialisation, pending stream buffers, CPU frame budget and GPU frame budget. “Bounded” means a declared ceiling plus degradation policy.
Degrade explicitly under pressure: reduce visual detail/effects, reduce offscreen/cache size, collapse distant layers, switch visual LOD, page/virtualise history. Do not fix every budget breach by growing caches.
## 32. UI readability and visual language

Professional distinctiveness is not `dark + neon + rounded cards + glow`. A strong system has clear hierarchy, controlled contrast, intentional density, distinctive restrained geometry, stable alignment, coherent type, semantic colour and purposeful motion.
Visual emphasis is budgeted: not every panel/state may simultaneously use maximum luminance, saturation, motion and contrast. Avoid border/glow overload, boxed-everything, arbitrary radii/gradients/asymmetry and multiple dominant focal points.
CanonSim may use an aggressive graphic language—strong silhouettes, high contrast, controlled material separation, limited intentional shading, graphic overlays, ink/splatter/stencil/screenprint and urban junkpunk/graffiti energy. These are stylistic choices, not usability law; style must not hide state or weaken hierarchy.
## 33. Agent-first frontend development

Preferred loop:

```text
agent → code/config/resource → Redot CLI/headless ; → deterministic test → screenshot/state artifact → inspect → patch → rerun
```

GUI editor is an inspector/optional authoring aid, not the required production path. Stable base scenes are acceptable; dynamic/repeated UI should favour code/components + small stable scene resources + typed/config data where it is genuinely data.
Do not make agents hand-edit giant `.tscn` files for every repeated element. A surface should be reproducible from known input state and preferably expose a screenshot and optional semantic overlay.
## 34. Large-history and streaming presentation

Chat/history presentation must stay bounded:

```text
persisted history → bounded query/page → read model → virtualized renderer
```

Never create `10,000 messages → 10,000 permanently live nodes`. Streaming may coalesce tokens, manage scroll and animate text; presentation smoothing may not change semantic content or operation terminality. Reserve layout to limit shift where possible.
## 35. Save/persistence relationship

Keep application config, session state, chat/history, simulation checkpoint/cursor, visual cache, asset cache and UI-local state distinct. Visual/asset caches rebuild; canonical/persistent state is not a disposable render cache. Frontend asks the application to save/restore; it does not invent persistence semantics.
## 36. Failure/degradation behaviour

Minimum visual recovery policy:

```text
missing asset → show safe placeholder/fallback + diagnostic ; invalid manifest → reject affected set, preserve usable scene ; stale scene revision → mark stale / rebuild from current source ; backend/LLM stream stall → expose lifecycle/timeout, never fake completion ; history over budget → page/virtualize ; resource pressure → explicit LOD/effect/cache degradation
```

Canonical/backend failures must not be hidden by attractive visual masking. Unknown is displayed as unknown, not success or absence.
## 37. Packaging, offline tooling and licensing

User sees one product; internal topology may remain multi-process:

```text
application package = Redot frontend + Python/application runtime + user data ; models/assets = separate managed locations ; simulation packs = managed content
```

Offline content tooling is not runtime:

```text
ComfyUI / Qwen Image · Blender headless · Pillow · trimesh · atlas/validation tools
```

These do not enter CanonSim core or become mandatory runtime dependencies merely because they generate assets. Runtime dependency admission follows §40.
Every third-party runtime dependency, plugin, codec, importer and shipped asset requires an explicit licence/redistribution inventory. A permissive engine licence does not imply that the complete shipped bundle is permissively redistributable.
## 38. Security/trust boundary

Treat Redot input, imported assets and external metadata as untrusted until application validation.

```text
path ≠ command ; import ≠ execution ; model output ≠ authority ; asset metadata ≠ executable code ; UI command ≠ direct CanonSim mutation ; remote API/agent ≠ bypass of application/semantic seam
```

Do not let diagnostic/DEV evidence become a secret exfiltration path.
## 39. Dependency admission / renderer fork gate

Runtime baseline is Redot 26.2 LTS. Another engine/runtime is admitted only when all are demonstrated:

```text
real consumer + concrete limitation/risk ; + measured quality/performance gap ; + acceptable runtime/dependency/licence envelope ; + testable agent workflow
```

Reconsider another renderer/runtime if Redot 2D/2.5D cannot represent the required visual class, a required asset class demands materially different runtime, measured GPU/RAM overhead breaks product budget, agent automation cannot reliably achieve required changes, or packaging/deployment creates an unacceptable constraint.
Never add Panda3D/ModernGL/wgpu/full 3D machinery just for future-proofing.
## 40. Usability evaluation stack

```text
0 static/automated audit ; → 1 expert heuristic review ; → 2 cognitive walkthrough ; → 3 task-based usability test ; → 4 controlled comparison when a defined question exists ; → 5 validated subjective scales when useful ; → 6 local instrumented behaviour when explicitly enabled/privacy-safe ; → 7 eye tracking/physiology only when cheaper evidence is insufficient
```

Heuristic evaluation records location, affected task, principle/heuristic, severity, reproduction and remediation. Cognitive walkthrough asks whether the user knows the goal/action/result/next step. Task studies record completion, time, errors and recovery; subjective preference is secondary.
Useful validated scales: SUS, UEQ/UEQ-S, NASA-TLX. NASA-TLX dimensions: mental demand, physical demand, temporal demand, performance, effort, frustration.
## 41. Neutral comparative experiment discipline

GUI “double blind” is often impractical. Where possible: neutral variant naming, concealed variant identity, necessary instructions only, analyst-blind subjective coding. Counterbalance within-subject order; use balanced/LATIN-square-style ordering when appropriate.
Control learning, fatigue, order, task difficulty, expertise, hardware and carryover. Predefine the primary outcome when practical. Never call a design better because it was shown second.
Experiment record:

```text
QUESTION · COMPETING HYPOTHESES · INTERVENTION ; ASSIGNMENT · CONTROL · BLOCKED/RECORDED NUISANCE ; TRACE IDENTITY · REALIZED DELTA · UNIT/SCOPE · SPILLOVER ; PRIMARY DISCRIMINANT · PRIMARY/SECONDARY METRICS ; CLAIM SCOPE · ORACLE/RELATION · REPLICATION · STOPPING RULE · DISPOSITION
```

`ASSIGNMENT ≠ REALIZED DELTA`. For causal work, small controlled factors are preferable unless interaction is the research question.
## 42. UI engineering metrics/statistics

Effectiveness: completion, error, accuracy, first-attempt success. Efficiency: time-on-task, pointer travel, steps, backtracking/search iterations. Recovery: recovery time, undo/retry, abandonment. Cognitive: workload/help/hesitation/decision reversals. UX: SUS/UEQ/confidence/satisfaction. Temporal: first feedback/actionability/completion/recovery/wait. State integrity: stale incidence, unknown outcomes, requested/effective mismatch, reconciliation. Interaction integrity: focus loss/restoration, duplicates, misfire, accidental destructive actions. System quality: input latency, frame time/drops, layout shift, rendering failure, memory/CPU/GPU/VRAM pressure, stream cost.
Track distributions, not only means. For comparative studies, randomize/counterbalance where possible, predefine the primary outcome, define analysis unit, account for paired/repeated measures, report sample size and uncertainty, and avoid treating non-significance as proof of equivalence.
## 43. Design review gates

```text
A task validity ; B information architecture ; C interaction/state/recovery ; D visual/token system ; E accessibility ; F performance/boundedness ; G empirical validation ; H state/trust/provenance/recovery ; I agent-operable verification
```

A gate passes only when its relevant task, contract and evidence exist; visual polish cannot substitute for missing semantic/state/accessibility correctness.
## 44. Automated checks and agent-operable evidence

Automate objective checks where feasible:

```text
contrast · hit areas · focus reachability/restoration ; keyboard semantics · overflow/truncation · token violations ; state completeness · reduced-motion path · accessibility tree ; requested/effective consistency · stale/unknown handling ; DPI/layout restore · duplicate commands · stream bounds ; Observatory claim/evidence rendering · causal-scope visibility · observer-boundary enforcement ; semantic mutation detection · visual regression · performance budgets
```

Automated checks collect evidence; they do not decide task fit, mental-model quality, visual naturalness or satisfaction.
## 45. Architecture/UX anti-patterns

```text
UI widget → direct CanonSim mutation ; Redot SceneTree → canonical world state ; Redot resource/UID → CanonSim identity ; LLM text → canonical object without validation ; Observatory projection → canonical world state ; World Profile → quality score ; causal/read dependency → shown as proven causality ; player surface → implicit omniscient observability ; model capability → automatic widget generation ; second backend transport hidden in frontend ; unbounded history nodes ; unbounded asset cache ; manual per-instance scene authoring as required agent workflow ; giant generic Visual DSL before first real scene ; Redot default theme treated as product identity ; style used to compensate for weak IA ; motion/color used as sole state carrier ; modal chains replacing missing IA ; fixed-English geometry ; renderer dependency added “just in case”
```

## 46. Implementation order

```text
A runtime/UI shell: custom theme → Chat → Settings → Models/Inference → History → Diagnostics ; → Simulation placeholder → application connection → headless/screenshot ; B semantic visual seam: read model → minimal Visual Scene IR → placeholder compositor ; → semantic/visual overlay → deterministic replay proof ; C vocabulary: manifest/identity → small reusable kit → variants → placement constraints ; → backgrounds → actors → effects ; D surface expansion: map → inventory → compass → journal → notices → perception/assurance/debug ; E optimization: atlas/cache → visual LOD → rebuild limits → history virtualization ; → CPU/GPU/VRAM budgets → concurrent-LLM benchmark
```

Do not scale asset production before A+B prove the seam.
## 47. Acceptance benchmark and verification gates

Acceptance scenario should include:

```text
Redot startup/packaging ; custom UI + keyboard/focus/accessibility ; Chat streaming + large history ; Models/Inference controls + effective-state display ; CanonSim placeholder world + deterministic Visual Scene IR ; procedural props/actors + map/inventory interaction ; assurance/observation views ; asset load/reload + missing/stale degradation ; backend loss → reconnect/cancellation truth ; screenshot/headless regression ; frontend alone vs frontend + concurrent local LLM
```

Required gates:

```text
G1 Redot startup/packaging works in actual runtime envelope ; G2 Chat/Settings/History use shared application operations ; G3 backend reconnect/cancellation semantics remain correct ; G4 CanonSim read-side seam is explicit/renderer-independent ; G5 Visual Scene IR fixture is deterministic ; G6 placeholder scene renders without hand-authored per-instance list ; G7 screenshot/headless regression works ; G8 frontend cannot bypass application/semantic boundaries ; G9 resource budgets measured with degradation paths ; G10 concurrent LLM + frontend measured ; G11 dependency/licence inventory complete for admitted runtime ; G12 asset identity/provenance exists before large ingestion
```

## 48. Shared seam with application architecture

```text
application operation / ordered event ; → typed semantic read model ; → ViewModel if presentation-specific derivation/state is needed ; → UI state and/or Visual Scene IR ; → Redot
```

The application document owns operations, semantics, identity, lifecycle, inference, persistence, gateway, backend/process boundaries and recovery. This document owns task/UX interaction, navigation, visual system, accessibility, Redot presentation, ViewModels, Visual Scene IR, camera, procedural composition, assets, visual LOD/cache/effects and frontend validation.
No second presentation super-layer. `PRESENTATION_SPEC` remains model-facing.
## 48.1 v5.2 closure requirements

The following are mandatory shared seams with the application architecture:

```text
Visual Scene IR identity closure
  = semantic input identity + composition seed + asset manifest identity
  + composition policy/version + Scene IR schema identity

Asset lifecycle
  = DISCOVERED → IDENTITY_VERIFIED → FORMAT_VALID → COMPATIBLE
  → VISUALLY_VALID → RUNTIME_READY

Scene invalidation
  = semantic / asset-manifest / composition-policy / schema changes invalidate only the affected presentation layers

Camera
  = semantic focus/target ≠ presentation camera ≠ user camera state

Performance
  = visual-only + concurrent-local-LLM measurements; optional expensive effects require degradation
```

These are contracts, not implementation suggestions.

## 49. Final design rules

```text
1 Workbench and game are one frontend/product.
2 Redot is the primary frontend/runtime; default theme is not CanonSim identity.
3 2D/2.5D is baseline; 3D/other renderer requires measured admission.
4 CanonSim is sole semantic authority.
5 UI is read/control surface, not second semantic store.
6 Visual Scene IR is renderer-independent read-side contract.
7 UNKNOWN/HIDDEN/ABSENT and CANONICAL/DERIVED/OBSERVED/VISUAL remain distinct.
8 Visual composition may vary presentation but cannot invent canonical facts.
9 Small reusable asset vocabulary + deterministic variants + procedural composition is the baseline content strategy.
10 AI/offline tooling creates vocabulary; runtime composes it; CanonSim supplies semantics.
11 Semantic LOD and visual LOD are separate.
12 Static layers/caches are bounded optimizations, never canonical state.
13 All consequential actions expose status, recovery and effective outcome.
14 Accessibility/keyboard/focus/reduced-motion/localisation/high-DPI are first-class.
15 Large history/streams/assets are explicitly bounded.
16 Visual performance is measured with and without concurrent local LLM inference.
17 Style is subordinate to hierarchy, state clarity and task success.
18 Agent workflow is code/config/CLI/headless/screenshot-first; GUI editor is support tooling.
19 New visual abstractions/dependencies require real consumer + problem + test/falsifier.
20 Automated regression proves objective properties; user testing proves task/experience questions.
```

## 50. One-line formula

> **CanonSim decides what exists and happens; Workbench application exposes safe operations and typed read models; this document decides how those results are understood, controlled and visualised; Visual Scene IR separates semantics from rendering; procedural composition assembles a small asset vocabulary; Redot presents the unified game/Workbench frontend without becoming a second simulator.**
## Appendix A — Source coverage map

```text
UI/UX human-centred design, IA, interaction, HCI models, ergonomics → §§1–9 ; visual tokens/type/colour/focus/motion/density/forms/search → §§10–15 ; AI trust/provenance/effective state/accessibility/responsive → §§16–20 ; Redot/2D-2.5D/Visual Scene IR/composition/assets → §§21–30 ; performance/cache/resource/agent workflow → §§31–37 ; security/dependency/research/usability/statistics → §§38–44 ; anti-patterns/order/acceptance/shared seam/final rules → §§45–50 ; v4.4 Visual Scene IR, observation, asset identity, packaging/licensing, degradation ; v5.2 closure contracts for composition identity, Asset Manifest, scene invalidation, camera separation and shared-GPU admission → §§23–31, 37–48 ; verification material is retained in §§40–48.
```

*This file is the full replacement for the previous v5.1 frontend/UI/visual specification.*
