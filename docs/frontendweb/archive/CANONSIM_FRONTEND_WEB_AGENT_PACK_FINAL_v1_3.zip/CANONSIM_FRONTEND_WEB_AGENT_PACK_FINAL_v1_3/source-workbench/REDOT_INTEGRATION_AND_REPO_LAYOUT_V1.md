# CanonSim — Redot Integration & Repository Layout Contract v1

## 1. Purpose

This is the mechanical contract for adding Redot to CanonSim Workbench without vendoring the engine or leaking engine types into CanonSim/application semantics.

## 2. Pinned baseline

```text
Engine: Redot
Version: 26.2 LTS
Tag: redot-26.2-stable
Renderer baseline: Compatibility
Language baseline: GDScript
Project root: workbench/presentation/redot/
```

Redot 26.3+ builds are not the production baseline. Their newer features may be evaluated in isolated branches/proofs, but production code must not require them until a version-admission decision is recorded.

## 3. Machine layout

Recommended Windows layout:

```text
D:\Dev\canonsim\                         ← Git repository
D:\Tools\Redot\26.2\                   ← external engine/toolchain
```

Do not place the Redot executable inside `D:\Dev\canonsim\`. The repository contains the Redot project, not the editor binary.

## 4. Repository layout

```text
canonsim/
├── core/
├── sim/
├── cli/
├── content/
├── schemas/
├── tests/
├── docs/
├── CANONSIM_WORLD_OBSERVATORY_AND_CONTROL_PLANE_V5_2.md
└── workbench/
    ├── application/
    ├── api/
    ├── features/
    └── presentation/
        └── redot/
            ├── project.godot
            ├── export_presets.cfg
            ├── scenes/
            ├── scripts/
            ├── ui/
            ├── visual/
            ├── themes/
            ├── assets/
            └── tests/
```

Create directories when they acquire a real owner/consumer; do not pre-create empty architecture theatre.

## 5. Git policy

Commit:

```text
project.godot
export_presets.cfg
GDScript source
scene/resource source files
source visual assets admitted by Asset Manifest
required import metadata produced by the pinned workflow
```

Ignore:

```gitignore
.godot/
```

Never commit:

```text
engine executable
export-template installation bundle
user-local editor settings
credentials/tokens
large generated cache
machine-local absolute paths unless explicitly part of a portable test fixture
```

## 6. Runtime boundary

```text
CanonSim
  owns: semantics/events/fold/RNG/world truth

Workbench application
  owns: operations/state/lifecycle/persistence/inference/gateway

Visual Scene IR
  owns: renderer-neutral presentation read model

Observatory / analytical read-side
  owns: derived run projections, experiments and World Questions; never canonical truth

Redot
  owns: UI/input/layout/camera/composition/animation/rendering/transient presentation state
```

Forbidden:

```text
Redot node → canonical mutation
Redot SceneTree → canonical world database
Redot resource UID → CanonSim entity identity
Redot script → duplicate simulation rules
Redot script → direct llama.cpp transport
```

## 7. Launcher contract

Use one repository-level configurable variable, for example:

```text
REDOT_EXE=D:\Tools\Redot\26.2\<redot-executable>
```

Do not hardcode multiple Redot paths across scripts. Agent/CI scripts resolve the single toolchain path and then invoke the project by `--path workbench/presentation/redot`.

Representative commands:

```text
%REDOT_EXE% --path workbench/presentation/redot
%REDOT_EXE% --headless --path workbench/presentation/redot ...
```

The repository should not assume that an editor GUI must be open for testing.

## 8. First vertical proof

The first Redot implementation must prove only the seam:

```text
known CanonSim fixture
→ typed application/read model
→ deterministic Visual Scene IR
→ Redot composition
→ screenshot/headless artifact
```

Minimum visual fixture:

```text
background + 1 actor + 2–3 props + overlay/debug state
```

No large asset library is required before the seam is proven.

## 9. Version upgrade gate

An engine upgrade requires all of:

```text
project open/save check
resource import check
scene runtime check
CLI/headless check
screenshot regression
UI/input/focus regression
CPU/RAM/GPU/VRAM comparison
concurrent local LLM comparison
export/package check
license/provenance refresh
agent workflow check
```

## 10. External references

Redot 26.2 LTS release: https://github.com/Redot-Engine/redot-engine/releases/tag/redot-26.2-stable
Redot 26.2 docs: https://docs.redotengine.org/
