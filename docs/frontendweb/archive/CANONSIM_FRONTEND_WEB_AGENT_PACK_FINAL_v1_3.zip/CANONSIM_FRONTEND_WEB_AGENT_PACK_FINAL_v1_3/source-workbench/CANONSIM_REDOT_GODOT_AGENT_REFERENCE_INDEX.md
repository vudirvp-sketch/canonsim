# CanonSim — Redot / Godot Agent Reference Index

**Purpose:** canonical external reference map for agents working on CanonSim Workbench / presentation runtime, with routing to the derived World Observatory control-plane contract when a task is analytical or causal.

**Checked:** 2026-09-24
**Project baseline:** Redot 26.2 LTS (`redot-26.2-stable`)
**Project scripting baseline:** GDScript
**Project visual baseline:** 2D / 2.5D, GL Compatibility, desktop/local-AI Workbench

---

## 1. How an agent must use this index

Use the smallest reference set that closes the current task.

**Priority order:**

1. CanonSim repository authority and owning project docs.
2. Official Redot 26.2 documentation / class reference for engine behavior and API.
3. Official Redot source / releases / demo projects when documentation is insufficient.
4. Godot documentation only for shared concepts, historical/background knowledge, or cross-checking behavior; re-verify all engine/API claims against Redot 26.2 before coding.
5. Community Agent Skills for workflow/patterns; never treat them as API authority.

**Do not:**
- assume current Godot 4.7/4.8 API == Redot 26.2 API;
- import Godot 4.7-only features into the Redot baseline without an explicit version-admission proof;
- let an engine skill override CanonSim ownership rules;
- make Redot `Node`, `Resource`, UID, SceneTree state, or renderer objects part of CanonSim semantic contracts.

---

## 2. CanonSim internal authority — read these first

### Always / before any Workbench change

- `AGENTS.md` — agent operating law, invariants, Git safety, stop/confirm gates, Definition of Done.
- `docs/AGENT_NAVIGATION.md` — repository map and reading gradient.
- `docs/BLUEPRINT.md` — cross-cutting architecture laws and component build index.
- `STATUS.md` — current iteration state / active KIs.

### Redot Workbench work

- `workbench/presentation/redot/project.godot` — live engine project configuration.
- `workbench/presentation/redot/` — current Redot-owned presentation code/assets.
- `CANONSIM_WORKBENCH_APPLICATION_ARCHITECTURE_V5_2.md` — application-side ownership and typed seam.
- `CANONSIM_VISUAL_PRESENTATION_RUNTIME_ARCHITECTURE_V5_2.md` — Redot runtime/presentation architecture.
- `CANONSIM_FRONTEND_UI_VISUAL_ENGINEERING_SPEC_V5_2.md` — UI/visual engineering contract.
- `REDOT_INTEGRATION_AND_REPO_LAYOUT_V1.md` — Redot version/toolchain/repository boundary.
- `REDOT_MIGRATION_README.md` — migration package and baseline.
- `CANONSIM_WORLD_OBSERVATORY_AND_CONTROL_PLANE_V5_2.md` — world observability, causal evidence, experiments, calibration, World Questions and bounded steering.

### Relevant implementation seams

- `workbench/scene_ir.py` — renderer-neutral Visual Scene IR.
- `workbench/scene_build.py` — read-side scene assembly.
- `scripts/visual_proof.py` — Redot proof/runner tooling.
- `tests/test_visual_proof.py` — visual proof regression coverage.

### Core invariant to preserve

`application operation / ordered event -> typed semantic read model -> optional ViewModel -> UI state / Visual Scene IR -> Redot`

Redot is presentation/runtime. CanonSim remains semantic authority.

---

## 3. Official Redot documentation — PRIMARY external authority

### 3.1 Main documentation hub

- https://docs.redotengine.org/
  - Start here for Redot-specific behavior.
  - Contains Getting Started, Tutorials, Classes, Export, UI, Rendering, Scripting, etc.

### 3.2 Redot 26.2 class reference

- https://docs.redotengine.org/en/26.2/Classes
  - Exact API lookup: classes, methods, properties, signals, constants.

### 3.3 GDScript

- https://docs.redotengine.org/en/26.2/Tutorials/scripting/gdscript/gdscript_basics
- https://docs.redotengine.org/tutorials/scripting/gdscript/gdscript_styleguide

Use for:
- typed GDScript;
- signals/callables/await;
- properties and setters/getters;
- assertions;
- naming/style;
- lifecycle methods;
- engine-specific script behavior.

### 3.4 Resource / scene model

- https://docs.redotengine.org/tutorials/scripting/resources

Use for:
- `Resource` vs scene resources;
- `PackedScene`;
- instancing;
- resource loading and sharing.

### 3.5 UI / controls

Start from the Redot class reference and UI tutorial index for:
- `Control`;
- `Container`;
- `PanelContainer`;
- `MarginContainer`;
- `VBoxContainer` / `HBoxContainer` / `GridContainer`;
- `ScrollContainer`;
- `SplitContainer`;
- `TabContainer`;
- `Tree`;
- `ItemList`;
- `RichTextLabel`;
- `LineEdit` / `TextEdit`;
- `Button` / `MenuButton` / `PopupMenu`;
- `TextureRect`;
- `Theme` / `ThemeDB`.

Useful direct references:
- `Control`: https://docs.redotengine.org/en/26.2/classes/class_control.html
- Class index: https://docs.redotengine.org/en/26.2/Classes

### 3.6 Input / focus / keyboard navigation

- https://docs.redotengine.org/tutorials/inputs/input_examples
- Redot class reference for `Control`, `Input`, `InputEvent`, `Viewport`.

For CanonSim UI, verify:
- focus ownership;
- keyboard traversal;
- mouse filters;
- handled/unhandled input;
- accessibility-relevant focus behavior.

### 3.7 Resolution / DPI / layout

Use the Redot documentation search for:
- Multiple resolutions;
- anchors and offsets;
- containers;
- stretch modes;
- viewport/display scaling.

Primary hub: https://docs.redotengine.org/

### 3.8 Performance / rendering

- https://docs.redotengine.org/tutorials/performance/
- Redot class/reference pages for `Performance`, rendering/server APIs, `CanvasItem`, `RenderingServer`.

For CanonSim, measure the real workload:
`Redot UI + long history + mostly static scene + several animated actors + light effects + concurrent local LLM on same GPU`.

### 3.9 2D / presentation

Use official Redot docs for:
- `Node2D`;
- `CanvasItem`;
- `Sprite2D`;
- `AnimatedSprite2D`;
- `Camera2D`;
- `CanvasLayer`;
- `CPUParticles2D`;
- shaders / `CanvasItem` materials;
- visibility and draw-order behavior.

Do not introduce a 3D-first architecture unless the project decision changes.

### 3.10 Command line / headless / export

Use the official Redot documentation and executable `--help` for the exact 26.2 CLI supported by the installed binary.

Agent workflow should favor:
- project-path explicit execution;
- headless runs for verification;
- deterministic test/artifact capture;
- explicit executable path via the project toolchain contract.

Project contract currently expects one external `REDOT_EXE` path, not multiple hard-coded paths.

### 3.11 Redot source / release / demos

- Engine: https://github.com/Redot-Engine/redot-engine
- Releases: https://github.com/Redot-Engine/redot-engine/releases
- Official docs source: https://github.com/Redot-Engine/redot-docs
- Demo projects: https://github.com/Redot-Engine/redot-demo-projects
- Redot C++ bindings (only if GDExtension becomes necessary): https://github.com/Redot-Engine/redot-cpp

Use source/issues/releases when docs are ambiguous or when a behavior appears version-specific.

---

## 4. Godot documentation — SECONDARY / cross-reference only

Godot remains valuable because Redot originated as a Godot fork and much of the conceptual/API vocabulary is shared. Redot's own docs explicitly state that they are adapted from Godot documentation. Still, the project baseline is Redot 26.2, so Redot docs win for engine behavior.

### Current Godot release reference

- Official release archive: https://godotengine.org/download/archive/
- Stable currently includes Godot 4.7.2; 4.8 is development-stage as of this index date.
- Godot latest/unstable docs: https://docs.godotengine.org/en/latest/

### Godot docs are most useful for

- broad engine concepts;
- architectural patterns;
- UI design concepts;
- GDScript language concepts;
- migration/history;
- examples not covered clearly by Redot docs.

### Version firewall

Never use `latest` Godot docs as direct implementation authority for Redot 26.2.

For an API question:

`Redot 26.2 class reference -> Redot 26.2 tutorials/source -> installed Redot binary/help -> Godot docs only as cross-check`

---

## 5. Agent Skills — directly useful

These are workflow aids, not authoritative engine documentation.

### A. `gda` / godot-agent — strongest agent-oriented option found

Repository:
https://github.com/aigengame/godot-agent

Skill:
https://github.com/aigengame/godot-agent/blob/main/src/gda/skill/SKILL.md

What it does:
- agent-first Godot CLI;
- structured JSON output;
- headless project inspection/editing;
- scene/node/script/resource/theme operations;
- static analysis;
- export;
- runtime control/inspection when configured.

Use for:
- agent ↔ engine feedback loop;
- deterministic inspection;
- headless verification;
- reducing fragile manual editor operations.

Important:
- described primarily for Godot;
- verify Redot 26.2 CLI/behavior before adopting it as a project dependency;
- do not let its abstractions override CanonSim's repository contracts.

### B. `@vl4dt/godot-skills` — broad skill pack

Repository:
https://github.com/vl4dt/godot-skills

It currently exposes 12 skills including:
- `godot-project-setup`
- `godot-brainstorming`
- `godot-gdscript-patterns`
- `godot-code-review`
- `godot-debugging`
- `godot-headless-workflow`
- `godot-ui`
- `godot-performance`
- `godot-animation`
- `godot-physics`
- `godot-networking`
- `godot-47-migration`

CanonSim-relevant subset:

**Use:**
- `godot-gdscript-patterns`
- `godot-code-review`
- `godot-debugging`
- `godot-headless-workflow`
- `godot-ui`
- `godot-performance`
- `godot-animation`
- `godot-project-setup` (only for tooling/setup tasks)

**Usually skip:**
- `godot-csharp-patterns` (project baseline is GDScript; C# is not admitted)
- `godot-networking` (only when actual networking work exists)
- `godot-physics` (not relevant to presentation-only baseline unless scope changes)
- `godot-47-migration` (Godot-specific, not a Redot 26.2 migration authority)

### C. UI-specific skill

https://github.com/vl4dt/godot-skills/blob/main/skills/godot-ui/SKILL.md

Useful for:
- Control hierarchy;
- containers;
- theme resources;
- responsive layout;
- UI interaction states;
- focus/navigation.

This is particularly relevant to Workbench because UI is a first-class product surface.

### D. Performance skill

https://github.com/vl4dt/godot-skills/blob/main/skills/godot-performance/SKILL.md

Useful for:
- profiling workflow;
- memory / draw-call awareness;
- runtime monitoring;
- performance regression thinking.

For CanonSim, replace generic mobile/game budgets with the project's shared-GPU benchmark and measured acceptance gates.

### E. Alternative GDScript pattern skills

- https://github.com/wshobson/agents/tree/main/plugins/game-development/skills/godot-gdscript-patterns
- https://github.com/sickn33/agentic-awesome-skills/tree/main/skills/godot-gdscript-patterns

Use as secondary pattern references only; reconcile with CanonSim architecture before applying.

### F. UI builder skill example

https://github.com/Courtshipfy/Godot-skills/blob/main/dot_codex/skills/godot-ui-builder/SKILL.md

Useful for practical Control-based UI construction and state completeness.

---

## 6. Agent Skills standard — for project-local skills

Canonical standard reference:
https://agentskills.io/specification

Reference implementation / examples:
https://github.com/anthropics/skills

Useful principle for CanonSim:
- keep each skill scoped to one task/domain;
- put exact trigger conditions in `description`;
- keep the main `SKILL.md` focused;
- put bulky reference material in `references/`;
- use progressive disclosure;
- version/validate skills like code.

For CanonSim, this supports project-local skills such as:

- `canonsim-redot-ui`
- `canonsim-redot-visual-ir`
- `canonsim-redot-agent-verification`
- `canonsim-redot-performance`
- `canonsim-workbench-seam-review`

These should be project-owned and take precedence over generic Godot skills whenever they constrain architecture or evidence requirements.

---

## 7. Suggested CanonSim agent routing matrix

| Task | Read first | External reference | Skill |
|---|---|---|---|
| Change UI layout | UI spec + current Redot scene/theme | Redot `Control` / `Container` / `Theme` | `godot-ui` |
| Add widget | UI spec + existing component patterns | Redot class reference | `godot-ui` |
| Write GDScript | relevant component owner | Redot GDScript reference/style guide | `godot-gdscript-patterns` |
| Debug startup/scene | integration contract + current project.godot | Redot docs + CLI/help | `godot-debugging`, `gda` |
| Headless verification | `scripts/visual_proof.py` + tests | Redot CLI/headless docs | `godot-headless-workflow`, `gda` |
| Screenshot regression | visual spec + proof script | Redot runtime/CLI docs | `godot-headless-workflow` |
| Performance change | performance contract + benchmark | Redot performance docs | `godot-performance` |
| Animation/effects | visual runtime spec | Redot 2D/animation/class docs | `godot-animation` |
| Resource/scene loading | repo seam + asset policy | Redot Resources / PackedScene docs | `godot-gdscript-patterns` |
| Input/focus | UI spec | Redot input/Control docs | `godot-ui` |
| Export/package | repo packaging contract | Redot export docs + release | `godot-project-setup`, `gda` |
| Architecture change | Workbench app + visual runtime specs | Redot docs only for feasibility | generic skills + project docs |
| World analysis / causal question | Observatory spec + owning CanonSim evidence source | no new engine API required; use measured run evidence | `canonsim-world-observatory` if installed |
| Alignment / calibration / bounded research rollout | Observatory spec + Workbench application architecture | reproduce run/arm/parameter/environment identity | `canonsim-world-observatory` |
| GDExtension | dependency-admission gate | Redot GDExtension docs / redot-cpp | no default skill; specialist review |
| Networking | application architecture first | Redot networking docs | `godot-networking` only when required |

---

## 8. Mandatory research protocol for version-sensitive questions

When a question is about an engine API, renderer, UI behavior, import rule, CLI option, export behavior, or runtime performance:

1. Identify the exact installed/pinned engine version.
2. Search Redot 26.2 docs/class reference.
3. If unclear, inspect Redot source, release notes, issue tracker, or run the installed binary with its supported CLI/help.
4. Only then compare with current Godot docs if the concept needs clarification.
5. Record project-impacting discoveries in the owning CanonSim document / decision surface.

Never cite a Godot `latest` page as proof that Redot 26.2 supports a feature.

---

## 9. Practical agent prompt fragment

Use this as a compact preamble when delegating Redot work:

> Work on CanonSim Workbench against the repository's Redot 26.2 LTS baseline. Treat CanonSim docs and existing code as the architectural authority. Use official Redot 26.2 documentation/class reference for engine/API facts. Use Godot documentation only as secondary cross-reference and re-check against Redot. Do not move canonical state into Redot SceneTree/resources/UIDs. Preserve the application/read-model/Visual Scene IR -> Redot boundary. For world questions, use the Observatory read/experiment surface rather than reading the whole repository: define scope, collect multi-seed evidence, distinguish read dependency from causality, return evidence + minimal causal slice + uncertainty + next discriminator, and never promote analytics/LLM output to canon. Prefer GDScript, code-built scenes, headless CLI verification, deterministic artifacts, and measured shared-GPU performance evidence. Do not introduce newer Redot/Godot features without an explicit version-admission proof.

---

## 10. Sources whose scope should be treated as non-authoritative

Do not use random tutorials, SEO articles, forum answers, old Stack Overflow posts, or unversioned snippets as primary API evidence.

Community material is useful for:
- alternative implementation ideas;
- troubleshooting hypotheses;
- pattern discovery;
- examples.

It is not sufficient for:
- claiming a 26.2 API exists;
- deciding project architecture;
- deciding dependency admission;
- claiming performance acceptance;
- changing CanonSim ownership boundaries.

---

## 11. Current-state notes

The Observatory document is a derived research/control-plane design. It does not prove that any Observatory runtime/tooling is already implemented. Re-read `STATUS.md` and owning code/tests before asserting implementation status.

- Redot official docs currently present **Redot 26.2** as the documentation branch.
- Redot's GitHub release list currently identifies **Redot LTS 26.2** / `redot-26.2-stable`.
- Godot's official archive currently lists **Godot 4.7.2 stable** and **Godot 4.8-dev6**; this is a separate version line.
- The strongest readily usable agent tooling found is Godot-oriented rather than Redot-specific. Treat it as an automation/pattern layer, not as evidence that every Godot feature is present in Redot 26.2.

