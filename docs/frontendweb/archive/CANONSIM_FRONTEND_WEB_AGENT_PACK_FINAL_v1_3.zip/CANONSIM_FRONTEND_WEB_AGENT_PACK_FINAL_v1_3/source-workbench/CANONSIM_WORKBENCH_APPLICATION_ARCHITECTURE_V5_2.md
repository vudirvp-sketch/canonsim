# CanonSim Workbench — Application / Runtime Architecture v5.2 (Redot)

> **Role:** full replacement for the previous Workbench architecture v5 draft. Consolidates the durable v4.2→v4.4 skeleton/design-brief contracts. It is an architecture/planning owner document, not an implementation gate. `AGENTS.md`, active `STATUS.md`, CanonSim owning specs/decisions/roadmap/tests remain higher authority.
> **Companions:** `CANONSIM_FRONTEND_UI_VISUAL_ENGINEERING_SPEC_V5_2.md` owns human factors, UX/UI, Redot, Visual Scene IR, procedural visual composition, assets and visual validation; `CANONSIM_WORLD_OBSERVATORY_AND_CONTROL_PLANE_V5_2.md` owns derived world observability, causal evidence, experiments, calibration/alignment and bounded steering design. `docs/PRESENTATION_SPEC.md` remains a separate model-facing CanonSim presentation/serialization owner.
## 0. Scope and consolidation rule

This document keeps concrete architecture load—owners, contracts, state vocabularies, identities, lifecycle, persistence, inference, external control, provenance, recovery, tests—and removes history/repetition. It does not merge CanonSim semantic authority, model-facing `PRESENTATION_SPEC`, worldbuilding, or renderer/UI details.

```text
CanonSim core        = canonical simulation semantics/events/fold/doors ; Workbench app        = operations/runtime/identity/lifecycle/persistence/inference/gateway ; Frontend companion   = UX/UI/Redot/Visual Scene IR/assets/visual validation ; PRESENTATION_SPEC    = model-facing CanonSim presentation/serialization contract
```

The two Workbench documents are peers. Redot is a presentation/runtime implementation detail, not a semantic owner. Their single shared seam is the typed application/read-side contract in §23.
## 1. Product boundary

Workbench is a first-class in-repository, local-first inference/application subsystem plus CanonSim simulation control, diagnostics, persistence and future visualisation. It is **one product/frontend**, not `Workbench.exe + Game.exe`, not a second simulator, and not a wrapper around a parallel semantic engine.
Primary surfaces: Models, Inference, Prompts, Chat, History, Diagnostics, Simulation, Settings/Appearance, Runs/Jobs, GUI, CLI/batch, persistence/recovery and inbound control. Future optional edges: TTS, STT, translation, additional inference backends.

```text
clients: GUI | CLI | local client | mobile web | agent ; ↓ ; Workbench gateway ; ↓ ; application operations ; ↓ ; domain / execution / stores ; ↙                    ↘ ; CanonSim semantic seam      backend adapter ; ↓ ; current cli/engine.py ; ↓ ; LLM backend
```

## 2. Authority hierarchy and responsibility ownership

```text
AGENTS.md / repo invariants ; → CanonSim owning specs + decisions + roadmap + tests ; → this application architecture ↕ frontend companion ; → external/research/style evidence
```

Single-owner examples:
| Concern | Owner | Must not be owned by |
|---|---|---|
| canonical world/events/fold | CanonSim | Workbench/UI |
| application operations/policy | `workbench/application` | widgets/CLI/gateway |
| stable typed concepts | `workbench/domain` | views/adapters |
| feature UX flow | `workbench/features` | domain |
| llama wire/protocol | current `cli/engine.py` under INV-4; later adapter extraction only by one-owner move | UI |
| prompt/profile/history/session/preferences stores | respective persistence owner | ViewModels |
| inbound transport/schema/auth | `api/gateway` | feature code |
| ordered stream delivery | execution/`api/streaming` edge | widgets |
| process mechanics | `platform/process` | application policy |
| backend protocol | backend adapter | domain/UI |
| visual/UI policy | frontend companion | application/domain |
| cache | local owning feature/store | global registry |
A consumer can use another owner's contract but cannot silently become its owner.
### 2.1 No God Object

Do not create one manager for window/tabs/models/inference/prompts/history/persistence/logging/CanonSim/theme/networking. A coordinator is justified only by a bounded real lifecycle or application operation. Proposed abstractions must identify one responsibility, owned state/lifecycle, concrete consumer/problem and test/falsifier; otherwise keep the responsibility local.
## 3. Canonical/semantic boundary

CanonSim remains sole owner of canonical truth:

```text
canonical event log → fold/projections → semantic products
```

Workbench must not create a second world model, canonical event log, semantic validator, brief builder, parser authority or truth store. LLM output is candidate data until it crosses the existing CanonSim/application validation seam.
State/authority classes remain distinct:

```text
CANONICAL = semantic truth ; CONFIGURATION = user-owned durable behavior ; SESSION = restorable working context ; WIDGET = ephemeral local interaction ; RUNTIME = live process/model/execution/resource state ; OBSERVATION = source/revision/freshness evidence ; HISTORY = operational indexed record ; OBSERVATORY = rebuildable analytical evidence over canonical runs ; CACHE = rebuildable acceleration ; BACKUP = explicit recovery artifact
```

Consequential evidence may carry `CANONICAL | OBSERVED | DERIVED | INFERRED | MODEL_CLAIM | HYPOTHETICAL | STALE | UNKNOWN | CONFLICT | HIDDEN | PRESENTATION`. Never infer absence from omission or silently upgrade authority.
## 4. Runtime topology, host and exposure modes

Independent axes:

```text
HOST = DESKTOP | HEADLESS_SERVER ; EXPOSURE = LOOPBACK | LAN | TUNNEL ; BACKEND = ATTACHED | MANAGED ; OBSERVE = MINIMAL | STANDARD | DEV
```

Public exposure is never implicit; LAN/remote control is opt-in and authenticated/authorized through a private/tunneled or explicitly configured boundary. GUI/CLI/mobile/agent clients all resolve to the same application operations.
### 4.1 Two network boundaries, not one

```text
OUTBOUND LLM transport: Workbench → backend; current physical owner = cli/engine.py under INV-4 ; INBOUND Workbench gateway: client → application operations; owner = api/gateway
```

Gateway owns protocol/schema/auth/session translation only; it never directly invokes backend transport, persistence internals or CanonSim internals. While INV-4 stands, `adapters/llama_cpp` may be a future typed boundary but cannot create a second physical network surface. A future transport lift is one owner-approved extraction with a mechanical one-owner test.
No generic RPC framework, event bus, plugin ABI, service locator, DI container or separate agent runtime is implied.
## 5. Package/feature shape

Design skeleton only; existence requires evidence/change locality.

```text
workbench/
├─ application/{operations,operation_identity,cancellation,composition}
├─ domain/{models,inference,prompts,conversations,execution,simulation,capabilities,assets,common_identity}
├─ adapters/llama_cpp/               # future target; current wire owner unchanged
├─ api/{contract,gateway,streaming,policy}
├─ persistence/{config,profiles,prompts,history,sessions,preferences,backups}
├─ features/{models,inference,chat,prompts,history,diagnostics,simulation,appearance,settings}
├─ platform/  integrations/  cli/
└─ presentation/                     # companion-owned UI/visual system
```

`domain` owns stable concepts; `features` owns user-facing flow/local presentation state. Physical modules earn existence through independent state/lifecycle, persistence, external protocol, tests or meaningful change locality.
## 6. Dependency direction

```text
views/ViewModels → presentation + feature-local presentation → application operations → domain contracts ; adapters/persistence/platform/integrations → implement/serve application/domain contracts
```

## 6.1 Composition Root contract

The composition root is the **single wiring owner** for the running application. It creates and connects concrete implementations at startup; it does not own business semantics, persistence rules, UI policy, retry policy or CanonSim meaning.

```text
composition root = construct → validate dependencies → wire owners → start lifecycle
not = service locator | global registry | god object | hidden dependency injector
```

Rules:
- Concrete dependency selection is visible at the composition boundary.
- Feature/domain/application code depends on contracts, not on the composition root.
- The composition root may select HOST/EXPOSURE/BACKEND/OBSERVE modes and environment paths, but may not silently alter semantic contracts.
- Tests may build smaller compositions explicitly; production composition must not be required for unit tests of domain/application contracts.
- A dependency that exists only because the composition root can create it is not automatically justified; it still requires a real consumer.

## 6.2 Feature ownership map

Every user-facing feature has one state/operation owner. Presentation may project that state but never become a competing owner.

| Feature | Owns | Calls/consumes | Must not own |
|---|---|---|---|
| Models | model discovery/selection flow and presentation state | application model operations, capabilities, diagnostics | backend wire protocol, canonical truth |
| Inference | user-facing inference configuration flow | application inference operations, effective/observed state | sampler wire quirks, transport |
| Chat | conversation interaction flow | operations, streaming events, history read models | CanonSim semantics, execution transport |
| History | query/navigation/read presentation | indexed history and execution records | canonical event log, backend state |
| Diagnostics | diagnostic presentation/filtering | structured observations | semantic truth, secrets |
| Simulation | simulation controls/read presentation | CanonSim/application seam | world rules, fold, semantic time |
| Settings/Appearance | user preferences and workspace presentation | configuration/session operations | runtime ownership, hidden defaults |
| Runs/Jobs | long-running operation presentation | execution identity/status/recovery operations | retry semantics, execution lifecycle |

A feature may own local ephemeral state only when that state has no application semantic meaning. Shared state is not created merely to avoid passing explicit data.

Forbidden direct edges: `domain → features/presentation/CLI/concrete adapter`; `features → backend process control/another feature's private state`; `presentation → llama.cpp transport/CanonSim internals/persistence internals`; `CLI → duplicate semantics`; `api/gateway → backend transport/CanonSim/persistence internals`; `streaming → canonical execution store`; `persistence → CanonSim truth`; UI → direct world mutation.
## 7. Data, configuration and state

### 7.1 Configuration

User-owned durable behavior: model/inference profiles, sampler presets, prompt profiles, theme/font/density/language/accessibility preferences, model-directory selection, backup policy.
### 7.2 Session

Restorable context: open/selected tabs, selected model, simulation pack/seed, conversation, history filters and meaningful panel/layout state.
### 7.3 Widget-local

`hover | focus | cursor | drag | temporary expansion | animation phase | pre-commit local edit | transient selection`.
### 7.4 Runtime

`backend process | loaded model | execution | stream buffer | cancellation handle | workers | admission slots`.
### 7.5 Cache

Candidates: model metadata, compatibility checks, token counts, capability discovery, history indexes, read-model fragments, render-prepared content, translation lookups. Every cache entry has identity/dependencies, validity rule and rebuild path; no global `everything` cache; cache is never the sole copy of user data.
## 7.6 Snapshot/checkpoint/artifact/cache distinction

These four terms are intentionally non-interchangeable:

```text
SESSION SNAPSHOT      = restorable Workbench working context
SIMULATION CHECKPOINT = CanonSim-defined reproducible simulation position/state reference
EXECUTION ARTIFACT    = immutable record of one Workbench operation/run and its material inputs/outcome
VISUAL CACHE          = rebuildable presentation acceleration artifact
```

Rules:
- A session snapshot MUST NOT be presented as a simulation checkpoint.
- A visual cache MUST be disposable without changing canonical or durable semantic state.
- An execution artifact closes the material inputs/identity needed to explain a run; it is not a replacement for CanonSim's canonical log.
- A simulation checkpoint is defined by CanonSim/application ownership; Workbench may reference it but must not invent checkpoint semantics.

## 8. External gateway/API contract

HTTP/SSE/WebSocket are delivery mechanisms; the semantic API is application operations.
Initial operation families:

```text
session.create/get/attach/detach ; run.start/get/cancel/stream ; chat.send ; prompt.test/prompt.compare ; execution.get/execution.replay ; model.list/inspect/load/unload ; simulation.start/step/stop ; history.query/get ; diagnostics.get/export

Analytical operation family (when implemented): `observatory.run | observatory.query | observatory.compare | observatory.profile | observatory.archaeology | observatory.calibrate`. Exact operation names remain owner-gated; these are the semantic capability families, not a mandate for a new framework.
```

Mutations use `client_request_id`/idempotency key where retry-safe mutation identity is required. Mutable sessions use expected revision. Exclusive control uses a short-lived lease token. Long-running work returns identity immediately.
Event envelope:

```text
event_id | session_id | operation_id/execution_id | sequence | event_type | observed_at | payload
```

Minimum rejection/failure distinctions: `AUTH_FAILED | AUTHZ_DENIED | DUPLICATE_REQUEST | STALE_REVISION | LEASE_EXPIRED | DOMAIN_REJECTED | RUNTIME_FAILED | SENT_OUTCOME_UNKNOWN`.
### 8.1 Tool/MCP authority

```text
model proposes tool call → parse/bound → capability check → permission/authz → application operation → result
```

A model-emitted tool name/arguments are inert data until explicitly authorized. Tool execution cannot bypass the application/semantic seam.
## 9. Identity closure

Path is location, not identity.

```text
logical_name + revision/version + strong content identity + relevant schema/metadata identity = material identity
```

Multi-file, sharded, multimodal or adapter-based assets use deterministic composite identity over all material constituents. Distinguish `logical_name`, `revision/version`, `content_digest`, `location`, `metadata`.

```text
same path + new bytes       → new content identity ; same name + new revision   → new revision identity ; same revision + new bytes  → identity mismatch; never silently reuse
```

Size/mtime/platform file identity may be a cheap scan fingerprint; it is not a correctness identity. Failed/incomplete strong hashing is explicit (`INTEGRITY_UNKNOWN` or equivalent).
## 10. Immutable execution artifact + provenance

Before side effects, freeze all materially relevant run inputs:

```text
execution_id/operation_id ; model identity + content identity ; pack/schema identity where relevant ; prompt identity + frozen material inputs ; resolved inference configuration ; backend/runtime/build/protocol identity ; capability snapshot ; serialized request identity/digest ; seed/deterministic inputs ; tool-authority state where relevant ; terminal result/status + relevant diagnostics
```

Existing engine/CanonSim provenance remains authoritative for its fields; Workbench extends/references it, not a competing duplicate schema.
Reproducibility scopes: `EXACT/BITWISE | SEMANTIC | APPROXIMATE | EXPLANATORY_ONLY`.
Separate:

```text
canonical reproducibility = same canonical inputs → same canonical replay ; request reproducibility   = same immutable request inputs → same serialized request ; inference reproducibility= request + declared model/backend/runtime conditions
```

Prompt text alone is insufficient when templates, special tokens, grammar, tokenizer/model metadata, seed or runtime configuration can differ. Replay creates a new execution identity.
### 10.1 Capability snapshot

```text
backend capability → normalized capability → product control policy → widget
```

Capability discovery never auto-generates controls. If capability data materially influences a run, the observed snapshot is immutable run provenance.
### 10.2 Observatory analytical run identity and evidence

The Observatory is a **derived research/control plane**, not another semantic authority. Workbench owns the analytical-run lifecycle and artifact identity; CanonSim remains owner of canonical simulation meaning.

Material analytical runs close provenance with:

```text
run_id + parent_run_id
+ pack/version/schema identity
+ seed + scenario/script + arm
+ parameter fingerprint
+ start/end tick
+ canonical log digest
+ environment fingerprint
+ analysis version
```

Analytical projections are rebuildable from CanonSim JSONL plus declared metadata. They may be stored in SQLite/DuckDB/Parquet/OCEL for read-side analysis, but no analytical store becomes canonical truth.

A Workbench execution/analysis artifact may carry:

```text
source identity | source revision | observation profile | claim/evidence class
| freshness where relevant | disposition | reproduction scope
```

Observatory analysis must preserve:

```text
observed ≠ intended ≠ implementation possibility ≠ warranted implementation
chronology ≠ causation
read dependency ≠ causal proof
assignment ≠ realized intervention
```

The World Question surface is a bounded application operation over derived evidence. Its outputs must return evidence, minimal causal slice, uncertainty, next discriminator, and scope rather than a naked verdict.

## 11. Application/backend/model/execution lifecycles

Keep state machines distinct:

```text
Application: STARTING → READY → DEGRADED → STOPPING → STOPPED ; Backend: ABSENT → STARTING → PROBING → READY → BUSY → STOPPING → STOPPED; ↘ FAILED ↔ RECOVERING ; Model: DISCOVERED → VALIDATED → SELECTED → LOADING → LOADED → ACTIVE; ↘ FAILED; ACTIVE → UNLOADING → EVICTED ; Execution: ADMITTED → STARTING → RUNNING → COMPLETING → COMPLETED; ↘ FAILED; ↘ CANCEL_REQUESTED → CANCELED/FAILED_TO_CANCEL/UNKNOWN
```

These are contract vocabularies, not one-class-per-state requirements. Each has one owner, legal transitions, terminal semantics and invalid-transition tests.
### 11.1 Backend process ownership

Application/runtime owns lifecycle policy; `platform/process` owns OS mechanics (spawn, termination, handles, stdio, exit observation); adapter owns backend protocol.
`ATTACHED`: observe readiness/health/exit; no implicit start/stop/restart; backend may disappear independently.
`MANAGED`: readiness/health/exit observation; bounded graceful stop; force-stop only under explicit policy/deadline.
Replacement: `prepare new → validate → ready → swap → retire old`; on failed replacement preserve known-good runtime when possible.
## 12. Operation identity, deadlines, retry and cancellation

One logical operation owns one absolute deadline on the monotonic clock. Lower layers receive remaining budget only.

```text
OperationContext = operation_id + started_monotonic + deadline_monotonic + cancellation
```

Per-attempt socket timeout is transport policy, not a new logical deadline; `tries × timeout_s` is invalid.
### 12.1 Dispatch outcome

```text
NOT_SENT             → retry may be permitted within remaining budget ; SENT_AND_TERMINAL    → return known result ; SENT_OUTCOME_UNKNOWN → no blind retry
```

Retry after `SENT_OUTCOME_UNKNOWN` requires strong backend idempotency/deduplication evidence; otherwise `UNKNOWN` is truthful terminal state.
### 12.2 Idempotency/stale control

Stable mutation identity prevents duplicate semantic effects across GUI/CLI/API retry. Idempotency does not replace semantic validation, lease or stale-revision checks.
### 12.3 Cancellation truth

Cancellation is a state transition: `CANCEL_REQUESTED → CANCELED | FAILED_TO_CANCEL | UNKNOWN`. Do not claim completion merely because a stop button was pressed. Late results are rejected by operation/execution identity and current revision; they cannot mutate newer state.
## 13. Streaming, bounded buffers and reconnect

```text
backend stream → bounded execution buffer → immutable execution record → ordered session events → clients
```

Canonical execution data is never silently dropped. Derived presentation deltas may coalesce/drop. Overflow must be bounded and observable; if complete output cannot be preserved, record partial/truncated semantics instead of pretending completeness.
Reconnect:

```text
reconnect(last_sequence) → replay retained ordered events OR RESYNC_REQUIRED + bounded current snapshot
```

Identity/order remain stable. Client disconnect does not implicitly cancel unrelated execution. SSE is the default one-way event direction; WebSocket is allowed only for a concrete bidirectional need.
## 14. Resource admission

Before mutable runtime transitions resolve relevant limits: `CPU | RAM | VRAM | context budget | active model slots | queue capacity | stream buffers | other explicit resources`.
Allowed result vocabulary: `ACCEPT | QUEUE | REJECT | EVICT | RELOAD`. Admission cannot half-apply a rejected transition or hide pressure behind infinite retries.
## 15. Persistence ownership

```text
CanonSim JSONL        = canonical truth (INV-1) ; Workbench history     = indexed operational/user data ; config/session        = user-owned durable state ; cache                 = rebuildable ; backup                = explicit recovery artifact
```

When indexed history is actually required, the first local candidate is stdlib `sqlite3`; do not invent a universal ORM/repository abstraction before a second backend/concurrency case exists.
Each durable store declares: `schema identity/version | logical writer | transaction boundary | atomic commit rule | recovery role | future-version behavior | backup/restore scope`.
### 15.1 Save/backup

```text
edited state → serialize → temporary artifact → flush/close → atomic replace → optional backup rotation
```

Distinguish `manual save | autosave | atomic write | backup | restore | export`. Backup policy may use `enabled | max_count | max_age | before_migration | before_destructive_change`.
Failures: cache failure → rebuild; backup failure → visible diagnostic; config corruption → preserve evidence + explicit recovery; CanonSim log failures follow CanonSim law.
### 15.2 Stale-writer protection

```text
loaded revision → edit → atomic compare-and-swap commit → COMMITTED | STALE_WRITER
```

Compare+write MUST be one atomic store operation (CAS-equivalent). Separate read/compare/write is insufficient. Conflict disposition: `RELOAD | MERGE | REJECT`. No speculative MVCC/CRDT layer.
### 15.3 Schema evolution

Each store owns bounded migrations. Unsupported future versions are not silently downgraded/emptied/defaulted. Migration failure preserves the original artifact and emits a diagnostic.
### 15.4 Cross-store crash recovery

Stores are not one distributed transaction. Recovery roles:

```text
AUTHORITATIVE → never invent source data ; REBUILDABLE   → regenerate from authoritative data ; RECONCILABLE  → temporary inconsistency has deterministic repair
```

Crash between related commits is reconciled using durable identity/revision evidence. ViewModels never perform recovery.
## 16. Runtime/data-directory contract

Production paths are explicit and `.git`/CWD independent:

```text
application/runtime | user configuration | user data/history ; models/assets       | cache | backups | logs/diagnostics
```

Define startup/recovery outcomes for missing, read-only, permission-denied, corrupt, partially migrated and externally removed paths. Upgrade/migration must cover missing runtime/backend executable, native-library mismatch, model-directory failure, schema incompatibility and failed recovery.
## 17. Clock contract

```text
CanonSim semantic time → simulation meaning/determinism ; monotonic clock        → deadline/timeout/retry/duration ; UTC/wall observation   → display/persistence timestamps where needed ; UI animation time      → visual only
```

No wall clock may enter CanonSim deterministic state, canonical replay or request identity.
## 18. Prompt ownership and reproducibility

Prompt roles may include `system | user/chat | narrator | summarizer | parser/structured-output | CanonSim-specific`. Sources may be `built-in | profile | session override | call-local override` where the semantic owner permits them.
Editable prompt UI is not permission to alter semantics owned by `BRIEF_SPEC`, `PARSER_SPEC`, `PRESENTATION_SPEC` or another owner. Material prompt inputs are frozen per execution; a mutable profile name alone is insufficient for reproducibility.
## 18.1 Simulation Pack identity and compatibility contract

A Simulation Pack is a content/provenance input, not merely a filesystem folder. Its identity is explicit:

```text
logical_pack_id + pack_revision + schema_identity + content_identity + compatibility + location
```

Execution provenance that consumes a pack records at minimum:

```text
pack_identity + pack_schema_identity + seed + source_revision where material
```

Rules:
- `logical_pack_id` identifies the logical pack; `pack_revision` identifies the intended revision; `content_identity` closes the actual material content.
- A path alone is never pack identity.
- Schema incompatibility is a validation result, not a missing-file condition.
- The application may discover/validate/select a pack; CanonSim remains owner of pack semantics and simulation meaning.
- Re-running with the same visible pack name but different content must not masquerade as the same reproducibility input.

## 19. Inference and sampler policy

Backend-specific flags, server defaults and wire quirks stay in the adapter. Generic Workbench types remain backend-neutral.
The UI/config contract is:

```text
REQUESTED → VALIDATED/ACCEPTED → EFFECTIVE → OBSERVED → PRESENTED
```

The 2026-09-23 llama.cpp research surface included temperature, top-k, top-p, min-p, top-n-sigma, typical-p, XTC, DRY, repetition/presence/frequency penalties, dynamic temperature, adaptive-p, Mirostat and sampler ordering/sequence. These are build-sensitive freshness evidence, not a frozen list; re-verify the pinned build before implementation.
Sampler policy belongs to the frontend for presentation but is architecturally constrained here: Basic/Advanced/Expert are disclosure layers, not semantic classes. Preset data requires `id | name | backend compatibility | parameter values | optional sampler order | description | schema/version` and must not silently modify out-of-scope settings.

### 19.1 Inference profile composition and effective-state closure

A named profile is a source of requested values, not proof of runtime state. Composition is explicit:

```text
BASE PROFILE → SESSION OVERRIDE → CALL-LOCAL OVERRIDE → VALIDATION/CLAMP → BACKEND RESOLUTION → OBSERVATION
```

Persist/diagnose these as separate layers where material:

```text
REQUESTED = what the caller asked for
ACCEPTED  = what the application contract accepted
EFFECTIVE = resolved values actually intended for backend execution
OBSERVED  = values/state actually observed from backend/runtime
PRESENTED = what the UI currently shows
```

A UI control MUST NOT overwrite `EFFECTIVE` merely because its widget value differs. Backend defaults, clamps, unsupported parameters and sampler ordering must remain observable when they materially change behaviour.
## 20. Model discovery and loading

```text
discover → inspect → select → resolve configuration → validate compatibility/capabilities ; → prepare backend → load → observe ready → expose active model
```

`file exists ≠ valid ≠ selected ≠ loading ≠ loaded ≠ active`.
For large assets, cheap size/mtime/platform-fingerprint scans may screen routine refresh; strong identity is computed when needed. Build-specific llama.cpp router/`/props`/`/slots`/model-replacement findings remain research evidence and must be re-verified.
## 21. History and diagnostics

Storage/read surface are separate:

```text
persistent history → bounded query/page → read model → frontend mapping → virtualized renderer
```

Never instantiate every historical message as a permanently live UI node. Selected records may fetch detail on demand. History rows and executions link via immutable IDs.
Diagnostics explain what was attempted, what happened and why. A structured diagnostic envelope should carry, where relevant: `observation time | source/component | operation/execution ID | severity | code/category | human message | structured context | redaction status | related resource identity`.
Observation profiles:

```text
MINIMAL = operational evidence ; STANDARD = normal diagnostics ; DEV = explicitly enabled deep bounded evidence
```

DEV may retain bounded raw prompt/response/backend evidence for calibration when permitted; credentials, tokens, secrets and secret-bearing headers never enter ordinary diagnostics. Raw evidence needs explicit size/lifetime/redaction/export policy.
## 22. CLI/batch parity

CLI/batch is a delivery surface over application operations. Console output should be bounded, stable enough for operators/automation, machine-readable where required, secret-free and explicit about terminal state. A `.bat`/launcher may select runtime paths but must not embed a second backend client or semantics implementation.
## 23. Shared seam with frontend companion
## 23.1 Redot runtime contract

The frontend companion uses **Redot 26.2 LTS** as the pinned presentation/runtime baseline. The application architecture does not depend on Redot internals and does not expose Redot types as application/domain contracts.

```text
repo project root = workbench/presentation/redot/
engine baseline   = Redot 26.2 LTS / redot-26.2-stable
project language  = GDScript unless a real consumer justifies another language
renderer baseline = Compatibility for the first measured 2D/2.5D slice
CLI automation    = Redot executable + --path / --headless workflows
engine binary     = outside the CanonSim Git tree
```

The repository commits the Redot **project**, not the Redot editor binary. Engine-specific APIs remain behind presentation adapters. No application/domain module may import Redot classes, resource paths, SceneTree objects or engine lifecycle objects.

Redot 26.3 and other non-LTS builds are research/compatibility targets only until separately admitted by evidence. Stable LTS is the production baseline.


```text
application operation / ordered event ; ↓ ; typed semantic read model ; ↓ ; ViewModel mapping (only when presentation derivation/state is real) ; ↓ ; UI state and/or Visual Scene IR ; ↓ ; Redot controls/sprites/compositor
```

**Application owner:** operations, domain semantics, identity, lifecycle, inference, persistence, recovery, gateway/authz, backend boundaries. **Frontend owner:** UX/human factors, navigation, UI tokens/components, accessibility, Redot, ViewModels, Visual Scene IR, camera/composition/assets/LOD/cache/effects, screenshots/regression/usability validation.
The frontend may derive presentation data but cannot mutate application semantics directly. There is no generic “presentation super-layer”.
## 24. CanonSim vertical seam

The first serious simulation slice must prove:

```text
Workbench intent → shared CanonSim application/semantic seam ; → existing parser/action/door/validation path where applicable ; → canonical event path → existing consequence/read-side projection ; → typed Workbench read model → frontend surface
```

Do not duplicate CanonSim pack parsing, canonical validation, folding, world truth or semantic time. Future visualisation consumes semantic products plus explicit observation scopes.
## 25. Shutdown/process-loss contract

```text
STOPPING → stop new work → signal owned runtimes → bounded graceful period ; → force-stop only under explicit policy/deadline → observe actual outcome ; → flush required state → STOPPED or FAILED_SHUTDOWN
```

ATTACHED backends are not silently terminated by Workbench shutdown. Backend loss during execution yields truthful terminal/unknown state and preserves evidence.
## 26. Boundedness/performance contract

“Bounded” requires an explicit ceiling and degradation policy. Before production acceptance define ceilings for: cold/warm startup, model discovery, history first-page/pagination, pending operations per class, stream buffer/update cadence, diagnostics export size/duration, graceful/forced shutdown, in-memory history materialisation and runtime resource usage. Detailed frontend CPU/GPU/VRAM budgets belong to the companion.
## 27. Dependency admission

```text
real consumer → demonstrated problem/risk → smallest typed seam ; → licence/runtime envelope → mechanical verification
```

No dependency for future-proofing. Runtime dependencies and offline content-generation tooling remain separate. No generic plugin/DI/workflow/persistence/RPC/event framework without a concrete consumer.
## 28. Research and decision discipline

For material forks:

```text
problem → current mechanism → alternatives → strengths/weaknesses ; → real consumer → falsifiable discriminating test → realized result → disposition
```

Claim status: `FACT | INFERENCE | HYPOTHESIS | PROPOSAL | UNKNOWN`.
Disposition: `CONFIRMED | PARTIALLY_CONFIRMED | REJECTED | UNRESOLVED | DEFERRED`.
Do not promote build-sensitive backend observations into generic law.
## 29. Adapter contract tests

Every backend/platform adapter crossing an application boundary requires executable contract tests for the behaviour the application relies on:

```text
capability discovery/normalisation
request serialization and identity propagation
backend defaults/clamps/unsupported fields
error and timeout mapping
cancellation propagation and truthful terminality
stream ordering / terminal event semantics
reconnect/resync behaviour where supported
model lifecycle and replacement
backend disconnect/crash
SENT_OUTCOME_UNKNOWN handling
secret/redaction boundaries
```

Adapter tests are not implementation snapshots. They prove the typed application contract against the concrete backend and prevent wire quirks from leaking upward.

## 29. Required failure matrix

| Failure | Required observation | Default disposition |
|---|---|---|
| backend unavailable | `FAILED/UNAVAILABLE` | bounded retry if allowed |
| startup timeout | `FAILED/STARTUP_TIMEOUT` | terminal; no hidden loop |
| malformed response | `FAILED/MALFORMED` | fail; retry only with evidence |
| protocol failure | `FAILED/PROTOCOL` | contract-defined retry |
| stream disconnect | `UNKNOWN` or confirmed terminal | bounded reconnect if safe |
| cancellation race | truthful terminal state | never fabricate canceled |
| late result | stale/discarded | diagnostics only |
| same-path replacement | identity mismatch | refresh/reject |
| stale writer | explicit conflict | reload/merge/reject |
| interrupted write | prior valid/recovery artifact | never silently empty |
| future schema | `UNSUPPORTED_VERSION` | preserve original |
| backup exhaustion | visible failure | no false durability claim |
| backend crash during run | terminal/unknown | preserve evidence |
| shutdown deadline | forced stop/failed shutdown | record actual outcome |
A boundary is recovery-ready only when relevant rows have executable tests.
## 30. Verification before abstraction promotion

Minimum durable v4.3/v4.4 proof set:

```text
□ fixed operation deadline across retries
□ ambiguous post-dispatch result becomes UNKNOWN unless safe idempotency is proven
□ NOT_SENT retry consumes remaining deadline only
□ ATTACHED is not silently terminated/restarted
□ MANAGED replacement is prepare/validate/swap/retire
□ atomic stale-writer CAS prevents overwrite
□ immutable execution artifact closes material run inputs
□ composite identity changes when material shard/part changes
□ canonical stream data never silently drops
□ resource admission cannot half-apply rejection
□ crash between stores follows declared recovery roles
□ tool call is inert without capability/permission
□ duplicate mutation with same identity does not duplicate effect
□ stale revision/expired lease cannot mutate newer state
□ reconnect continues order or emits RESYNC_REQUIRED
□ client disconnect does not cancel unrelated work
□ DEV observation never serializes credentials/secrets
□ non-loopback exposure cannot start without auth/authz
□ GUI/CLI/API share operation semantics
□ no second outbound LLM transport owner exists under INV-4
□ composition root is the only startup wiring owner and is not a service locator
□ feature ownership map has one owner per consequential state/operation
□ session snapshot, simulation checkpoint, execution artifact and visual cache remain distinct
□ simulation pack identity includes logical id/revision/schema/content identity
□ inference profile composition and requested/effective/observed closure are testable
□ adapter contract tests cover serialization, capabilities, errors, cancellation, streams and UNKNOWN
□ architecture tests catch forbidden dependency/import edges
```

## 31. Agent-friendly change locality

For any feature an agent should quickly locate: `application operation | state owner | persistence owner | feature/view | adapter/integration edge | owning tests`.
For every material boundary the contract should expose: `OWNER | INPUT | IDENTITY | CONTRACT | BOUNDS | AUTHORITY | PROGRESS/TERMINALITY | OBSERVATION | FAILURE/RECOVERY | IDEMPOTENCY/REVISION/LEASE | CLIENT/TRANSPORT | TEST`.
`ViewModel` is optional; add it only for real presentation-specific derivation/local state. Prefer obvious names over framework magic.
## 32. Implementation order (dependency logic, not backlog)

```text
1 identity + execution artifact + runtime/data directories + clock + dependency envelope ; 2 lifecycle + ATTACHED/MANAGED + deadline/retry/ambiguity + resource admission ; 3 persistence CAS + recovery roles + migrations + fault tests ; 4 preserve one outbound LLM owner + establish one inbound Workbench gateway ; 5 minimal application operations + typed API contract ; 6 live events + reconnect/resync + idempotency/revision/lease tests ; 7 capability-aware inference/configuration + model identity/loading ; 8 persistence foundations + provenance closure ; 9 thin Observatory substrate + run manifests + bounded World Question seam ; 10 frontend theme/primitives + Chat/Models/Inference ; 11 Diagnostics/History + CLI parity + reproducibility inspection ; 12 CanonSim seam + placeholder world ; 13 Visual Scene IR + deterministic visual proof ; 14 reusable asset vocabulary + maps/inventory/journal/etc. ; 15 visual/LLM concurrency optimization ; 16 optional TTS/STT/translation/backends
```

This does not supersede owner gates or current repository order.
## 33. Non-negotiable checklist

```text
[ ] one responsibility owner; no God Object
[ ] CanonSim sole canonical authority
[ ] one outbound LLM transport owner while INV-4 stands
[ ] one inbound gateway over application operations
[ ] GUI/CLI/API/mobile/agent share operation semantics
[ ] strong + composite content identity
[ ] immutable execution artifact and capability snapshot when material
[ ] explicit application/backend/model/execution lifecycles
[ ] ATTACHED/MANAGED ownership explicit
[ ] monotonic single operation deadline; retry cannot extend it
[ ] UNKNOWN after ambiguous dispatch unless safe deduplication is proven
[ ] truthful cancellation; safe late-result rejection
[ ] bounded streaming; ordered reconnect/resync; no canonical data loss
[ ] explicit resource admission
[ ] atomic stale-writer CAS
[ ] store schema/migration/recovery/backup contracts
[ ] cross-store recovery roles
[ ] runtime/data paths `.git`/CWD independent
[ ] clock domains separated
[ ] secrets excluded from ordinary diagnostics; DEV raw evidence bounded/redacted
[ ] remote exposure explicit/authenticated/authorized
[ ] tool calls inert until capability/permission
[ ] prompts remain under their semantic owner
[ ] requested/effective/observed distinction preserved
[ ] configuration/session/widget/runtime/cache remain distinct
[ ] history/read surfaces bounded
[ ] no speculative generic framework layers
[ ] relevant failure/architecture tests executable
[ ] feature change locality remains agent-understandable
[ ] Observatory artifacts are derived/rebuildable and cannot mutate canonical semantics
[ ] analytical runs close run/pack/seed/arm/parameter/environment provenance
[ ] World Question outputs expose evidence, scope, uncertainty and next discriminator
```

## 34. Final architecture

```text
                         CANONSIM
                 canonical events / fold
                           │
                  semantic/application seam
                           │
                  WORKBENCH APPLICATION
                           │
        ┌──────────────────┼───────────────────┐
        │                  │                   │
    operations         persistence          adapters
        │                  │                   │
    gateway/CLI       history/session      LLM backend
    API clients       profiles/backups          │
        └──────────────────┼───────────────────┘
                           │
                    typed read models
                           │
                FRONTEND / VISUAL COMPANION
                           │
                    ViewModel / Scene IR
                           │
                         REDOT
```

> **CanonSim decides canonical meaning/world change; Workbench application decides safe operations, lifecycle, persistence, inference and external control; the frontend companion decides how those results become understandable and visual; Redot presents them without becoming a second simulator.**
## Appendix A — Source coverage map

```text
v4.2 identity/lifecycle/single-transport/persistence/security/dependency → §§2,4–10,11–18,27,33 ; v4.3 deadline/UNKNOWN/CAS/execution-artifact/recovery/stream/resource/tool → §§10–17,29–30,33 ; v4.4 gateway/live-session/idempotency/revision/lease/host/exposure/observation → §§4,8,13,21,25,30,33 ; llama freshness/capability/sampler/model lifecycle → §§10,19,20 ; prompt ownership/reproducibility → §§10,18 ; CanonSim consumption/vertical proof → §§3,24 ; agent/research/change locality → §§28,31,32 ; v5.2 closure additions → §6.1–6.2, §7.6, §18.1, §19.1, §29
```

*This file is the full replacement for the previous v5.1 Workbench application architecture.*
