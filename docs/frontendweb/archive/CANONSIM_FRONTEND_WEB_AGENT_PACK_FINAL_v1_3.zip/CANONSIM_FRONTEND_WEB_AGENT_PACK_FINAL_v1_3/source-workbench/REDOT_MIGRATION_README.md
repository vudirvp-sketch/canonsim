# CanonSim Workbench v5.2 — Redot migration package

This package replaces the v5.1 Workbench documents with a Redot-first runtime contract.

## Runtime decision

- Primary frontend/runtime: **Redot 26.2 LTS** (`redot-26.2-stable`).
- Initial renderer baseline: **Compatibility** for the first measured 2D/2.5D slice.
- Project root in repository: `workbench/presentation/redot/`.
- Redot executable and export-template bundle: external toolchain, not committed into the CanonSim repository.
- Default scripting language: GDScript. C#/.NET is not admitted unless a real product requirement creates a separate consumer.
- Redot 26.3+ is not the production baseline; newer features require explicit version admission.

## Files

```text
CANONSIM_WORKBENCH_APPLICATION_ARCHITECTURE_V5_2.md
CANONSIM_FRONTEND_UI_VISUAL_ENGINEERING_SPEC_V5_2.md
CANONSIM_VISUAL_PRESENTATION_RUNTIME_ARCHITECTURE_V5_2.md
REDOT_INTEGRATION_AND_REPO_LAYOUT_V1.md
CANONSIM_WORLD_OBSERVATORY_AND_CONTROL_PLANE_V5_2.md
```

## Architectural invariant

```text
CanonSim semantics/events/fold
        ↓
Workbench application operations + typed read models
        ↓
Visual Scene IR / ViewModels
        ↓
Redot presentation runtime
```

Redot may own presentation-local state (camera, selection, animation playback, focus, transient effects, caches). It may not own canonical world state, canonical event history, semantic time, canonical identity, simulation rules, backend truth or persistence authority.

## Migration principle

The old Godot-first wording is removed from the active runtime contract. References that remain to the upstream lineage are not runtime dependencies and do not authorize direct coupling. Visual Scene IR stays renderer-neutral so the project remains migratable without changing CanonSim semantics.

The World Observatory is a derived research/control plane over CanonSim runs. It may project, compare, explain, calibrate and propose bounded interventions, but it does not create canonical truth, a second world store, or a second semantic authority.

## Installation model

1. Install/download **Redot 26.2 LTS** for the development platform.
2. Keep the Redot executable in a stable external tools directory.
3. Open/create the project directly at `<repo>/workbench/presentation/redot/`.
4. Use the Compatibility renderer for the initial vertical slice.
5. Keep generated `.godot/` cache out of Git.
6. Commit the Redot project files, scenes, scripts, themes, source assets and export configuration.

The exact executable filename is intentionally not hardcoded in the architecture; repository launch scripts should resolve it through one configurable toolchain path.

## Official references

- Redot 26.2 LTS: https://github.com/Redot-Engine/redot-engine/releases/tag/redot-26.2-stable
- Redot documentation: https://docs.redotengine.org/
