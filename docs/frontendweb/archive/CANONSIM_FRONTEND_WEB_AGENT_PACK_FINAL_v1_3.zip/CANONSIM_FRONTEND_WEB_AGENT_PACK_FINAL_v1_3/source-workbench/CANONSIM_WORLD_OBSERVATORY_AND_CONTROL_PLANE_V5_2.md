# CanonSim — World Observatory & Control Plane v5.2 (Integrated)

> **Role:** derived observability, longitudinal analysis, causal experimentation, calibration, alignment, and bounded steering for CanonSim/Workbench.
>
> **Status:** `PROPOSAL / RESEARCH ARCHITECTURE / OPERATIONAL ANALYTICS`. This document does **not** override `AGENTS.md`, `STATUS.md`, `docs/TASKS.md`, `docs/TEST_PLAN.md`, owning `*_SPEC.md`, `worldbuild/*`, or explicit owner-gated decisions.
>
> **Source lineage:** distilled from `CANONSIM_WORLD_OBSERVATORY_ULTIMATE(3).md` supplied for this integration; source SHA-256 `580735d97bffb98196ac4c90562782fc46e69bd46f6dc4598705c20a346867fa`. Historical findings below are evidence snapshots, not current-state truth.

## 0. Operating law

The system has one semantic authority:

```text
CANON generates truth
→ OBSERVATORY explains/queries truth
→ EXPERIMENTS test claims
→ CALIBRATION searches bounded parameter space
→ STEERING only proposes/selects lawful bounded interventions
→ LLM interprets/renders evidence; it never authors canon
```

Authority order for Observatory work:

```text
AGENTS.md / repository law
→ STATUS.md / active state
→ owning specs / runtime contracts
→ CanonSim / worldbuild semantics
→ this document / Observatory and research control-plane design
→ derived analytical artifacts
→ agent / LLM interpretation
```

Never create:

```text
second semantic authority
second canonical event store
second world model
hand-maintained causal database
analytics that can mutate canon
optimizer output promoted to canon
LLM output promoted to canon
```

Use explicit evidence classes:

```text
FACT | INFERENCE | HYPOTHESIS | PROPOSAL | UNKNOWN
CONFIRMED | PARTIALLY_CONFIRMED | REJECTED | UNRESOLVED | DEFERRED
```

Preserve these distinctions:

```text
observed behavior ≠ intended behavior ≠ possible implementation ≠ warranted implementation
chronology ≠ dependency ≠ influence ≠ causation
world truth ≠ actor knowledge ≠ belief ≠ interpretation ≠ intent ≠ resolution ≠ consequence ≠ narration
permission ≠ capability ≠ intent ≠ resolution ≠ consequence ≠ learning
assignment ≠ realized intervention
```

Agent laws:

```text
Do not infer a world law from one seed.
Do not infer causality from event adjacency.
Do not infer coverage from a fixed script.
Do not infer semantic outcomes from cosmetic hashes.
Do not widen claim scope beyond evidence scope.
Do not add runtime machinery when a derived projection answers the question.
Do not let analytics become authoritative.
Do not call a read dependency causal without intervention evidence.
Do not treat a research rollout as a real run.
Do not promote a regime label into canonical state.
```

Core doctrine:

> **Do not make the world cognitively small. Make its consequential structure queryable.**

A strong long-horizon witness is a durable loop:

```text
PAST EVENT
→ STATE / RELATION / OBJECT / KNOWLEDGE / RESOURCE / INSTITUTIONAL RESIDUE
→ CONSUMER
→ DECISION / EVENT
→ NEW RESIDUE
→ LATER CONSUMER
→ CHANGED FUTURE OPTION
```

Not every event needs every link. Claims about durable world behavior do.

---

## 1. Plane separation and Workbench ownership

Use five logical planes plus presentation:

```text
CANONICAL PLANE     creates truth; append-only events; fold/replay; canonical state
OBSERVATION PLANE   regenerable projections and queries over runs/logs
EXPERIMENT PLANE    controlled comparisons, ablations, mutations, counterfactuals
CALIBRATION PLANE   offline bounded parameter search and held-out checks
CONTROL PLANE       lawful bounded intervention selection only
PRESENTATION PLANE  human/agent/LLM rendering of evidence
```

The Workbench application owns:

```text
operation identity
analytical-run lifecycle
analysis job admission/bounds
query dispatch
artifact identity/provenance
result retention/recovery policy
```

CanonSim remains owner of:

```text
canonical events
fold/replay
semantic time
RNG
world truth
pack/world meaning
canonical validation
```

The frontend/Redot layer owns:

```text
observation-profile selection
query/result presentation
assurance/debug views
visualisation of derived analytical data
camera/UI/presentation state
```

Derived analytical stores are allowed only when they are:

```text
read-only
rebuildable
attributable
scoped
versioned
deletable
```

Canonical JSONL remains sufficient to reconstruct analytical projections.

---

## 2. Run identity and analytical evidence

Every analytical run must be attributable. Minimal manifest:

```text
run_id
parent_run_id
pack
pack_version
schema_version
seed
scenario / script
arm
parameter_fingerprint
start_tick
end_tick
canonical_log_digest
environment_fingerprint
analysis_version
```

For byte-sensitive work also retain, as material:

```text
Python version
PYTHONHASHSEED
pack/version
schema version
seed
scenario/script
arm
parameter fingerprint
environment fingerprint
```

Never claim cross-version byte identity unless the contract explicitly establishes it.

Minimal rebuildable derived model:

```text
run
event_fact
state_delta
knowledge_fact
event_object
relation_delta
object_lifecycle
decision_trace
dependency_edge
world_profile
experiment
outcome
```

Typical field semantics:

```text
event_fact:
  event_id, tick, type, actor, target, cause_id, cause_kind, outcome

state_delta:
  event_id, tick, entity, property, from, to, irreversible

knowledge_fact:
  event_id, tick, actor/subject, knowledge_item, effect

event_object:
  event_id, object_id, object_type, role

dependency_edge:
  derived evidence only; never causal authority

outcome:
  semantic predicate, first-passage time, persistence, scope, disposition
```

Storage ladder:

```text
JSONL      canonical truth
SQLite     rebuildable local projection
FTS/vec    derived retrieval only
DuckDB     offline analysis
Parquet    columnar population/archive
OCEL 2.0   optional analytical interchange
```

Never move DuckDB/Parquet/OCEL into runtime merely because they are useful offline.

Canonical runtime constraints remain explicit:

```text
INV-1  state changes only through canonical events; state = fold(log)
INV-2  canonical time/order/RNG/execution are deterministic under contract
INV-3  content/settings remain separate from engine code
INV-4  LLM/network remain outside canonical core behind explicit adapter
INV-5  committed log is immutable; correction is another event
```

Runtime pipeline:

```text
seed → scheduler → intent → capability / permission / knowledge gates
→ resolver → canonical event → fold → canonical state
```

For byte-sensitive analysis retain Python version, `PYTHONHASHSEED`, pack/version, schema version, seed, scenario/script, arm, parameter fingerprint and environment fingerprint. `requires-python >=3.11` alone is not a cross-version golden-byte contract. Guard ambient entropy/time/network escape surfaces: secrets, `os.urandom`, UUID randomness, wall-clock APIs, undeclared filesystem reads, and network imports outside the explicit adapter.

Reuse existing analytical infrastructure before adding machinery: `balance_harness.py`, `profile_harness.py`, `worldgen_profile.py`, `chronicle.py`, `checkpoint.py`, paired-delta/common-random-number runs and block-scoped ablations. The seven-hole UAP vocabulary is only a test-design lens, never a second ontology.

Analytical output must declare at least:

```text
source identity
scope
analysis version
observation profile
claim/evidence class
freshness or source revision where relevant
disposition
```

---

## 3. Semantic coverage: declaration → consequence

Use one canonical coverage path:

```text
DECLARED
→ REACHABLE
→ REALIZED
→ CANONICAL EFFECT
→ DOWNSTREAM CONSUMER
→ FUTURE DIVERGENCE
→ OBSERVER CONSEQUENCE
→ PLAYER / READER CONSEQUENCE
→ HELD-OUT TRANSFER
```

Coverage codes:

```text
D  declaration
R  reachable
S  realized
E  canonical effect
C  downstream consumer
A  integrated multi-mechanism witness
F  future divergence
O  observer/knowledge consequence
P  player/reader consequence
T  held-out transfer
U  unresolved measurement / independence / scope
—  not materially present / N/A
```

“Integrated” is not proved by:

```text
action in JSON
unit test import
callable resolver
event type existence
metric movement
cause-depth increase
chronicle prose
```

Required action-to-consequence census:

```text
pack
action_id
resolver
static_reachability
valid_examples
invalid_examples
attempts
realizations
canonical_event_types
state/relation/resource/object writes
actor/group/institution effects
knowledge effects
consumer_count
future_divergence_count
observer/surface evidence
held_out evidence
mutation_detection
coverage_state
failure_class
```

Failure classes:

```text
DECLARED_BUT_UNREACHABLE
REACHABLE_BUT_UNREALIZED
REALIZED_BUT_NO_EVENT
EVENT_BUT_NO_STATE
STATE_BUT_NO_CONSUMER
CONSUMER_BUT_NO_FUTURE_DIVERGENCE
HIDDEN_ONLY_CONSEQUENCE
SURFACE_OMISSION
MUTATION_ESCAPE
HELD_OUT_FAILURE
```

Deep reachability is precondition-aware:

```text
TARGET EVENT/STATE
↑ required predicates
↑ actions satisfying predicates
↑ their preconditions
↑ actions satisfying those preconditions
...
→ backward candidate set
→ forward exact simulation
→ canonical verification
```

Random exploration is a baseline, not the final deep-search method. Prefer `first_failing` diagnostics where the owning code exposes them.

---

## 4. World projections: temporal, relational, object-centric, decision

### 4.1 Temporal relation projection

The world graph is a derived projection, not canonical state.

Node classes may include:

```text
PERSON / NPC
GROUP
INSTITUTION
LOCATION
OBJECT
RESOURCE
EVENT
KNOWLEDGE ITEM
```

Edges may include:

```text
trust, fear, suspicion, reputation, kin
authority, ownership, co-presence, membership
employment, obligation, knowledge, belief-about
debt, object-carrier, object-location
institutional dependency
```

Every derived edge is temporal:

```text
source → target
axis
start/end or activation interval
value/delta
source event
persistence / decay / expiry
```

Required questions:

```text
Who became connected or isolated?
Which actors bridge groups?
Which relations persist, reverse, or decay?
Which relationships survive major events?
Which objects create social connectivity?
Which institutional links become load-bearing?
```

Canonical scalar relation state remains canonical; the projection explains its trajectory.

### 4.2 Relation lifecycle

```text
initial relation
→ interaction/event
→ delta
→ consumer
→ persistence / decay
→ later interaction
→ later behavior / option change
```

Minimum relation ledger:

```text
reader
subject
axis
event_id
tick
delta
source
decay/expiry
```

Useful derived measures:

```text
trajectory
interaction_count
delta_mass
reversal_count
persistence
re-encounter
consumer_count
future-option_effects
```

Re-encounter proof:

```text
interaction A
→ persistent relation/knowledge residue
→ time / separation
→ re-encounter
→ behavior difference
```

### 4.3 Object lifecycle

Actor-only traces are insufficient. Important objects may carry durable causal structure:

```text
creation
→ ownership
→ storage/location
→ carrier transfer
→ use
→ damage/condition
→ theft/loss
→ institutional recognition
→ destruction/disappearance
→ residue/replacement function
```

Material persistence is strong when:

```text
event
→ material residue
→ later mechanism consumes residue
→ later outcome changes
```

A renderer mentioning a destroyed object is not proof of material persistence.

### 4.4 Decision/read trace

Use shadow/public derivation where possible:

```text
actor
intent
state_reads
knowledge_reads
relation_reads
resource_reads
object_reads
world_reads
predicate_results
candidate_set
selected_branch
writes
```

A read dependency means only:

```text
R consumed W
```

It does not mean:

```text
W caused R
```

A runtime-adjacent read-set sidecar is `PROPOSAL` only when shadow derivation cannot answer a material question. Any sidecar must satisfy:

```text
same inputs + sidecar OFF
vs
same inputs + sidecar ON
→ byte-identical canonical output
```

Dependency types must stay explicit:

```text
chronological lineage
read dependency
branch influence
state effect
downstream divergence
persistent causal dependency
```

---

## 5. Causal archaeology, residue, influence

Causal evidence ladder:

```text
READ DEPENDENCY
→ BRANCH INFLUENCE
→ STATE EFFECT
→ DOWNSTREAM DIVERGENCE
→ PERSISTENT CAUSAL DEPENDENCY
```

Definitions:

```text
READ DEPENDENCY      R consumed W
BRANCH INFLUENCE     perturbing W can alter R's predicate/branch
STATE EFFECT         canonical write changed state
DOWNSTREAM DIVERGENCE BASE and PERTURBED futures diverge
PERSISTENT DEP.      changed result remains functionally consequential
```

Claim strength is bounded by the weakest material condition among:

```text
intervention isolation
realized-intervention fidelity
measurement validity
replication
scope/transfer coverage
confound control
spillover control
```

Apparently independent evidence is one family when it shares:

```text
evidence root / assumptions / metric / observation boundary /
implementation / script or seed selection / failure mode
```

### 5.1 Causal slice

For a failure/outcome:

```text
observed state
→ first divergence
→ influence region
→ sufficient blocker set
→ responsible owner boundary
→ minimized counterexample
```

Use transient diagnostics:

```text
CausalSlice
FailureCore
BoundaryBlame
CounterexampleCapsule
```

### 5.2 Causal archaeology

For an unexplained present condition:

```text
CURRENT CONDITION
→ immediate consumers
→ predecessor residue
→ event/state/relation/object history
→ earliest verified material difference
→ first downstream consequence
→ current surviving effect
```

This converts “why is this true now?” into a bounded historical query.

### 5.3 Residue classes

Track separately:

```text
state residue
relation residue
knowledge residue
material/object residue
resource/economic residue
institutional residue
spatial/topological residue
obligation/commitment residue
```

Residue state:

```text
DEAD          no downstream consumer in examined scope
LIVE          consumed by a later mechanism
REACTIVATABLE dormant until a lawful future condition
```

Long-run claims strengthen when residue survives time/separation and changes a later legal option, decision, or event.

### 5.4 Influence footprint

For a seed event/intervention:

```text
affected entities
affected properties
affected relation axes
affected objects/resources
affected institutions
first divergence tick
downstream branch extent
persistence horizon
option loss/gain
observer/surface consequences
```

Influence footprint is evidence, not causality by itself.

---

## 6. Ensembles, World Profile, regimes, micro→meso→macro

One seed is one witness:

```text
N seeds = empirical distribution
```

Every ensemble report should include:

```text
N
seed scope
pack/version
scenario/script
arm
parameter fingerprint
semantic outcome predicate
uncertainty interval when applicable
example seeds / counterexamples
```

Prefer semantic outcomes over raw state hashes:

```text
P(outcome)
P(failure)
P(irreversible_event)
P(institutional_escalation)
P(relationship_reversal)
P(future_divergence)
P(persistent_residue)
time-to-event
persistence
```

Matched-prefix/common-random-number runs are preferred where valid:

```text
same prefix
+ one realized semantic intervention
→ bounded continuation
→ compare consequences
```

### 6.1 Temporal integrity

Keep separate:

```text
generation time
assignment time
scheduled execution time
realization time
canonical event tick
recording time
observer-visible time
```

When bursts follow gaps, classify:

```text
LEGITIMATE_CATCH_UP
LATE_REALIZATION
LATE_RECORDING
SCHEDULER_AMPLIFICATION
```

Check pause/resume, catch-up, checkpoint/resume, and matched-prefix continuation.

### 6.2 World Profile

`WorldProfile` is a vector, never a single world-quality score.

Semantic domains:

```text
ACTIVITY        routine / meaningful / autonomous consequential
COUPLING        cross-system transitions / consumers / motif diversity
AGENCY          decision diversity / persistence / switches
RELATIONS       distribution / change / persistence / re-encounter
MATERIAL        creation / transfer / loss / destruction / residue
KNOWLEDGE       asymmetry / knowledge-driven decisions / observer divergence
RESOURCES       scarcity / debt / resource-driven decisions
INSTITUTIONS    response / escalation / persistence
TIME            density / clustering / time-to-consequence
SURFACE         causal signal / saturation / reconstruction
```

Operational measures include:

```text
P(outcome)
signature diversity
routine share
consequential share
agency concentration
irreversible rate + first time
declared→realized frontier
future divergence
```

For each metric ask:

```text
Can metric change while phenomenon does not?
Can phenomenon change while metric does not?
```

Do not relabel M3 raw cause depth as world depth. Routine event count is not depth.

### 6.3 Regimes

Analyze trajectory, not only endpoints.

Descriptive clusters may include:

```text
ROUTINE
SOCIAL_PRESSURE
MATERIAL_PRESSURE
INSTITUTIONAL_ESCALATION
STAGNATION
RECOVERY
```

Measure:

```text
occupancy
residence time
entry/exit conditions
transition probability
first-entry time
escape probability
return probability
```

Regime labels are derived and never canonical state without explicit runtime ownership.

### 6.4 Micro ↔ meso ↔ macro

Use longitudinal loops:

```text
MICRO     individual decision / relation / object
↓
MESO      group / household / workshop / institution / local network
↓
MACRO     world profile / regime / outcome distribution
↓
MACRO PRESSURE
↓
MESO RESPONSE
↓
MICRO DECISION
```

Report separate masses:

```text
routine activity
meaningful events
irreversible changes
relation changes
object/material changes
knowledge changes
institutional changes
autonomous consequential decisions
reader-visible causal evidence
```

A huge event count with low consequential mass is routine-heavy, not necessarily deep.

---

## 7. Exceptional spaces and process-pattern analysis

Some places, entities, objects, or configurations may be disproportionately important because many causal paths converge through them. This is an analytical pattern, not a new ontology. Detect candidates using `causal throughput`, `dependency diversity`, `cross-system coupling`, `persistence`, `option centrality / bottleneck behavior`, and `irreversible-transition concentration`. Counterfactually compare `BASE` vs `SPACE-ABLATION` and measure reachable-state loss, institutional response change, relation-network fragmentation, object/resource-flow disruption and future divergence. Interpret only as “empirically load-bearing in this scope”.

Process mining is a read-only microscope for event populations, not a runtime law. Use it for recurring variants, rare paths, bottlenecks, convergence/divergence, object-lifecycle motifs, repeated routine loops and missing downstream consumers. Prefer object-centric process analysis when events span people, objects, resources, locations and institutions. Never promote a discovered process model into world authority merely because it fits observed logs.

---

## 8. Endogenous agency: test before redesign

Current trigger-driven autonomy is a research hypothesis, not a settled defect.

Competing explanations:

```text
harness / PC waiting artifact
missing content
measurement blindness
inert existing urgency
scheduler / temporal artifact
true mechanism gap
```

Cheapest discriminating tests:

```text
A  autonomous baseline
B  urgency ablation
C  positive control
D  content scaling
```

Promotion rule for a new agency mechanism:

```text
autonomous baseline remains materially idle
AND urgency ablation establishes current contribution
AND positive control moves the measurement surface
AND content scaling does not explain the gap
AND runtime owner + phase + falsifier exist
```

Do not collapse group agency into one mind. Separate:

```text
individual
group
institution
```

When promoted, candidate read-side drivers may combine:

```text
WORLD STATE
+ OWN KNOWLEDGE
+ RELATIONS
+ RESOURCES
+ ROLE / OBLIGATIONS
+ THREATS
+ OPPORTUNITIES
+ COMMITMENTS
+ RECENT RESIDUE
→ DRIVERS
→ pack-declared candidate intents
→ capability/permission/knowledge/precondition filter
→ deterministic arbitration
→ optional commitment/hysteresis
→ existing intent door
→ resolution → event
```

Candidate drivers:

```text
DEFICIT
THREAT
OPPORTUNITY
OBLIGATION
ROLE
RELATIONSHIP_PRESSURE
RESOURCE_PRESSURE
SOCIAL_PRESSURE
KNOWLEDGE_CHANGE
RECENT_RESIDUE
DEADLINE
COMMITMENT
```

Determinism requirement:

```text
same seed + pack + state + scheduler position
→ same candidate set + priorities + selected intent
```

LLM planning is never canonical agency.

---

## 9. Experiments, mutations, counterfactuals

Every material causal comparison records:

```text
QUESTION
COMPETING_HYPOTHESES
INTERVENTION_TARGET
ASSIGNMENT
CONTROL
BLOCKED_NUISANCE
RECORDED_NUISANCE
SEED / PREFIX IDENTITY
REALIZED_DELTA
UNIT / SCOPE
SPILLOVER
PRIMARY_DISCRIMINANT
SECONDARY_METRICS
ESTIMAND / CLAIM SCOPE
ORACLE / RELATION
REPLICATION
STOPPING RULE
FIRST DIVERGENCE
PERSISTENCE
DISPOSITION
```

Minimal-pair law:

```text
same context + exactly one semantic difference → compare outcome
```

Controls:

```text
POSITIVE  known intervention → known signal
NEGATIVE  irrelevant intervention → no target signal
SHAM      workflow executes; semantic intervention absent
```

Assignment never substitutes for realized intervention.

Mutation curriculum:

```text
remove downstream consumer
change relation delta
change threshold
disable autonomous driver
remove residue
alter resource quantity
remove knowledge update
skip institutional response
change scheduler order
remove causal write
break object-carrier binding
suppress observer evidence
```

A relevant mutant that escapes weakens negative-evidence strength. Mutation law: a negative detector/test result is weak until the detector is shown to catch meaningful semantic mutations.

Counterexample capsule:

```text
seed
pack/version
scenario
prefix digest
intervention
realized delta
first divergence
failing relation
minimum required inputs
expected
observed
disposition
```

Use delta debugging to minimize a failing witness while preserving the violated relation.

---

## 10. Sensitivity, calibration, world envelope, steering

Sensitivity ladder:

```text
A deterministic one-factor sanity check
B Morris / global screening
C selected interaction analysis
D Sobol / variance decomposition when assumptions fit
E constrained search on a small load-bearing subset
```

Use sensitivity against selected outputs, never as a global world ranking.

Useful outputs:

```text
outcome probability
time-to-outcome
persistence
routine density
agency concentration
institutional escalation
relationship reversal
future divergence
regime occupancy
```

Calibration loop:

```text
constraints
→ bounded parameter subset
→ candidate parameters
→ ensemble simulation
→ profile / outcomes
→ constraint evaluation
→ causal/sensitivity sanity checks
→ held-out evaluation
```

Never optimize a scalar “world quality”. Optimizer output is not canon.

### World Envelope

The target is a vector of explicit constraints:

```text
DIMENSION
TARGET / BAND
TOLERANCE
SCOPE
MEASUREMENT
INTERVENTION OWNER
KNOWN CONFOUNDERS
STOP CRITERION
```

Example dimensions:

```text
routine share
consequential event rate
actor concentration
irreversible-event rate
relation persistence
institutional escalation
meaningful outcome diversity
future divergence
```

When outside the envelope, diagnose before changing runtime:

```text
MEASUREMENT_GAP
CONTENT_GAP
UNREACHABLE_PATH
INERT_MECHANISM
EXCESS_ROUTINE
ACTOR_CONCENTRATION
MISSING_CONSUMER
WEAK_OR_EXCESSIVE_PERSISTENCE
SCARCE_IRREVERSIBLE_CONSEQUENCE
TEMPORAL_DISTORTION
PARAMETER_MIS_CALIBRATION
TRUE_ENDOGENOUS_AGENCY_GAP
```

Alignment loop:

```text
observe trajectory
→ compare envelope
→ identify violated dimension
→ smallest likely load-bearing causes
→ cheapest discriminating experiment
→ content / parameter / mechanism / steering intervention
→ ensemble rerun
→ accept / reject / defer
```

### Bounded steering

Conservative levels:

```text
L0 OBSERVE
L1 SUGGEST
L2 RESEARCH_ROLLOUT
L3 RUNTIME_STEER
L4 PARAMETER_ADAPT   (deferred; new runtime contract required)
```

Receding-horizon pattern:

```text
checkpoint
→ fork candidate futures
→ simulate bounded horizon H
→ evaluate envelope constraints
→ reject illegal / out-of-scope candidates
→ choose admissible candidate
→ emit normal lawful intent
→ advance
→ repeat
```

Hard prohibitions:

```text
rewrite the past
invent canonical events
mutate canon outside normal doors
use hidden player information outside contract
silently change parameters
retroactively repair outcomes
write rollout data into canon
```

Steering objective:

```text
constraint satisfaction under canonical invariants
```

not hidden narrative optimisation.

---

## 11. Observation boundaries, player surface, and Workbench queries

Information states:

```text
OBJECTIVE
→ PERCEIVED
→ KNOWN
→ INFERRED
→ BELIEVED
→ NARRATED
```

Queries must be able to distinguish:

```text
What is true?
What does actor A know?
What does B believe?
What did C actually observe?
What can D legally infer?
What can the player receive?
What did the narrator say?
```

Player/reader proof chain:

```text
WORLD TRUTH
→ OBSERVER ACCESS
→ KNOWLEDGE / ARTIFACT / INSTITUTION / ENVIRONMENT SIGNAL
→ CHRONICLE / BRIEF / SURFACE
→ PLAYER INFERENCE
```

Readable prose never proves canon.

Observer-boundary adversarial corpus should cover omniscient queries, `knower=None`, planted leaks, all legal prefixes, relevant actors and provenance matching.

### World Question contract

An agent-facing query should declare:

```text
QUESTION
CLASS
TARGET
SCOPE
KNOWN
UNKNOWN
COMPETING_HYPOTHESES
INTERVENTION
CONTROL
OBSERVABLES
PRIMARY_DISCRIMINANT
RUN PLAN
REALIZED DELTA
FIRST DIVERGENCE
CAUSAL SLICE
PERSISTENCE
REPLICATION
FAILURE CLASS
DISPOSITION
PRACTICAL CONSEQUENCE
ENVIRONMENT / SCOPE
```

Result rule:

```text
ANSWER
→ EVIDENCE
→ MINIMAL CAUSAL SLICE
→ UNCERTAINTY
→ NEXT DISCRIMINATOR
```

Query families:

```text
OBSERVE      profile / ensemble / relation / object / temporal / regime
EXPLAIN      why event / what reads / what consumes / where divergence begins
SEARCH       reach target / deep action / missing consumer
ARCHAEOLOGY  present blocker / residue chain / earliest verified difference
ALIGN        trajectory vs envelope / violated dimension
CALIBRATE    bounded parameter search
STEER        lawful bounded rollout comparison
```

Standard result schemas:

```text
EXPLAIN EVENT:
  EVENT
  PRECONDITIONS / READS
  IMMEDIATE EFFECT
  RELATION/OBJECT/RESOURCE EFFECT
  DOWNSTREAM CONSUMER
  FIRST DIVERGENCE
  PERSISTENCE
  OBSERVER EFFECT
  PLAYER EFFECT
  EVIDENCE CLASS / DISPOSITION

WHY STAGNANT:
  WINDOW
  ROUTINE SHARE
  CONSEQUENTIAL SHARE
  ACTOR CONCENTRATION
  AUTONOMOUS CONSEQUENTIAL RATE
  EVENT CLUSTERING
  CHANGE FROM PRIOR WINDOW
  COMPETING DIAGNOSES
  CONTROL RESULTS
  DISPOSITION

WHY RELATION X:
  PAIR / AXIS
  TRAJECTORY
  EVENT CONTRIBUTORS
  DECAY / EXPIRY
  READ DEPENDENCIES
  BEHAVIORAL CONSUMERS
  COUNTERFACTUAL RESULT
  CLAIM SCOPE

WHY OPTION X:
  CURRENT OPTION
  CURRENT BLOCKER
  RESIDUE CHAIN
  EARLIEST VERIFIED MATERIAL DIFFERENCE
  COUNTERFACTUAL ALTERNATIVE
  PERSISTENCE
  SCOPE
```

No World Question result may imply stronger causality than its evidence ladder supports.

---

## 12. Verification and recertification

Observatory verification extends existing engineering gates; it does not replace them.

Useful regimes:

```text
gate
unit
pack
reachability
composition
architecture
metric
branching
temporal
observer
surface
llm_contract
llm_live
world_probe
mutation
recertification
held_out
```

Existing T0–T8 remain necessary:

```text
T0 schema
T1 determinism
T2 replay
T3 blind-NPC / knowledge boundary
T4 irreversibility
T5 impossible intent
T6 smoke / long-path closure
T7 readability
T8 director-off A/B
```

Observatory-specific acceptance requires:

```text
derivation purity
regenerability
deletability
determinism
environment attribution
scope attribution
epistemic classification
disposition
noninterference
mutation sensitivity
counterexample replayability
```

Core invariants:

```text
same canonical log → same analytical output
analysis execution → no canonical semantic mutation
canonical event → expected projection rows
```

Synthetic dependency fixture:

```text
A writes X
B reads X
B writes Y
C reads Y
```

The Observatory must reconstruct the structure while refusing to label `A→B` causal without intervention evidence.

Recertification after material changes:

```text
old property still holds
old falsifier still works
expected sensitivity remains non-zero
measurement semantics unchanged or explicitly versioned
```

Never refresh goldens blindly.

---

## 13. Worldbuilding-scale validation

Observatory evidence must bridge world-scale structure to human-scale consequences.

Biography witness:

```text
birth
→ childhood
→ training
→ work
→ relationships/family
→ money/debt
→ institutions
→ conflict/loss
→ adaptation
→ aging
→ death
→ memory
```

Crisis witness:

```text
crisis
→ required decisions
→ required institutions / relationships
→ consequences
→ residue
→ missing-link diagnosis
```

Loss witness should affect multiple real domains:

```text
relationship
resource/status
obligation
memory/knowledge
future options
```

Genre robustness asks whether the same canonical state supports different lawful readings:

```text
adventure / mystery / politics / relationship drama / tragedy / comedy / biography
```

Compression/carrier ablation:

```text
remove carrier
→ simulate
→ compare reachable futures and downstream consequences
```

If only prose changes, the element may be non-causal flavor rather than world machinery.

---

## 14. Runtime-promotion gate and standing non-goals

A new runtime primitive requires:

```text
REAL CONSUMER
REAL FAILURE / MATERIAL QUALITY GAP
NATIVE LIMIT
REPEATED SHAPE
MINIMAL INTERVENTION
FALSIFIER
INFORMATION / SEMANTIC OWNER
PHASE / GATE
VERIFICATION PLAN
```

Otherwise keep the result as:

```text
research vocabulary
read-side projection
test relation
proposal
```

Standing non-goals absent new evidence and explicit ownership:

```text
second canonical world database
second semantic authority
generic canonical graph database / knowledge graph
generic workflow/lifecycle runtime
generic reactive engine
full CRDT/MVCC semantic world state
generic all-purpose planner
LLM-controlled canon
universal truth/confidence/risk score
multi-oracle “truth” engine
permanent diagnostic graph as authority
full distributed data platform without workload evidence
optimizer as world law
```

Derived graph/object/process/warehouse/optimizer structures are fine when their non-authority boundary is explicit.

---

## 16. Unknowns and evidence discipline

Keep these visible until evidence changes status:

```text
current long-horizon endogenous idleness = HYPOTHESIS / UNRESOLVED
fork-with-perturbation semantics = UNKNOWN until measured
runtime steering cost = UNKNOWN until measured
M4 semantics/current implementation alignment = UNRESOLVED until synchronized
cross-version byte identity = NOT A CONTRACT unless explicitly established
derived read-set sidecar necessity = PROPOSAL; shadow derivation first
OCEL runtime role = NOT RUNTIME; analytical interchange only
distributed analytical backend necessity = UNKNOWN / workload-gated
```

Historical Observatory evidence must never stand in for current repository state. Re-read owner files.

---

## 17. Preserved historical evidence, witness portfolio, transfer rules, and analytical scale

These are snapshot findings from the supplied source, not timeless world laws. Preserve them for regression, routing, falsification, and recertification.

### Historical cognitive-scaling snapshot

The supplied source reports an audit snapshot at `iter-216 / HEAD 41be836...`: core ≈22.6k Python lines, tests ≈52.6k lines, docs ≈30k Markdown lines, 5 packs, and ≈1.6k numeric/configuration leaves in the examined snapshot. The interpretation is that observability pressure was already material while world-content scale remained comparatively small; the remedy is machine-queryable consequential structure, not making the world cognitively smaller. Re-read `STATUS.md` before treating these numbers as current state.

### F1 — raw `cause` depth is mostly adjacency

| Run | Events | `cause == previous` | Raw depth max / median |
|---|---:|---:|---:|
| `province_calendar` seed 42 | 2,288 | 100% | 2,283 / 1,140 |
| `province_feud` seed 53 | 68 | 87% | 53 / 32.5 |
| `day1_full` seed 125 | 56 | 64% | 37 / 12 |

Therefore raw `cause` depth is not world depth.

### F2 — historical long-horizon witness was routine-dominated

`province_calendar`: 520,073 ticks / 2,288 events; 23 event types; `status_decayed=1,098`; `watch_change=722`; `talk=265`; routine share 0.91; 40 semantic signatures; ≈98% signature repetition; 0 irreversible state changes; position writes 2,168; fatigue writes 1,820; PC suspicion writes 36; 376 non-world events; two NPCs ≈95% of non-world events. The PC script mostly waited, so this is witness-specific evidence.

### F3 — witness is not a distribution

`province_feud`, seeds 1–60: headline chain 6/60; first tallow-lamp contested check failed 54/60; `intent_rejected` appeared 58/60; all final-state fingerprints differed; 11 event-type sets; semantic variance concentrated in fear/fire more than cosmetic worldgen.

### F4 — action census is cheap; naive mutation guidance is weak

Historical Province probe: 2,500 random scripts × 30 steps; ≈68 s total / ≈27 ms per run; 27/42 declared outcome-events realized; 38 event types realized. Naive event-type/property mutation reached 25/42, no better than random; deep reachability therefore requires precondition-aware search.

### F5 — fixed-script coverage is confounded

The historical `39/134` fixed-script × 6-seed result is not world coverage because driver design and seed choice confound it.

### F6 — stale schema-reader defect

Historical audit reproduced `EventLogWriter(append=True)` rejecting stale `schema_version` while `read_log()` accepted a structurally valid stale-header log. Required relation: `valid events + stale/unsupported header → LogError`. Route this through normal verification ownership, not Observatory authority.

### Historical witness portfolio

Keep complementary witnesses; do not collapse them into one giant scenario:

```text
tavern/day1_full              theft → knowledge → suspicion/leverage → watch → movement → fire → burnout
tavern/day1_theft_and_arson   theft + carrier + arson + fire lifecycle
tavern/exp0_week              repeated action/object/decay/director
road/road_smoke               movement → mid-route watch → knowledge → arrival
grim/grim_smoke               flirt → jealousy → proposition → reputation/trust/fear → leverage → shame
pressure/pressure_smoke       boiler → seam → dread/cold → group response → coal
province/province_smoke       generated world → route → movement → watch/knowledge
province/province_companion   companion → co-presence → rumor/talk → fatigue/queue → movement
province/province_feud        arson → suspicion → fire → alarm → panic → grief → spread → burnout → guild
province/province_calendar    calendar → season/weather → checks → market/fair → talk/rumor → economy crossings
```

Historical pack capability matrix is evidence/routing, not exhaustive proof:

| Capability | Tavern | Road | Grim | Pressure | Province |
|---|---:|---:|---:|---:|---:|
| movement/location | A | A | S | S | A |
| long travel/queued activity | S | A | — | — | A |
| perception/visibility/hearing | A | A | A | A | A |
| action/resolver | A | A | A | A | A |
| impossible intent | A | A | A | A | A |
| canonical mutation | A | P | A | A | A |
| relations | P | S | A | S | A |
| knowledge asymmetry | A | A | A | A | A |
| rumor | A | A | A | A | A |
| crime/suspicion | A | S | S | — | A |
| fire/irreversible material | A | S | S | — | A |
| object lifecycle | A | S | S | — | A |
| economy/accounts | S | — | A | A | S |
| economy downstream | P | — | A | A | P |
| group/faction agency | S | — | — | A | A |
| autonomous actors/groups | A | A | P | A | A |
| calendar/season | S | S | S | S | A |
| weather coupling | A | A | A | A | A |
| director/deferred hooks | A | S | S | S | A |
| leverage/secrets | A | S | A | — | A |
| cultures/names | — | — | — | — | A |
| travel pricing | — | A | — | — | A |
| world generation | A | A | A | — | A |
| large generated surface | — | — | — | — | A |
| chronicle/causal output | A | P | A | P | A/P |
| long horizon | A | A | S | A | A |
| causal ablation | A | S | S | S | A |
| held-out transfer | P | P | P | P | P |

Legend: `A` integrated witness + downstream consequence; `S` isolated/station witness; `P` partial integration/scope gap; `D` declared only; `U` unresolved; `—` not materially present/N/A.

### Cross-domain mechanism transfer

Use the transplantation law:

```text
foreign domain → mechanism → invariant → remove domain cargo
→ target adaptation → incompatibilities / hidden assumptions
→ competing explanation → cheapest discriminating test
→ realized consequence → counterexample/refinement
→ transfer/scope check → durable residue
```

Search for operations, not labels: generation, transformation, propagation, diffusion, filtering, aggregation, decomposition, feedback, degradation, trace preservation, accumulation, constraint propagation, state transition, sensitivity, failure localization, counterfactual ablation, bounded traversal, indirect observation, lifecycle tracing, hierarchical decomposition, heterogeneous agency, dependency analysis, emergent interaction, candidate generation + exact verification, representation change.

Reject `SURFACE ANALOGY`, `CARGO-CULT TRANSFER`, `HIDDEN ASSUMPTION`, `ARBITRARY TRANSFER`, `DECORATIVE COMPLEXITY`, `THRESHOLD LEAKAGE`, `TERMINOLOGY LEAKAGE`, `FALSE INDEPENDENCE`. Prefer `change representation → make operation tractable → verify exact semantic result separately`. Valid patterns include candidate generation → conservative filtering → exact validation; derived representation → search → exact canonical verification; semantic addressing → local variation control → deterministic replay.

For third-order interactions, test whether A improves, constrains, generalizes or refutes B, exposes B's hidden assumption, collapses with B into an existing primitive, or jointly creates a capability absent from each alone. Do not infer that both mechanisms must be implemented.

### Big-data strategy

“Big data” here means many runs, long histories and wide analytical populations, not distributed infrastructure by default:

```text
SMALL                  JSONL + SQLite
MEDIUM                 DuckDB over JSONL / SQLite exports
LARGE OFFLINE POP      Parquet + DuckDB
VERY LARGE / DISTRIB.  only after workload evidence justifies it
```

High-value population queries include actor relation trajectories, object lifecycles, outcome/time-to-event distributions, rare-event discovery, run clustering, regime transitions, parameter sensitivity, counterfactual divergence and process variants. Canonical JSONL must remain sufficient to reconstruct every projection.

---

## 18. Execution roadmap

### P0 — expose the substrate

```text
1 action-to-consequence census
2 multi-seed population runner + manifest
3 BASE/PERTURBED future-divergence harness
4 thin analytical projection
5 compact World Profile
6 run/trajectory artifact format
7 H-AUTONOMY discriminating tests
```

### P1 — explanation

```text
8 relation ledger/lifecycle
9 object lifecycle
10 temporal multiplex graph projection
11 shadow decision/read traces
12 causal slices + counterexample capsules
13 residue/persistence
14 influence footprints
15 regime detection
16 bounded World Question surface
17 OCEL export only if analytically useful
```

### P2 — search / calibration

```text
18 precondition-aware backward reachability
19 sensitivity screening
20 selected interaction sensitivity
21 constrained calibration + held-out evaluation
22 exceptional-space detection / ablation
23 research-only steering
```

### P3 — conditional runtime changes

```text
24 receding-horizon runtime director
25 runtime bounded intervention search
26 endogenous goal/need/driver arbitration
27 runtime adaptive parameter control
```

Every P3 item requires a new runtime contract and the promotion gate.

---

## 19. Candidate analytical CLI

Names are illustrative; exact commands are implementation-owned:

| Command | Purpose |
|---|---|
| `obs run --pack --script --seeds a:b --arm ...` | population + manifests |
| `obs outcomes --class ...` | semantic outcome distributions |
| `obs census --pack ...` | action/consequence coverage |
| `obs profile --run/--seeds --window ...` | profile + trajectory |
| `obs relation --actor A --actor B` | relation lifecycle |
| `obs object --id X` | object lifecycle / residue |
| `obs slice --event/--entity/--property ...` | bounded causal slice |
| `obs archaeology --condition ...` | historical residue chain |
| `obs pair --base ... --perturb ...` | divergence + persistence |
| `obs regimes ...` | regime occupancy/transitions |
| `obs reach --target ...` | deep reachability |
| `obs sens ...` | sensitivity |
| `obs calibrate ...` | offline calibration |
| `obs align ...` | envelope comparison |
| `obs steer ...` | research-only bounded rollout |

All outputs must be bounded, deterministic where the underlying run is deterministic, scoped, and evidence-bearing.

---

## 20. Agent operating loop

For any material world question:

```text
1 DEFINE
   target phenomenon, scope, horizon, envelope if applicable

2 OBSERVE
   multi-seed population, not a single witness

3 PROJECT
   action / relation / object / decision / outcome / temporal views

4 PROFILE
   vector trajectory + regime signals

5 DIAGNOSE
   violated dimension + competing explanations

6 TRACE
   causal slice + residue chain + consumers + first divergence

7 TEST
   cheapest minimal pair / ablation / control

8 SCREEN
   load-bearing parameter/content candidates

9 CALIBRATE
   bounded offline search + held-out evaluation

10 ALIGN
   compare trajectory to envelope

11 STEER (optional)
   lawful bounded rollout; never rewrite canon

12 VERIFY
   replay / mutation / observer / surface / held-out checks

13 PERSIST
   retain only decisions/evidence that change future work
```

Default intervention preference:

```text
1 measurement / observation gap
2 declared-but-unreachable / unrealized path
3 missing downstream consumer
4 content gap
5 parameter mis-calibration
6 missing mechanism
7 research-only steering
8 runtime steering / adaptive agency only after explicit promotion
```

This is a diagnostic default, not a universal law.

---

## 21. Definition of done

An Observatory capability is complete when:

```text
REAL QUESTION
→ REAL CONSUMER
→ MINIMAL DERIVED DATA
→ REPRODUCIBLE RUN
→ EXPLICIT OBSERVABLE
→ FALSIFIER
→ ACCEPTANCE TEST
→ BOUNDED AGENT OUTPUT
→ DISPOSITION
→ DURABLE DECISION only if future work changes
```

A negative or inconclusive result is valid when evidence supports it.

Every completed research session records:

```text
QUESTION
VERDICT
ESTABLISHED EVIDENCE
KEY ALTERNATIVES TESTED
REMAINING UNCERTAINTY
PRACTICAL CONSEQUENCE
NEXT VERIFICATION STEP
```

Final operating model:

```text
WORLD / CONTENT
→ CANONICAL DETERMINISTIC RUNTIME
→ IMMUTABLE RUNS
   ├─ MICRO: decisions / reads
   ├─ RELATIONS: temporal trajectories
   ├─ OBJECTS: lifecycle / residue
   ├─ MESO: groups / institutions / processes
   └─ MACRO: ensembles / profile / regimes
→ CAUSAL ARCHAEOLOGY
→ COUNTERFACTUAL DIVERGENCE
→ SENSITIVITY
→ CALIBRATION
→ WORLD ENVELOPE
→ BOUNDED STEERING (optional)
→ NORMAL INTENT DOOR
→ NEW CANON EVENT
→ FUTURE EVIDENCE
```

Absolute boundary:

```text
CANONICAL SIMULATION = truth
ALL OTHER LAYERS    = observation, experiment, search, calibration, control, or presentation
```

The intended outcome is not a simpler world. It is a world whose history, relationships, dependencies, residues, distributions, causal structure, failure modes, and controllable degrees of freedom can be queried by a human or LLM without reconstructing the entire repository manually.
