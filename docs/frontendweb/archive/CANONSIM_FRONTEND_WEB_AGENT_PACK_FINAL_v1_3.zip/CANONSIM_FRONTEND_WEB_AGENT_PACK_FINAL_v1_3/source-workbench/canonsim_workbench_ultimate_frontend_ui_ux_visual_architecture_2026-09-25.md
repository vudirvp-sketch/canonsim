# CanonSim Workbench — Ultimate Frontend / UI / UX / Visual Architecture
## Consolidated normative guide for the Redot Workbench and World Observatory
### 2026-09-25

> **Purpose:** consolidate the frontend/UI/visual/ergonomics findings and recommendations into one agent-oriented source of truth.  
> **Scope:** current Redot frontend, v5.2 Workbench / World Observatory plans, UI law, interaction architecture, visual identity, accessibility, localization, responsive behavior, verification, and implementation order.  
> **Principle:** preserve CanonSim's semantic/truthfulness architecture. The frontend is a projection and investigation instrument, not a second authority, second transport, or decorative game layer.

---

## 0. Executive doctrine

CanonSim Workbench must be treated as an **instrument for truthful interaction with deterministic world state and evidence**, not as a generic dashboard, generic dark AI client, or collection of independent screens.

The frontend architecture must therefore optimize for:

```text
semantic truthfulness
→ low cognitive load
→ fast task completion
→ inspectability
→ reversible navigation where appropriate
→ explicit evidence / provenance
→ deterministic rendering
→ bounded complexity
→ accessibility
→ agent maintainability
```

The central UX invariant is:

```text
QUESTION
→ SCOPE
→ FOCUS
→ PRIMARY VIEW
→ CONTEXT
→ INSPECT / COMPARE / DRILL
→ EVIDENCE
→ PROVENANCE
→ NEXT DISCRIMINATOR
```

The central implementation invariant is:

```text
canonical/backend state
→ typed read model
→ ViewModel only where projection logic is needed
→ UI / Visual Scene IR
→ Redot presentation
```

Never:

```text
UI
→ hidden transport
→ semantic authority
```

Never:

```text
visual appearance
→ implied truth
```

---

# 1. Current implementation baseline

## 1.1 Verified current state

The supplied audit of the full clone and the v5.2 planning pack establishes the following current baseline:

| Area | Current state |
|---|---|
| Chat | Implemented; llama.cpp over loopback gateway |
| Models | Implemented; discover/load/unload/fetch/import flows |
| Settings | Implemented; backend launch configuration |
| Inference | Disabled navigation placeholder |
| Prompts | Disabled navigation placeholder |
| History | Disabled navigation placeholder |
| Diagnostics | Disabled navigation placeholder |
| Simulation | Disabled navigation placeholder |
| Observatory | **Absent, including navigation/stub surface** |
| World/game rendering | Python-side Scene IR placeholder exists; Redot does not consume it |
| Redot composition | Imperative UI construction concentrated in `shell.gd` (~2200+ lines) |
| Reusable custom controls | Minimal / effectively absent |
| Runtime Redot proof in sandbox/CI | Not available; visual/interactivity gates are therefore not continuously executable |
| Current visual language | Functional dark UI; technically disciplined tokens; weak CanonSim-specific identity |

The audit explicitly notes that only Chat, Models, and Settings are currently real surfaces, while Observatory has no frontend entry point at all. fileciteturn1file0L13-L21

## 1.2 What is already strong and should be preserved

### Design-system discipline

The implementation already demonstrates real token usage rather than purely declarative token documentation:

```text
primitives
→ semantic tokens
→ component tokens
→ component states
→ composition
```

The theme contains component states such as normal / hover / pressed / disabled / focus / readonly, and measured contrast values are documented. fileciteturn1file0L28-L34

### State honesty

The current implementation uses explicit states such as:

```text
EMPTY
DISCOVERED
LOADING
FAILED
...
```

and does not fabricate unavailable functionality as successful content. fileciteturn1file0L52-L60

### Chat scrolling

The later scrolling fix is a good reference pattern:

```text
smooth scrollbar tween
+
near-bottom gate
+
late-layout settle
```

The user should not be yanked to the bottom merely because a new message arrived. fileciteturn1file0L54-L60

### Native OS dialogs

Model selection uses OS dialogs rather than recreating file-system dialogs inside Redot. Preserve this principle wherever native system affordances are materially better.

### Authority / claim separation

The existing conceptual split must remain explicit:

```text
authority:
CANONICAL
OBSERVED
DERIVED
UNKNOWN

claim status:
FACT
INFERENCE
HYPOTHESIS
PROPOSAL
UNKNOWN
```

These are different dimensions and must never collapse into one generic status color or label.

---

# 2. Core diagnosis

The main problem is **not lack of styling polish**.

The actual system gap is:

```text
semantic architecture
        >
frontend interaction architecture
        >
visual implementation
```

The planning documents are stronger at specifying:

```text
what the UI must not falsely imply
```

than at specifying:

```text
how a human investigates a complex world efficiently
```

The Workbench therefore needs a missing middle layer:

```text
SEMANTIC / BACKEND CONTRACT
          ↓
ANALYTICAL INTERACTION GRAMMAR
          ↓
VISUAL / UI SYSTEM
          ↓
REDOT IMPLEMENTATION
          ↓
RUNTIME + TASK PROOF
```

Without that layer, Observatory can become a collection of charts, graphs, cards, and status widgets rather than an actual research instrument.

---

## 2.1 Human-centred task loop

Use this loop for every major surface:

```text
context of use
→ user / goal / constraints
→ task / workflow
→ information architecture
→ interaction model
→ visual/type system
→ prototype
→ usability evaluation
→ implementation
→ measurement
→ iteration
```

A screen is a projection of a workflow, not the design starting point.

For each major task define:

```text
USER · GOAL · TASK · CONTEXT · INPUT · DECISION · ACTION
→ FEEDBACK · SUCCESS · FAILURE · RECOVERY
→ ACCESSIBILITY · INPUT MODALITY · INTERRUPTION · RESUMPTION
```

Task graph:

```text
Goal → choose → inspect → decide → act → verify → recover / continue
```

Prioritise high-frequency, high-cost, high-risk and high-load workflows before decorative refinement.

HCI model caveats:

```text
Fitts law → target acquisition / travel guidance, not a universal UI formula
Hick-Hyman → grouping / defaults / search guidance, not an arbitrary menu-size law
"7±2" → not an interface-capacity law
WCAG target-size values → applicable conformance guidance, not universal native-desktop geometry
```
# 3. Specification integrity: prevent normative drift

## 3.1 The law chain

Every approved UX/UI requirement must survive through:

```text
FULL NORMATIVE SPEC
→ ACTIVE WORKING LAW
→ IMPLEMENTATION CONTRACT
→ TEST / PROOF
```

No requirement may silently disappear while documents are shortened.

The current audit identifies a concrete drift:

`docs/VISUAL_SYSTEM_UI.md` is a useful compact working law, but it omits material requirements that exist in the larger v5.2 specification, including:

```text
accessibility
keyboard / focus
reduced motion
responsive / DPI / multi-monitor behavior
localization / Cyrillic support
```

The result is a governance defect: future agent work can appear compliant with the short law while silently violating the larger approved requirements. fileciteturn1file0L36-L45

## 3.2 Required solution

`VISUAL_SYSTEM_UI.md` must either:

1. contain the complete minimum normative checklist, or
2. explicitly reference the authoritative sections/specs that remain binding.

It must never be an accidental lossy compression of the approved law.

Recommended compact routing:

```text
VISUAL_SYSTEM_UI.md
    ↓
"Mandatory companion requirements"
    ├── Accessibility
    ├── Responsive / DPI
    ├── Localization
    ├── Reduced motion
    ├── Observatory interaction grammar
    └── Verification
```

The short law is a routing/index layer, not permission to forget omitted requirements.

---

# 4. Workbench information architecture

## 4.1 Surface vs intent

Do not make every representation a top-level surface.

The architectural distinction should be:

```text
SURFACE
= user intent / work context

VIEW
= representation of information
```

Recommended conceptual structure:

```text
WORK
├── Chat
├── Simulation
└── Observatory

RESOURCES
├── Models
├── Prompts
└── History

SYSTEM
├── Runs
├── Diagnostics
└── Settings
```

This is a conceptual IA, not a mandatory literal menu. The key invariant is:

```text
intent surfaces stay few
representations stay inside the relevant surface
```

Avoid:

```text
Chat
Models
Settings
Inference
Prompts
History
Diagnostics
Simulation
Observatory
...
```

becoming a flat catalog of 12–20 equally prominent destinations.

## 4.2 Navigation rail

The current navigation rail works while there are only a few surfaces. It should not scale by simple vertical addition.

Before surface count expands, define:

```text
grouping
hierarchy
selection
focus
keyboard traversal
restoration
overflow/collapse behavior
```

A nav rail must remain a navigation instrument, not a feature directory.

---

# 5. Analytical Workspace: the missing interaction layer

The Observatory needs a first-class workspace grammar.

## 5.1 Workspace regions

Conceptual regions:

```text
CONTEXT
QUERY
SCOPE / FILTER
PRIMARY VIEW
INSPECTOR
EVIDENCE / PROVENANCE
```

These are semantic roles, not mandatory permanent panels.

They must be collapsible/resizable according to task and viewport.

### Context

Expose enough identity to answer:

```text
What am I looking at?
Under which run?
With which seed?
Over which time window?
Under which observation profile?
Against which analysis/result revision?
```

Example:

```text
CURRENT CONTEXT
province · run_0042 · seed 42 · tick 1180–1540 · CANON VIEW
```

### Query

Represent the actual research question:

```text
question
class
target
scope
observer/profile
comparison arm
filters
```

### Primary view

Exactly one representation should normally have primary visual attention:

```text
timeline
table
diff
profile
map
graph
```

Do not show every representation simultaneously merely because the backend can produce it.

### Inspector

Selection details:

```text
identity
state
history
relations
contributors
consumers
downstream effects
provenance
```

### Evidence / provenance

Show:

```text
evidence
disposition
scope
uncertainty
source
analysis revision
next discriminator
```

---

# 6. Shared selection model

Selection must be a first-class application concept, not a local widget behavior.

## 6.1 Selection invariant

A selected semantic identity should propagate across representations:

```text
select event E
→ timeline highlights E
→ graph highlights related dependencies
→ object view highlights affected objects
→ inspector opens E
→ evidence view scopes to E
```

Likewise:

```text
select actor
→ related events / objects / relations / consequences become context
```

Selection should remain stable across:

```text
view switches
semantic zoom
drill-down
compare
filter changes
```

unless the selected identity genuinely leaves the active scope.

## 6.2 Cross-highlighting

All synchronized representations should reference the same semantic identity.

Never implement cross-highlighting by matching display strings, row indices, or ad-hoc local IDs.

Use canonical identity / typed read-model identity.

---

# 7. Focus + context

A central Observatory primitive should be:

```text
FOCUS
+
CONTEXT
```

not only geometric zoom.

Example:

```text
FOCUS:
event 714

CONTEXT:
±30 events
same actor
same object
same relation axis
same causal slice
```

The user must be able to change context without losing the focal identity.

---

# 8. Semantic zoom

Ordinary camera zoom is insufficient.

Define semantic levels such as:

```text
event-level
→ cluster-level
→ regime-level
→ world-level
```

At each level:

```text
different aggregation
different labels
different metadata density
same underlying identities
```

Semantic zoom must never change the underlying meaning silently.

---

# 9. Compare mode

`BASE` vs `PERTURBED` analysis requires a dedicated interaction contract.

## 9.1 Compare model

Use:

```text
BASE
PERTURBED
COMMON PREFIX
FIRST DIVERGENCE
CHANGED CONSEQUENCES
PERSISTENCE
```

Both arms must share:

```text
time axis
semantic identity space
selection
scale where meaningful
navigation position
comparison scope
```

The correct model is:

```text
one temporal coordinate system
+
two experiment arms
```

not two independent pages.

## 9.2 Comparison UX

A useful default structure:

```text
BASE                      PERTURBED
────────────────────      ────────────────────
event 101                 event 101
event 118                 event 118
event 132                 event 132
                          ✦ event 133
                          ✦ relation change
                          ✦ object transfer
                          ✦ state divergence
```

Difference markers must be anchored to semantic identity and time, not merely color.

---

# 10. Timeline as a primary analytical primitive

The timeline should be a first-class Observatory representation.

Recommended semantic lanes:

```text
actors
events
relations
objects
resources
institutions
knowledge
regimes
divergence
observer access
```

Important derived markers:

```text
FIRST DIVERGENCE
PERSISTENCE INTERVAL
REGIME TRANSITION
RE-ENCOUNTER
STATE EFFECT
```

Timeline interaction should support:

```text
select
range
scrub
focus
semantic zoom
compare alignment
jump to divergence
jump to source evidence
```

---

# 11. Graph policy

Graph is useful but dangerous.

## 11.1 Core rule

> Graph is a contextual microscope, not the default representation of the world.

Prefer:

```text
timeline
table
inspector
diff
```

before unrestricted graph.

Graph should answer explicit questions:

```text
show dependency neighborhood
show relation neighborhood
show object flow
show institutional links
```

## 11.2 Graph limits

Always bound:

```text
node count
edge count
neighborhood depth
visible labels
layout scope
```

Prefer local neighborhoods over hairballs.

---

# 12. Evidence Ladder as a UI primitive

The conceptual evidence ladder should become an actual reusable interaction component.

Recommended states:

```text
READ DEPENDENCY
→ BRANCH INFLUENCE
→ STATE EFFECT
→ DOWNSTREAM DIVERGENCE
→ PERSISTENT CAUSAL DEPENDENCY
```

Example UI model:

```text
EVIDENCE
READ            ✓
BRANCH          ✓
STATE           ✓
DIVERGENCE      ✓
PERSISTENCE     ?
```

Then:

```text
CLAIM:
X contributed to Y

DISPOSITION:
PARTIALLY_CONFIRMED

SCOPE:
run=42..60

NEXT DISCRIMINATOR:
matched counterfactual intervention
```

Do not allow a graph edge, prose statement, or `cause_id` alone to visually imply a causal conclusion.

---

# 13. Epistemic visual grammar

The frontend must distinguish:

```text
UNKNOWN
≠ NOT OBSERVED
≠ NO MATCH
≠ NO EVIDENCE
≠ ABSENT
≠ OUT OF SCOPE
≠ FAILED
≠ STALE
```

Recommended semantic states:

```text
KNOWN
SUPPORTED
PARTIAL
AMBIGUOUS
UNRESOLVED
UNKNOWN
OUT_OF_SCOPE
STALE
```

These states must not depend on color alone.

Use combinations of:

```text
label
icon
shape
pattern
line treatment
position
textual explanation
```

Color is supportive, not authoritative.

---

# 14. Authority and claim status

Keep these orthogonal:

```text
AUTHORITY
CANONICAL
OBSERVED
DERIVED
UNKNOWN
```

and:

```text
CLAIM
FACT
INFERENCE
HYPOTHESIS
PROPOSAL
UNKNOWN
```

Never use one overloaded status such as:

```text
blue = truth
green = derived
red = false
```

The UI must allow a statement to be:

```text
OBSERVED + INFERENCE
```

or:

```text
CANONICAL + FACT
```

without semantic collision.

---

# 15. Query lifecycle

Observatory queries require their own visible lifecycle.

Recommended:

```text
DRAFT
→ VALIDATED
→ ADMITTED
→ RUNNING
→ PARTIAL
→ COMPLETE
→ FAILED
→ CANCELED
→ STALE
```

Expose stable identifiers where relevant:

```text
QUERY ID
RUN ID
RESULT REVISION
```

The user must know whether they are viewing:

```text
live/current result
previous result
partial result
stale result
recomputed result
```

---

## 15.1 Dense data surfaces, forms and search

Density is task-dependent:

```text
reading: low/medium
authoring/chat: medium
data grids / diagnostics: high + strong hierarchy
expert configuration: high + progressive disclosure
```

Tables are for row/column comparison, not arbitrary layout.

Dense data should support:

```text
find → compare → inspect/edit → act
```

where relevant:

```text
stable columns
numeric alignment
row grouping
sticky/frozen headers
sorting/filtering near data
visible selection
keyboard semantics
accessible headers
stable semantic identity
virtualization
```

Forms follow user reasoning rather than database schema:

```text
identity/target
→ essential choice
→ dependent choices
→ optional detail
→ advanced
→ validation
→ commit
```

Preserve recoverable input and distinguish:

```text
invalid
incomplete
unavailable
```

Search supports partial knowledge, preserved query state and explicit result scope.

# 16. Empty / no-result semantics

Never collapse all empty outcomes into one empty-state card.

Distinguish:

```text
NO DATA
NO MATCH
NO EVIDENCE
UNKNOWN
OUT OF SCOPE
BLOCKED
PARTIAL
```

Examples:

```text
NO EVIDENCE
```

must not render as:

```text
NO RELATION
```

and:

```text
OUT OF SCOPE
```

must not render as:

```text
NOT FOUND
```

---

# 17. Drill-down and semantic navigation

Provide a predictable analytical path:

```text
world profile
→ regime
→ time window
→ event
→ actor / object / relation
→ causal slice
→ source event
→ exact evidence
```

Navigation history must be semantic.

Preferred breadcrumb:

```text
Province
→ stagnation window 420–610
→ regime ROUTINE
→ actor Maren
→ event watch_change#714
→ downstream divergence
```

Avoid:

```text
Screen 1 > Screen 2 > Screen 3
```

The user must be able to:

```text
Back
Forward
return to current scope
restore prior focus
```

---

# 18. Persistent workspace state

An analytical investigation should be reopenable as the same working context.

Persist, where semantically appropriate:

```text
query
scope
selection
filters
view
semantic zoom level
comparison arms
inspector state
evidence position
navigation context
```

Reopening an investigation should restore the research state rather than always returning to a generic home screen.

---

# 19. Evidence Capsule

Introduce a first-class immutable/read-only research artifact:

```text
EVIDENCE CAPSULE
```

Suggested contents:

```text
question
scope
run(s)
target
result
evidence
causal slice
uncertainty
disposition
next discriminator
provenance
analysis revision
```

A capsule must be reopenable into its analytical context.

A screenshot is not an Evidence Capsule.

---

# 20. Task-oriented ergonomics

UX quality must be evaluated by user tasks, not component count.

Minimum task suite:

```text
T1  discover → load → verify a model
T2  prompt → generate → stop → recover
T3  find a world divergence
T4  select event → inspect consequences
T5  compare BASE vs PERTURBED
T6  locate evidence behind a claim
T7  return to a prior analytical context
T8  export / reopen analytical result
```

For each task define:

```text
entry state
goal
primary actions
focus transitions
state transitions
error branches
completion proof
recovery path
```

---

# 21. Interaction-cost budget

Do not turn ergonomics into a vague aesthetic judgement.

Use simple task-path budgets.

Recommended default targets:

```text
COMMON ACTION
≤ 1 primary interaction after context is established

CONTEXT CHANGE
≤ 2–3 deliberate interactions

DEEP INSPECTION
predictable path with no manual ID copying

RECOVERY
must not require restarting the whole task
```

These are product targets, not universal HCI laws.

---

## 21.1 Consequential interaction contracts

Every consequential/state-changing operation makes status and effect legible.

Lifecycle vocabulary:

```text
IDLE · READY · QUEUED · RUNNING · WAITING · BLOCKED
SUCCEEDED · FAILED · CANCELED · RECOVERING · STALE
DEGRADED · OFFLINE · PARTIAL · UNKNOWN
```

Action contract:

```text
constraint → preview → confirmation only when needed → commit → verify
```

Every consequential action receives timely, local, interpretable feedback or an explicit no-op explanation.

Every important failure exposes:

```text
WHAT FAILED
WHY / BEST AVAILABLE CAUSE
WHAT REMAINS INTACT
WHAT CAN BE DONE NOW
WHETHER SEMANTIC EFFECT IS KNOWN
RETRY / UNDO / BACK / RESET / EXPORT / RECONCILE where applicable
```

Never hide actionable diagnostics behind a generic error.

# 22. Visual system: preserve discipline, change the semantic language

## 22.1 Current strengths

The existing token architecture is one of the better parts of the implementation.

Preserve:

```text
primitives
→ semantic tokens
→ component states
→ composition
```

and avoid raw values in product code.

## 22.3 Spatial, Gestalt and density grammar

Use:

```text
proximity
similarity
continuity
common region
figure/ground
```

Rules:

```text
related items closer than unrelated items
component internals tighter than section boundaries
meaningful ownership gets meaningful boundaries
whitespace is structural information
stable positions support recognition and expert motor memory
```

Starting spacing scale is tunable, not a law:

```text
optical: 2–4
component: 8–16
section: 24–32
major: 40–64+
```

Density is task-dependent:

```text
reading: low/medium
authoring/chat: medium
data/diagnostics: high + strong hierarchy
expert configuration: high + progressive disclosure
```

The objective is correct perception, location and manipulation for the task, not maximum information per pixel.

## 22.2 Current weakness

The present visual language is technically coherent but still reads as a generic dark AI/developer application.

The audit notes that the theme is a Catppuccin-Mocha-derived dark system with good contrast discipline but little CanonSim-specific semantic identity. fileciteturn1file0L93-L99

The solution is not decoration.

Do not solve identity by adding:

```text
fantasy ornaments
glowing magic UI
parchment everywhere
ornamental borders
generic game HUD effects
```

Use semantic identity through:

```text
typography
geometry
composition
iconography
timeline grammar
evidence marks
selection treatment
state notation
graphic rhythm
```

---

# 23. Two-layer visual identity

Separate:

### Workbench chrome

```text
quiet
precise
instrument-like
restrained
low-noise
high legibility
```

### CanonSim world presentation

```text
graphic
material
distinctive
strong silhouettes
deterministic
illustrated
```

They may share:

```text
typography logic
spacing
selection/focus grammar
semantic status grammar
```

They should not necessarily share ornamental treatment.

---

# 24. Accent-color policy

Do not assume the answer to semantic overload is "add more colors".

The current accent is used for several roles such as:

```text
interactive affordance
live / generating
focus
selected navigation
```

The actual issue is:

```text
single visual channel
→ too many semantic roles
```

First disambiguate with:

```text
shape
weight
pattern
iconography
line style
position
motion
```

Only introduce additional semantic colors when those roles truly require them and contrast/accessibility remains valid.

Target:

```text
no status rainbow
no color-only semantics
```

---

# 25. Surface grammar: avoid card-driven UI

The visual law should prefer:

```text
surface
divider
row
field
lane
timeline
inspector
evidence strip
```

over:

```text
card inside card inside card
```

The current implementation uses many `PanelContainer`-based surfaces, including patterns conceptually named as model/message cards. This is the concrete implementation area that should be reconciled with the v5.2 prohibition on "boxed-everything".

The target is not "zero panels".

The target is:

```text
containers exist because they establish semantic grouping,
not because every piece of information needs a rounded box.
```

---

# 26. Token system expansion

In addition to colors, spacing, typography, and styleboxes, define semantic dimensions for:

```text
CONTROL_HEIGHT_S
CONTROL_HEIGHT_M
CONTROL_HEIGHT_L

HIT_TARGET_MIN

ICON_SIZE_S
ICON_SIZE_M
ICON_SIZE_L

RADIUS_S
RADIUS_M
RADIUS_L

MOTION_FAST
MOTION_STANDARD
MOTION_SLOW

FOCUS_RING_WIDTH

DIVIDER_THICKNESS
```

Do not scatter raw dimensions such as button heights or motion durations throughout surface code.

This is especially important for:

```text
DPI
compact mode
accessibility
responsive layout
visual tuning
```

---

# 27. Typography

Define one explicit typography contract:

```text
UI family
prose family
monospace family
fallback chain
weight hierarchy
numeric treatment
tabular number treatment
code/log treatment
Cyrillic support
```

Important:

```text
font metrics are part of layout,
not an afterthought.
```

Never design fixed widths from English labels alone.

---

# 28. Truncation policy

`clip_text` is dangerous on critical informational content.

Never silently truncate:

```text
errors
diagnostics
effective state
model identity
result identity
provenance
important status
```

Prefer:

```text
wrap
expand
tooltip
inspector
copy action
detail view
```

Truncation may be used for non-critical decorative or repeated text only.

---

# 29. Settings UX model

Settings must distinguish:

```text
EFFECTIVE
DRAFT
PENDING
OBSERVED
```

Example:

```text
CURRENT EFFECTIVE
8192

DRAFT
16384

AFTER APPLY / NEXT SPAWN
16384

LIVE PROCESS
still using 8192
```

This prevents the common AI-tool UX error where a control appears changed while the backend remains unchanged.

The Settings UI should explicitly represent the transition:

```text
edit
→ validate
→ apply
→ observe actual state
```

---

# 30. Chat ergonomics

The current chat needs to grow beyond:

```text
messages
input
send
stop
```

Required message-level affordances where applicable:

```text
copy
regenerate / retry
inspect metadata
recover failure
export
```

Chat output should support:

```text
text selection
code/log selection
clear error presentation
per-message identity
run/model provenance
```

The existing near-bottom scroll behavior should remain the reference.

---

## 30.1 AI-specific interaction contract

AI-driven surfaces must expose operational truth:

```text
USER INPUT
SYSTEM / DEVELOPER POLICY
MODEL INPUT
RESOLVED CONFIGURATION
MODEL OUTPUT
OBSERVED RUNTIME
DIAGNOSTICS
```

Preserve:

```text
requested ≠ accepted ≠ effective ≠ observed ≠ presented
```

Presets must be intent-named, inspectable, editable and versioned when persistence matters.

Keep failure classes distinct:

```text
user input
configuration incompatibility
backend/model
resource
transport
cancellation
internal failure
```

For expensive/state-changing commands distinguish:

```text
new command
vs
retry
```

If post-dispatch outcome is unknown after transport loss, surface the uncertainty rather than blindly retrying a potentially duplicated operation.

Where reproducibility matters, retain:

```text
model
backend
configuration
prompt
seed
run
relevant diagnostics
```

Never claim bitwise reproducibility without backend guarantees.

# 31. Focus and keyboard contract

Accessibility is not just a theme feature.

Define:

```text
focus order
focus entry
focus restoration
keyboard shortcuts
Escape behavior
cancel behavior
default action
selection movement
```

Recommended baseline:

```text
Escape
→ cancel / close / clear current transient action

Stop shortcut
→ stop active generation

surface switch
→ restore meaningful focus

reopen surface
→ restore last meaningful focus where valid
```

Focus must be task-aware.

Examples:

```text
Chat
→ composer

Models
→ search/filter/selected model

Settings
→ first or last meaningful field

Observatory
→ query or preserved selection
```

---

# 32. Accessibility contract

Minimum requirements:

```text
semantic accessible names
keyboard reachability
visible focus
logical tab order
screen-reader-compatible roles where supported
non-color state encoding
reduced motion
adequate hit targets
contrast
text scaling tolerance
```

Reference baseline:

```text
applicable WCAG 2.2
platform accessibility requirements
ISO 9241-171:2025 as the software-accessibility reference used by the v5.2 plan
```

Where supported, also require:

```text
state-change notification
screen-reader interoperability
forced/high-contrast behaviour
```

Accessibility defects that block task completion are functional defects.
The current audit found only limited tooltips, almost no keyboard shortcuts, no reduced-motion path, and no automated focus/accessibility tests. fileciteturn1file0L64-L78

Do not describe accessibility as "done" because focus style tokens exist.

---

# 33. Reduced-motion policy

Every motion effect must have a meaningful static equivalent.

Current examples needing policy:

```text
chat scroll tween
busy-dot pulse
future transitions / loaders
```

Define:

```text
motion enabled
motion reduced
```

Reduced mode should remove:

```text
non-essential pulsing
decorative motion
long transitions
```

while preserving essential state visibility.

---

# 34. Responsive / DPI / multi-monitor contract

The fixed 1440×900 baseline is not sufficient as a product contract.

Define supported viewport classes:

```text
SMALL
MEDIUM
LARGE
HIGH-DPI
ULTRAWIDE
```

For each verify:

```text
no critical clipping
critical actions reachable
critical text visible
focus remains reachable
inspector can collapse
navigation remains usable
context identity remains visible
```

Also define:

```text
minimum window size
stretch / scaling behavior
font scaling assumptions
multi-monitor restore behavior
DPI change behavior
```

---

# 35. Localization

Localization architecture should be introduced before surface count expands.

Use one translation boundary:

```text
_tr("chat.empty_state")
_tr("models.load_failed")
_tr("observatory.no_evidence")
```

not hard-coded user-facing strings across GDScript.

The relevant requirement is not merely "translate to Russian".

It is:

```text
localization-ready layout
+
Cyrillic-safe metrics
+
wrapping
+
button resizing
+
tooltip expansion
+
long-label testing
```

The audit confirms that localization infrastructure is currently absent despite explicit Cyrillic-safe requirements in the larger plan. fileciteturn1file0L81-L85

---

# 36. Component architecture

## 36.1 Do not preserve `shell.gd` as the long-term composition boundary

The current ~2200+ line imperative shell is acceptable as an early bootstrap but is a growing architectural risk.

The correct refactor is not:

```text
2200 lines
→ 100 tiny classes
```

and not:

```text
every widget
→ its own `.gd` + `.tscn`
```

Instead separate by semantic responsibility:

```text
shell / workspace controller
nav
chat
models
settings
observatory
shared controls
visual proof hooks
```

Create reusable components only when they have:

```text
reuse
or independent state
or independent test contract
or meaningful lifecycle
```

This avoids both a god-script and cargo-cult component proliferation.

---

# 37. Visual Scene IR integration

The Python-side Scene IR and scene building must eventually enter the actual Redot presentation path.

The present gap is:

```text
Scene IR exists
→ Redot does not consume it
```

The target is:

```text
canonical scene/read model
→ Visual Scene IR
→ bounded Redot scene generation/rendering
```

Do not invent a second parallel frontend scene authority.

The World view must remain a projection of authoritative/typed data.

---

## 37.1 Target graphics scope and presentation pipeline

The target visual runtime is:

```text
2D / 2.5D
```

not 3D-first.

Baseline:

```text
static/procedural background
+ composited world layers
+ sprite actors
+ animated sprite states
+ small transient effects
+ UI overlays
```

Do not make the following mandatory foundations:

```text
physics world
rigid bodies
ragdolls
large 3D terrain
ray tracing
heavy GI
volumetrics
massive skeletal animation
GPU-heavy world simulation
```

Later admission of such capabilities requires a separate runtime/dependency decision.

Presentation pipeline:

```text
CanonSim semantic/read products
→ Visual Scene IR
→ scene composition policy
→ asset selection / variation
→ presentation read model
→ Redot
→ Canvas / sprites / effects / UI
→ GPU
```

Keep distinct:

```text
semantic procedural generation
vs
visual procedural composition
```

CanonSim determines semantic existence, relevance and observability.

The compositor determines how a bounded subset is shown and cannot create canonical facts.

Deterministic composition may use:

```text
local semantic context + seed + style profile
+ asset vocabulary + placement constraints
+ visibility / observation rules
→ visual composition
```

# 38. World rendering principle

Do not let world art become a UI status channel.

World visuals may express:

```text
place
regime
material state
silhouette
structure
spatial relation
visible consequences
```

but semantic authority must remain available as explicit metadata/state.

The user must not need to infer:

```text
canonical
observed
derived
unknown
```

from artistic appearance.

---

## 38.1 Asset, camera, map and presentation-LOD rules

Asset pipeline:

```text
semantic specification
→ generation / acquisition
→ cleanup / normalization
→ validation
→ variant generation
→ atlas/spritesheet
→ asset manifest
→ content identity
→ runtime load
```

Filesystem location is not semantic asset identity. Distinguish:

```text
AssetId
content digest
location
version / compatibility
lifecycle
variant
source / derived / runtime artifact
presentation LOD
```

Camera layers:

```text
SEMANTIC FOCUS / TARGET
PRESENTATION CAMERA
USER CAMERA STATE
```

Camera changes must not mutate semantic focus or world state.

Useful presentation profiles:

```text
LOCAL_SCENE
MAP
CHARACTER_FOCUS
INSPECTION
DEBUG
```

Map levels:

```text
WORLD → REGIONAL → LOCAL → SCENE
```

Inventory, compass, journal/notes and notice-board surfaces are projections, not independent semantic models.

Visual LOD is distinct from semantic LOD:

```text
FULL → REDUCED → IMPOSTOR / COMPOSITE → ABSTRACT
```

Visual LOD must never alter semantic truth.

Static backgrounds should be cacheable. Dynamic actors/effects should update only when necessary.

## 39.0 Observatory analytical population scaling

Observatory "big data" means many runs, long histories and broad analytical populations, not distributed infrastructure by default.

Prefer:

```text
SMALL        JSONL + SQLite
MEDIUM       DuckDB over JSONL / SQLite exports
LARGE        Parquet + DuckDB
DISTRIBUTED  only after measured workload evidence justifies it
```

The frontend consumes bounded projections/read models; it must not materialise an entire analytical population into live Redot controls.

Canonical source data must remain sufficient to reconstruct required projections.

# 39. Bounded rendering

For large worlds and large histories:

```text
viewport
→ visible semantic subset
→ aggregation
→ culling
→ virtualization
```

Do not instantiate thousands of live Controls merely because the backend contains thousands of records.

This applies to:

```text
History
Observatory
timeline
tables
graph neighborhoods
world objects
```

---

## 39.1 Joint frontend / local-LLM performance contract

Benchmark the actual workload:

```text
Redot UI
+
large history
+
mostly static world
+
small animated-actor population
+
light effects
+
concurrent local LLM inference on the same GPU
```

Measure both:

```text
frontend alone
frontend + simultaneous inference
```

Required metrics:

```text
cold / warm startup
RAM idle / active
VRAM idle / active
CPU during streaming
GPU during scene/effects
frame-time p50 / p95 / p99
UI latency during streaming
history rendering cost
scene rebuild cost
asset load/reload cost
peak memory
stream-buffer size/update cadence
shutdown/reconnect behaviour
```

Budget categories:

```text
active/cache texture memory
asset count
active actors
active effects
atlas/texture size
scene rebuild frequency
materialised history
pending stream buffers
CPU frame budget
GPU frame budget
```

Boundedness requires:

```text
declared ceiling + measurement + degradation path
```

Do not solve every budget breach by growing caches.

# 40. History and analytical virtualization

The existing fixed message cap is a bootstrap measure, not a scalable history architecture.

Long-range UI must use:

```text
paged read model
+
viewport virtualization
+
stable identity
+
selection preservation
+
incremental loading
```

The same foundation should support both History and Observatory.

---

# 41. Dashboard syndrome prohibition

Add to the anti-pattern list:

```text
DASHBOARD SYNDROME
=
many simultaneously visible metrics,
charts and status cards,
with no primary question, focal selection,
analytical navigation, or next action.
```

A World Profile is not successful because it contains more graphs.

Successful composition is:

```text
QUESTION
→ PRIMARY DISCRIMINANT
→ PRIMARY VIEW
→ DETAIL
→ EVIDENCE
```

---

# 42. Context identity strip

Every high-consequence analytical surface should make current context legible.

Expose:

```text
pack
run
seed
tick / time window
model / inference context where relevant
observation profile
result revision
freshness
```

Do not permanently show all metadata.

Use progressive disclosure:

```text
compact identity strip
→ expandable context detail
```

---

# 43. Verification architecture

The frontend requires three distinct proof layers.

```text
STATIC UI PROOF
≠
RUNTIME UI PROOF
≠
TASK / HUMAN UX PROOF
```

## 43.1 Static proof

Can verify without Redot runtime:

```text
token usage
forbidden raw values
translation boundary
interactive control metadata
status-role mapping
contrast calculations
configuration invariants
component naming
surface registration
```

## 43.2 Runtime proof

Requires Redot:

```text
layout
focus
keyboard
responsive behavior
DPI
visual regression
scroll behavior
interaction states
accessibility tree
motion policy
```

## 43.3 Task proof

Must demonstrate:

```text
user can complete T1..T8
without hidden assumptions
without copying IDs manually
without false semantic implication
without unnecessary recovery cost
```

---

# 44. Verification matrix

Recommended automated/manual gate set:

| Gate | Verify |
|---|---|
| A | task validity / goal clarity |
| B | information architecture |
| C | interaction + state correctness |
| D | visual/token correctness |
| E | accessibility |
| F | performance / boundedness |
| G | empirical runtime validation |
| H | truth / provenance / epistemic correctness |
| I | agent-verifiability / maintainability |

Do not call a surface "complete" while major gates are merely undocumented.

The current audit concludes that C is comparatively strong, D is partially strong, while E/G/I are materially incomplete. fileciteturn1file0L103-L114

---

# 45. Proof infrastructure without Redot runtime

Where runtime Redot is unavailable:

```text
do not pretend runtime validation passed.
```

Instead split:

```text
verified statically
runtime-gated
manually verified
not verified
```

Static Python checks may still verify:

```text
WCAG contrast from theme values
token completeness
raw-value detection
localization coverage
control metadata coverage
viewport configuration presence
forbidden-pattern scans
```

This creates partial protection without fabricating runtime evidence.

---

# 46. Visual proof matrix

When Redot runtime is available, standardize deterministic captures for:

```text
SMALL viewport
MEDIUM viewport
LARGE viewport
HIGH-DPI equivalent
ULTRAWIDE equivalent
```

And task/state captures:

```text
empty
loading
ready
partial
stale
failed
selected
focused
disabled
compare
evidence
inspector
```

Visual regression must compare semantics, not merely pixels where nondeterministic rendering is expected.

---

# 47. Status bar policy

Do not permanently consume primary attention with engineering metadata.

Current elements such as:

```text
seam status
Redot version
internal proof state
```

are useful for diagnostics/assurance but should not necessarily dominate the normal task surface.

Main shell status should prioritize:

```text
connection
current run/context
active operation
unsaved changes
critical state
```

Developer/assurance metadata belongs in:

```text
Diagnostics
About
Assurance
```

unless currently actionable.

---

# 48. Iconography

Define a small semantic icon vocabulary:

```text
run
stop
pause
refresh
inspect
copy
search
filter
compare
timeline
relation
object
knowledge
warning
unknown
provenance
scope
lock
```

Rules:

```text
icon-only control
→ accessible name + tooltip

icon
≠
meaning by shape alone

do not create icon soup
```

---

# 49. Native vs custom controls

Use native OS affordances when they reduce friction:

```text
file selection
folder selection
window behavior
clipboard where appropriate
```

Use custom controls where CanonSim semantics require:

```text
evidence ladder
semantic timeline
compare alignment
world inspector
canonical status notation
```

Do not custom-build something merely to make it visually consistent.

---

## 49.1 Persistence, packaging and trust boundary

Keep distinct:

```text
application configuration
session state
chat/history
simulation checkpoint/cursor
visual cache
asset cache
UI-local state
```

Render/asset caches are rebuildable; canonical/persistent state is not a disposable render cache.

The user should see one product even when topology remains multi-process:

```text
Redot frontend
+
Python/application runtime
+
user data
```

Offline content tools may include:

```text
ComfyUI / Qwen Image
Blender headless
Pillow
atlas/validation tooling
```

They must not become runtime dependencies merely because they generate or validate content.

Every admitted runtime dependency, plugin, codec, importer and shipped asset requires an explicit licence/redistribution inventory.

Security/trust boundary:

```text
path ≠ command
import ≠ execution
model output ≠ authority
asset metadata ≠ executable code
UI command ≠ direct CanonSim mutation
external API/agent ≠ semantic/application bypass
```

Diagnostic/development surfaces must not create hidden data-exfiltration paths.

## 49.2 Drag/drop policy

Where drag/drop materially reduces pointer work, support it as an accelerator, never as the only route:

```text
drag/drop
+
equivalent keyboard/context-menu/action path
```

Candidate uses:

```text
model import
artifact → history/diagnostics
run → compare
entity → Observatory scope
```

Do not introduce drag/drop merely because the platform permits it.

# 50. Observatory implementation strategy

Do not jump directly from documentation to a full 1800-line Observatory implementation.

Build a vertical UX slice:

```text
nav entry
→ Observatory surface
→ empty state
→ World Question contract
→ scope
→ one selection
→ one primary read-only view
→ inspector
→ evidence strip
```

The purpose of this spike is to test:

```text
question grammar
selection
context
focus
drill-down
evidence
visual hierarchy
```

before full analytical backend coverage exists.

The current absence of any Observatory surface means this is now more important than polishing secondary shell surfaces indefinitely. The audit explicitly identifies Observatory as absent even as a stub while other surfaces are already being advanced. fileciteturn1file0L64-L78

---

# 51. Recommended Observatory first slice

Minimum viable analytical flow:

```text
1. Open Observatory
2. Establish current context
3. Enter / select World Question
4. Choose scope
5. Show one deterministic primary representation
6. Select one semantic object/event
7. Open inspector
8. Show evidence status
9. Navigate back without losing context
```

No need initially for:

```text
full causal graph
full map
full history
ensemble analytics
all overlays
```

The goal is to validate the interaction grammar, not to maximize feature count.

---

## 51.1 Observatory task scope

Primary task families:

```text
observe ensemble / trajectory / relation / object / regime
explain event / dependency / downstream consumer
search reachability / missing consumer
archaeologize a present blocker into verified historical residue
compare BASE vs PERTURBED futures
align a trajectory against a declared World Envelope
review calibration / research-rollout evidence
```

World Question state preserves:

```text
QUESTION
CLASS
TARGET
SCOPE
KNOWN
UNKNOWN
COMPETING HYPOTHESES
OBSERVABLES
PRIMARY DISCRIMINANT
EVIDENCE
MINIMAL CAUSAL SLICE
UNCERTAINTY
NEXT DISCRIMINATOR
DISPOSITION
```

A World Profile is a vector of observables, not a scalar quality score.

## 51.2 Usability evaluation and engineering metrics

Evaluation stack:

Validated subjective measures may be used when useful:

```text
SUS
UEQ / UEQ-S
NASA-TLX
```

NASA-TLX dimensions:

```text
mental demand
physical demand
temporal demand
performance
effort
frustration
```

These complement task evidence; they do not replace observed task completion and recovery behaviour.
```text
static/automated audit
→ expert heuristic review
→ cognitive walkthrough
→ task-based usability test
→ controlled comparison when a defined question exists
→ validated subjective scale when useful
→ instrumented behaviour when explicitly justified/privacy-safe
```

Track:

```text
effectiveness
efficiency
recovery
cognitive workload
temporal latency
state integrity
interaction integrity
memory / CPU / GPU / VRAM / frame-time quality
```

Track distributions, not only means.

For controlled comparisons:

```text
neutral naming
counterbalanced order
control learning/fatigue/order/carryover
predefined primary outcome
stable trace identity
```

Preserve:

```text
ASSIGNMENT ≠ REALISED DELTA
```

Do not infer equivalence from a non-significant result alone.

# 52. Implementation order

## P0 — normative foundation

```text
1. repair working-law/specification integrity
2. add accessibility / reduced-motion / localization / responsive minimums
3. define shared context model
4. define selection model
5. define focus/navigation model
6. define epistemic state grammar
7. define task/proof contracts
```

## P1 — Observatory interaction skeleton

```text
1. Observatory navigation entry
2. empty/read-only surface
3. World Question contract
4. context strip
5. query lifecycle
6. primary view
7. selection
8. inspector
9. evidence ladder
10. semantic breadcrumb
```

## P2 — existing frontend structural cleanup

```text
1. shell responsibility split
2. shared components
3. localization boundary
4. token expansion
5. critical-text truncation audit
6. keyboard shortcuts
7. focus restoration
8. viewport/min-size policy
```

## P3 — analytical depth

```text
1. timeline
2. compare
3. semantic zoom
4. cross-highlighting
5. archaeology
6. bounded graph
7. Evidence Capsules
8. persistent research contexts
```

## P4 — world presentation

```text
1. Visual Scene IR → Redot integration
2. deterministic world rendering
3. world visual identity
4. procedural/asset presentation
5. assurance/debug overlays
```

---

## 52.1 Acceptance benchmark

Representative acceptance should cover:

```text
Redot startup / packaging
custom UI + keyboard/focus/accessibility
Chat streaming + large history
Models/Inference controls + effective-state display
CanonSim placeholder world + deterministic Visual Scene IR
procedural props/actors + map/inventory interaction
assurance / observation views
asset load/reload + missing/stale degradation
backend loss → reconnect/cancellation truth
screenshot/headless regression
frontend alone vs frontend + concurrent local LLM
```

Required evidence includes, where applicable:

```text
runtime startup
shared application operations
reconnect/cancellation semantics
explicit CanonSim read-side seam
deterministic Scene IR fixture
bounded composition
visual regression
semantic-boundary enforcement
resource-budget measurements
concurrent-LLM benchmark
dependency/licence inventory
asset identity/provenance
```

## 52.0 Evidence classification

Use explicit proof states:

```text
STATIC_VERIFIED
RUNTIME_VERIFIED
MANUALLY_VERIFIED
TASK_VERIFIED
DEFERRED
NOT_VERIFIED
```

Runtime-unavailable evidence must never be represented as a passing runtime gate.

# 53. Explicit anti-patterns

Prohibit:

```text
second hidden frontend transport
second semantic authority
visual inference of truth
color-only status
status rainbow
generic dashboard syndrome
graph hairballs
card-everything
decorative motion as state
default Redot theme as product identity
unbounded Control-node rendering
silent truncation of critical information
hard-coded UI strings
flat navigation feature catalogs
component proliferation without responsibility
manual ID copying between analytical views
two unsynchronised comparison screens
fake runtime "passed" status when Redot did not execute
```

Also prohibit:

```text
"more panels" as the default answer to "more information"
```

---

# 54. Important negative corrections

The following conclusions should **not** be adopted too literally from earlier analysis:

### 54.1 "One accent color is insufficient"

Do not automatically add more accents.

Correct diagnosis:

```text
one visual channel currently carries too many semantic roles
```

First diversify semantic encoding through:

```text
shape
pattern
weight
iconography
position
line treatment
```

then consider more colors only if required.

### 54.2 "Every component should become `.gd` + `.tscn`"

Not required.

Use decomposition by:

```text
responsibility
state
reuse
testability
lifecycle
```

Avoid file proliferation for its own sake.

### 54.3 "Accessibility is zero"

Avoid absolute wording.

Correct engineering statement:

```text
accessibility implementation and verification are materially incomplete
relative to the normative specification.
```

### 54.4 "1 of 12 surfaces"

Useful as a scope warning, not a product KPI.

The important fact is:

```text
primary analytical/world value is not yet represented in the frontend.
```

### 54.5 "Only one real user"

Do not encode assumptions about user population that are not established by project evidence.

The defensible requirement is:

```text
Cyrillic-safe and localization-ready UI is explicitly required.
```

---

# 55. Agent decision rules

When implementing any frontend task, the agent must answer in this order:

```text
1. What user task is being solved?
2. What semantic state is authoritative?
3. What is the minimum information needed?
4. Which existing surface owns the task?
5. Is this a new surface or merely a new view?
6. What selection/focus/context behavior is required?
7. What epistemic states must be visible?
8. What is the smallest reusable component boundary?
9. Which tokens are required?
10. Which accessibility/localization/responsive requirements apply?
11. How will the change be statically verified?
12. How will it be runtime-verified if Redot is available?
13. How will the actual task be proven?
```

If the answer requires:

```text
new transport
new authority
new generic visualization abstraction
new global status color
new top-level surface
```

treat it as an architectural escalation, not a normal implementation detail.

---

# 56. Definition of Done for a frontend surface

A surface is not complete because it renders.

It is complete only when:

```text
task defined
+ IA defined
+ state model defined
+ interaction model defined
+ focus/keyboard path defined
+ token usage verified
+ critical text not silently clipped
+ accessibility path defined
+ responsive behavior defined
+ localization boundary respected
+ truth/evidence semantics explicit
+ boundedness respected
+ static proof passes
+ runtime proof passes when available
+ task proof exists
```

Any intentionally deferred item must be marked explicitly as:

```text
DEFERRED
```

not silently omitted.

---

# 57. Ultimate architecture summary

CanonSim Workbench should converge toward:

```text
                         CANONICAL / BACKEND STATE
                                   │
                                   ▼
                           TYPED READ MODELS
                                   │
                                   ▼
                        ANALYTICAL INTERACTION
                         ┌─────────┼─────────┐
                         │         │         │
                      CONTEXT   SELECTION  QUERY
                         │         │         │
                         └─────────┼─────────┘
                                   ▼
                            PRIMARY VIEW
                         ┌─────────┼──────────┐
                         │         │          │
                      Timeline   Table      Compare
                         │         │          │
                         └─────────┼──────────┘
                                   ▼
                               INSPECTOR
                                   │
                                   ▼
                         EVIDENCE / PROVENANCE
                                   │
                                   ▼
                         NEXT DISCRIMINATOR
                                   │
                                   ▼
                           TASK / RESULT CAPSULE
```

Visual presentation is downstream:

```text
semantic state
→ visual tokens
→ bounded scene/view representation
→ Redot
```

Never the reverse.

---

# 58. Final priorities

The highest-value correction is **not** "make the current UI prettier".

It is to establish the missing interaction foundation:

```text
SPECIFICATION INTEGRITY
        ↓
ANALYTICAL INTERACTION GRAMMAR
        ↓
SHARED CONTEXT + SELECTION + FOCUS
        ↓
EVIDENCE / EPISTEMIC GRAMMAR
        ↓
TASK / PROOF GRAMMAR
        ↓
VISUAL IMPLEMENTATION
```

The practical sequence should therefore be:

```text
repair working law
→ establish accessibility/localization/responsive baseline
→ introduce Observatory skeleton
→ validate selection/context/evidence grammar
→ decompose shell by responsibility
→ implement analytical views
→ connect Scene IR to Redot
→ refine distinctive CanonSim visual identity
```

Do not spend many iterations polishing a peripheral generic chat shell while the project's defining analytical surface remains absent.

The correct target is not:

```text
more screens
```

but:

```text
fewer intents
+
shared semantic interaction grammar
+
multiple truthful representations
+
reliable evidence navigation
```

---

# 59. Contradictions / disputes / resolution register

| Issue | Position A | Position B | Resolution |
|---|---|---|---|
| Accent color | One accent is too overloaded | Never add a second accent | Keep accent restrained; first distribute meaning across non-color channels; add colors only if semantically necessary |
| Component architecture | Split every UI piece into `.gd` + `.tscn` | Keep one monolithic shell | Split by semantic responsibility/state/reuse/testability; avoid both extremes |
| Observatory priority | Finish Chat/Models/Settings first | Observatory should jump forward | Build a small Observatory vertical slice early; continue only proven necessary peripheral work |
| Accessibility status | "Almost zero" | Theme tokens already support focus/contrast | State is materially incomplete in implementation and proof despite some good foundations |
| Specification size | One huge source is precise | Huge specs overload agents | Keep one authoritative normative source; maintain a compact routing law that references, rather than silently deletes, mandatory requirements |
| Graph centrality | Graph is the analytical centerpiece | Graph is too noisy | Use graph as a bounded contextual view; make timeline/table/diff/inspector primary |
| Visual identity | More decoration will make CanonSim distinctive | Keep generic functional UI | Build identity through semantic geometry, typography, iconography and notation; avoid ornamental overload |
| Current UI state | "Product is nearly there" | Core world/Observatory is absent | Treat current frontend as a useful infrastructure slice, not the completed product |
| Runtime testing | Static contracts are sufficient for now | Runtime proof is mandatory | Static proof is valuable but cannot substitute for runtime/task proof |
| Localization | Add it later | Add it before more surfaces | Establish translation boundary now; full language expansion can remain staged |
| Fixed viewport | 1440×900 is acceptable bootstrap | Full responsive system is required immediately | Keep baseline but define min-size/stretch/viewport matrix before surface count grows |
| Visual Scene IR | Backend placeholder can wait | It should drive UI immediately | Do not block initial Observatory interaction spike, but preserve one eventual semantic path into Redot; never build a second scene authority |

---

# 60. Non-negotiable invariants

```text
1. UI never becomes semantic authority.
2. Frontend never invents truth from appearance.
3. CANONICAL / OBSERVED / DERIVED / UNKNOWN remain distinct.
4. FACT / INFERENCE / HYPOTHESIS / PROPOSAL / UNKNOWN remain distinct.
5. Selection is shared semantic identity, not widget-local state.
6. Context is visible for high-consequence analytical work.
7. Compare uses synchronized semantic coordinates.
8. Graph remains bounded.
9. Critical information is never silently truncated.
10. Color is never the sole carrier of important state.
11. Accessibility is part of implementation, not documentation.
12. Localization is part of layout architecture, not post-hoc translation.
13. Responsive/DPI behavior is a contract, not an anecdotal success case.
14. Static proof does not masquerade as runtime proof.
15. Runtime proof does not masquerade as task proof.
16. New abstractions require semantic justification.
17. New top-level surfaces require intent justification.
18. Evidence and provenance remain reachable from analytical claims.
19. Results remain reopenable with sufficient context.
20. Every deliberately deferred requirement is explicitly marked DEFERRED.
```
