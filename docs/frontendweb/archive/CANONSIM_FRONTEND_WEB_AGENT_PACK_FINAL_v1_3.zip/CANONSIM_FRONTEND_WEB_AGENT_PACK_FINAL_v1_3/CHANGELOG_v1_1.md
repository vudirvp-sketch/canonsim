# Changelog — FINAL v1.1

## Why v1.1 exists

v1.0 was structurally sound, but comparison with the supplied active repository snapshot exposed a routing gap and several Workbench semantics that were stronger in the live repo than in the derived web contract.

v1.1 closes those gaps without changing the frontend stack decision.

## Added

### Active repository routing
`docs/ACTIVE_REPO_ROUTING.md` establishes the precedence:

```text
active repo binding law
> current implementation/tests
> derived web pack
> historical Workbench source
> Redot reference
```

It records the current repository checkpoint and identifies the live owner for frontend UX, visual system, application/runtime, Observatory, world presentation, inference control, topology, and SSI/risk concerns.

### Effective-state closure
`docs/EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md` adds explicit:

```text
REQUESTED
→ ACCEPTED / REJECTED
→ EFFECTIVE
→ OBSERVED
→ PRESENTED
```

This prevents widget values, optimistic clicks, labels, and transport success from being silently promoted to runtime truth.

### Model lifecycle
The pack now explicitly separates discovery, validation, selection, loading, loaded, active, failure and eviction/unloading states.

### Prompt/profile composition and reproduction
Material input composition, replay identity, and simulation-pack identity are now explicit frontend preservation contracts.

### Resource-pressure presentation
Where the application exposes admission evidence, the frontend preserves `ACCEPT`, `QUEUE`, `REJECT`, `EVICT`, and `RELOAD` distinctions rather than inventing a generic error state.

### Visual state/workflow discipline
The web contract now points directly at the active visual-system law: semantic containers, honest surface state matrices, and functional-first / owner-gated visual refinement.

### Adapter verification
Material frontend adapters are expected to verify capabilities/defaults/clamps/errors/cancellation/stream/UNKNOWN semantics rather than only parsing JSON.

### Snapshot provenance
`REPO_GROUND_TRUTH.md` now records the supplied repository HEAD, base commit, and dirty/untracked status so working-tree evidence cannot be confused with committed law.

## Corrected

- Fixed a duplicated gateway-boundary paragraph inherited by the decision document.
- Re-homed active-repository routing above historical V5.2/Redot source material.
- Tightened acceptance gates for effective state, model lifecycle, reproduction identity, resource admission, and adapter contracts.

## Intentionally not added

The pack does **not** import backend process management, persistence/CAS, Redot node/resource architecture, a browser-side execution engine, a generic event bus, or a new global state framework. Those remain owned by the existing application/runtime boundaries.

## Stack decision

Unchanged:

```text
React + TypeScript + Vite
Web / PWA-first
Tauri 2 optional
Redot frozen / archived
Visual Scene IR retained as renderer-neutral contract
```
