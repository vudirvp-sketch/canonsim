# CanonSim Frontend Web Agent Pack — FINAL v1.3

## Purpose
Self-contained, agent-oriented implementation pack for the active CanonSim frontend path.

## Normative entry point
`docs/00_FRONTEND_STACK_DECISION_v1_5.md` (content revision **v1.7**)

## Start here if building the first client
**`docs/SKELETON_ACCEPTANCE.md`** — four criteria only. Do not run the full acceptance matrix or V5.2 source tree until S0 is green.

## Agent read order
See `docs/AGENT_READ_ORDER.md` (S0 subset vs post-S0 full order).

## Active decision
React + TypeScript + Vite + Web/PWA-first. Tauri 2 optional. Redot frozen/archived.

## Architectural law
Active repo binding laws take precedence over this derived pack. CanonSim remains semantic authority. Python Workbench application/gateway remains the application boundary. Visual Scene IR remains renderer-neutral. The browser is an untrusted downstream presentation client.

## What v1.3 adds
- **Skeleton S0 gate** — walking client acceptance (POST/op, virtualized live Trajectory, multi-tab, load note); stops over-regulation.
- **Dual-read law** — LIVE `session.events` tail ≠ durable HISTORY via Observatory/logs/artifacts.
- **Connection budget / stream policy** — HTTP/1.1 limits, focused-tab default, failure class for budget exhaustion; no SSE in S0.
- **Tooling floor** — typecheck, dependency boundaries, runtime validation, virtualization proof, multi-tab smoke (post-S0).
- **Optional P1** — layout manifest, Capabilities/Config screen, schema-driven settings (`HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md`).

## What v1.2 added
Harness/Trajectory, browser multi-tab runtime, surface modules (see `CHANGELOG_v1_2.md`).

## Pack contents
- `docs/` — normative contracts including S0, stream/budget, optional config.
- `repo-ground-truth/` — pinned implementation snapshots (may reflect a dirty working tree; see REPO_GROUND_TRUTH).
- `source-workbench/` — historical derivation sources (not S0 reading list).
- `legacy-redot-reference/` — historical reference only.
- `checks/` — integrity manifest.

## Critical rules
- S0 before full matrix.
- Do not implement SSE/WebSocket before gateway contract + connection policy.
- Live tail ≠ durable history.
- Do not redesign the backend merely to make the frontend cleaner.
- Do not create a second execution engine, event bus, or truth authority in React.
- Do not port Cordis/DeepSeek Harness runtime; import quality bar only.
- Each browser tab is an independent gateway client; never promote browser storage to canon.
- Live repository remains authoritative over this pack’s snapshot.
