# Changelog — Frontend Web Agent Pack

## v1.2 (2026-09-28)

### Added
- `docs/HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md` — Trajectory surface, traceability axes, surface composability without a browser plugin kernel; explicit mapping from DeepSeek Harness *quality* to CanonSim *ownership*.
- `docs/BROWSER_RUNTIME_AND_SCALABILITY_CONTRACT.md` — multi-tab/process model, performance bounds, gateway client transport isolation, PWA/offline, multi-tab anti-patterns.
- `docs/SURFACE_MODULE_CONTRACT.md` — mount/ownership/extension rules for React surfaces.
- Acceptance matrix sections: Harness/Traceability, Browser runtime.
- Transfer matrix rows for Trajectory, surface modules, multi-tab, transport isolation, virtualization, PWA stale marking, harness-quality failure presentation.
- Model lifecycle UI affordance table in effective-state contract.
- Stack decision revision marker v1.6 + section 20b + expanded non-goals and final architecture box.

### Corrected / tightened
- Agent read order aligned with README and new contracts.
- Observatory contract: Trajectory as first-class primary view; multi-surface coordination without private buses.
- Seam contracts: transport-adapter isolation; multi-tab; surface modules; Trajectory ≠ second store.
- Effective-state: per-tab independence; forbidden collapse of tab local state to shared truth; verification case for two independent clients.
- Acceptance: clarified that React does not yet exist in the snapshot and this pack is the implementation contract; SSE not landed.
- README critical rules: no Cordis port; no storage-as-canon.

### Intentionally not added
- No Cordis/dsh dependency, no browser agent loop, no second event bus, no WebSocket implementation, no Electron, no mandatory global state framework, no Redot parity program.

### Stack decision
Unchanged product path:

```text
React + TypeScript + Vite
Web / PWA-first
Tauri 2 optional
Redot frozen / archived
Visual Scene IR retained as renderer-neutral contract
```

## v1.1
See prior `CHANGELOG_v1_1.md` for active-repo routing, effective-state, model lifecycle, resource pressure, adapter verification, snapshot provenance.
