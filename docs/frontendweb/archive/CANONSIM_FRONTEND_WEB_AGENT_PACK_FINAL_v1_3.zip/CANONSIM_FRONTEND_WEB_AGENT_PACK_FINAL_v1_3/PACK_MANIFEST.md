# Pack Manifest — CANONSIM_FRONTEND_WEB_AGENT_PACK_FINAL v1.3

## Identity
- Pack id: `CANONSIM_FRONTEND_WEB_AGENT_PACK_FINAL`
- Version: **v1.3**
- Stack decision content revision: **v1.7** (filename retained: `00_FRONTEND_STACK_DECISION_v1_5.md`)
- Date: 2026-09-28

## S0-first entry
- `docs/SKELETON_ACCEPTANCE.md`

## Normative docs
1. docs/00_FRONTEND_STACK_DECISION_v1_5.md
2. docs/SKELETON_ACCEPTANCE.md
3. docs/ACTIVE_REPO_ROUTING.md
4. docs/EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md
5. docs/HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md
6. docs/BROWSER_RUNTIME_AND_SCALABILITY_CONTRACT.md
7. docs/STREAM_AND_CONNECTION_BUDGET_CONTRACT.md
8. docs/SURFACE_MODULE_CONTRACT.md
9. docs/TRANSFER_MATRIX.md
10. docs/SEAM_CONTRACTS.md
11. docs/OBSERVATORY_UX_CONTRACT.md
12. docs/VISUAL_PROOF_CONTRACT.md
13. docs/ACCEPTANCE_MATRIX.md
14. docs/HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md (optional P1)
15. docs/REPO_GROUND_TRUTH.md

## Supporting
- docs/AGENT_READ_ORDER.md
- docs/SOURCE_CROSSWALK.md
- README.md
- CHANGELOG_v1_3.md
- CHANGELOG_v1_2.md
- CHANGELOG_v1_1.md
- checks/SHA256SUMS.txt
- checks/verify_pack.py

## Evidence trees
- repo-ground-truth/
- source-workbench/
- legacy-redot-reference/

## Integrity
`python checks/verify_pack.py` from pack root.
