#!/usr/bin/env python3
"""Verify FINAL CanonSim frontend agent pack integrity and required entrypoints."""
from __future__ import annotations

from hashlib import sha256
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
SUMS = ROOT / "checks" / "SHA256SUMS.txt"
REQUIRED = [
    "README.md",
    "PACK_MANIFEST.md",
    "CHANGELOG_v1_1.md",
    "CHANGELOG_v1_2.md",
    "CHANGELOG_v1_3.md",
    "docs/00_FRONTEND_STACK_DECISION_v1_5.md",
    "docs/SKELETON_ACCEPTANCE.md",
    "docs/ACTIVE_REPO_ROUTING.md",
    "docs/EFFECTIVE_STATE_AND_REPRODUCTION_CONTRACT.md",
    "docs/HARNESS_SURFACE_AND_TRACEABILITY_CONTRACT.md",
    "docs/BROWSER_RUNTIME_AND_SCALABILITY_CONTRACT.md",
    "docs/STREAM_AND_CONNECTION_BUDGET_CONTRACT.md",
    "docs/SURFACE_MODULE_CONTRACT.md",
    "docs/HARNESS_CONFIG_AND_LAYOUT_OPTIONAL.md",
    "docs/AGENT_READ_ORDER.md",
    "docs/TRANSFER_MATRIX.md",
    "docs/SEAM_CONTRACTS.md",
    "docs/OBSERVATORY_UX_CONTRACT.md",
    "docs/VISUAL_PROOF_CONTRACT.md",
    "docs/ACCEPTANCE_MATRIX.md",
    "docs/REPO_GROUND_TRUTH.md",
]


def digest(path: Path) -> str:
    h = sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def main() -> int:
    missing = [r for r in REQUIRED if not (ROOT / r).is_file()]
    if missing:
        print("MISSING required files:")
        for m in missing:
            print(f"  - {m}")
        return 1

    if not SUMS.is_file():
        print(f"MISSING checksum file: {SUMS}")
        return 1

    errors = 0
    checked = 0
    for line in SUMS.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) < 2:
            print(f"BAD SUMS line: {line!r}")
            errors += 1
            continue
        expected, rel = parts[0], parts[-1]
        path = ROOT / rel
        if not path.is_file():
            print(f"MISSING listed file: {rel}")
            errors += 1
            continue
        actual = digest(path)
        checked += 1
        if actual != expected:
            print(f"HASH MISMATCH: {rel}")
            print(f"  expected {expected}")
            print(f"  actual   {actual}")
            errors += 1

    if errors:
        print(f"FAIL: {errors} error(s), {checked} file(s) checked")
        return 1
    print(f"OK: {checked} file(s) checked, {len(REQUIRED)} required entrypoints present")
    return 0


if __name__ == "__main__":
    sys.exit(main())
