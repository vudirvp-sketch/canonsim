# Canonsim Worldbuilding Theory

## 0. Базовая мысль

**Мир — это не набор описаний.
Мир — это пространство причин, ограничений, субъектов, памяти и возможных историй.**

Для Canonsim это можно выразить так:

**World = Substrate + Time + Pressure + Actors + Culture + Memory + Consequence + Readability**

Или ещё точнее:

**Worldbuilding = проектирование пространства возможных историй.**

Worldbuilder не обязан заранее написать эти истории. Его задача — построить такие условия, при которых истории могут **естественно возникать из устройства мира**, а не извлекаться из заранее написанного сценария.

Это является естественным продолжением центральной архитектурной формулы проекта:

> Simulator produces facts.
> LLM produces meaning.
> The log stores canon.
> The mediator holds the boundary.

То есть worldbuilding в Canonsim состоит не столько в том, чтобы «написать мир», сколько в том, чтобы определить **что существует, что может происходить, почему оно происходит, кто это воспринимает и как это меняет дальнейшее пространство возможностей**.
[`VISION.md`](https://github.com/vudirvp-sketch/canonsim/blob/main/docs/VISION.md), [`BLUEPRINT.md`](https://github.com/vudirvp-sketch/canonsim/blob/main/docs/BLUEPRINT.md)

---

# 1. Мир должен существовать без игрока

Первый фундаментальный принцип:

**Игрок не является причиной существования мира.**

Мир должен:

* иметь прошлое до прихода игрока;
* продолжать жить вне внимания игрока;
* иметь собственные процессы;
* изменяться вследствие внутренних причин;
* порождать события, которые игрок не инициировал.

Это уже буквально присутствует в архитектуре через:

* pre-PC worldgen;
* history before play;
* macro-time;
* cold/warm/active LOD;
* autonomous NPC/group activity;
* factions;
* aggregate off-screen events;
* condensation при приближении игрока.

Игрок не «включает» мир.
Он **входит в уже идущую историю**.

Поэтому важная формула Canonsim:

**The player enters a world; the world does not enter the player.**

Это один из главных результатов линии Dwarf Fortress → Canonsim. При этом проект сознательно избегает копирования DF-монолита: история и глубина должны оставаться читаемыми, а не просто огромными. [`phases.md §5`](https://github.com/vudirvp-sketch/canonsim/blob/main/docs/blueprint/phases.md)

---

# 2. Мир — не энциклопедия, а причинная система

Статическое описание:

> «Здесь есть река, железо, торговцы и гарнизон»

почти ничего не говорит о мире.

Причинный вариант:

> «Железо добывается в холмах → его перевозят по реке → расстояние увеличивает стоимость → потеря каравана создаёт дефицит → дефицит меняет поведение торговцев → торговцы повышают страх → guild начинает действовать → действия guild меняют состояние рынка».

Вот это уже мир.

Поэтому одна из наиболее глубоких существующих формул проекта:

**Depth ≠ amount of content.
Depth ≈ meaningful intersections between primitives.**

Это L9 — **small alphabet, deep composition**.

Отсюда следует:

> Хороший worldbuilding не обязан добавлять всё больше сущностей.
> Он должен добиваться того, чтобы уже существующие сущности **начинали значимо взаимодействовать**.

Поэтому:

**10 систем, которые никак не соприкасаются = поверхностный мир.**

**6 систем, которые образуют сложную причинную сеть = потенциально глубокий мир.**

Именно это хорошо видно в triangle experiment world-2:

**fire → alarm → fear → knowledge → suspicion → faction ratio → faction action → further consequences**

Один исходный глагол начинает распространяться по нескольким независимым системам.

Здесь рождается очень важное определение:

**World depth = causal composability.**

---

# 3. Мир должен иметь «давление»

Одной причинности недостаточно.

История появляется, когда состояние мира находится под давлением.

Давление может быть:

* scarcity;
* fear;
* debt;
* grief;
* political tension;
* suspicion;
* weather;
* distance;
* time;
* resource shortage;
* social obligation;
* institutional conflict.

Поэтому мир удобнее мыслить не как набор объектов, а как:

**objects + pressures acting through them.**

В `Sarrow Vale` это уже очень хорошо видно:

* iron;
* river trade;
* garrison;
* old families;
* guild;
* fear;
* grievance;
* travel cost;
* seasonal change.

Из этого вырастает одна из самых полезных идей, уже закреплённых в research lineage проекта:

## Displacement

**Снижение давления в одной части системы не обязательно уничтожает давление. Оно может перенести его в другое место или отложить его во времени.**

То есть:

**stabilization = redistribution of pressure**

Это один из потенциально наиболее сильных принципов для будущих world packs.

Мир становится интересным, когда решения не закрывают проблему, а **перестраивают карту напряжений**.

---

# 4. У мира должны быть собственные субъекты

NPC — не декорация и не текстовый интерфейс.

Субъект должен иметь:

**cause → flaw → need → want → behavior**

Это уже практически зафиксировано в `spine` и AP-9/AP-8.

Например:

> Wilmot хочет восстановить фамильное имя.
> Ему нужно восстановить мельницу.
> Его flaw — grief answers every question first.
> Источник — гибель наследника и мельницы.

Тогда поведение субъекта становится не случайным набором реплик.

Получается:

**History → psychology → constraint → behavior → consequence**

Это и есть причина, по которой `spine` в проекте значительно важнее простого personality text.

---

# 5. Желание само по себе не создаёт персонажа

Гораздо важнее комбинация:

**Want + Need + Flaw + Cause**

Потому что:

* `want` говорит, куда субъект движется;
* `need` показывает, что ему действительно необходимо;
* `flaw` ограничивает способ движения;
* `cause` связывает всё это с историей.

Таким образом персонаж — это не «набор черт».

Он является:

**локальным причинным аттрактором мира.**

То есть определённые состояния мира естественным образом заставляют именно этого персонажа реагировать определённым образом.

---

# 6. Но персональность — только половина

Вторая половина — **culture**.

И здесь, возможно, у Canonsim уже сформировался наиболее интересный собственный worldbuilding-механизм.

В `province_pack` культура выражена через:

**name profile + vocabulary + prohibitions + members + history**

Например:

### Lowland

* flowing phonotactics;
* `sarrow`, `toll`, `waybill`, `weighbeam`, `tally`;
* shelter law.

### Hill

* clipped/hard phonotactics;
* `bloom`, `charcoal`, `wergeld`;
* wergeld memory.

Это важный принцип:

## Culture is not lore. Culture is constraint.

То есть культура становится реальной только тогда, когда она **меняет то, что люди говорят, помнят, называют, считают допустимым и делают**.

---

# 7. Особая ценность запретов

В проекте особенно сильна идея prohibition.

Не:

> «Эта культура получает +10 к торговле».

А:

> «Есть вещи, которые эта культура не может себе позволить сделать».

Это гораздо сильнее.

Потому что идентичность очень часто задаётся не возможностями, а **границами допустимого**.

Отсюда:

**Identity = preferred behaviors + forbidden behaviors + reasons**

То есть:

> «Мы такие»
> не менее важно, чем
> «мы не такие».

Это и есть полезная интерпретация `estrangement-as-data`.

---

# 8. Различие культуры должно происходить на нескольких уровнях одновременно

Один language set недостаточен.

Хорошая культура должна проявляться хотя бы через несколько из:

**Names
Vocabulary
Rituals
Prohibitions
Economics
Social relationships
Institutions
Historical memory
Aesthetic preferences
Interpretation of events**

Тогда возникает эффект:

> разные группы живут в одном физическом мире, но **по-разному понимают его**.

Это важнее простого «две расы с разными именами».

---

# 9. Мир имеет несколько истин одновременно

Это одна из наиболее оригинальных сторон Canonsim.

Есть:

### Objective truth

Что реально произошло.

### Perceived truth

Что субъект увидел.

### Known truth

Что субъект знает.

### Inferred truth

Что субъект вывел.

### Believed truth

Во что субъект верит.

### Narrated truth

Как это сейчас представлено игроку.

Отсюда:

**Один мир → множество внутренних моделей мира.**

Поэтому знание — не просто memory system.

Это **часть worldbuilding**.

---

# 10. Мир должен содержать не только события, но и память о событиях

Событие само по себе недостаточно.

Важна цепочка:

**event → perception → knowledge → interpretation → future behavior**

Например:

> мельница сгорела

не равно:

> Wilmot knows the mill burned

и не равно:

> Garrick believes the guild caused it

и не равно:

> Maren remembers what the fire cost her family

Это четыре разных worldbuilding-факта.

Поэтому хороший мир имеет не одну историю, а **слой историй для разных наблюдателей**.

---

# 11. Причинность должна быть записана, а не реконструирована

L7 — очень важная аксиома:

**Causality is recorded, not reconstructed.**

Смысл:

> мир не должен в последний момент придумывать «почему это случилось».

Причина должна появляться **в тот же момент, когда возникает событие**, а дальнейшие системы читают эту причинность.

Это особенно важно для worldbuilding, потому что именно причинность превращает:

**лore**

в

**history**.

---

# 12. История — это не список фактов

История становится worldbuilding только тогда, когда она продолжает действовать.

То есть:

**Past event → residue in present**

Например:

> feud happened

слишком абстрактно.

Но:

> feud → heir killed → family debt → grievance → prohibition → distrust → faction behavior

уже делает прошлое частью текущего мира.

Поэтому хорошая история должна оставлять:

**residue.**

---

# 13. Residue — один из центральных объектов worldbuilding

После события в мире что-то должно остаться:

* изменённое состояние;
* потеря;
* долг;
* знание;
* шрам;
* слух;
* запрет;
* изменение отношений;
* разрушенный объект;
* политическое последствие;
* изменение маршрута;
* изменение цены.

Это позволяет определить:

**World history = accumulation of meaningful residues.**

А не:

**World history = archive of old events.**

---

# 14. Отсюда возникает важная связь с Курвицем

Курвиц говорит про:

* humor;
* heartbreak;
* autobiography;
* names;
* cultural references;
* weird specificity.

Canonsim добавляет к этому механизм:

**Чтобы мир был человеческим, человеческий смысл должен иметь место, куда приземлиться.**

Например:

> heartbreak

должен иметь:

**cause → relationship → loss → state → memory → future behavior**

Тогда трагедия становится частью мира, а не текстовым эпитетом.

---

# 15. Хороший мир должен позволять рассказывать множество типов историй

Это, пожалуй, самый важный принцип Курвица, который стоит перенести в Canonsim.

Необходимо тестировать не только:

> работает ли adventure?

а:

> может ли тот же мир рассказать разные классы историй?

Например:

**Adventure**

Куда идти?

**Mystery**

Что произошло?

**Political story**

Кто заинтересован в том, чтобы это произошло?

**Romance**

Почему два человека тянутся или не могут быть вместе?

**Tragedy**

Почему потеря становится неизбежной?

**Comedy**

Можно ли шутить внутри собственной логики мира?

**Biography**

Можем ли мы прожить в этом мире жизнь одного человека?

Последний тест особенно сильный.

---

# 16. Biography test

Условный «ultimate worldbuilding test»:

**можно ли рассказать жизнь человека от рождения до смерти, не покидая логики этого мира?**

Тогда внезапно оказываются нужны:

* семья;
* профессия;
* соседство;
* образование;
* деньги;
* жильё;
* культура;
* повседневные места;
* отношения;
* политика;
* сезонность;
* социальная мобильность;
* изменение статуса;
* старение;
* смерть;
* память окружающих.

Это позволяет проверить, существует ли:

**world outside the adventure plot.**

---

# 17. Отсюда следует принцип MESO

У Canonsim уже достаточно сильны:

### MICRO

NPC, object, event.

### MACRO

region, faction, economy, history, climate.

Но между ними должен постоянно развиваться:

# MESO

Именно meso делает мир обитаемым.

Это:

* семья;
* guild;
* inn;
* workshop;
* market;
* school;
* shrine;
* neighborhood;
* local institution;
* profession;
* festival;
* bureaucracy;
* caravan;
* household;
* local custom.

Именно meso отвечает на вопрос:

> **как macro-система становится частью повседневной жизни человека?**

В `Sarrow Vale` этот слой уже начинает формироваться через:

**market + keep + weir + crofts + manor + road + fair + guild + families + garrison.**

Это направление я бы считал одним из естественных продолжений world-2.

---

# 18. География должна быть причинной

Canonsim уже очень правильно делает это через `travel`.

География не просто:

> «вот река».

А:

**river → route → distance → travel time → cost → exposure → scarcity → behavior**

То есть:

**Geography is mechanics.**

Это принципиально отличает worldbuilding от картографии.

Хорошая карта не просто выглядит убедительно.

Она **меняет поведение мира**.

---

# 19. И поэтому topology важнее visual realism

Из пространственной архитектуры проекта следует ещё один принцип:

**Representational realism is optional. Causal realism is not.**

Не обязательно моделировать:

* 3D;
* voxels;
* физику;
* каждый метр пространства.

Важно моделировать:

* что с чем связано;
* куда можно попасть;
* сколько это стоит;
* что находится между;
* как меняется доступность;
* как topology влияет на последствия.

Именно поэтому graph of scales работает лучше «симуляции всего пространства».

---

# 20. LOD — не оптимизация, а часть ontology мира

Это тоже необычная мысль Canonsim.

LOD здесь означает не только:

> меньше деталей ради performance.

Он говорит:

> разные масштабы мира **действительно существуют как разные способы его рассмотрения**.

Например:

### Cold

population count.

### Warm

group-level activity.

### Active

individual entities.

### Reader

present scene.

Это естественно соответствует:

**Population → group → individual → experience**

Поэтому LOD можно понимать как:

**масштаб существования, а не только масштаб рендеринга.**

---

# 21. Lazy generation тоже является worldbuilding

Lazy generation здесь не только оптимизация.

Она означает:

> неизвестная деталь не обязана существовать как fully materialized object до момента взаимодействия с ней.

Но после meaningful observation или promotion она получает устойчивость.

Получается:

**potential world → observed world → materialized canon**

Это довольно сильная онтологическая модель.

Мир как бы содержит:

**не только вещи,
но и пространство потенциальных вещей.**

---

# 22. Naming — это не косметика

Здесь Курвиц прекрасно дополняет Canonsim.

Уже существует name generator:

**culture → phonotactic profile → generated name**

Но более общий принцип сильнее:

> **Naming is one of the cheapest ways to establish ontological specificity.**

Имя показывает:

* к какому языку относится объект;
* из какой культуры он пришёл;
* какой у мира исторический фон;
* насколько он отличается от читателя;
* какие культурные ассоциации он вызывает.

Поэтому name generation — не utility.

Это **world identity layer**.

---

# 23. Но generated names ≠ world identity

Здесь важно не переоценить procedural generation.

Случайные:

> Sathranthaem
> Drist
> Wathru

ещё не создают культуру.

Они создают сигнал культуры.

Культура появляется, когда эти имена сочетаются с:

* vocabulary;
* rituals;
* prohibitions;
* institutions;
* history;
* behavior.

Поэтому:

**name → hint**

**name + context → culture**

---

# 24. «Негативное пространство» — полноценный инструмент

Уже существующая идея `negative space` заслуживает повышения статуса.

Мир определяется не только тем, что в нём есть.

Но и:

**что в нём отсутствует.**

Например:

* нет магии;
* нет рабства;
* нет океанской торговли;
* нет сильной центральной власти;
* нет письменных контрактов;
* нет института церкви;
* нет определённого технологического уровня.

Особенно важно:

**absence must have consequences.**

Если в мире нет X, нужно спросить:

> что стало возможным именно потому, что X отсутствует?

И наоборот:

> какие институты появились для компенсации этого отсутствия?

---

# 25. Канон, симуляция и смысл — разные вещи

Одно из важнейших архитектурных следствий:

**Fact ≠ Meaning.**

Например:

> «grain price increased 20%»

— факт.

Но:

> «the market feels poorer»

— интерпретация.

А:

> «Maren feels the market slipping out of her hands»

— уже субъективная человеческая трактовка.

И:

> «everyone remembers this as the winter that broke Malby»

— культурная память.

Таким образом pipeline:

**fact → interpretation → meaning → narrative**

а не:

**LLM invents fact → prose pretends it happened.**

Это, пожалуй, и есть главное отличие Canonsim от обычного AI-RP.

---

# 26. Хороший worldbuilding должен давать миру «reader»

Здесь очень полезен новый Reader Law из intake-27:

**event with zero read surfaces is functionally dead.**

Следовательно:

> Не всякая внутренняя сложность мира превращается в worldbuilding experience.

Событие становится частью художественного мира, только когда у него существует путь:

**event → observer / memory / system / artifact / chronicle / narrative**

То есть:

**Worldbuilding is not only production of state. It is production of legible consequences.**

---

# 27. Но legibility не должна означать explanation

Это важное ограничение.

Нельзя просто написать:

> «The guild is upset because the player burned the mill.»

Это превращает simulation в exposition.

Лучше:

**burn → alarm → fear → faction response → changed behavior**

и читатель сам собирает:

> «а, поэтому guild начал бояться».

Отсюда:

## Good worldbuilding creates recoverable causality.

Игрок должен иметь возможность **ретроспективно реконструировать историю**, но не потому, что narrator её объяснил, а потому что мир оставил достаточно следов.

---

# 28. Worldbuilding therefore works through residue

Можно построить почти универсальную формулу:

**Event
→ immediate observable
→ state change
→ knowledge change
→ social response
→ residue
→ future option space**

И именно последнее особенно важно.

Событие должно менять не только настоящее.

Оно должно менять:

# **что теперь может произойти.**

---

# 29. Отсюда формула настоящей глубины

Не:

> сколько событий может произойти?

А:

> **насколько предыдущие события изменяют множество будущих возможностей?**

Можно назвать это:

## Causal Reach

У события есть causal reach, если оно меняет:

* состояние;
* знания;
* отношения;
* маршруты;
* доступность;
* поведение;
* цены;
* будущие события.

Поэтому маленький event может иметь огромный worldbuilding value.

Например:

> broken waybill

формально маленькая деталь.

Но если он ведёт к:

> suspicion → inspection → refusal → reputation → lost route → scarcity → faction reaction

то это уже важный элемент мира.

---

# 30. Именно поэтому Canonsim не должен измерять «количество лора»

Гораздо полезнее спрашивать:

### Does this fact have a reader?

### Does it have a cause?

### Does it have a consequence?

### Does it alter future options?

### Does someone remember it?

### Does someone interpret it differently?

### Does it interact with another primitive?

Это гораздо более содержательная метрика worldbuilding.

---

# 31. Мир должен иметь внутренние шутки

Здесь начинается зона Курвица, которой проект пока уделяет меньше внимания.

Хороший мир должен позволять:

**humor to emerge from its own references.**

Не:

> в мире есть смешная реплика.

А:

> люди используют его собственные культурные категории, чтобы шутить друг над другом.

То есть:

**world → shared concepts → jokes**

Признак зрелой культуры:

> жители могут смеяться, используя **не наши**, а свои культурные точки отсчёта.

---

# 32. Мир должен выдерживать heartbreak

Аналогично:

**world must have a place for loss.**

Это означает, что потеря должна:

* быть возможной;
* быть необратимой;
* иметь последствия;
* быть воспринятой;
* изменить отношения;
* оставить память;
* менять будущее.

У Canonsim механическая база для этого уже есть:

**irreversibility + causality + knowledge + residue.**

Следующий шаг — авторский.

---

# 33. Worldbuilding = constraints + affordances

Это ещё одна полезная формула.

Каждый хороший мир должен определять одновременно:

### Affordances

Что здесь возможно?

### Constraints

Что здесь невозможно?

### Costs

Что нужно заплатить?

### Consequences

Что произойдёт после?

### Meanings

Как разные люди это интерпретируют?

Получаем:

**World = possibility space shaped by constraints and costs.**

---

# 34. Поэтому культура, экономика и политика должны быть не отдельными системами

Если они существуют изолированно, мир распадается на subsystems.

В хорошем worldbuilding:

**economy ↔ politics ↔ culture ↔ psychology ↔ geography ↔ history**

Для `Sarrow Vale` уже намечено:

**iron ↔ river ↔ market ↔ guild ↔ garrison ↔ old families ↔ feud ↔ culture**

И вот эта связность значительно важнее количества деталей.

---

# 35. «One resource» не обязательно плохо

Очень хороший вывод из res-1:

Проблема не в наличии одного focal resource.

Проблема — когда ресурс превращается в единственную ось мира.

Правильная форма:

**focal resource + ordinary flows + sinks + institutions + human consequences**

То есть:

> один ресурс может быть ядром, если вокруг него существует достаточно разных человеческих отношений.

---

# 36. Хороший world pack поэтому должен иметь «pillar»

World pack не должен пытаться объяснить всё.

Он должен выбрать:

**что здесь особенно важно?**

Например для Sarrow Vale:

* river artery;
* iron;
* feud;
* three factions;
* two cultures;
* grim asymmetry;
* seasonal trade.

Это можно назвать:

# **World Pillar**

Потом каждое новое authored element должно так или иначе усиливать хотя бы один pillar.

---

# 37. Но pillars не должны становиться железной дорогой

Это важная оговорка.

Поскольку проект построен вокруг simulation, pillar:

**не должен становиться script.**

Он должен быть:

> **pressure / vocabulary / constraint / tendency**

а не:

> **предписанной последовательностью событий.**

То есть:

**pillar creates probability landscape, not plot.**

---

# 38. Worldbuilding therefore has two authoring modes

### Structural authoring

Определить:

* entities;
* rules;
* relationships;
* resources;
* constraints;
* culture;
* history;
* vocabulary;
* hooks.

### Experiential authoring

Определить:

* what feels strange;
* what feels human;
* what feels funny;
* what feels tragic;
* what the player is expected to notice;
* what remains mysterious.

Первое уже сильно развито.

Второе — следующий большой frontier.

---

# 39. Поэтому я бы выделил три уровня authored world

## Level A — Mechanics

Что может произойти.

## Level B — Meaning

Почему это имеет значение именно здесь.

## Level C — Voice / atmosphere

Как этот мир говорит сам о себе.

Сейчас Canonsim очень силён на A, уже заметно развивается на B, а C в большой степени оставляется narrator'у.

В перспективе правильнее:

> narrator генерирует expression,
> pack задаёт cultural constraints of expression.

---

# 40. Это позволяет переосмыслить LLM

LLM не должен быть worldbuilder-in-chief.

Он:

**не создаёт онтологию мира.**

Но он может:

* выбирать формулировки;
* соединять factual residue;
* создавать локальную texture;
* раскрывать культурный смысл;
* придавать голос;
* показывать perception.

То есть:

**Simulation = what is true.
Pack = what kind of world this is.
LLM = how this truth is experienced.**

---

# 41. И наконец: «хороший мир» в Canonsim

Можно дать достаточно точное определение:

> **A good Canonsim world is a bounded, culturally specific, causally coherent possibility space whose internal pressures generate divergent consequences, whose actors possess asymmetric goals and knowledge, whose history leaves persistent residue, and whose complexity remains legible through human-scale experience.**

По-русски:

> **Хороший мир Canonsim — это ограниченное и культурно специфичное пространство возможностей, где причинно связанные силы сталкиваются через субъектов с различными интересами и знаниями, прошлое оставляет устойчивые следы, а возникающая сложность остаётся доступной человеческому восприятию.**

---

# 42. Сжатая формула

Вся теория может быть сжата до:

**WORLD =**
**PLACE**
× **TIME**
× **PRESSURE**
× **ACTORS**
× **CULTURE**
× **KNOWLEDGE**
× **CONSEQUENCE**
× **MEANING**

А worldbuilding pipeline:

**Author Pillars**
↓
**Generated Substrate**
↓
**History**
↓
**Actors + Institutions**
↓
**Pressures**
↓
**Interactions**
↓
**Consequences**
↓
**Knowledge / Memory**
↓
**Residue**
↓
**New Possibility Space**
↓
**Human-readable Experience**

То есть:

# **Worldbuilding is the engineering of consequential possibility.**

---

# 43. Практический pipeline для world pack

Из всей этой теории я бы вывел такой авторский workflow:

### 1. Choose the Pillars

Что делает именно этот мир особенным?

### 2. Define the Absences

Чего в нём нет — и как это изменило его?

### 3. Define the Physical Substrate

Где находятся ключевые nodes и какие связи между ними причинно значимы?

### 4. Define the Historical Residue

Что происходило до начала игры и какие следы это оставило?

### 5. Define Actors

Кто чего хочет, что ему нужно и что мешает?

### 6. Define Cultures

Какие названия, слова, привычки и запреты делают группы отличимыми?

### 7. Define Pressures

Что находится под дефицитом, угрозой, долгом, страхом, временем?

### 8. Define Institutions / Meso

Где ordinary life встречается с macro forces?

### 9. Define Couplings

Какие системы должны реально влиять друг на друга?

### 10. Define Readers

Кто и через какой surface сможет увидеть последствия?

### 11. Run the Counterfactual

Что изменится, если player делает X?

### 12. Run the Biography Test

Можно ли прожить здесь человеческую жизнь?

### 13. Run the Genre Tests

Adventure / Mystery / Romance / Tragedy / Comedy / Biography.

### 14. Run the Compression Test

Можно ли убрать половину элементов, не разрушив мир?

Если да — вероятно, половина была декоративной.

---

# 44. И здесь появляется, возможно, самый полезный критерий

**Не спрашивать: «насколько подробно описан мир?»**

Спрашивать:

> **«Сколько разных человеческих историй может честно родиться из его устройства?»**

И ещё сильнее:

> **«Сколько из этих историй можно объяснить не сценаристом, а самим устройством мира?»**

Это уже очень хороший критерий именно для Canonsim.

---

# 45. Где здесь Курвиц

Курвиц добавляет к Canonsim не новую механику, а **missing human dimension**.

Из него особенно ценны:

**Names**
→ культурная specificity

**Obscure references**
→ нестандартная cultural vocabulary

**Negative space**
→ identity by absence

**Humor**
→ возможность жить в мире, а не только решать его проблемы

**Heartbreak**
→ способность мира выдерживать человеческую потерю

**Autobiography**
→ проверка everyday life

**Long maturation**
→ world должен накапливать внутренние связи до использования

В то же время Canonsim даёт Курвицевскому worldbuilding недостающую формализацию:

**causality

* persistence
* knowledge
* simulation
* consequence
* asymmetric perception
* autonomous life**

И получается очень сильная комбинация:

# **Kurvitz asks: “Can people live meaningful lives here?”**

# **Canonsim asks: “Can the world itself generate the conditions for those lives?”**

Вот на этом стыке, мне кажется, и находится наиболее интересная собственная идея проекта.

---

# 46. Самая компактная кристаллизация

Если от всего текста оставить только один абзац:

> **Canonsim treats worldbuilding as the construction of a causal possibility space rather than a lore corpus. A world exists before and beyond the player; geography, history, scarcity, institutions, cultures, actors and asymmetric knowledge form a network of pressures; events leave durable residue that changes future possibilities; cultures are expressed through names, vocabulary, prohibitions and behavior rather than exposition; the simulation produces truth, while narrative exposes meaning. World depth comes from meaningful composition between a small number of primitives, and world quality is measured not by content volume but by the number, variety and human legibility of stories that can emerge from the same substrate.**

И, пожалуй, ещё одна строка, которая может стать девизом именно **worldbuilding-части** Canonsim:

> **Не придумывай больше вещей. Придумывай больше последствий.**

А для культурной части:

> **Не описывай, чем люди являются. Определи, что для них возможно, невозможно, свято, смешно и болезненно.**
